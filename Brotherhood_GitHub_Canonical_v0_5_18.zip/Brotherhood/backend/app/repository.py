from __future__ import annotations

import base64
import hashlib
import json
import os
from datetime import datetime, timezone
from typing import Iterable
from uuid import UUID

from .database import connection, is_database_configured
from .models import (
    AssessmentDimensionResult,
    AssessmentResultRecord,
    AssessmentResultUpsert,
    CalibrationConsentRecord,
    CalibrationConsentUpsert,
    CalibrationPilotStatus,
    AuthProvider,
    Community,
    CommunityCreate,
    CommunityKind,
    CompatibilityRequest,
    FriendshipOutcomeRecord,
    FriendshipOutcomeUpsert,
    IdentityResolveRequest,
    IdentityResolveResponse,
    IncidentStatus,
    MessageCreate,
    MessageRecord,
    AppVersionManifest, AttachmentKind, AttachmentPayload, ChatAttachmentRecord, ChatMessageCreate, ChatMessageEdit, ChatMessageRecord, MessageReactionRecord,
    ConversationSummary, ConversationType, ConversationMemberRecord, DeviceKeyRecord, DeviceKeyUpsert, EncryptionMode, GroupConversationCreate, PushTokenUpsert,
    NumerologyProfile,
    Person,
    Personality32,
    ProfileAvatarRecord,
    ProfileAvatarUpsert,
    ProfileRecord,
    ProfileUpsert,
    TrustIncident,
    TrustIncidentCreate,
    TrustSummary,
)
from .services import compatibility
from .quality_matching import aggregate_latent, parse_desired_qualities, positive_projection, quality_fit
from .calibration_pilot import PilotEnrollmentError, pilot_config, validated_invite_digest
from . import storage as memory


def gid(value: int) -> str:
    if value < 1 or value > 9_999_999_999:
        raise ValueError("global_id outside canonical range")
    return f"{value:010d}"


def storage_mode() -> str:
    configured = os.getenv("BROTHERHOOD_STORAGE_MODE", "auto").strip().lower()
    if configured not in {"auto", "postgres", "memory"}:
        raise RuntimeError("BROTHERHOOD_STORAGE_MODE must be auto, postgres or memory")
    if configured == "memory":
        return "memory"
    if configured == "postgres":
        if not is_database_configured():
            raise RuntimeError("BROTHERHOOD_STORAGE_MODE=postgres but DATABASE_URL is missing")
        return "postgres"
    return "postgres" if is_database_configured() else "memory"


def production_storage_ready() -> bool:
    return storage_mode() == "postgres"


def _secret(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"{name} is required for PostgreSQL encrypted fields")
    return value


def resolve_identity(payload: IdentityResolveRequest) -> IdentityResolveResponse:
    if storage_mode() == "memory":
        return memory.resolve_identity(payload)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT global_id FROM user_identities WHERE provider=%s::auth_provider AND tenant=%s AND provider_subject=%s",
                (payload.provider.value, payload.tenant, payload.provider_subject),
            )
            row = cur.fetchone()
            if row:
                return IdentityResolveResponse(global_id=row[0], global_id_display=gid(row[0]), created=False)
            cur.execute("INSERT INTO users DEFAULT VALUES RETURNING global_id")
            global_id = cur.fetchone()[0]
            cur.execute(
                """
                INSERT INTO user_identities(global_id, provider, tenant, provider_subject, verified_at)
                VALUES (%s, %s::auth_provider, %s, %s, now())
                """,
                (global_id, payload.provider.value, payload.tenant, payload.provider_subject),
            )
        conn.commit()
    return IdentityResolveResponse(global_id=global_id, global_id_display=gid(global_id), created=True)


def upsert_profile(global_id: int, payload: ProfileUpsert) -> ProfileRecord:
    if storage_mode() == "memory":
        return memory.upsert_profile(global_id, payload)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO cities(country_code, region_name, name)
                VALUES (%s, %s, %s)
                ON CONFLICT (country_code, region_name, name)
                DO UPDATE SET name=EXCLUDED.name
                RETURNING city_id
                """,
                (payload.country_code.upper(), payload.region_name or "", payload.city),
            )
            city_id = cur.fetchone()[0]
            cur.execute(
                """
                INSERT INTO profiles(
                    global_id, display_name, birth_date, latin_name, city_id, about,
                    friendship_goals, interests, values_profile, lifestyle_profile,
                    boundaries, visibility, completed_profile_sections, locale, updated_at
                ) VALUES (
                    %s,%s,%s,%s,%s,%s,%s::jsonb,%s::jsonb,%s::jsonb,%s::jsonb,%s::jsonb,%s,%s,%s,now()
                )
                ON CONFLICT (global_id) DO UPDATE SET
                    display_name=EXCLUDED.display_name,
                    birth_date=EXCLUDED.birth_date,
                    latin_name=EXCLUDED.latin_name,
                    city_id=EXCLUDED.city_id,
                    about=EXCLUDED.about,
                    friendship_goals=EXCLUDED.friendship_goals,
                    interests=EXCLUDED.interests,
                    values_profile=EXCLUDED.values_profile,
                    lifestyle_profile=EXCLUDED.lifestyle_profile,
                    boundaries=EXCLUDED.boundaries,
                    visibility=EXCLUDED.visibility,
                    completed_profile_sections=EXCLUDED.completed_profile_sections,
                    locale=EXCLUDED.locale,
                    updated_at=now()
                """,
                (
                    global_id,
                    payload.display_name,
                    payload.birth_date,
                    payload.latin_name,
                    city_id,
                    payload.about,
                    json.dumps(payload.friendship_goals, ensure_ascii=False),
                    json.dumps(payload.interests, ensure_ascii=False),
                    json.dumps(payload.values, ensure_ascii=False),
                    json.dumps(payload.lifestyle, ensure_ascii=False),
                    json.dumps(payload.boundaries, ensure_ascii=False),
                    payload.visibility,
                    payload.completed_profile_sections,
                    payload.locale,
                ),
            )
        conn.commit()
    result = get_profile(global_id)
    if result is None:
        raise RuntimeError("profile upsert failed")
    return result


def get_profile(global_id: int) -> ProfileRecord | None:
    if storage_mode() == "memory":
        return memory.get_profile(global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT p.global_id, p.display_name, p.birth_date, p.latin_name,
                       c.name, c.country_code, NULLIF(c.region_name,''), p.about,
                       p.friendship_goals, p.interests, p.values_profile, p.lifestyle_profile,
                       p.boundaries, p.visibility, p.completed_profile_sections, p.locale
                FROM profiles p
                LEFT JOIN cities c ON c.city_id=p.city_id
                WHERE p.global_id=%s
                """,
                (global_id,),
            )
            row = cur.fetchone()
    if not row:
        return None
    return ProfileRecord(
        global_id=row[0],
        global_id_display=gid(row[0]),
        display_name=row[1],
        birth_date=row[2],
        latin_name=row[3],
        city=row[4] or "",
        country_code=(row[5] or "ZZ").strip(),
        region_name=row[6],
        about=row[7] or "",
        friendship_goals=list(row[8] or []),
        interests=list(row[9] or []),
        values=list(row[10] or []),
        lifestyle=list(row[11] or []),
        boundaries=dict(row[12] or {}),
        visibility=row[13],
        completed_profile_sections=row[14],
        locale=row[15],
    )


def upsert_profile_avatar(global_id: int, payload: ProfileAvatarUpsert) -> ProfileAvatarRecord:
    try:
        data = base64.b64decode(payload.data_base64, validate=True)
    except Exception as exc:
        raise ValueError("avatar data_base64 is invalid") from exc
    if not data or len(data) > 512_000:
        raise ValueError("avatar must be between 1 and 512000 bytes after decoding")
    signatures = {
        "image/jpeg": data.startswith(b"\xff\xd8\xff"),
        "image/png": data.startswith(b"\x89PNG\r\n\x1a\n"),
        "image/webp": len(data) >= 12 and data.startswith(b"RIFF") and data[8:12] == b"WEBP",
    }
    if not signatures.get(payload.content_type, False):
        raise ValueError("avatar bytes do not match declared content_type")
    digest = hashlib.sha256(data).hexdigest()
    if digest.lower() != payload.sha256.lower():
        raise ValueError("avatar sha256 mismatch")
    if storage_mode() == "memory":
        return memory.upsert_profile_avatar(global_id, payload.content_type, data, digest)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO profile_avatars(global_id, content_type, image_bytes, sha256, updated_at)
                VALUES (%s,%s,%s,%s,now())
                ON CONFLICT (global_id) DO UPDATE SET
                    content_type=EXCLUDED.content_type,
                    image_bytes=EXCLUDED.image_bytes,
                    sha256=EXCLUDED.sha256,
                    updated_at=now()
                RETURNING global_id, content_type, sha256, octet_length(image_bytes), updated_at
                """,
                (global_id, payload.content_type, data, digest),
            )
            row = cur.fetchone()
        conn.commit()
    return ProfileAvatarRecord(global_id=row[0], content_type=row[1], sha256=row[2], byte_size=row[3], updated_at=row[4])


def _assessment_score_map_postgres(cur, global_id: int) -> dict[str, int]:
    cur.execute(
        "SELECT assessment_code, scores FROM assessment_results WHERE global_id=%s AND assessment_code BETWEEN 'f001' AND 'f100' AND assessment_version=%s",
        (global_id, "visual-latent-v2"),
    )
    result: dict[str, int] = {}
    for code, scores in cur.fetchall():
        data = scores if isinstance(scores, dict) else json.loads(scores)
        score = data.get("total_score")
        if isinstance(score, int):
            result[code] = max(0, min(100, score))
    return result


def _assessment_documents_postgres(cur, global_id: int) -> list[dict]:
    cur.execute(
        "SELECT scores FROM assessment_results WHERE global_id=%s AND assessment_code BETWEEN 'f001' AND 'f100' AND assessment_version=%s",
        (global_id, "visual-latent-v2"),
    )
    return [scores if isinstance(scores, dict) else json.loads(scores) for (scores,) in cur.fetchall()]


def _trust_summary_postgres(cur, global_id: int) -> TrustSummary:
    cur.execute(
        """
        SELECT
          count(*) FILTER (WHERE status IN ('confirmed','final')),
          count(*) FILTER (WHERE status IN ('pending','under_review','appealed')),
          COALESCE(sum(score_impact) FILTER (WHERE status IN ('confirmed','final')), 0)
        FROM trust_incidents WHERE subject_global_id=%s
        """,
        (global_id,),
    )
    confirmed, pending, impact = cur.fetchone()
    cur.execute(
        "SELECT count(*) FROM verified_interactions WHERE first_global_id=%s OR second_global_id=%s",
        (global_id, global_id),
    )
    interactions = cur.fetchone()[0]
    # New accounts start neutral at 70; confirmed evidence can only reduce this value.
    score = max(0, min(100, 70 + int(impact or 0)))
    return TrustSummary(
        global_id=global_id,
        global_id_display=gid(global_id),
        score=score,
        verified_interactions=int(interactions),
        confirmed_incidents=int(confirmed),
        pending_incidents=int(pending),
    )


def trust_summary(global_id: int) -> TrustSummary:
    if storage_mode() == "memory":
        return memory.trust_summary(global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            return _trust_summary_postgres(cur, global_id)


def list_people(
    city: str,
    radius_km: int,
    requester_global_id: int | None = None,
    desired_qualities: list[str] | None = None,
    locale: str = "ru",
) -> list[Person]:
    if storage_mode() == "memory":
        return memory.list_people(city, radius_km, requester_global_id, desired_qualities or [], locale)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT p.global_id, p.display_name,
                       extract(year from age(current_date, p.birth_date))::int AS age,
                       c.name, p.interests, p.friendship_goals, p.values_profile, p.lifestyle_profile,
                       pp.brotherhood32_code, pp.brotherhood32_scores,
                       pp.enneagram_type, pp.zodiac_sign, pp.vedic_numerology,
                       COALESCE(ar.total_rating,0)::int
                FROM profiles p
                JOIN users u ON u.global_id=p.global_id AND u.status='active'
                LEFT JOIN cities c ON c.city_id=p.city_id
                LEFT JOIN personality_profiles pp ON pp.global_id=p.global_id
                LEFT JOIN account_ratings ar ON ar.global_id=p.global_id
                WHERE p.visibility='discoverable' AND c.name=%s
                  AND (%s IS NULL OR p.global_id <> %s)
                ORDER BY ar.total_rating DESC NULLS LAST, p.updated_at DESC
                LIMIT 200
                """,
                (city, requester_global_id, requester_global_id),
            )
            rows = cur.fetchall()
            requester_scores = _assessment_score_map_postgres(cur, requester_global_id) if requester_global_id else {}
            requester_interests: list[str] = []
            if requester_global_id:
                cur.execute("SELECT interests FROM profiles WHERE global_id=%s", (requester_global_id,))
                r = cur.fetchone()
                requester_interests = list((r and r[0]) or [])
            desired = parse_desired_qualities(desired_qualities or [])

            result: list[Person] = []
            for row in rows:
                global_id = int(row[0])
                interests = list(row[4] or [])
                goals = list(row[5] or [])
                trust = _trust_summary_postgres(cur, global_id)
                candidate_scores = _assessment_score_map_postgres(cur, global_id)
                candidate_documents = _assessment_documents_postgres(cur, global_id)
                hidden_traits, hidden_confidence = aggregate_latent(candidate_documents)
                fit_score, fit_confidence, matched_qualities = quality_fit(desired, hidden_traits, hidden_confidence, locale)
                public_qualities = positive_projection(hidden_traits, locale)
                shared_interest = _overlap(requester_interests, interests) if requester_global_id else 0
                comp = compatibility(CompatibilityRequest(
                    my_scores=requester_scores,
                    candidate_scores=candidate_scores,
                    shared_interest_percent=shared_interest,
                    trust_score=trust.score,
                )) if requester_global_id else None
                scores = dict(row[9] or {})
                personality = None
                if row[8] and scores:
                    personality = Personality32(
                        code=row[8],
                        title=str(scores.get("title", row[8])),
                        social_energy=int(scores.get("social_energy", 50)),
                        perception=int(scores.get("perception", 50)),
                        decision_style=int(scores.get("decision_style", 50)),
                        life_rhythm=int(scores.get("life_rhythm", 50)),
                        bond_style=int(scores.get("bond_style", 50)),
                    )
                numerology_data = dict(row[12] or {})
                numerology = None
                if numerology_data.get("soul_number") and numerology_data.get("destiny_number"):
                    numerology = NumerologyProfile(
                        soul_number=int(numerology_data["soul_number"]),
                        destiny_number=int(numerology_data["destiny_number"]),
                        name_number=int(numerology_data["name_number"]) if numerology_data.get("name_number") else None,
                        maturity_number=int(numerology_data.get("maturity_number", numerology_data["destiny_number"])),
                    )
                result.append(Person(
                    global_id=global_id,
                    global_id_display=gid(global_id),
                    name=row[1],
                    age=max(18, int(row[2] or 18)),
                    city=row[3] or city,
                    distance_km=0,  # city-level search; exact coordinates are deliberately not exposed
                    compatibility=comp.score if comp else 0,
                    trust_score=trust.score,
                    account_rating=int(row[13] or 0),
                    interests=interests,
                    goals=goals,
                    values=list(row[6] or []),
                    lifestyle=list(row[7] or []),
                    personality32=personality,
                    enneagram_type=row[10],
                    zodiac=row[11],
                    numerology=numerology,
                    friendship_test_score=comp.tests_score if comp else 0,
                    common_tests=comp.common_tests if comp else 0,
                    test_category_scores=comp.category_scores if comp else {},
                    friendship_expectations_score=0,
                    quality_fit=fit_score,
                    quality_fit_confidence=fit_confidence,
                    positive_qualities=public_qualities if public_qualities else matched_qualities,
                    explanation=(
                        f"Тестовая совместимость рассчитана по {comp.common_tests} общим тестам; полный гибридный итог рассчитывает APK."
                        if comp else "Профиль доступен для совместимого подбора после входа."
                    ),
                ))
            return result


def upsert_friendship_outcome(payload: FriendshipOutcomeUpsert) -> FriendshipOutcomeRecord:
    """Internal analytics write. Pair order is canonicalized to prevent duplicate A/B and B/A rows."""
    first_global_id, second_global_id = sorted((payload.first_global_id, payload.second_global_id))
    if first_global_id == second_global_id:
        raise ValueError("friendship outcome requires two different users")
    if payload.searcher_global_id is not None and payload.searcher_global_id not in {first_global_id, second_global_id}:
        raise ValueError("searcher_global_id must belong to the connection pair")
    canonical = payload.model_copy(update={
        "first_global_id": first_global_id,
        "second_global_id": second_global_id,
    })
    if storage_mode() == "memory":
        return memory.upsert_friendship_outcome(canonical)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO friendship_outcomes(
                    connection_id, first_global_id, second_global_id, matched_at, layer_scores,
                    searcher_global_id, search_role, desired_qualities, quality_fit_score,
                    quality_fit_confidence, quality_model_version,
                    still_active_30d, still_active_90d, ended_reason, messages_exchanged_30d, updated_at
                ) VALUES (%s,%s,%s,%s,%s::jsonb,%s,%s,%s::jsonb,%s,%s,%s,%s,%s,%s,%s,now())
                ON CONFLICT (connection_id) DO UPDATE SET
                    layer_scores=EXCLUDED.layer_scores,
                    searcher_global_id=EXCLUDED.searcher_global_id,
                    search_role=EXCLUDED.search_role,
                    desired_qualities=EXCLUDED.desired_qualities,
                    quality_fit_score=EXCLUDED.quality_fit_score,
                    quality_fit_confidence=EXCLUDED.quality_fit_confidence,
                    quality_model_version=EXCLUDED.quality_model_version,
                    still_active_30d=EXCLUDED.still_active_30d,
                    still_active_90d=EXCLUDED.still_active_90d,
                    ended_reason=EXCLUDED.ended_reason,
                    messages_exchanged_30d=EXCLUDED.messages_exchanged_30d,
                    updated_at=now()
                RETURNING connection_id, first_global_id, second_global_id, matched_at, layer_scores,
                          searcher_global_id, search_role, desired_qualities, quality_fit_score,
                          quality_fit_confidence, quality_model_version,
                          still_active_30d, still_active_90d, ended_reason, messages_exchanged_30d, updated_at
                """,
                (
                    canonical.connection_id, canonical.first_global_id, canonical.second_global_id,
                    canonical.matched_at, json.dumps(canonical.layer_scores), canonical.searcher_global_id,
                    canonical.search_role, json.dumps(canonical.desired_qualities), canonical.quality_fit_score,
                    canonical.quality_fit_confidence, canonical.quality_model_version, canonical.still_active_30d,
                    canonical.still_active_90d, canonical.ended_reason, canonical.messages_exchanged_30d,
                ),
            )
            row = cur.fetchone()
        conn.commit()
    return FriendshipOutcomeRecord(
        connection_id=row[0], first_global_id=row[1], second_global_id=row[2], matched_at=row[3],
        layer_scores=dict(row[4] or {}), searcher_global_id=row[5], search_role=row[6],
        desired_qualities=dict(row[7] or {}), quality_fit_score=row[8], quality_fit_confidence=row[9],
        quality_model_version=row[10], still_active_30d=row[11], still_active_90d=row[12],
        ended_reason=row[13], messages_exchanged_30d=row[14], updated_at=row[15],
    )


def friendship_outcomes_for_analysis() -> list[FriendshipOutcomeRecord]:
    """Internal-only export for offline statistical calibration; never exposed as public profile data."""
    if storage_mode() == "memory":
        return memory.friendship_outcomes_for_analysis()
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT connection_id, first_global_id, second_global_id, matched_at, layer_scores,
                       searcher_global_id, search_role, desired_qualities, quality_fit_score,
                       quality_fit_confidence, quality_model_version,
                       still_active_30d, still_active_90d, ended_reason, messages_exchanged_30d, updated_at
                FROM friendship_outcomes
                ORDER BY matched_at, connection_id
                """
            )
            rows = cur.fetchall()
    return [FriendshipOutcomeRecord(
        connection_id=row[0], first_global_id=row[1], second_global_id=row[2], matched_at=row[3],
        layer_scores=dict(row[4] or {}), searcher_global_id=row[5], search_role=row[6],
        desired_qualities=dict(row[7] or {}), quality_fit_score=row[8], quality_fit_confidence=row[9],
        quality_model_version=row[10], still_active_30d=row[11], still_active_90d=row[12],
        ended_reason=row[13], messages_exchanged_30d=row[14], updated_at=row[15],
    ) for row in rows]


def _overlap(first: Iterable[str], second: Iterable[str]) -> int:
    a = {str(item).casefold() for item in first}
    b = {str(item).casefold() for item in second}
    return len(a & b) * 100 // max(1, len(a | b))


def list_communities(city: str, kind: CommunityKind, locale: str = "ru") -> list[Community]:
    if storage_mode() == "memory":
        return memory.list_communities(city, kind, locale)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT co.community_id::text, co.title, co.category, COALESCE(c.name,'Онлайн'),
                       count(cm.global_id) FILTER (WHERE cm.status='active') AS members,
                       co.kind::text, co.is_online, co.description, co.verified_only
                FROM communities co
                LEFT JOIN cities c ON c.city_id=co.city_id
                LEFT JOIN community_members cm ON cm.community_id=co.community_id
                WHERE co.kind=%s::community_kind AND (co.is_online OR c.name=%s)
                GROUP BY co.community_id, c.name
                ORDER BY members DESC, co.created_at DESC
                """,
                (kind.value, city),
            )
            return [Community(
                id=row[0], title=row[1], category=row[2], city=row[3], members=int(row[4]),
                kind=CommunityKind(row[5]), online=bool(row[6]), description=row[7], verified_only=bool(row[8])
            ) for row in cur.fetchall()]


def create_community(payload: CommunityCreate) -> Community:
    if storage_mode() == "memory":
        return memory.create_community(payload)
    with connection() as conn:
        with conn.cursor() as cur:
            city_id = None
            if not payload.online:
                cur.execute(
                    "INSERT INTO cities(country_code,region_name,name) VALUES('ZZ','',%s) ON CONFLICT(country_code,region_name,name) DO UPDATE SET name=EXCLUDED.name RETURNING city_id",
                    (payload.city,),
                )
                city_id = cur.fetchone()[0]
            cur.execute(
                """
                INSERT INTO communities(owner_global_id,kind,title,category,city_id,is_online,verified_only,description)
                VALUES(%s,%s::community_kind,%s,%s,%s,%s,%s,%s)
                RETURNING community_id::text
                """,
                (payload.owner_global_id, payload.kind.value, payload.title, payload.category, city_id, payload.online, payload.verified_only, payload.description),
            )
            community_id = cur.fetchone()[0]
            cur.execute(
                "INSERT INTO community_members(community_id,global_id,role) VALUES(%s,%s,'owner') ON CONFLICT DO NOTHING",
                (community_id, payload.owner_global_id),
            )
        conn.commit()
    return Community(id=community_id, title=payload.title, category=payload.category, city=payload.city, members=1,
                     kind=payload.kind, online=payload.online, description=payload.description, verified_only=payload.verified_only)


def create_incident(payload: TrustIncidentCreate) -> TrustIncident:
    if storage_mode() == "memory":
        return memory.create_incident(payload)
    key = _secret("TRUST_ENCRYPTION_KEY")
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO trust_incidents(reporter_global_id,subject_global_id,category,occurred_at,description_ciphertext)
                VALUES(%s,%s,%s,%s,pgp_sym_encrypt(%s,%s)) RETURNING incident_id::text,status::text,score_impact
                """,
                (payload.reporter_global_id, payload.subject_global_id, payload.category, payload.occurred_at, payload.description, key),
            )
            incident_id, status, score_impact = cur.fetchone()
            for ref in payload.evidence_refs:
                cur.execute(
                    "INSERT INTO incident_evidence(incident_id,storage_key,content_hash) VALUES(%s,%s,%s)",
                    (incident_id, ref, "client-provided-ref"),
                )
        conn.commit()
    return TrustIncident(id=incident_id, **payload.model_dump(), status=IncidentStatus(status), score_impact=score_impact)


def moderate_incident(incident_id: str, confirmed: bool) -> TrustIncident | None:
    if storage_mode() == "memory":
        return memory.moderate_incident(incident_id, confirmed)
    key = _secret("TRUST_ENCRYPTION_KEY")
    status = IncidentStatus.CONFIRMED if confirmed else IncidentStatus.REJECTED
    impact = -12 if confirmed else 0
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE trust_incidents SET status=%s::incident_status, score_impact=%s
                WHERE incident_id=%s
                RETURNING incident_id::text,reporter_global_id,subject_global_id,category,occurred_at,
                          pgp_sym_decrypt(description_ciphertext,%s),status::text,score_impact
                """,
                (status.value, impact, incident_id, key),
            )
            row = cur.fetchone()
            if not row:
                return None
            cur.execute("SELECT storage_key FROM incident_evidence WHERE incident_id=%s ORDER BY created_at", (incident_id,))
            evidence = [r[0] for r in cur.fetchall()]
        conn.commit()
    return TrustIncident(id=row[0], reporter_global_id=row[1], subject_global_id=row[2], category=row[3],
                         occurred_at=row[4].isoformat(), description=row[5], evidence_refs=evidence,
                         status=IncidentStatus(row[6]), score_impact=row[7])



def _pilot_locale(value: str, accepted: tuple[str, ...]) -> str:
    normalized = value.strip().lower().replace("_", "-")
    if normalized in accepted:
        return normalized
    base = normalized.split("-", 1)[0]
    if base in accepted:
        return base
    raise PilotEnrollmentError("unsupported_locale", "instrument locale is not enabled for this pilot", 400)


def _pilot_status_from_counts(config, total_used: int, locale_counts: dict[str, int]) -> CalibrationPilotStatus:
    remaining_total = max(0, config.max_participants - total_used) if config.mode != "disabled" else 0
    locale_remaining = {
        locale: max(0, min(config.locale_limits.get(locale, 0) - locale_counts.get(locale, 0), remaining_total))
        if config.mode != "disabled" else 0
        for locale in config.accepted_locales
    }
    return CalibrationPilotStatus(
        mode=config.mode,
        cohort_id=config.cohort_id,
        pilot_wave=config.wave_id,
        consent_version=config.consent_version,
        model_version=config.model_version,
        stimulus_version=config.stimulus_version,
        accepted_locales=list(config.accepted_locales),
        capacity_total=config.max_participants,
        capacity_used=total_used,
        capacity_remaining=remaining_total,
        locale_remaining=locale_remaining,
        invite_required=config.requires_invite,
    )


def calibration_pilot_status() -> CalibrationPilotStatus:
    config = pilot_config()
    if storage_mode() == "memory":
        total_used, locale_counts = memory.calibration_pilot_counts(config.cohort_id, config.wave_id)
        return _pilot_status_from_counts(config, total_used, locale_counts)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT instrument_locale, count(*)
                FROM calibration_consents
                WHERE cohort_id=%s AND pilot_wave=%s AND opt_in=true AND enrollment_state='active'
                GROUP BY instrument_locale
                """,
                (config.cohort_id, config.wave_id),
            )
            locale_counts = {str(row[0]): int(row[1]) for row in cur.fetchall()}
    return _pilot_status_from_counts(config, sum(locale_counts.values()), locale_counts)


def upsert_calibration_consent(payload: CalibrationConsentUpsert) -> CalibrationConsentRecord:
    config = pilot_config()
    if storage_mode() == "memory":
        return memory.upsert_calibration_consent(payload, config)

    requested_locale = payload.instrument_locale.strip().lower().replace("_", "-")
    locale = _pilot_locale(payload.instrument_locale, config.accepted_locales) if payload.opt_in else requested_locale.split("-", 1)[0]
    with connection() as conn:
        with conn.cursor() as cur:
            # Serialize enrollment decisions so total and per-locale quotas cannot be overbooked.
            cur.execute("SELECT pg_advisory_xact_lock(hashtext('brotherhood-calibration-pilot-enrollment'))")
            cur.execute(
                """
                SELECT opt_in,cohort_id,pilot_wave,instrument_locale,enrollment_state
                FROM calibration_consents WHERE global_id=%s FOR UPDATE
                """,
                (payload.global_id,),
            )
            existing = cur.fetchone()
            existing_active = bool(existing and existing[0] and existing[4] == "active")
            existing_active_current = bool(
                existing_active and existing[1] == config.cohort_id and existing[2] == config.wave_id
            )
            if not payload.opt_in and existing and existing[3]:
                locale = str(existing[3])

            if payload.opt_in:
                if config.mode == "disabled":
                    raise PilotEnrollmentError("pilot_disabled", "controlled calibration pilot is disabled", 403)
                if not payload.eligibility_ack:
                    raise PilotEnrollmentError("eligibility_ack_required", "pilot conditions must be acknowledged", 400)
                if payload.consent_version != config.consent_version:
                    raise PilotEnrollmentError("consent_version_mismatch", "pilot consent version is not current", 409)
                invite_sha256 = None
                if config.requires_invite and not existing_active_current:
                    invite_sha256 = validated_invite_digest(payload.invite_code, config)
                    if invite_sha256 is None:
                        raise PilotEnrollmentError("invalid_invite", "valid controlled-pilot invite code is required", 403)
                    cur.execute(
                        """
                        INSERT INTO calibration_pilot_invite_redemptions(
                            invite_sha256,global_id,cohort_id,pilot_wave,redeemed_at
                        ) VALUES(%s,%s,%s,%s,now())
                        ON CONFLICT(invite_sha256) DO NOTHING
                        RETURNING invite_sha256
                        """,
                        (invite_sha256,payload.global_id,config.cohort_id,config.wave_id),
                    )
                    if cur.fetchone() is None:
                        raise PilotEnrollmentError("invite_already_used", "controlled-pilot invite code was already redeemed", 409)

                cur.execute(
                    """
                    SELECT instrument_locale,count(*)
                    FROM calibration_consents
                    WHERE cohort_id=%s AND pilot_wave=%s AND opt_in=true AND enrollment_state='active'
                    GROUP BY instrument_locale
                    """,
                    (config.cohort_id, config.wave_id),
                )
                locale_counts = {str(row[0]): int(row[1]) for row in cur.fetchall()}
                total_used = sum(locale_counts.values())
                old_locale = str(existing[3]) if existing_active_current else None
                effective_total = total_used if existing_active_current else total_used + 1
                effective_locale = locale_counts.get(locale, 0) + (0 if existing_active_current and old_locale == locale else 1)
                if existing_active_current and old_locale and old_locale != locale:
                    effective_locale = locale_counts.get(locale, 0) + 1
                if effective_total > config.max_participants:
                    raise PilotEnrollmentError("pilot_full", "controlled calibration pilot capacity is full", 409)
                if effective_locale > config.locale_limits.get(locale, 0):
                    raise PilotEnrollmentError("locale_quota_full", "controlled pilot locale quota is full", 409)

                cur.execute(
                    """
                    INSERT INTO calibration_consents(
                        global_id,opt_in,consent_version,cohort_id,instrument_locale,enrollment_state,pilot_wave,
                        consented_at,withdrawn_at,updated_at
                    ) VALUES(%s,true,%s,%s,%s,'active',%s,now(),NULL,now())
                    ON CONFLICT(global_id) DO UPDATE SET
                        opt_in=true,consent_version=EXCLUDED.consent_version,cohort_id=EXCLUDED.cohort_id,
                        instrument_locale=EXCLUDED.instrument_locale,enrollment_state='active',pilot_wave=EXCLUDED.pilot_wave,
                        consented_at=COALESCE(calibration_consents.consented_at,now()),withdrawn_at=NULL,updated_at=now()
                    RETURNING global_id,opt_in,consent_version,cohort_id,instrument_locale,enrollment_state,pilot_wave,updated_at
                    """,
                    (payload.global_id, config.consent_version, config.cohort_id, locale, config.wave_id),
                )
            else:
                # Withdrawal is unconditional: disabled/full pilot state must never trap calibration data.
                cur.execute(
                    """
                    INSERT INTO calibration_consents(
                        global_id,opt_in,consent_version,cohort_id,instrument_locale,enrollment_state,pilot_wave,
                        consented_at,withdrawn_at,updated_at
                    ) VALUES(%s,false,%s,%s,%s,'withdrawn',%s,NULL,now(),now())
                    ON CONFLICT(global_id) DO UPDATE SET
                        opt_in=false,enrollment_state='withdrawn',withdrawn_at=now(),updated_at=now()
                    RETURNING global_id,opt_in,consent_version,cohort_id,instrument_locale,enrollment_state,pilot_wave,updated_at
                    """,
                    (payload.global_id, config.consent_version, config.cohort_id, locale, config.wave_id),
                )
            row = cur.fetchone()
            if not payload.opt_in:
                cur.execute("DELETE FROM assessment_calibration_attempts WHERE global_id=%s", (payload.global_id,))
        conn.commit()
    return CalibrationConsentRecord(
        global_id=row[0],opt_in=row[1],consent_version=row[2],cohort_id=row[3],
        instrument_locale=row[4],enrollment_state=row[5],pilot_wave=row[6],updated_at=row[7],
    )


def calibration_consent_for_user(global_id: int) -> CalibrationConsentRecord | None:
    if storage_mode() == "memory":
        return memory.calibration_consent_for_user(global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT global_id,opt_in,consent_version,cohort_id,instrument_locale,enrollment_state,pilot_wave,updated_at
                FROM calibration_consents WHERE global_id=%s
                """,
                (global_id,),
            )
            row=cur.fetchone()
    if not row:
        return None
    return CalibrationConsentRecord(
        global_id=row[0],opt_in=row[1],consent_version=row[2],cohort_id=row[3],
        instrument_locale=row[4],enrollment_state=row[5],pilot_wave=row[6],updated_at=row[7],
    )


def calibration_opted_in(global_id: int) -> bool:
    row=calibration_consent_for_user(global_id)
    return bool(row and row.opt_in)

def upsert_assessment_result(payload: AssessmentResultUpsert) -> AssessmentResultRecord:
    if storage_mode() == "memory":
        return memory.upsert_assessment_result(payload)
    score_json = payload.model_dump(mode="json")
    raw_trace = score_json.pop("response_trace")
    score_json["response_trace"] = []
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO assessment_results(global_id,assessment_code,assessment_version,scores,answer_consistency,idealized_self_presentation,completed_at)
                VALUES(%s,%s,%s,%s::jsonb,%s,%s,to_timestamp(%s/1000.0))
                ON CONFLICT(global_id,assessment_code,assessment_version) DO UPDATE SET
                    scores=EXCLUDED.scores,
                    answer_consistency=EXCLUDED.answer_consistency,
                    idealized_self_presentation=EXCLUDED.idealized_self_presentation,
                    completed_at=EXCLUDED.completed_at
                RETURNING result_id::text
                """,
                (payload.global_id, payload.assessment_id, payload.scoring_version, json.dumps(score_json, ensure_ascii=False),
                 payload.answer_consistency, payload.idealized_self_presentation, payload.completed_at_epoch_ms),
            )
            result_id = cur.fetchone()[0]
            cur.execute(
                """
                SELECT opt_in,cohort_id,consent_version,instrument_locale,enrollment_state
                FROM calibration_consents WHERE global_id=%s
                """,
                (payload.global_id,),
            )
            consent=cur.fetchone()
            if consent and consent[0] and consent[4] == "active" and consent[3] == payload.instrument_locale:
                cur.execute(
                    """
                    INSERT INTO assessment_calibration_attempts(
                        global_id,assessment_code,assessment_version,stimulus_version,instrument_locale,cohort_id,consent_version,
                        started_at,completed_at,answer_consistency,dimensions,response_trace
                    ) VALUES(%s,%s,%s,%s,%s,%s,%s,to_timestamp(%s/1000.0),to_timestamp(%s/1000.0),%s,%s::jsonb,%s::jsonb)
                    ON CONFLICT(global_id,assessment_code,assessment_version,completed_at) DO NOTHING
                    """,
                    (payload.global_id,payload.assessment_id,payload.scoring_version,payload.stimulus_version,payload.instrument_locale,
                     consent[1],consent[2],payload.started_at_epoch_ms,payload.completed_at_epoch_ms,payload.answer_consistency,
                     json.dumps([row.model_dump() for row in payload.dimensions],ensure_ascii=False),json.dumps(raw_trace,ensure_ascii=False)),
                )
        conn.commit()
    safe=payload.model_dump()
    safe["response_trace"]=[]
    return AssessmentResultRecord(id=result_id, **safe)


def assessment_results_for_user(global_id: int) -> list[AssessmentResultRecord]:
    if storage_mode() == "memory":
        return memory.assessment_results_for_user(global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT result_id::text,scores FROM assessment_results WHERE global_id=%s AND assessment_version=%s ORDER BY completed_at DESC",
                (global_id, "visual-latent-v2"),
            )
            rows = cur.fetchall()
    result: list[AssessmentResultRecord] = []
    for result_id, scores in rows:
        data = scores if isinstance(scores, dict) else json.loads(scores)
        data["id"] = result_id
        result.append(AssessmentResultRecord.model_validate(data))
    return result


def create_message(payload: MessageCreate) -> MessageRecord:
    if payload.sender_global_id == payload.recipient_global_id:
        raise ValueError("sender and recipient must differ")
    if storage_mode() == "memory":
        return memory.create_message(payload)
    key = _secret("MESSAGE_ENCRYPTION_KEY")
    first, second = sorted((payload.sender_global_id, payload.recipient_global_id))
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT c.conversation_id FROM conversations c
                JOIN conversation_members a ON a.conversation_id=c.conversation_id AND a.global_id=%s
                JOIN conversation_members b ON b.conversation_id=c.conversation_id AND b.global_id=%s
                WHERE c.conversation_type='direct'
                LIMIT 1
                """,
                (first, second),
            )
            found = cur.fetchone()
            if found:
                conversation_id = found[0]
            else:
                cur.execute("INSERT INTO conversations(conversation_type) VALUES('direct') RETURNING conversation_id")
                conversation_id = cur.fetchone()[0]
                cur.execute("INSERT INTO conversation_members(conversation_id,global_id) VALUES(%s,%s),(%s,%s)",
                            (conversation_id, first, conversation_id, second))
            cur.execute(
                """
                INSERT INTO messages(conversation_id,sender_global_id,client_message_id,body_ciphertext,created_at)
                VALUES(%s,%s,%s,pgp_sym_encrypt(%s,%s),to_timestamp(%s/1000.0))
                ON CONFLICT(sender_global_id,client_message_id) DO UPDATE SET client_message_id=EXCLUDED.client_message_id
                RETURNING message_id::text,status
                """,
                (conversation_id, payload.sender_global_id, payload.client_message_id, payload.body, key, payload.created_at_epoch_ms),
            )
            message_id, status = cur.fetchone()
        conn.commit()
    return MessageRecord(id=message_id, status=status, **payload.model_dump())


def messages_for_user(global_id: int) -> list[MessageRecord]:
    if storage_mode() == "memory":
        return memory.messages_for_user(global_id)
    key = _secret("MESSAGE_ENCRYPTION_KEY")
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT m.message_id::text,m.sender_global_id,
                       CASE WHEN m.sender_global_id=%s THEN other.global_id ELSE %s END AS recipient_global_id,
                       m.client_message_id,pgp_sym_decrypt(m.body_ciphertext,%s),m.status,
                       (extract(epoch from m.created_at)*1000)::bigint
                FROM messages m
                JOIN conversation_members me ON me.conversation_id=m.conversation_id AND me.global_id=%s
                JOIN conversation_members other ON other.conversation_id=m.conversation_id AND other.global_id<>%s
                ORDER BY m.created_at
                """,
                (global_id, global_id, key, global_id, global_id),
            )
            rows = cur.fetchall()
    return [MessageRecord(id=r[0], sender_global_id=r[1], recipient_global_id=r[2], client_message_id=r[3], body=r[4], status=r[5], created_at_epoch_ms=r[6]) for r in rows]


def upsert_personality_profile(global_id: int, payload):
    from .models import PersonalityProfileRecord
    if storage_mode() == "memory":
        memory.PERSONALITY_PROFILES[global_id] = payload
        return PersonalityProfileRecord(global_id=global_id, global_id_display=gid(global_id), **payload.model_dump())
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO personality_profiles(
                    global_id,brotherhood32_code,brotherhood32_scores,enneagram_type,enneagram_wing,
                    zodiac_sign,vedic_numerology,model_version,updated_at
                ) VALUES(%s,%s,%s::jsonb,%s,%s,%s,%s::jsonb,%s,now())
                ON CONFLICT(global_id) DO UPDATE SET
                    brotherhood32_code=EXCLUDED.brotherhood32_code,
                    brotherhood32_scores=EXCLUDED.brotherhood32_scores,
                    enneagram_type=EXCLUDED.enneagram_type,
                    enneagram_wing=EXCLUDED.enneagram_wing,
                    zodiac_sign=EXCLUDED.zodiac_sign,
                    vedic_numerology=EXCLUDED.vedic_numerology,
                    model_version=EXCLUDED.model_version,
                    updated_at=now()
                """,
                (
                    global_id,
                    payload.brotherhood32_code,
                    json.dumps(payload.brotherhood32_scores, ensure_ascii=False),
                    payload.enneagram_type,
                    payload.enneagram_wing,
                    payload.zodiac_sign,
                    json.dumps(payload.vedic_numerology, ensure_ascii=False),
                    payload.model_version,
                ),
            )
        conn.commit()
    return PersonalityProfileRecord(global_id=global_id, global_id_display=gid(global_id), **payload.model_dump())


def get_personality_profile(global_id: int):
    from .models import PersonalityProfileRecord
    if storage_mode() == "memory":
        payload = memory.PERSONALITY_PROFILES.get(global_id)
        return None if payload is None else PersonalityProfileRecord(global_id=global_id, global_id_display=gid(global_id), **payload.model_dump())
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT brotherhood32_code,brotherhood32_scores,enneagram_type,enneagram_wing,
                       zodiac_sign,vedic_numerology,model_version
                FROM personality_profiles WHERE global_id=%s
                """,
                (global_id,),
            )
            row = cur.fetchone()
    if not row:
        return None
    return PersonalityProfileRecord(
        global_id=global_id,
        global_id_display=gid(global_id),
        brotherhood32_code=row[0],
        brotherhood32_scores=dict(row[1] or {}),
        enneagram_type=row[2],
        enneagram_wing=row[3],
        zodiac_sign=row[4],
        vedic_numerology=dict(row[5] or {}),
        model_version=row[6],
    )


# ---- Brotherhood Chat Core v0.5.8 -------------------------------------------------

def upsert_device_key(global_id: int, payload: DeviceKeyUpsert) -> DeviceKeyRecord:
    if storage_mode() == "memory":
        return memory.upsert_device_key(global_id, payload)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO device_keys(global_id,device_id,identity_public_key_b64,prekey_id,prekey_public_key_b64,prekey_signature_b64,updated_at)
                VALUES(%s,%s,%s,%s,%s,%s,now())
                ON CONFLICT(global_id,device_id) DO UPDATE SET
                    identity_public_key_b64=EXCLUDED.identity_public_key_b64,
                    prekey_id=EXCLUDED.prekey_id,
                    prekey_public_key_b64=EXCLUDED.prekey_public_key_b64,
                    prekey_signature_b64=EXCLUDED.prekey_signature_b64,
                    updated_at=now()
                RETURNING extract(epoch from created_at)*1000
                """,
                (global_id,payload.device_id,payload.identity_public_key_b64,payload.prekey_id,payload.prekey_public_key_b64,payload.prekey_signature_b64),
            )
            created=int(cur.fetchone()[0])
        conn.commit()
    return DeviceKeyRecord(global_id=global_id,global_id_display=gid(global_id),created_at_epoch_ms=created,**payload.model_dump())


def device_keys_for_user(global_id: int) -> list[DeviceKeyRecord]:
    if storage_mode() == "memory":
        return memory.device_keys_for_user(global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT device_id,identity_public_key_b64,prekey_id,prekey_public_key_b64,prekey_signature_b64,extract(epoch from created_at)*1000 FROM device_keys WHERE global_id=%s AND revoked_at IS NULL ORDER BY updated_at DESC",
                (global_id,),
            )
            rows=cur.fetchall()
    return [DeviceKeyRecord(global_id=global_id,global_id_display=gid(global_id),device_id=r[0],identity_public_key_b64=r[1],prekey_id=r[2],prekey_public_key_b64=r[3],prekey_signature_b64=r[4],created_at_epoch_ms=int(r[5])) for r in rows]


def _conversation_summary_postgres(cur, conversation_id: str, viewer_global_id: int) -> ConversationSummary:
    key=_secret("MESSAGE_ENCRYPTION_KEY")
    cur.execute(
        """
        SELECT c.conversation_type,c.title,count(DISTINCT cm.global_id)::int,
               max(extract(epoch from m.created_at)*1000)::bigint,
               (SELECT CASE WHEN lm.encryption_mode='e2ee' THEN 'E2EE'
                            WHEN lm.body_ciphertext IS NOT NULL THEN left(pgp_sym_decrypt(lm.body_ciphertext,%s),160)
                            ELSE 'MEDIA' END
                  FROM messages lm WHERE lm.conversation_id=c.conversation_id ORDER BY lm.created_at DESC LIMIT 1),
               (SELECT other.global_id FROM conversation_members other WHERE other.conversation_id=c.conversation_id AND other.global_id<>%s ORDER BY other.joined_at LIMIT 1)
        FROM conversations c
        JOIN conversation_members cm ON cm.conversation_id=c.conversation_id
        LEFT JOIN messages m ON m.conversation_id=c.conversation_id
        WHERE c.conversation_id=%s::uuid
        GROUP BY c.conversation_id
        """, (key,viewer_global_id,conversation_id))
    row=cur.fetchone()
    if not row:
        raise ValueError("conversation not found")
    ctype=ConversationType(row[0])
    peer=int(row[5]) if ctype==ConversationType.DIRECT and row[5] is not None else None
    title=row[1] or (f"global_id {gid(peer)}" if peer else "Chat")
    return ConversationSummary(id=conversation_id,conversation_type=ctype,title=title,peer_global_id=peer,member_count=int(row[2]),encryption_mode=EncryptionMode.E2EE if ctype==ConversationType.DIRECT else EncryptionMode.SERVER,last_message_preview=row[4] or "",last_message_at_epoch_ms=int(row[3]) if row[3] is not None else None,unread_count=0)


def has_user_block(owner_global_id: int, subject_global_id: int) -> bool:
    if storage_mode() == "memory":
        return memory.has_user_block(owner_global_id, subject_global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT 1 FROM user_blocks WHERE blocker_global_id=%s AND blocked_global_id=%s LIMIT 1",
                (owner_global_id, subject_global_id),
            )
            return cur.fetchone() is not None


def is_user_blocked(first_global_id: int, second_global_id: int) -> bool:
    if storage_mode() == "memory":
        return memory.is_user_blocked(first_global_id, second_global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT 1 FROM user_blocks
                WHERE (blocker_global_id=%s AND blocked_global_id=%s)
                   OR (blocker_global_id=%s AND blocked_global_id=%s)
                LIMIT 1""",
                (first_global_id, second_global_id, second_global_id, first_global_id),
            )
            return cur.fetchone() is not None


def set_user_block(owner_global_id: int, subject_global_id: int, blocked: bool) -> bool:
    if storage_mode() == "memory":
        return memory.set_user_block(owner_global_id, subject_global_id, blocked)
    if owner_global_id == subject_global_id:
        raise ValueError("cannot block yourself")
    with connection() as conn:
        with conn.cursor() as cur:
            if blocked:
                cur.execute(
                    """INSERT INTO user_blocks(blocker_global_id, blocked_global_id)
                    VALUES(%s,%s) ON CONFLICT(blocker_global_id,blocked_global_id) DO NOTHING""",
                    (owner_global_id, subject_global_id),
                )
            else:
                cur.execute(
                    "DELETE FROM user_blocks WHERE blocker_global_id=%s AND blocked_global_id=%s",
                    (owner_global_id, subject_global_id),
                )
        conn.commit()
    return blocked


def upsert_push_token(global_id: int, payload: PushTokenUpsert) -> bool:
    if storage_mode() == "memory":
        return memory.upsert_push_token(global_id, payload)
    key = _secret("PUSH_TOKEN_ENCRYPTION_KEY")
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO push_tokens(global_id,device_id,provider,token_ciphertext,updated_at)
                VALUES(%s,%s,%s,pgp_sym_encrypt(%s,%s),now())
                ON CONFLICT(global_id,device_id,provider) DO UPDATE SET
                    token_ciphertext=EXCLUDED.token_ciphertext, updated_at=now()""",
                (global_id, payload.device_id, payload.provider, payload.token, key),
            )
        conn.commit()
    return True


def open_direct_conversation(owner_global_id: int, peer_global_id: int) -> ConversationSummary:
    if storage_mode() == "memory":
        return memory.open_direct_conversation(owner_global_id, peer_global_id)
    if owner_global_id==peer_global_id:
        raise ValueError("direct chat requires another user")
    if is_user_blocked(owner_global_id, peer_global_id):
        raise ValueError("direct chat is blocked between these users")
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT c.conversation_id::text FROM conversations c
                JOIN conversation_members a ON a.conversation_id=c.conversation_id AND a.global_id=%s
                JOIN conversation_members b ON b.conversation_id=c.conversation_id AND b.global_id=%s
                WHERE c.conversation_type='direct' AND (SELECT count(*) FROM conversation_members x WHERE x.conversation_id=c.conversation_id)=2 LIMIT 1""",
                (owner_global_id,peer_global_id))
            row=cur.fetchone()
            if row:
                return _conversation_summary_postgres(cur,row[0],owner_global_id)
            cur.execute("INSERT INTO conversations(conversation_type,owner_global_id) VALUES('direct',%s) RETURNING conversation_id::text",(owner_global_id,))
            cid=cur.fetchone()[0]
            cur.execute("INSERT INTO conversation_members(conversation_id,global_id,role) VALUES(%s,%s,'owner'),(%s,%s,'member')",(cid,owner_global_id,cid,peer_global_id))
        conn.commit()
    with connection() as conn:
        with conn.cursor() as cur:
            return _conversation_summary_postgres(cur,cid,owner_global_id)


def create_group_conversation(owner_global_id: int, payload: GroupConversationCreate) -> ConversationSummary:
    if storage_mode()=="memory":
        return memory.create_group_conversation(owner_global_id,payload)
    members=sorted(set(payload.member_global_ids)|{owner_global_id})
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("INSERT INTO conversations(conversation_type,title,owner_global_id) VALUES('group',%s,%s) RETURNING conversation_id::text",(payload.title,owner_global_id))
            cid=cur.fetchone()[0]
            for member in members:
                cur.execute("INSERT INTO conversation_members(conversation_id,global_id,role) VALUES(%s,%s,%s) ON CONFLICT DO NOTHING",(cid,member,'owner' if member==owner_global_id else 'member'))
        conn.commit()
    with connection() as conn:
        with conn.cursor() as cur:
            return _conversation_summary_postgres(cur,cid,owner_global_id)


def conversations_for_user(global_id: int) -> list[ConversationSummary]:
    if storage_mode()=="memory":
        return memory.conversations_for_user(global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT conversation_id::text FROM conversation_members WHERE global_id=%s ORDER BY joined_at DESC",(global_id,))
            ids=[r[0] for r in cur.fetchall()]
            return [_conversation_summary_postgres(cur,cid,global_id) for cid in ids]


def conversation_members(conversation_id: str, viewer_global_id: int) -> list[ConversationMemberRecord]:
    if storage_mode() == "memory":
        return memory.conversation_members(conversation_id, viewer_global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            _ensure_member(cur, conversation_id, viewer_global_id)
            cur.execute(
                "SELECT global_id,role FROM conversation_members WHERE conversation_id=%s::uuid ORDER BY CASE role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END, joined_at",
                (conversation_id,),
            )
            rows = cur.fetchall()
    return [ConversationMemberRecord(global_id=int(r[0]), global_id_display=gid(int(r[0])), role=r[1]) for r in rows]


def _ensure_group_owner(cur, conversation_id: str, owner_global_id: int) -> None:
    cur.execute("SELECT 1 FROM conversations WHERE conversation_id=%s::uuid AND conversation_type='group' AND owner_global_id=%s", (conversation_id, owner_global_id))
    if not cur.fetchone():
        raise ValueError("only group owner can manage members")


def add_group_member(conversation_id: str, owner_global_id: int, member_global_id: int) -> list[ConversationMemberRecord]:
    if storage_mode() == "memory":
        return memory.add_group_member(conversation_id, owner_global_id, member_global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            _ensure_group_owner(cur, conversation_id, owner_global_id)
            cur.execute(
                "INSERT INTO conversation_members(conversation_id,global_id,role) VALUES(%s::uuid,%s,'member') ON CONFLICT(conversation_id,global_id) DO NOTHING",
                (conversation_id, member_global_id),
            )
        conn.commit()
    return conversation_members(conversation_id, owner_global_id)


def remove_group_member(conversation_id: str, owner_global_id: int, member_global_id: int) -> list[ConversationMemberRecord]:
    if storage_mode() == "memory":
        return memory.remove_group_member(conversation_id, owner_global_id, member_global_id)
    if member_global_id == owner_global_id:
        raise ValueError("group owner cannot remove himself")
    with connection() as conn:
        with conn.cursor() as cur:
            _ensure_group_owner(cur, conversation_id, owner_global_id)
            cur.execute("DELETE FROM conversation_members WHERE conversation_id=%s::uuid AND global_id=%s", (conversation_id, member_global_id))
        conn.commit()
    return conversation_members(conversation_id, owner_global_id)


def _ensure_member(cur, conversation_id: str, global_id: int) -> ConversationType:
    cur.execute("SELECT c.conversation_type FROM conversations c JOIN conversation_members cm ON cm.conversation_id=c.conversation_id WHERE c.conversation_id=%s::uuid AND cm.global_id=%s",(conversation_id,global_id))
    row=cur.fetchone()
    if not row:
        raise ValueError("conversation not found or user is not a member")
    return ConversationType(row[0])


def create_chat_message(conversation_id: str, sender_global_id: int, payload: ChatMessageCreate) -> ChatMessageRecord:
    if storage_mode()=="memory":
        return memory.create_chat_message(conversation_id,sender_global_id,payload)
    key=_secret("MESSAGE_ENCRYPTION_KEY")
    with connection() as conn:
        with conn.cursor() as cur:
            ctype=_ensure_member(cur,conversation_id,sender_global_id)
            expected=EncryptionMode.E2EE if ctype==ConversationType.DIRECT else EncryptionMode.SERVER
            if ctype == ConversationType.DIRECT:
                cur.execute(
                    "SELECT global_id FROM conversation_members WHERE conversation_id=%s::uuid AND global_id<>%s LIMIT 1",
                    (conversation_id, sender_global_id),
                )
                peer_row = cur.fetchone()
                if peer_row:
                    peer_global_id = int(peer_row[0])
                    cur.execute(
                        """SELECT 1 FROM user_blocks
                        WHERE (blocker_global_id=%s AND blocked_global_id=%s)
                           OR (blocker_global_id=%s AND blocked_global_id=%s)
                        LIMIT 1""",
                        (sender_global_id, peer_global_id, peer_global_id, sender_global_id),
                    )
                    if cur.fetchone():
                        raise ValueError("direct chat is blocked between these users")
            if payload.encryption_mode!=expected:
                raise ValueError("invalid encryption mode for conversation")
            if payload.message_type == "edit":
                raise ValueError("edit messages must use the edit endpoint")
            if payload.reply_to_message_id is not None:
                cur.execute("SELECT 1 FROM messages WHERE message_id=%s::uuid AND conversation_id=%s::uuid",(payload.reply_to_message_id,conversation_id))
                if not cur.fetchone():
                    raise ValueError("reply target is not in this conversation")
            if expected==EncryptionMode.E2EE and (payload.body is not None or not payload.ciphertext_b64 or not payload.nonce_b64):
                raise ValueError("direct messages must contain ciphertext only")
            if expected==EncryptionMode.SERVER and not (payload.body or payload.attachments):
                raise ValueError("group messages require text or attachment")
            if expected==EncryptionMode.E2EE:
                cur.execute(
                    """INSERT INTO messages(conversation_id,sender_global_id,client_message_id,encryption_mode,message_type,e2ee_ciphertext,e2ee_nonce,key_id,ratchet_counter,sender_ephemeral_public_key_b64,recipient_prekey_id,reply_to_message_id,created_at)
                    VALUES(%s,%s,%s,'e2ee',%s,decode(%s,'base64'),decode(%s,'base64'),%s,%s,%s,%s,%s::uuid,to_timestamp(%s/1000.0))
                    ON CONFLICT(sender_global_id,client_message_id) DO UPDATE SET client_message_id=EXCLUDED.client_message_id RETURNING message_id::text,status""",
                    (conversation_id,sender_global_id,payload.client_message_id,payload.message_type,payload.ciphertext_b64,payload.nonce_b64,payload.key_id,payload.ratchet_counter,payload.sender_ephemeral_public_key_b64,payload.recipient_prekey_id,payload.reply_to_message_id,payload.created_at_epoch_ms))
            else:
                cur.execute(
                    """INSERT INTO messages(conversation_id,sender_global_id,client_message_id,encryption_mode,message_type,body_ciphertext,reply_to_message_id,created_at)
                    VALUES(%s,%s,%s,'server',%s,CASE WHEN %s IS NULL THEN NULL ELSE pgp_sym_encrypt(%s,%s) END,%s::uuid,to_timestamp(%s/1000.0))
                    ON CONFLICT(sender_global_id,client_message_id) DO UPDATE SET client_message_id=EXCLUDED.client_message_id RETURNING message_id::text,status""",
                    (conversation_id,sender_global_id,payload.client_message_id,payload.message_type,payload.body,payload.body,key,payload.reply_to_message_id,payload.created_at_epoch_ms))
            msg_id,status=cur.fetchone()
            attachment_records=[]
            for item in payload.attachments:
                if expected==EncryptionMode.E2EE:
                    cur.execute("""INSERT INTO message_attachments(message_id,client_attachment_id,kind,mime_type,file_name,byte_size,encryption_mode,data_ciphertext,nonce_b64) VALUES(%s,%s,%s,%s,%s,%s,'e2ee',decode(%s,'base64'),%s) RETURNING attachment_id::text""",(msg_id,item.client_attachment_id,item.kind.value,item.mime_type,item.file_name,item.byte_size,item.data_b64,item.nonce_b64))
                else:
                    cur.execute("""INSERT INTO message_attachments(message_id,client_attachment_id,kind,mime_type,file_name,byte_size,encryption_mode,data_ciphertext,nonce_b64) VALUES(%s,%s,%s,%s,%s,%s,'server',pgp_sym_encrypt_bytea(decode(%s,'base64'),%s),NULL) RETURNING attachment_id::text""",(msg_id,item.client_attachment_id,item.kind.value,item.mime_type,item.file_name,item.byte_size,item.data_b64,key))
                aid=cur.fetchone()[0]
                attachment_records.append(ChatAttachmentRecord(id=aid,client_attachment_id=item.client_attachment_id,kind=item.kind,mime_type=item.mime_type,file_name=item.file_name,byte_size=item.byte_size,nonce_b64=item.nonce_b64))
        conn.commit()
    return ChatMessageRecord(id=msg_id,conversation_id=conversation_id,sender_global_id=sender_global_id,client_message_id=payload.client_message_id,message_type=payload.message_type,encryption_mode=payload.encryption_mode,body=payload.body if expected==EncryptionMode.SERVER else None,ciphertext_b64=payload.ciphertext_b64,nonce_b64=payload.nonce_b64,key_id=payload.key_id,ratchet_counter=payload.ratchet_counter,sender_ephemeral_public_key_b64=payload.sender_ephemeral_public_key_b64,recipient_prekey_id=payload.recipient_prekey_id,reply_to_message_id=payload.reply_to_message_id,attachments=attachment_records,status=status,created_at_epoch_ms=payload.created_at_epoch_ms)


def chat_messages(conversation_id: str, global_id: int) -> list[ChatMessageRecord]:
    if storage_mode()=="memory":
        return memory.chat_messages(conversation_id,global_id)
    key=_secret("MESSAGE_ENCRYPTION_KEY")
    with connection() as conn:
        with conn.cursor() as cur:
            _ensure_member(cur,conversation_id,global_id)
            cur.execute(
                """INSERT INTO message_receipts(message_id,global_id,delivered_at)
                SELECT m.message_id,%s,now() FROM messages m
                WHERE m.conversation_id=%s::uuid AND m.sender_global_id<>%s
                ON CONFLICT(message_id,global_id) DO UPDATE SET delivered_at=COALESCE(message_receipts.delivered_at,EXCLUDED.delivered_at)""",
                (global_id,conversation_id,global_id))
            cur.execute(
                """SELECT m.message_id::text,m.sender_global_id,m.client_message_id,m.message_type,m.encryption_mode,
                CASE WHEN m.encryption_mode='server' AND m.body_ciphertext IS NOT NULL THEN pgp_sym_decrypt(m.body_ciphertext,%s) ELSE NULL END,
                CASE WHEN m.e2ee_ciphertext IS NULL THEN NULL ELSE encode(m.e2ee_ciphertext,'base64') END,
                CASE WHEN m.e2ee_nonce IS NULL THEN NULL ELSE encode(m.e2ee_nonce,'base64') END,m.key_id,m.ratchet_counter,m.sender_ephemeral_public_key_b64,m.recipient_prekey_id,m.reply_to_message_id::text,m.status,extract(epoch from m.created_at)*1000,extract(epoch from m.edited_at)*1000
                FROM messages m WHERE m.conversation_id=%s::uuid ORDER BY m.created_at ASC LIMIT 500""",(key,conversation_id))
            rows=cur.fetchall()
            result=[]
            for r in rows:
                cur.execute("SELECT attachment_id::text,client_attachment_id,kind,mime_type,file_name,byte_size,nonce_b64 FROM message_attachments WHERE message_id=%s::uuid ORDER BY created_at",(r[0],))
                atts=[ChatAttachmentRecord(id=a[0],client_attachment_id=a[1],kind=AttachmentKind(a[2]),mime_type=a[3],file_name=a[4],byte_size=int(a[5]),nonce_b64=a[6]) for a in cur.fetchall()]
                cur.execute("SELECT emoji,count(*)::int FROM message_reactions WHERE message_id=%s::uuid GROUP BY emoji ORDER BY emoji",(r[0],))
                reactions={emoji:int(count) for emoji,count in cur.fetchall()}
                cur.execute("SELECT count(*) FILTER (WHERE delivered_at IS NOT NULL)::int,count(*) FILTER (WHERE read_at IS NOT NULL)::int FROM message_receipts WHERE message_id=%s::uuid",(r[0],))
                delivered_count,read_count=cur.fetchone()
                result.append(ChatMessageRecord(id=r[0],conversation_id=conversation_id,sender_global_id=int(r[1]),client_message_id=r[2],message_type=r[3],encryption_mode=EncryptionMode(r[4]),body=r[5],ciphertext_b64=r[6],nonce_b64=r[7],key_id=r[8],ratchet_counter=r[9],sender_ephemeral_public_key_b64=r[10],recipient_prekey_id=r[11],reply_to_message_id=r[12],attachments=atts,status=r[13],created_at_epoch_ms=int(r[14]),edited_at_epoch_ms=int(r[15]) if r[15] is not None else None,reactions=reactions,delivered_count=int(delivered_count or 0),read_count=int(read_count or 0)))
            return result


def attachment_payload(attachment_id: str, global_id: int) -> AttachmentPayload | None:
    if storage_mode()=="memory":
        return memory.attachment_payload(attachment_id,global_id)
    key=_secret("MESSAGE_ENCRYPTION_KEY")
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""SELECT a.attachment_id::text,a.client_attachment_id,a.kind,a.mime_type,a.file_name,a.byte_size,a.nonce_b64,a.encryption_mode,
                CASE WHEN a.encryption_mode='server' THEN encode(pgp_sym_decrypt_bytea(a.data_ciphertext,%s),'base64') ELSE encode(a.data_ciphertext,'base64') END
                FROM message_attachments a JOIN messages m ON m.message_id=a.message_id JOIN conversation_members cm ON cm.conversation_id=m.conversation_id AND cm.global_id=%s WHERE a.attachment_id=%s::uuid""",(key,global_id,attachment_id))
            r=cur.fetchone()
    if not r:
        return None
    rec=ChatAttachmentRecord(id=r[0],client_attachment_id=r[1],kind=AttachmentKind(r[2]),mime_type=r[3],file_name=r[4],byte_size=int(r[5]),nonce_b64=r[6])
    return AttachmentPayload(attachment=rec,encryption_mode=EncryptionMode(r[7]),data_b64=r[8])


def mark_chat_read(conversation_id: str, global_id: int, message_id: str) -> bool:
    if storage_mode()=="memory":
        return memory.mark_chat_read(conversation_id,global_id,message_id)
    with connection() as conn:
        with conn.cursor() as cur:
            _ensure_member(cur,conversation_id,global_id)
            cur.execute("UPDATE conversation_members SET last_read_message_id=%s::uuid WHERE conversation_id=%s::uuid AND global_id=%s",(message_id,conversation_id,global_id))
            cur.execute("""INSERT INTO message_receipts(message_id,global_id,delivered_at,read_at)
                SELECT message_id,%s,now(),now() FROM messages WHERE message_id=%s::uuid AND conversation_id=%s::uuid AND sender_global_id<>%s
                ON CONFLICT(message_id,global_id) DO UPDATE SET delivered_at=COALESCE(message_receipts.delivered_at,EXCLUDED.delivered_at),read_at=EXCLUDED.read_at""",(global_id,message_id,conversation_id,global_id))
            cur.execute("UPDATE messages SET status='read' WHERE message_id=%s::uuid AND conversation_id=%s::uuid",(message_id,conversation_id))
        conn.commit()
    return True



def edit_chat_message(message_id: str, global_id: int, payload: ChatMessageEdit) -> ChatMessageRecord:
    if storage_mode()=="memory":
        return memory.edit_chat_message(message_id,global_id,payload)
    key=_secret("MESSAGE_ENCRYPTION_KEY")
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT conversation_id::text,encryption_mode,sender_global_id,status FROM messages WHERE message_id=%s::uuid",(message_id,))
            original=cur.fetchone()
            if not original:
                raise ValueError("message not found")
            conversation_id, mode, sender, status = original
            if int(sender) != global_id:
                raise ValueError("only the sender can edit this message")
            if status == "deleted":
                raise ValueError("deleted message cannot be edited")
            if mode != payload.encryption_mode.value:
                raise ValueError("encryption mode cannot change")
            _ensure_member(cur,conversation_id,global_id)
            event_id=str(uuid4())
            client_id=f"edit-{uuid4().hex[:16]}"
            if payload.encryption_mode == EncryptionMode.E2EE:
                if payload.body is not None or not payload.ciphertext_b64 or not payload.nonce_b64:
                    raise ValueError("E2EE edit must contain ciphertext only")
                cur.execute(
                    """INSERT INTO messages(message_id,conversation_id,sender_global_id,client_message_id,encryption_mode,message_type,e2ee_ciphertext,e2ee_nonce,key_id,ratchet_counter,sender_ephemeral_public_key_b64,recipient_prekey_id,reply_to_message_id,created_at,edited_at)
                    VALUES(%s::uuid,%s::uuid,%s,%s,'e2ee','edit',decode(%s,'base64'),decode(%s,'base64'),%s,%s,%s,%s,%s::uuid,to_timestamp(%s/1000.0),to_timestamp(%s/1000.0))""",
                    (event_id,conversation_id,global_id,client_id,payload.ciphertext_b64,payload.nonce_b64,payload.key_id,payload.ratchet_counter,payload.sender_ephemeral_public_key_b64,payload.recipient_prekey_id,message_id,payload.edited_at_epoch_ms,payload.edited_at_epoch_ms))
            else:
                if payload.body is None:
                    raise ValueError("group edit requires body")
                cur.execute(
                    """INSERT INTO messages(message_id,conversation_id,sender_global_id,client_message_id,encryption_mode,message_type,body_ciphertext,reply_to_message_id,created_at,edited_at)
                    VALUES(%s::uuid,%s::uuid,%s,%s,'server','edit',pgp_sym_encrypt(%s,%s),%s::uuid,to_timestamp(%s/1000.0),to_timestamp(%s/1000.0))""",
                    (event_id,conversation_id,global_id,client_id,payload.body,key,message_id,payload.edited_at_epoch_ms,payload.edited_at_epoch_ms))
        conn.commit()
    return ChatMessageRecord(
        id=event_id,conversation_id=conversation_id,sender_global_id=global_id,client_message_id=client_id,
        message_type="edit",encryption_mode=payload.encryption_mode,body=payload.body if payload.encryption_mode==EncryptionMode.SERVER else None,
        ciphertext_b64=payload.ciphertext_b64,nonce_b64=payload.nonce_b64,key_id=payload.key_id,ratchet_counter=payload.ratchet_counter,
        sender_ephemeral_public_key_b64=payload.sender_ephemeral_public_key_b64,recipient_prekey_id=payload.recipient_prekey_id,
        reply_to_message_id=message_id,attachments=[],status="sent",created_at_epoch_ms=payload.edited_at_epoch_ms,edited_at_epoch_ms=payload.edited_at_epoch_ms)


def toggle_message_reaction(message_id: str, global_id: int, emoji: str):
    if storage_mode()=="memory":
        return memory.toggle_message_reaction(message_id,global_id,emoji)
    allowed={"👍","🤝","❤️","🔥","👏","😂"}
    if emoji not in allowed:
        raise ValueError("unsupported reaction")
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT m.conversation_id::text FROM messages m JOIN conversation_members cm ON cm.conversation_id=m.conversation_id AND cm.global_id=%s WHERE m.message_id=%s::uuid",(global_id,message_id))
            if not cur.fetchone():
                raise ValueError("message not found or user is not a member")
            cur.execute("SELECT 1 FROM message_reactions WHERE message_id=%s::uuid AND global_id=%s AND emoji=%s",(message_id,global_id,emoji))
            if cur.fetchone():
                cur.execute("DELETE FROM message_reactions WHERE message_id=%s::uuid AND global_id=%s AND emoji=%s",(message_id,global_id,emoji))
            else:
                cur.execute("INSERT INTO message_reactions(message_id,global_id,emoji) VALUES(%s::uuid,%s,%s)",(message_id,global_id,emoji))
            cur.execute("SELECT message_id::text,global_id,emoji FROM message_reactions WHERE message_id=%s::uuid ORDER BY created_at",(message_id,))
            rows=cur.fetchall()
        conn.commit()
    return [MessageReactionRecord(message_id=r[0],global_id=int(r[1]),emoji=r[2]) for r in rows]

def delete_chat_message(message_id: str, global_id: int) -> bool:
    if storage_mode()=="memory":
        return memory.delete_chat_message(message_id,global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            # Soft-delete keeps the E2EE envelope/counter available for ratchet traversal, but removes
            # server-readable content and media. Android decrypts tombstones only to advance keys and never renders them.
            cur.execute("SELECT encryption_mode FROM messages WHERE message_id=%s::uuid AND sender_global_id=%s",(message_id,global_id))
            row=cur.fetchone()
            if not row:
                conn.rollback()
                return False
            if row[0] == "server":
                cur.execute("UPDATE messages SET status='deleted',deleted_at=now(),body_ciphertext=NULL WHERE message_id=%s::uuid",(message_id,))
            else:
                cur.execute("UPDATE messages SET status='deleted',deleted_at=now() WHERE message_id=%s::uuid",(message_id,))
            cur.execute("DELETE FROM message_attachments WHERE message_id=%s::uuid",(message_id,))
            cur.execute("DELETE FROM message_reactions WHERE message_id=%s::uuid",(message_id,))
        conn.commit()
    return True

def set_typing(conversation_id: str, global_id: int, typing: bool) -> bool:
    if storage_mode()=="memory":
        return memory.set_typing(conversation_id,global_id,typing)
    with connection() as conn:
        with conn.cursor() as cur:
            _ensure_member(cur,conversation_id,global_id)
            if typing:
                cur.execute("INSERT INTO conversation_typing(conversation_id,global_id,expires_at) VALUES(%s::uuid,%s,now()+interval '8 seconds') ON CONFLICT(conversation_id,global_id) DO UPDATE SET expires_at=EXCLUDED.expires_at",(conversation_id,global_id))
            else:
                cur.execute("DELETE FROM conversation_typing WHERE conversation_id=%s::uuid AND global_id=%s",(conversation_id,global_id))
        conn.commit()
    return True

def typing_users(conversation_id: str, global_id: int) -> list[int]:
    if storage_mode()=="memory":
        return memory.typing_users(conversation_id,global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            _ensure_member(cur,conversation_id,global_id)
            cur.execute("DELETE FROM conversation_typing WHERE expires_at<=now()")
            cur.execute("SELECT global_id FROM conversation_typing WHERE conversation_id=%s::uuid AND global_id<>%s AND expires_at>now() ORDER BY global_id",(conversation_id,global_id))
            rows=[int(r[0]) for r in cur.fetchall()]
        conn.commit()
    return rows

def app_version_manifest() -> AppVersionManifest:
    return AppVersionManifest(
        version_code=int(os.getenv("BROTHERHOOD_LATEST_VERSION_CODE","23")),
        version_name=os.getenv("BROTHERHOOD_LATEST_VERSION_NAME","0.5.18"),
        min_supported_version_code=int(os.getenv("BROTHERHOOD_MIN_VERSION_CODE","16")),
        play_url=os.getenv("BROTHERHOOD_PLAY_URL") or None,
        test_download_url=os.getenv("BROTHERHOOD_TEST_DOWNLOAD_URL") or None,
        release_notes=os.getenv("BROTHERHOOD_RELEASE_NOTES","Brotherhood scene-library-v4 composition diversity, controlled invite pilot and privacy-separated calibration traces."),
    )
