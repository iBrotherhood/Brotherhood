# Canonical visual-assessment registry for Brotherhood v0.5.18.
# All 100 psychological/behavioural blocks use neutral similarity semantics.
VALID_TEST_IDS = {f"f{number:03d}" for number in range(1, 101)}
SAFETY_CRITICAL_TEST_IDS: set[str] = set()
SIMILARITY_TEST_IDS = set(VALID_TEST_IDS)
PROFILE_SECTION_CODES = {"identity", "photo", "city", "about", "friendship_goals", "interests", "boundaries", "communication", "availability", "verification"}

# Shadow predictor kept separate from the canonical 100% compatibility weights.
FRIENDSHIP_EXPECTATION_TEST_IDS = {"f065", *(f"f{number:03d}" for number in range(71, 81))}

TEST_KIND_ORDER = [
    "loyalty", "integrity", "reliability", "conflict", "boundaries",
    "support", "competition", "communication", "mutual_aid", "lifestyle",
]
TEST_KIND_BY_ID = {
    f"f{number:03d}": TEST_KIND_ORDER[(number - 1) // 10]
    for number in range(1, 101)
}
