# Brotherhood Android Development Signing

## Status

This signing identity is for **DEVELOPMENT / INTERNAL TESTING ONLY**.

It is not a Google Play or production signing identity.

Canonical Android package identity:

- Application ID: `org.federationofavatars.brotherhood`
- Development build type: Android `debug`
- Production signing: **not configured in this workflow**

Android updates require all three conditions:

1. same `applicationId`;
2. same signing certificate;
3. higher `versionCode`.

## Why this exists

GitHub-hosted runners are ephemeral. A debug keystore generated automatically on a new runner is not a stable Brotherhood identity. Canonical Development APKs therefore fail closed unless the Brotherhood Development keystore is restored from GitHub Secrets.

There is no fallback from canonical Development signing to an automatically generated debug certificate.

## Create the Development keystore once

Run on a trusted local machine with JDK/keytool installed:

```bash
export BROTHERHOOD_DEV_KEYSTORE_PASSWORD='choose-a-strong-password'
export BROTHERHOOD_DEV_KEY_PASSWORD='choose-a-strong-key-password'
export BROTHERHOOD_DEV_KEY_ALIAS='brotherhood-development'

./scripts/create_development_keystore.sh Brotherhood-development-signing.jks
```

Keep the `.jks` file outside Git and back it up securely. Losing this key means future Development APKs cannot update already-installed canonical Development builds.

## Generate Base64 for GitHub Secret transport

Linux / Termux:

```bash
base64 -w 0 Brotherhood-development-signing.jks \
  > Brotherhood-development-signing.jks.b64
```

macOS:

```bash
base64 < Brotherhood-development-signing.jks \
  | tr -d '\n' \
  > Brotherhood-development-signing.jks.b64
```

The `.b64` file is private key material. Do not commit or send it in logs.

## Get the certificate SHA-256 fingerprint

```bash
keytool -list -v \
  -keystore Brotherhood-development-signing.jks \
  -alias brotherhood-development
```

Copy the `SHA256:` fingerprint. The fingerprint is public metadata and does not contain the private key.

## Configure GitHub

Repository → **Settings → Secrets and variables → Actions**.

Create four repository **Secrets**:

- `BROTHERHOOD_DEV_KEYSTORE_BASE64`
- `BROTHERHOOD_DEV_KEYSTORE_PASSWORD`
- `BROTHERHOOD_DEV_KEY_ALIAS`
- `BROTHERHOOD_DEV_KEY_PASSWORD`

`BROTHERHOOD_DEV_KEYSTORE_BASE64` is the complete one-line content of `Brotherhood-development-signing.jks.b64`.

Create one repository **Variable** (not a secret):

- `BROTHERHOOD_DEV_CERT_SHA256`

Set it to the certificate SHA-256 fingerprint returned by `keytool`. Colons and case are normalized by CI.

## CI behavior

The canonical Development workflow:

1. fails if any Development signing Secret is absent;
2. fails if `BROTHERHOOD_DEV_CERT_SHA256` is absent;
3. restores the keystore to `$GITHUB_WORKSPACE/.ci-signing/`;
4. sets permissions to `0600`;
5. validates the alias and keystore password;
6. validates the keystore certificate fingerprint;
7. runs unit tests;
8. builds `assembleDebug` signed by the Development key;
9. verifies the APK with `apksigner`;
10. verifies signer SHA-256 again from the APK;
11. verifies package metadata with Android build tools;
12. calculates the final APK SHA-256;
13. creates `DEVELOPMENT_SIGNING_REPORT.txt`;
14. uploads only the verified Development APK and non-secret reports.

No Release APK or AAB is produced by this Development workflow.

## Artifact naming

Example:

```text
Brotherhood-v0.5.18-development-b123.apk
```

Build class:

```text
DEVELOPMENT
NOT FOR PUBLIC DISTRIBUTION
NOT A PRODUCTION RELEASE
```

## Version rules

Every Development APK intended to update an installed build must have a greater `versionCode`.

For v0.5.18:

- `versionName = 0.5.18`
- `versionCode = 23`

Future versions must increase `versionCode`.

## First migration from old GitHub debug APKs

Older Brotherhood test APKs may have been signed by ephemeral GitHub debug certificates. The new permanent Development certificate cannot update an APK signed by a different certificate.

If Android reports:

```text
INSTALL_FAILED_UPDATE_INCOMPATIBLE
```

during the **first** migration to canonical Development signing, uninstall the old ephemeral-debug Brotherhood APK once, then install the canonical Development APK.

After that one-time transition, subsequent canonical Development APKs update normally as long as:

- application ID stays unchanged;
- the Development key stays unchanged;
- versionCode increases.

Uninstalling may remove local app data. Do not uninstall merely because a normal update prompt is shown.

## Android security warnings / Play Protect

A GitHub-downloaded APK is a sideloaded application. Android/Play Protect may still show standard warnings about installing from a browser, file manager, or unknown source.

Brotherhood does not disable or bypass:

- Google Play Protect;
- Android Package Installer;
- unknown-source protection;
- developer verification.

Stable signing removes Brotherhood-controlled sources of update/security confusion, but it cannot and should not suppress Android's standard sideload warnings.

## Production signing

Do not use the Development key for production.

Production must later use a separate:

```text
Brotherhood Production Signing Identity
```

with a separate security and release process.
