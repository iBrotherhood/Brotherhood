# AI TEMPORARY MEMORY — ACTIVE

Status: v0.5.18 corrective source locally qualified; exact-HEAD GitHub CI pending

## Active task
Qualify the three Kotlin compilation failures proven by GitHub run `83241548302`, synchronize repository workflow metadata with the new corrective HEAD, and package v0.5.18 without changing product algorithms.

## Confirmed implementation state
- `AssessmentLocalStore` now persists and restores `composition_variant`;
- `CoreProfileQuestion` now carries the deterministic non-scoring composition variant required by the visual UI;
- `MainViewModel` no longer passes the retired `friendshipExpectationsScore` argument;
- stale Android unit tests no longer expect active Friendship Expectations or moral risk flags;
- active model remains `visual-latent-v2`; stimulus provenance remains `scene-library-v4`;
- Compatibility weights, Vedic 5%, controlled pilot, applicationId and signing policy are unchanged;
- canonical workflows must expect `versionName 0.5.18` and `versionCode 23`.

## Completed verification
- Python/backend/architecture regression: 99/99 PASS;
- focused pure Kotlin core compilation: PASS;
- OpenAPI: 0.5.18 / 45 paths;
- full local Android Gradle/APK could not run because the sandbox cannot resolve `github.com` to retrieve the verified wrapper JAR.

## Exact next safe action
Run the v0.5.18 canonical GitHub archive through `android-build.yml` until `ANDROID_CI_APK_ARTIFACT_PASS`. Do not open the controlled pilot before exact-HEAD Android CI passes.
