# Загрузка Brotherhood v0.5.23 в GitHub

## Постоянная структура репозитория

Один раз в корне GitHub должны находиться:

```text
Brotherhood.zip
.github/workflows/android-build.yml
```

`android-build.yml` является универсальным и после принятия не меняется между версиями. В каждом следующем цикле заменяется только канонический `Brotherhood.zip`.

## Обновление рабочего HEAD

1. Заменить файл `Brotherhood.zip` в корне репозитория.
2. Не переименовывать его.
3. Не менять workflow из-за повышения versionName/versionCode.
4. Запустить `Build Brotherhood APK from Brotherhood.zip`.

Workflow сам:

- проверяет ZIP;
- распаковывает `Brotherhood/`;
- запускает unit tests и Kotlin compile;
- собирает APK;
- извлекает фактические versionName/versionCode;
- проверяет applicationId/minSdk/targetSdk;
- проверяет v2 signature;
- динамически именует APK/artifact;
- выводит `ANDROID_CI_APK_ARTIFACT_PASS`.

## Development APK

В `NON_CANONICAL_DEBUG` APK предназначена для uninstall/reinstall. Workflow не устраняет предупреждения AVG, Play Protect или Unknown Sources. Обновление поверх предыдущей APK гарантируется только при одном постоянном Development certificate.

## Backend

Для Vercel/Neon нужны реальные production variables и credentials. Android APK не получает серверные secrets.
