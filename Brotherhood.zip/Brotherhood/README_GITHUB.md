# Загрузка Brotherhood v0.5.17 в GitHub

## Каноническая загрузка

1. Распаковать `Brotherhood_GitHub_Canonical_v0_5_14.zip`.
2. Открыть верхнюю папку `Brotherhood/`.
3. Загрузить **содержимое** этой папки в корень GitHub-репозитория.
4. Проверить, что в корне GitHub находятся `android/`, `backend/`, `database/`, `.github/` и `Brotherhood.zip`.

Верхняя папка `Brotherhood/` обязательна внутри выдаваемого ZIP. В GitHub её содержимое становится корнем репозитория, чтобы GitHub видел `.github/workflows`.

## Канон исходников и тестового APK

- Канонический источник — распакованный код GitHub.
- `Brotherhood.zip` — детерминированный снимок этого же исходного кода для тестовой APK-сборки.
- `source-check.yml` отклоняет commit, если `Brotherhood.zip` расходится с распакованным кодом.

## Тестовая сборка APK из архива

```text
Actions → Build Brotherhood test APK from Brotherhood.zip → Run workflow
```

`android-build.yml`:

1. проверяет `Brotherhood.zip`;
2. распаковывает верхнюю папку `Brotherhood/`;
3. находит `Brotherhood/android/settings.gradle.kts`;
4. запускает Android unit tests;
5. выполняет `assembleDebug`;
6. публикует APK и SHA-256 в GitHub Artifacts.

## Прямая сборка распакованного кода

```text
Actions → Build Brotherhood APK from unpacked source → Run workflow
```

Внутренний `.github/workflows/android-source-build.yml` собирает `android/` напрямую.

## Vercel + Neon

Подключить тот же GitHub-репозиторий к Vercel и выбрать Root Directory `backend`.

Минимальные production variables:

- `DATABASE_URL` — pooled Neon PostgreSQL URL;
- `INTERNAL_AUTH_SECRET`;
- `TRUST_ENCRYPTION_KEY`;
- `MESSAGE_ENCRYPTION_KEY`;
- `BROTHERHOOD_ALLOWED_ORIGINS`;
- provider credentials Google / Telegram / Facebook по мере подключения.

Android APK никогда не получает `DATABASE_URL` или серверные секреты.
