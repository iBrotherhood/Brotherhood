# Change cycle — EMPIRICAL_CALIBRATION_I18N v0.5.15

## Scope
Sequential functional cycle on top of v0.5.14. No architecture reset, no applicationId/signing/Compatibility-weight change.

## Cycle A — empirical calibration readiness
- active psychological model: `visual-latent-v2`;
- stimulus library: `scene-library-v2`;
- 100 blocks × 6 = 600 indirect visual-associative tasks;
- 24 neutral scene archetypes and 12 visual paradigms;
- exact private item-level response trace added for calibration provenance;
- offline calibration SQL + Python diagnostics added;
- diagnostics cover option concentration, entropy, scene/paradigm exposure, cross-language distribution drift and optional cross-validated 90-day outcome association;
- every calibration output is review-only: no automatic production loading/weight mutation and no causal claim from correlation.

Actual empirical coefficient fitting is **DATA_PENDING** because no real Brotherhood cohort/outcome dataset was supplied in this cycle.

## Cycle B — quality-fit evolution
- user-selectable catalog expanded from 84 to 112 qualities;
- simple and multi-coordinate composite qualities remain context-dependent, not moral scores;
- role/context never injects desired qualities;
- backend/shared/Android catalog parity is guarded;
- Quality Fit remains separate from Compatibility, Trust and Account Completeness.

## Cycle C — scalable whole-app localization
- `AppLanguage` is a runtime descriptor, not a fixed enum;
- current complete packs: RU / UK / EN;
- selector is a horizontal carousel;
- selected locale controls navigation, sections, assessment presentation, public results, Quality Fit labels, self-analysis, numerology, status text, Zodiac labels, built-in city labels and bundled DEBUG fixture presentation;
- RTL/LTR is read from locale metadata;
- language activation is fail-closed against a complete required-key set plus numerology locale coverage;
- generated translation memory currently contains 582 source entries and 713 required runtime keys;
- built-in geography uses locale-dependent labels while stable search/storage values do not change (`Киев` storage/search value can render as `Киев`, `Київ`, or `Kyiv`);
- arbitrary user-authored text and geographic strings are not silently machine-translated.

## Causal Kernel additions
Allowed:
`locale carousel -> complete pack -> localized presentation`.

Forbidden:
- locale -> different latent/Compatibility scoring;
- incomplete locale -> visible carousel option;
- locale -> rewrite canonical city/search/storage value;
- locale -> silently rewrite arbitrary user-authored content;
- response trace -> public API;
- calibration correlation -> automatic production model mutation.

## Validation
- Python/backend/architecture regression: 85/85 PASS.
- Pure Kotlin core compile/smoke: PASS (100 / 600 / 50 / 112 / 24 / 12 / visual-latent-v2).
- OpenAPI: PASS, v0.5.15, 42 paths.
- Locale city/API targeted regression included in the 85-test suite.
- Full Android Gradle/APK: deferred to existing GitHub CI because the source environment has no `gradle-wrapper.jar`; no repeated network-dependent Gradle retries.
- Real PostgreSQL migration execution: environment-deferred.

## Next evidence cycle
1. GitHub Android CI -> `ANDROID_CI_APK_ARTIFACT_PASS`.
2. Collect private `visual-latent-v2` response/outcome data.
3. Run calibration diagnostics only after minimum sample thresholds are met.
4. Review candidate changes as a new explicit model version; never silently mutate v2.
