# Change cycle — PSYCHOLOGICAL_MATCHING v0.5.14

## Request
Implement the agreed hidden visual/associative psychological model, positive-only public interpretation, user-authored desired qualities, role/context-specific Quality Fit, complete canon fixation and causal Kernel.

## Primary route
`psychological_visual_matching`

Secondary/validation routes: `database`, `kernel_archive`, `release_packaging`.

## Main implementation units
1. Canon + causal Kernel + forbidden edges.
2. Visual task model and hidden loadings.
3. Private latent-profile aggregation and legacy quarantine.
4. User-authored SearchIntent + 84 simple/composite qualities.
5. Quality Fit and positive public projection.
6. Public API/UI privacy boundary.
7. Outcome snapshot/calibration loop without automatic production changes.
8. Regression guards and release validation.

## Preserved invariants
- Compatibility 15-layer weights unchanged and total 100%.
- Vedic numerology remains 5% and is not a psychological test.
- Trust and Account Completeness remain separate.
- `applicationId`, logo master, Android security/signing policies unchanged.

## Verdict
LOCAL_PASS_LIVE_DEFERRED — all available local gates pass; GitHub Android CI and real PostgreSQL migration execution remain environment gates.
