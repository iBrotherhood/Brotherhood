# Change cycle — VISUAL_COMPOSITION_CONTROLLED_PILOT v0.5.17

## Observation and evidence
Run 83237541436 failed in `:app:compileDebugKotlin` at `BrotherhoodApp.kt:2617:2` with `Expecting '}'`. No successful unit-test, assemble, APK, signing, metadata or artifact-upload marker exists in that run.

## Root cause
The compatibility UI source was truncated: two Kotlin blocks remained open and the `CompatibilityMetric` declaration was lost.

## Minimal source repair
Restored the complete `CompatibilityPanel`, all 15 canonical layers and `CompatibilityMetric`. Did not alter compatibility weights and did not restore the retired fixed-ID Friendship Expectations score.

## Functional continuation
- `scene-library-v4`;
- 48 scenes / 16 paradigms / 8 deterministic non-scoring compositions;
- same composition behind all four choices;
- private composition telemetry only;
- controlled closed pilot with one-use digest invitations and quotas;
- transient invite handling;
- unconditional withdrawal and raw-attempt purge.

## Validation
98/98 Python/backend/architecture tests PASS; pure Kotlin core smoke PASS; OpenAPI 0.5.17/45 paths; language packs regenerated. Full Android/APK qualification remains GitHub-CI pending.
