# Change cycle — VISUAL_CALIBRATION_PILOT v0.5.16

## Goal
Expand the indirect visual stimulus bank and make the first-user calibration pipeline technically usable without weakening the causal/privacy Kernel.

## Implemented
1. `scene-library-v3`: 48 scenes / 16 paradigms across the actual 600-task bank.
2. Single deterministic option-presentation source shared by UI and scorer.
3. Calibration trace: presentation slot, first-selection latency, selection changes, question position.
4. Separate opt-in calibration consent/attempt store; active aggregate profile strips raw trace.
5. Withdrawal purges raw attempts.
6. Early-pilot item export plus temporally guarded outcome export.
7. Calibration report v2: item entropy/concentration, position bias, latency, locale drift, retest, coverage, pilot stage and optional 90d predictive diagnostics.
8. Private runner with `umask 077` and default raw-CSV purge.
9. Canon/causal Kernel/NORM updated with consent, withdrawal and temporal-leakage forbidden edges.

## Not changed
- applicationId;
- Compatibility weights;
- Vedic 5%;
- Trust / Account Completeness semantics;
- 112-quality user-authored Quality Fit principle;
- master logo/signing architecture;
- CI logic except expected functional release metadata.
