# Change cycle — ANDROID_COMPILE_CORRECTIVE v0.5.18

## Observation
Run `83241548302` failed in `:app:compileDebugKotlin` before tests, assemble, APK validation or artifact upload.

## Root causes
1. Local response-trace deserialization omitted the newly required composition field.
2. Core profile visual questions did not carry the composition field consumed by UI.
3. MainViewModel retained a named argument removed from HybridCompatibilityEngine.
4. Stale unit tests still asserted retired diagnostics.
5. The repository-level workflow observed in GitHub still expected historical metadata `0.5.11 / 16`.

## Minimal safe fix
Only the affected source, tests, active metadata and release documentation were changed. Product formulas and pilot architecture were not modified.

## Verification
- `PYTHONPATH=backend python -m pytest -q backend/tests tests/architecture` → 99 passed.
- focused `kotlinc` compile over visual/core-profile model and engines → PASS.
- exact-HEAD Android CI → pending.
