# SESSION HANDOFF — Brotherhood v0.5.17

## Current HEAD
Brotherhood v0.5.17 / versionCode 22 / `org.federationofavatars.brotherhood`.

## Active request completed locally
Fixed run 83237541436 source failure; expanded composition diversity inside 48 scenes; prepared first controlled pilot cohort without changing calibration architecture.

## Confirmed canon
- 100 × 6 indirect visual psychological tasks; numerology is not a test.
- Hidden inference only; public interpretation positive/contextual.
- User selects desired qualities; role injects none.
- Quality Fit separate from Compatibility / Trust / Completeness.
- Composition is non-scoring calibration evidence.
- No raw trace retention without current controlled-pilot enrollment.
- Calibration never auto-mutates production.

## Active model
- scoring: `visual-latent-v2`;
- stimulus: `scene-library-v4`;
- 48 scenes / 16 paradigms / 8 compositions / 50 latent coordinates / 112 qualities.

## Validation completed
- backend + architecture 98/98 PASS;
- pure Kotlin core PASS;
- OpenAPI 0.5.17 / 45 paths;
- locale catalog 610/741 RU-UK-EN;
- source static security/workflow checks PASS; final ZIP replay pending packaging.

## Deferred/live checks
- exact-HEAD GitHub Android CI/APK;
- real PostgreSQL migration/quota concurrency;
- real controlled cohort and calibration evidence.

## Exact next safe action
Run v0.5.17 through canonical GitHub CI. Only after CI pass, open the controlled pilot with configured digest invitations and quotas; start with the optional functional wave or the 18-person RU/UK/EN wave defined in the protocol.
