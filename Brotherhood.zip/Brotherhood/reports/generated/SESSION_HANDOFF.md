# SESSION HANDOFF — Brotherhood v0.5.16

## Current HEAD
Brotherhood v0.5.16 / versionCode 21 / `org.federationofavatars.brotherhood`.

## Active request completed locally
Expanded visual stimulus bank and first-user real-data calibration pipeline.

## Confirmed canon
- 100 × 6 indirect visual psychological tasks; numerology is not a test.
- Hidden inference only; user-facing interpretation positive/contextual.
- User selects desired qualities; role injects none.
- Quality Fit separate from Compatibility / Trust / Completeness.
- No raw calibration retention without explicit opt-in.
- Calibration never auto-mutates production.

## Active model
- scoring: `visual-latent-v2`;
- stimulus: `scene-library-v3`;
- 48 scenes / 16 paradigms / 50 latent coordinates / 112 user-selectable qualities.

## Validation completed
- backend + architecture 89/89 PASS;
- i18n 14/14 PASS after regeneration;
- pure Kotlin core smoke PASS;
- OpenAPI 0.5.16 / 44 paths;
- source static security/workflow checks PASS.

## Deferred/live checks
- real PostgreSQL migration/export;
- canonical GitHub Android CI/APK;
- real empirical calibration after opt-in cohort data exists.

## Exact next safe action
Run v0.5.16 through canonical GitHub Android CI. When real users opt into calibration, run the `early` pipeline first; do not modify model loadings from synthetic or sparse data.
