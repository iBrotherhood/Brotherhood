# SESSION HANDOFF

## Current HEAD

Brotherhood v0.5.20 / versionCode 25.

## Active user request

Create the new archive and decide workflow policy.

## Decision

Use one new universal `android-build.yml` in this cycle, then freeze it. Future cycles replace only canonical `Brotherhood.zip`.

## Main changes

Positive test results, strengths on Home/Profile, discovery history, scalable language carousel, screenshot-confirmed UX fixes, honest manual Development install UI and universal CI.

## Validation

106 backend/architecture tests PASS; 32 pure Kotlin unit methods PASS; OpenAPI 0.5.20/45; locale 617/748; static workflow/security checks PASS.

## Deferred

GitHub exact-HEAD Compose/APK build and screenshot review of the newly built APK.

## Next safe action

Upload the final universal workflow once and then run it with the final `Brotherhood.zip`. Do not modify YAML on later releases.
