# Independent verification — Brotherhood v0.5.20

## Backend and architecture

Command: `pytest -q backend/tests tests/architecture`

Observed: `106 passed`.

## Pure Kotlin model/unit tests

Android-free model/data/domain sources plus all unit-test classes were compiled with `kotlinc` and executed through a local JUnit-compatible runner.

Observed: `KOTLIN_UNIT_PASS methods=32`.

This includes PositiveProfileProjector first-completion and retake checks.

## API and localization

- OpenAPI: `0.5.20`, 45 paths.
- Locale generator: 617 translation entries, 748 required runtime keys, enabled RU/UK/EN.
- Twelve-language registry fixture includes LTR and RTL metadata; incomplete languages remain disabled.

## Static checks

- JSON: 45 PASS.
- Android XML: 15 PASS.
- Python compile: 30 PASS.
- Universal workflow YAML: PASS.
- Workflow shell blocks: 10/10 `bash -n` PASS.
- Android security invariants: PASS.
- aapt/apksigner parser regression: PASS.
- private signing material: absent.

## Environment boundary

Full Android Compose/APK exact-HEAD build is not claimed locally because the source intentionally lacks `gradle-wrapper.jar` and the environment cannot reliably fetch it. GitHub CI is the exact-HEAD gate.

Verdict: LOCAL_PASS_LIVE_DEFERRED.
