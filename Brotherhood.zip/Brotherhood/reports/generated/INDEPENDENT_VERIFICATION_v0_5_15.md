# Independent verification — Brotherhood v0.5.15

Verifier mode: read/test/diff only after implementation freeze; no source correction is claimed by this report.

### Check: backend + architecture regression
Command run:
`PYTHONPATH=backend pytest -q backend/tests tests/architecture`

Output observed:
`85 passed in 2.63s`

Expected: all tests pass.  
Actual: all 85 pass.  
Result: **PASS**

### Check: pure Kotlin core
Command run:
`kotlinc` over Android-free model/data/domain core plus localization stub, followed by v0.5.15 smoke jar.

Output observed:
`BH_V15_SMOKE_PASS tests=100 tasks=600 traits=50 qualities=112 scenes=24 paradigms=12 model=visual-latent-v2`

Expected: compile and invariant smoke pass.  
Actual: PASS; only pre-existing unused-parameter warnings.  
Result: **PASS**

### Check: OpenAPI
Command run:
Generate `docs/openapi.json` from `app.openapi()`.

Output observed:
`OPENAPI_PASS version=0.5.15 paths=42`

Result: **PASS**

### Check: parsers / security
Observed before packaging:
- JSON parse PASS;
- Android XML parse PASS;
- source workflow YAML PASS;
- every source workflow `run:` block `bash -n` PASS;
- AAPT package quoted-field regression PASS;
- apksigner `certificate SHA-256 digest` semantic-marker regression PASS;
- `allowBackup=false`, `usesCleartextTraffic=false`, FileProvider non-exported PASS;
- no `REQUEST_INSTALL_PACKAGES`, no `READ_MEDIA_*`, no private signing material PASS.

Result: **PASS**

### Adversarial probe: locale must not rewrite search identity
Observed:
- built-in city `kyiv` has stable value `Киев`;
- UI/API labels render `Киев` / `Київ` / `Kyiv`;
- English label still searches people using stable value and returns canonical demo candidate.

Result: **PASS**

### Adversarial probe: calibration cannot self-modify production
Observed:
- analysis tool emits review statuses only;
- `automatic_production_mutation=false`;
- causal Kernel forbids correlation -> silent model mutation;
- raw response trace is absent from public assessment receipt.

Result: **PASS**

### Environment-deferred gates
- full Android/Compose/Gradle/APK: `gradle-wrapper.jar` absent locally -> **LOCAL_PASS_LIVE_DEFERRED** to canonical GitHub CI;
- real PostgreSQL migration/export execution: **PARTIAL_ENVIRONMENT**;
- empirical visual loading calibration: **DATA_PENDING**, because no real cohort/outcome dataset exists in this cycle.

Final local verdict: **LOCAL_PASS_LIVE_DEFERRED**
