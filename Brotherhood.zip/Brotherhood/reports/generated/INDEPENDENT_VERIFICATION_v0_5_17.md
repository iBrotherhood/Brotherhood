# Independent verification — Brotherhood v0.5.17

### Check: GitHub failure classification
Command/evidence: full extracted run log from `logs_83237541436.zip`.
Observed: `:app:compileDebugKotlin FAILED`; `BrotherhoodApp.kt:2617:2 Syntax error: Expecting '}'`.
Expected: Kotlin source compiles.
Actual: source section was truncated.
Result: FAIL in old run / repaired in v0.5.17.

### Check: structural source guard
Observed: balanced Kotlin structure; complete 15-layer Compatibility panel; `CompatibilityMetric` declaration present.
Result: PASS.

### Check: backend and architecture
Command: `PYTHONPATH=backend python -m pytest -q`.
Observed: `98 passed`.
Result: PASS.

### Check: OpenAPI
Observed: API `0.5.17`, 45 paths.
Result: PASS.

### Check: stimulus-bank smoke
Observed: 100 blocks / 600 tasks / 50 latent coordinates / 112 qualities / 48 scenes / 16 paradigms / 8 compositions / `scene-library-v4`.
Result: PASS.

### Check: controlled cohort privacy
Observed: closed default, transient invite code, digest-only redemption, quotas, opt-in raw trace, unconditional withdrawal purge, public raw-latent exclusion.
Result: PASS.

### Check: full Android APK
Observed: local environment does not provide reliable full Gradle/APK qualification.
Result: LOCAL_PASS_LIVE_DEFERRED; exact-HEAD GitHub CI required.
