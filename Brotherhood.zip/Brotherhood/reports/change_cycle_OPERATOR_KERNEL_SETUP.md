# Change cycle — Operator Kernel setup

- Before: **ABSENT** (`START_HERE.md` / `KERNEL.md` absent in v0.5.12).
- After: **ACTIVE_OPERATOR_KERNEL**.
- Added compact startup/dispatch Kernel, Brotherhood vocabulary/anchors, runtime-primary routes config/resolver, route capsules, scoped rules, enforcement matrix, hooks/agents/skills registries, memory/risk/verification norms and healer guards.
- Runtime tooling is isolated under `ops/operator_kernel/` and does not alter Android/backend business behavior.
- Composite request regression: numerology + Android + release resolves to `numerology_self_analysis` primary with release validation route.
- Architecture/behavior tests are included in the 40/40 affected local PASS set.
- File map is refreshed after final source edits and before packaging.
