# KERNEL — Brotherhood

## 1. Project identity and current HEAD
- Project: Brotherhood.
- Domain: platonic male friendship 18+, discovery, compatibility, trust, communication, groups, mutual aid, business/projects and self-analysis.
- Current/target state is read from `PROJECT_MANIFEST.json`; do not duplicate fast-changing CI/version facts here.
- Kernel status after this cycle: ACTIVE_OPERATOR_KERNEL.

## 2. Top project goal
Preserve working Brotherhood behavior while moving sequentially toward a production-ready Android + server product. Fix or extend only the requested scope with evidence and regression checks.

## 3. Top Kernel goal
Active dispatch layer: classify requests with Brotherhood vocabulary, route to exact canonical anchors/files, enforce write boundaries, validation and proof without rereading the whole archive.

## 4. What Kernel is not
Not navigation-only; not a copy of the archive; not a replacement for CANON/SSOT/NORM; not permission for broad refactors; not a reason to read all files.

## 5. Active truth hierarchy
1. Current explicit user instruction. 2. Confirmed user CANON. 3. This KERNEL. 4. `docs/CANON/**`. 5. `docs/SSOT/**`. 6. `docs/NORM/**`. 7. ADR/rules/healer. 8. Runtime code/config. 9. Tests/CI. 10. Current reports/logs. 11. Historical/reference.

## 6. Mandatory startup route
Read `START_HERE.md`, this file, active task/handoff, instruction registry, relevant CANON/SSOT/NORM, keywords/route map, `file_map.summary.json`; resolve primary/composite route; load only route capsule/rules/anchors and exact source files before edit; determine validation/proof before change.

## 7. Language, glossary and canonical spellings
Primary operator language: Russian. UI: data-driven multilingual runtime; currently RU/UK/EN, future locales via complete language packs and carousel. Canonical product terms include `Brotherhood`, `global_id`, `Trust Score`, `Compatibility`, `Account Completeness`, `Brotherhood-32`, `Enneagram`, `Vedic numerology`, `Quality Fit`, retired `Friendship Expectations v0.5.12`, `SearchIntent`, `visual-latent-v2`, `NON_CANONICAL_DEBUG`. See keyword registry.

## 8. Keywords and triggers
The full dictionary is `docs/AI/PROJECT_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md`. Major groups: psychological visual matching / Quality Fit; numerology/self-analysis; compatibility; Android/UI; backend/API; auth/security; database/migrations; CI/signing/APK; release/archive; tests/logs; kernel/docs/reference.

## 9. Keyword → query class → route → anchor
Runtime-primary route definitions: `ops/operator_kernel/config/routes.yaml`. Human map: `docs/AI/PROJECT_OPERATOR_KERNEL_ROUTE_MAP.md`. Composite requests retain all critical routes.

## 10. Canonical anchors / WHERE_FIXED
Product canon: `docs/CANON/BROTHERHOOD_PRODUCT_CANON.md`; psychological matching canon: `docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md`; localization canon: `docs/CANON/BROTHERHOOD_LOCALIZATION_CANON.md`; causal/forbidden-edge anchor: `docs/AI/CAUSAL_RELATIONSHIP_KERNEL.md`; current technical state: `docs/SSOT/CURRENT_STATE.md`; rules: `docs/NORM/**`; current source files listed by route.

## 11. Context capsule rules
Use only `ops/operator_kernel/capsules/<route>.json` for the active route. Never preload full file map, all docs, all reports or all logs.

## 12. Patch permission boundary
Each route defines `required_read`, `allowed_write`, `forbidden_write`, risk and validation. Read target files before editing. No adjacent refactors or dependency/version/CI/signing changes unless required by the active task.

## 13. Forbidden drift
Do not turn Brotherhood into dating; do not change `applicationId`; do not merge Trust/Compatibility/Completeness; do not use provider ID as owner; do not use names in Vedic friendship compatibility; do not change the fixed 5% Vedic compatibility weight without explicit user instruction; do not change master logo or signing/CI without route evidence; do not reintroduce direct socially desirable psychological questions; do not expose raw latent coordinates; do not turn Quality Fit into a moral score; do not inject desired qualities from a role; do not let legacy direct-question results feed `visual-latent-v2`; do not retain raw calibration traces without explicit opt-in; do not use post-match assessments to explain earlier outcomes; do not convert calibration heuristics into automatic production changes.

## 14. Validation gates
Route-specific tests plus syntax/parse, affected unit tests, security/static checks where applicable, archive CRC/top-folder/parity, and GitHub Android CI for full APK qualification when local Gradle environment cannot run reliably.

## 15. Proof and reports
Every completion claim needs changed-file list + command/test result or artifact/hash. Reports live in `reports/generated/`; history in `reports/historical/`.

## 16. Runtime route resolver
`python ops/operator_kernel/operator_kernel.py resolve "..."`. `routes.yaml` (JSON-compatible YAML) is the runtime-primary route source; Python hardcodes only fallback behavior.

## 17. File-map freshness
Run `python ops/operator_kernel/operator_kernel.py refresh-map` after all edits and before final packaging. Summary must be generated from the final tree.

## 18. Healer guards
See `docs/healer/**`: demotion, overload, keyword loss, route staleness, full-read regression, runtime disconnect, memory pollution and archive mixing.

## 19. Operational AI memory
Only active unresolved work in `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md`; promote stable facts into CANON/SSOT/NORM and move completed history to reports.

## 20. Archive and release rules
Keep deterministic top folder `Brotherhood/`; `Brotherhood.zip` must be byte-identical to versioned source; canonical GitHub archive must contain the same nested source archive. Never package secrets/private signing material.

## 21. Next safe cycle
Read `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md` and `reports/generated/SESSION_HANDOFF.md`; continue only the explicitly pending route.
