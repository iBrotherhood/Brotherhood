# Brotherhood

## 0.5.19 — 2026-08-01

Corrective Android unit-test release for GitHub run `83256062351`.

- Main `compileDebugKotlin` was already successful.
- Replaced stale direct-question unit-test contracts with visual-latent-v2 / scene-library-v4 contracts.
- Corrected Enneagram visual-choice testing to follow hidden loadings rather than fixed answer positions.
- Corrected cross-test integrity testing: contradictions reduce internal consistency but never create moral risk or public flags.
- Added an architecture regression guard for the exact unresolved legacy members.
- Android: `versionCode 24`, `versionName 0.5.19`.
- Production algorithms and product canon are unchanged.

## 0.5.18 — 2026-08-01

Corrective Android source release for GitHub run `83241548302`.

- Fixed `AssessmentLocalStore` persistence/restoration of `composition_variant`.
- Added deterministic composition metadata to Brotherhood-32 and Enneagram visual questions.
- Removed the retired `friendshipExpectationsScore` named argument from active hybrid compatibility calculation.
- Updated stale Android unit tests that still expected the retired Friendship Expectations diagnostic and moral risk flags.
- Added an architecture regression guard for all three exact compiler errors.
- Android: `versionCode 23`, `versionName 0.5.18`.
- Product canon, Compatibility weights, Vedic 5%, controlled pilot architecture, signing and applicationId are unchanged.

## 0.5.17 — 2026-08-01
- fixed GitHub run 83237541436 Kotlin source failure: restored the truncated `CompatibilityPanel`, its closing structure and `CompatibilityMetric`; all 15 canonical compatibility layers are present and the retired Friendship Expectations shadow was not reintroduced;
- retained hidden scoring `visual-latent-v2` and upgraded stimulus provenance to `scene-library-v4`;
- expanded each of the 48 scenes with eight deterministic non-scoring composition variants while keeping one shared composition behind all four choices in a task;
- recorded `composition_variant` only as private calibration evidence and prohibited it from affecting latent scoring;
- introduced the first controlled pilot cohort: closed-by-default enrollment, explicit acknowledgement, one-use invitation SHA-256 digests, total/locale quotas and unconditional withdrawal;
- separated plaintext invitation handling from persistent/offline storage; invitation codes are never committed, queued, logged or stored in PostgreSQL;
- preserved raw item-level trace only for an active current-cohort participant; ordinary users send/store aggregate profiles only;
- added controlled-pilot status/enrollment APIs, transactional PostgreSQL quota enforcement and invite-redemption records containing digests only;
- regenerated whole-app RU/UK/EN language packs and OpenAPI; future language activation remains fail-closed on complete coverage;
- Android: `versionCode 22`, `versionName 0.5.17`.

## 0.5.16 — 2026-08-01
- retained the active hidden scoring model `visual-latent-v2` and upgraded stimulus provenance to `scene-library-v3`;
- expanded the actual 600-task generator from 24 to 48 neutral scene archetypes and from 12 to 16 visual paradigms;
- made option presentation deterministic and shared between UI and scorer so presentation-slot bias is measurable;
- added calibration-only presentation slot, first-selection latency, answer-change count and randomized task-position trace fields;
- separated aggregate operational profile results from raw item-level calibration attempts; raw server retention now requires explicit `calibration-consent-v1` opt-in and withdrawal purges retained raw attempts;
- added early-pilot and temporally guarded pre-match 30/90-day PostgreSQL calibration exports;
- expanded offline diagnostics with position-bias, latency, language drift, retest, scene/paradigm coverage and pilot-readiness reporting;
- added a private calibration runner that purges row-level CSV by default;
- preserved 112 user-selected qualities, 15-layer Compatibility, Trust/Completeness separation and Vedic numerology at 5%;
- Android: `versionCode 21`, `versionName 0.5.16`.


## 0.5.15 — 2026-08-01

### Empirical-calibration readiness, scene library v2 and scalable localization
- promoted active psychological provenance to `visual-latent-v2` / `scene-library-v2`;
- expanded the hidden visual scene library to 24 neutral archetypes across 12 paradigms while preserving 100 blocks × 6 = 600 indirect tasks;
- added private versioned item-level response trace for empirical diagnostics; raw trace/latent data remain internal-only;
- added review-only calibration tooling for option concentration, entropy, scene/paradigm coverage, cross-locale drift and 90-day outcome association; calibration never mutates production automatically;
- expanded the user-authored Quality Fit catalog from 84 to 112 positive/contextual qualities; role still injects no defaults;
- introduced data-driven language registry/packs and language carousel; current complete packs are RU/UK/EN and future languages are activation-gated by full coverage;
- language direction supports `ltr`/`rtl`; changing language refreshes server-localized surfaces without changing scoring semantics;
- fixed remote Brotherhood-32 titles to rehydrate by stable type code instead of copying one server-language title into every locale;
- localized user-facing Zodiac names;
- localized built-in city labels and DEBUG fixture presentation while preserving stable city search/storage values and leaving arbitrary user-authored content untouched;
- fixed the locale generator so declared stable domain keys (including `city.name.*`) are materialized automatically and participate in the fail-closed coverage gate;
- fixed calibration export SQL to the physical PostgreSQL schema (`assessment_code`, `assessment_version`, `completed_at`, `search_role`);
- canonical Compatibility remains 15 layers / 100%, Vedic Numerology remains exactly 5%, and Quality Fit remains separate from Compatibility, Trust and Account Completeness;
- Android: `versionCode 20`, `versionName 0.5.15`.

# Brotherhood v0.5.14

- Replaced the canonical 100×6 direct/situational self-report bank with indirect visual/associative tasks (`visual-latent-v1`).
- Added hidden multidimensional latent profile with 50 neutral/contextual coordinates and 84 user-selectable quality targets across friendship, communication, character, business, leadership and lifestyle.
- Added user-authored role + qualities SearchIntent and separate Quality Fit; role never injects target qualities.
- Removed universal good/bad trait direction from production assessment scoring; public interpretation is positive/contextual only.
- Public assessment API now returns completion receipts only; raw dimensions are internal-only.
- Quarantined legacy direct-question results so they cannot feed the visual latent model.
- Added causal Kernel with explicit forbidden edges and regression guards.
- Retired the v0.5.12 fixed-ID Friendship Expectations shadow because those IDs no longer preserve the old semantics in visual-latent-v1; expectation preferences now flow through user-authored Quality Fit qualities.
- Canonical Compatibility weights remain unchanged at 100%; Vedic Numerology remains 5% and is not a test.
- Android: `versionCode 19`, `versionName 0.5.14`.

## 0.5.14 — 2026-08-01

### Hidden visual psychological matching + user-authored Quality Fit
- exact user request -> selected role/qualities -> candidate hidden profile -> Quality Fit -> positive public strengths;
- Quality Fit remains mathematically separate from Compatibility, Trust and Account Completeness;
- 100 psychological/behavioral tests × 6 indirect visual tasks = 600 tasks;
- no direct socially desirable item bank;
- no automatic model reweighting from 30/90-day outcomes.

# Brotherhood v0.5.13

- Integrated every available numerology record/configuration from the authorized `Numerology-main.zip` source inventory.
- Added RU/UK/EN runtime knowledge coverage for 11 Soul Number, 11 Life Path × five sections, 52 Birth Chart, 11 Pinnacle and 12 Outer/Expression records.
- Added deterministic date-derived Life Path, Birth Chart, isolated/missing rules and four Pinnacles matching the supplied reference formulas.
- Preserved the exact supplied Vietnamese source snapshot and machine provenance separately from the normalized APK asset.
- Vedic friendship compatibility remains date-only and exactly 5% of the production compatibility model; names remain descriptive only.
- Added Operator Kernel routing/boundaries/verification infrastructure for future scoped continuation.
- Version: `versionCode 18`, `versionName 0.5.13`.

# Changelog

## 0.5.13 — 2026-07-31

### Complete numerology knowledge integration
- functional Android/source release;
- no `applicationId`, signing-policy, master-logo, Trust/Compatibility/Completeness separation or permission change;
- the canonical 100 psychological/behavioral tests / 600 questions remain intact and separate from numerology; numerology has no questionnaire.

# Brotherhood v0.5.12

- Added longitudinal `friendship_outcomes` for 30/90-day friendship calibration; this data is internal analytics and not public reputation.
- Added a shadow `Friendship Expectations` predictor from existing f065 + f071–f080; the canonical 15 production weights remain unchanged and Vedic Numerology remains 5%.
- Added offline logistic-regression calibration tooling that produces review-only candidate weights and never rewrites production weights automatically.
- Converted the 100 × 6 assessment presentation into paired, shuffled situational prompts and hides construct titles until completion to reduce answer gaming.
- Added bounded profile avatar import: app-private local storage, resize/compress, ≤512 KiB backend synchronization, no broad storage/media permission.
- Placed the canonical Brotherhood mark in the Home identity card and differentiated core feature icons without modifying the master SVG.
- Preserved Trust, Compatibility and Account Completeness as separate systems.
- Repaired known apksigner/aapt parser regressions in the unpacked-source workflow.
- Version: `versionCode 17`, `versionName 0.5.12`.


## 0.5.12 — 2026-07-31

### Outcome-calibrated friendship matching, veiled assessments and avatar
- current production compatibility weights remain 100% total: 18/10/10/9/8/7/7/7/7/5/4/3/2/2/1;
- numerology remains exactly 5%;
- Friendship Expectations is diagnostic only pending longitudinal evidence;
- new outcome and avatar migrations are additive (`0002`, `0003`);
- no change to `applicationId`, master logo geometry, production signing or permission canon.

## 0.5.11 — 2026-07-31

### Canonical BR logo + discovery/privacy upgrade
- встроен канонический логотип Brotherhood из пользовательского SVG: master SVG + 512/1024 PNG, adaptive launcher foreground, Android 13 monochrome icon и Android 12+ splash;
- сохранены точные бренд-цвета: `#000000` и `#ECAF21`; UI больше не перекрашивает логотип Material tint-ом;
- проведён аудит 10 предоставленных dating/friendship/numerology песочниц; AGPL/no-license код не копируется, MIT/CC0 проекты используются как архитектурные и UX-ориентиры;
- добавлен Quick Discovery deck: один кандидат за раз, skip, undo skip, просмотр подробной совместимости и запрос дружбы;
- добавлены persistent discovery filters: verified-only, online-only, shared-interest requirement, min Trust, min compatibility, hide requested;
- добавлены режимы видимости профиля `discoverable / connections / private` с синхронизацией на backend;
- явно оформлен Passport mode через город поиска, не меняющий домашний город пользователя;
- профиль дополнен статистикой запросов, чатов и групп;
- Android `versionCode = 15`, `versionName = 0.5.11`; backend/API defaults = 0.5.11.


## 0.5.9 — 2026-07-31

### Discoverability / navigation / Brotherhood naming
- подтверждено по CI SHA, что APK-6 был собран из v0.5.8; отсутствие функций на экране было UX-проблемой, а не старым APK;
- название приложения во всех локалях изменено на `Brotherhood`;
- добавлена отдельная главная панель с прямым доступом к чатам, 15 слоям совместимости, самоанализу, 100 тестам, Trust, Brotherhood-32, эннеаграмме, зодиаку и ведической нумерологии;
- нижняя навигация упрощена до `Главная / Люди / Чаты / Группы / Профиль`;
- чаты стали first-class вкладкой и получили badge непрочитанных сообщений;
- Tests и Trust вынесены в самостоятельные overlay-экраны с явной кнопкой назад;
- последняя выбранная вкладка сохраняется в `SettingsStore`;
- принципы Diia Open Source изучены как архитектурный ориентир: компактная bottom navigation, badges, accessibility semantics, модульные auth/i18n/queue/crypto packages; EUPL-код напрямую не копируется;
- Android `versionCode = 14`, `versionName = 0.5.9`; backend version defaults = 0.5.9.

## 0.5.8 — 2026-07-31

### Multi-layer compatibility, self-analysis, Chat Core and Android updates
- совместимость разделена на независимые слои: тесты, интересы, характер, ценности, образ жизни, цели дружбы, общение, конфликты, бизнес/взаимопомощь, социальный формат, Brotherhood-32, эннеаграмма, зодиак, ведическая нумерология и география;
- добавлены базовая и персонализированная итоговая совместимость; Trust Score остаётся отдельным показателем;
- ведическая нумерология закреплена как математический расчёт без тестов; дружеская совместимость этого слоя рассчитывается только из двух дат рождения, число имени исключено из compatibility score;
- добавлен раздел самоанализа по пройденным тестам и профильным моделям;
- личный чат переведён на Brotherhood Private Chat E2EE v1 с Android Keystore, signed prekey, ECDH, HKDF ratchet, AES-GCM, TOFU pinning и fingerprints;
- групповые чаты остаются не секретными и серверно модерируемыми, но шифруются при хранении;
- чат получил replies, reactions, typing, edit events, sender delete, per-user delivery/read receipts, offline outbox, фото/аудио/видео/файлы и системную запись голосовых заметок;
- закрыты safety/group tails: block/unblock, закрытая жалоба в Trust moderation, управление составом группы владельцем, encrypted push-token registration hook;
- добавлен стабильный signing-контур: при наличии GitHub Secrets CI собирает подписанный release APK и AAB;
- Play In-App Updates добавлен для Play-установок, sideload update использует version manifest и стабильную подпись;
- добавлен заменяемый logo slot и выровнены основные action/navigation controls;
- Android `versionCode = 13`, `versionName = 0.5.8`; backend API = 0.5.8.

## 0.5.7 — 2026-07-31

### GitHub APK build unit-test / Brotherhood-32 scoring fix
- разобран `logs_83032884747.zip`: ZIP, распаковка, JDK 17, Gradle, Android SDK 36 и production Kotlin compile прошли успешно;
- единственное падение: `Personality32EngineTest.identical_profiles_have_maximum_compatibility`;
- исправлена семантическая инверсия `bondStyle`: шкала идёт от стабильной/вовлечённой связи (0) к адаптивной/независимой (100), поэтому устойчивость теперь рассчитывается как `100 - bondStyle`;
- тест максимальной совместимости привязан к полностью стабильной связи;
- добавлен regression-test, подтверждающий, что одинаковые независимые профили не получают такой же long-term friendship fit, как одинаковые устойчивые профили;
- Android `versionCode = 12`, `versionName = 0.5.7`;
- workflow менять не требуется.

## 0.5.6 — 2026-07-31

### GitHub APK build compile fix
- исправлен единственный Kotlin compiler error из GitHub Actions run `logs_83021345746.zip`;
- устранён JVM `Platform declaration clash` в `MainViewModel`: Compose-state свойство `language` генерировало setter `setLanguage(AppLanguage)`, который конфликтовал с ручной функцией того же имени;
- публичный обработчик переименован в `changeLanguage(AppLanguage)`, обновлены оба вызова в `BrotherhoodApp.kt`;
- `SettingsStore.setLanguage(...)` сохранён без изменений, поскольку находится в другом классе и JVM-конфликта не создаёт;
- проведён статический аудит аналогичных getter/setter method clashes по всем Kotlin-файлам — дополнительных конфликтов не найдено;
- Android `versionCode` повышен до 11, `versionName` до 0.5.6;
- workflow менять не требуется: CI снова подтвердил корректную распаковку ZIP, JDK 17, Gradle и Android SDK 36 до стадии `:app:compileDebugKotlin`.

# Changelog

## 0.5.3 — 2026-07-31

- проанализированы `Песочница.xz`, SberID SDK archive и Flutter idle template;
- добавлен лицензионный фильтр: MIT-паттерны допустимы, GPLv3/Sber AT-NC-SA код не включён;
- backend получил реальный runtime repository для Neon/PostgreSQL;
- `DATABASE_URL` автоматически переключает storage с test-memory на PostgreSQL;
- добавлены server-side profiles, users search, communities, assessment results, trust incidents и messages;
- приватные trust descriptions и сообщения шифруются на PostgreSQL через отдельные Vercel secrets;
- добавлены server-side app sessions с hash токена и проверка `session → global_id`;
- internal identity/session endpoints защищаются `INTERNAL_AUTH_SECRET` в production;
- добавлен provider readiness registry для Google/Telegram/Facebook;
- Android получил RemoteDataRepository поверх Vercel API;
- DemoRepository ограничен debug fallback;
- pending mutations получили retry/flush после восстановления сети;
- добавлены профильные API endpoints и offline queue для sync профиля;
- версия Android/API обновлена до 0.5.3.

## 0.5.2 — 2026-07-31

- зафиксирован канон имён архивов и верхнего каталога `Brotherhood/`;
- добавлен полный реестр Brotherhood-32 из 32 уникальных типов;
- добавлен Service Hub со всеми модулями совместимости;
- добавлен экран сообщений и offline outbox UI;
- редактирование профиля заменено с placeholder на рабочую форму;
- профиль сохраняется локально;
- расширена SQLite-схема кеша, pending mutations, recent entities, sync metadata и message outbox;
- добавлены canonical requirements и provider registry;
- усилено разделение APK / Vercel backend / Neon;
- добавлены тесты 32 типов, `global_id` и ведической нумерологии;
- версия Android и API обновлена до 0.5.2.

### Дополнительная квалификация v0.5.3

- Brotherhood-32 получил отдельный встроенный 20-вопросный профиль вместо заранее заполненного demo-результата;
- эннеаграмма получила отдельный 18-вопросный встроенный профиль;
- дата рождения стала редактируемой с ограничением 18+;
- зодиак и ведическая нумерология автоматически пересчитываются после изменения даты/латинского имени;
- core personality profile и каждый завершённый тест синхронизируются через offline queue → Vercel → Neon;
- сервер отдаёт чистый `friendship_test_score`, число общих тестов и risk flags, а полный гибридный итог рассчитывается локально в APK;
- удалены персональные demo-данные из исходного кода;
- материалы Песочницы используются только как лицензируемые архитектурные/UI-ориентиры; GPL и ограниченные SDK напрямую не встраиваются.
