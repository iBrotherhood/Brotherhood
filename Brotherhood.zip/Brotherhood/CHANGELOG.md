# Brotherhood v0.5.11

- Fixed Kotlin JVM setter collision for `profileVisibility` by renaming the ViewModel action to `changeProfileVisibility`.
- Introduced fail-closed permanent Brotherhood Development APK signing.
- Removed canonical fallback to ephemeral GitHub debug certificates.
- Separated Development signing from future Production signing; Development workflow no longer emits release APK/AAB.
- Added APK signer fingerprint, package metadata and SHA-256 verification.
- Added `docs/ANDROID_DEVELOPMENT_SIGNING.md` and safe Development keystore helper.
- Version: `versionCode 16`, `versionName 0.5.11`.

# Changelog

## 0.5.11 — 2026-07-31

### Canonical BR logo + discovery/privacy upgrade
- встроен канонический логотип Brotherhood из пользовательского SVG: master SVG + 512/1024 PNG, adaptive launcher foreground, Android 13 monochrome icon и Android 12+ splash;
- сохранены точные бренд-цвета: `#000000` и `#ECAF21`; UI больше не перекрашивает логотип Material tint-ом;
- проведён аудит 10 предоставленных dating/friendship/numerology песочниц; AGPL/no-license код не копируется, MIT/CC0 проекты используются как архитектурные и UX-ориентиры;
- добавлен Quick Discovery deck: один кандидат за раз, skip, undo skip, просмотр подробной совместимости и запрос дружбы;
- добавлены persistent discovery filters: verified-only, online-only, shared-interest requirement, min Trust, min compatibility, hide requested;
- добавлены режимы видимости профиля `discoverable / connections / private` с синхронизацией на backend;
- явно оформлен Passport mode через город поиска, не меняющий домашний город пользователя;
- профиль дополнен статистикой запросов, чатов и групп;
- Android `versionCode = 15`, `versionName = 0.5.11`; backend/API defaults = 0.5.11.


## 0.5.9 — 2026-07-31

### Discoverability / navigation / Brotherhood naming
- подтверждено по CI SHA, что APK-6 был собран из v0.5.8; отсутствие функций на экране было UX-проблемой, а не старым APK;
- название приложения во всех локалях изменено на `Brotherhood`;
- добавлена отдельная главная панель с прямым доступом к чатам, 15 слоям совместимости, самоанализу, 100 тестам, Trust, Brotherhood-32, эннеаграмме, зодиаку и ведической нумерологии;
- нижняя навигация упрощена до `Главная / Люди / Чаты / Группы / Профиль`;
- чаты стали first-class вкладкой и получили badge непрочитанных сообщений;
- Tests и Trust вынесены в самостоятельные overlay-экраны с явной кнопкой назад;
- последняя выбранная вкладка сохраняется в `SettingsStore`;
- принципы Diia Open Source изучены как архитектурный ориентир: компактная bottom navigation, badges, accessibility semantics, модульные auth/i18n/queue/crypto packages; EUPL-код напрямую не копируется;
- Android `versionCode = 14`, `versionName = 0.5.9`; backend version defaults = 0.5.9.

## 0.5.8 — 2026-07-31

### Multi-layer compatibility, self-analysis, Chat Core and Android updates
- совместимость разделена на независимые слои: тесты, интересы, характер, ценности, образ жизни, цели дружбы, общение, конфликты, бизнес/взаимопомощь, социальный формат, Brotherhood-32, эннеаграмма, зодиак, ведическая нумерология и география;
- добавлены базовая и персонализированная итоговая совместимость; Trust Score остаётся отдельным показателем;
- ведическая нумерология закреплена как математический расчёт без тестов; дружеская совместимость этого слоя рассчитывается только из двух дат рождения, число имени исключено из compatibility score;
- добавлен раздел самоанализа по пройденным тестам и профильным моделям;
- личный чат переведён на Brotherhood Private Chat E2EE v1 с Android Keystore, signed prekey, ECDH, HKDF ratchet, AES-GCM, TOFU pinning и fingerprints;
- групповые чаты остаются не секретными и серверно модерируемыми, но шифруются при хранении;
- чат получил replies, reactions, typing, edit events, sender delete, per-user delivery/read receipts, offline outbox, фото/аудио/видео/файлы и системную запись голосовых заметок;
- закрыты safety/group tails: block/unblock, закрытая жалоба в Trust moderation, управление составом группы владельцем, encrypted push-token registration hook;
- добавлен стабильный signing-контур: при наличии GitHub Secrets CI собирает подписанный release APK и AAB;
- Play In-App Updates добавлен для Play-установок, sideload update использует version manifest и стабильную подпись;
- добавлен заменяемый logo slot и выровнены основные action/navigation controls;
- Android `versionCode = 13`, `versionName = 0.5.8`; backend API = 0.5.8.

## 0.5.7 — 2026-07-31

### GitHub APK build unit-test / Brotherhood-32 scoring fix
- разобран `logs_83032884747.zip`: ZIP, распаковка, JDK 17, Gradle, Android SDK 36 и production Kotlin compile прошли успешно;
- единственное падение: `Personality32EngineTest.identical_profiles_have_maximum_compatibility`;
- исправлена семантическая инверсия `bondStyle`: шкала идёт от стабильной/вовлечённой связи (0) к адаптивной/независимой (100), поэтому устойчивость теперь рассчитывается как `100 - bondStyle`;
- тест максимальной совместимости привязан к полностью стабильной связи;
- добавлен regression-test, подтверждающий, что одинаковые независимые профили не получают такой же long-term friendship fit, как одинаковые устойчивые профили;
- Android `versionCode = 12`, `versionName = 0.5.7`;
- workflow менять не требуется.

## 0.5.6 — 2026-07-31

### GitHub APK build compile fix
- исправлен единственный Kotlin compiler error из GitHub Actions run `logs_83021345746.zip`;
- устранён JVM `Platform declaration clash` в `MainViewModel`: Compose-state свойство `language` генерировало setter `setLanguage(AppLanguage)`, который конфликтовал с ручной функцией того же имени;
- публичный обработчик переименован в `changeLanguage(AppLanguage)`, обновлены оба вызова в `BrotherhoodApp.kt`;
- `SettingsStore.setLanguage(...)` сохранён без изменений, поскольку находится в другом классе и JVM-конфликта не создаёт;
- проведён статический аудит аналогичных getter/setter method clashes по всем Kotlin-файлам — дополнительных конфликтов не найдено;
- Android `versionCode` повышен до 11, `versionName` до 0.5.6;
- workflow менять не требуется: CI снова подтвердил корректную распаковку ZIP, JDK 17, Gradle и Android SDK 36 до стадии `:app:compileDebugKotlin`.

# Changelog

## 0.5.3 — 2026-07-31

- проанализированы `Песочница.xz`, SberID SDK archive и Flutter idle template;
- добавлен лицензионный фильтр: MIT-паттерны допустимы, GPLv3/Sber AT-NC-SA код не включён;
- backend получил реальный runtime repository для Neon/PostgreSQL;
- `DATABASE_URL` автоматически переключает storage с test-memory на PostgreSQL;
- добавлены server-side profiles, users search, communities, assessment results, trust incidents и messages;
- приватные trust descriptions и сообщения шифруются на PostgreSQL через отдельные Vercel secrets;
- добавлены server-side app sessions с hash токена и проверка `session → global_id`;
- internal identity/session endpoints защищаются `INTERNAL_AUTH_SECRET` в production;
- добавлен provider readiness registry для Google/Telegram/Facebook;
- Android получил RemoteDataRepository поверх Vercel API;
- DemoRepository ограничен debug fallback;
- pending mutations получили retry/flush после восстановления сети;
- добавлены профильные API endpoints и offline queue для sync профиля;
- версия Android/API обновлена до 0.5.3.

## 0.5.2 — 2026-07-31

- зафиксирован канон имён архивов и верхнего каталога `Brotherhood/`;
- добавлен полный реестр Brotherhood-32 из 32 уникальных типов;
- добавлен Service Hub со всеми модулями совместимости;
- добавлен экран сообщений и offline outbox UI;
- редактирование профиля заменено с placeholder на рабочую форму;
- профиль сохраняется локально;
- расширена SQLite-схема кеша, pending mutations, recent entities, sync metadata и message outbox;
- добавлены canonical requirements и provider registry;
- усилено разделение APK / Vercel backend / Neon;
- добавлены тесты 32 типов, `global_id` и ведической нумерологии;
- версия Android и API обновлена до 0.5.2.

### Дополнительная квалификация v0.5.3

- Brotherhood-32 получил отдельный встроенный 20-вопросный профиль вместо заранее заполненного demo-результата;
- эннеаграмма получила отдельный 18-вопросный встроенный профиль;
- дата рождения стала редактируемой с ограничением 18+;
- зодиак и ведическая нумерология автоматически пересчитываются после изменения даты/латинского имени;
- core personality profile и каждый завершённый тест синхронизируются через offline queue → Vercel → Neon;
- сервер отдаёт чистый `friendship_test_score`, число общих тестов и risk flags, а полный гибридный итог рассчитывается локально в APK;
- удалены персональные demo-данные из исходного кода;
- материалы Песочницы используются только как лицензируемые архитектурные/UI-ориентиры; GPL и ограниченные SDK напрямую не встраиваются.
