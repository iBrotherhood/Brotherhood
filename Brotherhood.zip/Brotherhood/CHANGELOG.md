## 0.5.7 — 2026-07-31

### GitHub APK build unit-test / Brotherhood-32 scoring fix
- разобран `logs_83032884747.zip`: ZIP, распаковка, JDK 17, Gradle, Android SDK 36 и production Kotlin compile прошли успешно;
- единственное падение: `Personality32EngineTest.identical_profiles_have_maximum_compatibility`;
- исправлена семантическая инверсия `bondStyle`: шкала идёт от стабильной/вовлечённой связи (0) к адаптивной/независимой (100), поэтому устойчивость теперь рассчитывается как `100 - bondStyle`;
- тест максимальной совместимости привязан к полностью стабильной связи;
- добавлен regression-test, подтверждающий, что одинаковые независимые профили не получают такой же long-term friendship fit, как одинаковые устойчивые профили;
- Android `versionCode = 12`, `versionName = 0.5.7`;
- workflow менять не требуется.

## 0.5.6 — 2026-07-31

### GitHub APK build compile fix
- исправлен единственный Kotlin compiler error из GitHub Actions run `logs_83021345746.zip`;
- устранён JVM `Platform declaration clash` в `MainViewModel`: Compose-state свойство `language` генерировало setter `setLanguage(AppLanguage)`, который конфликтовал с ручной функцией того же имени;
- публичный обработчик переименован в `changeLanguage(AppLanguage)`, обновлены оба вызова в `BrotherhoodApp.kt`;
- `SettingsStore.setLanguage(...)` сохранён без изменений, поскольку находится в другом классе и JVM-конфликта не создаёт;
- проведён статический аудит аналогичных getter/setter method clashes по всем Kotlin-файлам — дополнительных конфликтов не найдено;
- Android `versionCode` повышен до 11, `versionName` до 0.5.6;
- workflow менять не требуется: CI снова подтвердил корректную распаковку ZIP, JDK 17, Gradle и Android SDK 36 до стадии `:app:compileDebugKotlin`.

# Changelog

## 0.5.3 — 2026-07-31

- проанализированы `Песочница.xz`, SberID SDK archive и Flutter idle template;
- добавлен лицензионный фильтр: MIT-паттерны допустимы, GPLv3/Sber AT-NC-SA код не включён;
- backend получил реальный runtime repository для Neon/PostgreSQL;
- `DATABASE_URL` автоматически переключает storage с test-memory на PostgreSQL;
- добавлены server-side profiles, users search, communities, assessment results, trust incidents и messages;
- приватные trust descriptions и сообщения шифруются на PostgreSQL через отдельные Vercel secrets;
- добавлены server-side app sessions с hash токена и проверка `session → global_id`;
- internal identity/session endpoints защищаются `INTERNAL_AUTH_SECRET` в production;
- добавлен provider readiness registry для Google/Telegram/Facebook;
- Android получил RemoteDataRepository поверх Vercel API;
- DemoRepository ограничен debug fallback;
- pending mutations получили retry/flush после восстановления сети;
- добавлены профильные API endpoints и offline queue для sync профиля;
- версия Android/API обновлена до 0.5.3.

## 0.5.2 — 2026-07-31

- зафиксирован канон имён архивов и верхнего каталога `Brotherhood/`;
- добавлен полный реестр Brotherhood-32 из 32 уникальных типов;
- добавлен Service Hub со всеми модулями совместимости;
- добавлен экран сообщений и offline outbox UI;
- редактирование профиля заменено с placeholder на рабочую форму;
- профиль сохраняется локально;
- расширена SQLite-схема кеша, pending mutations, recent entities, sync metadata и message outbox;
- добавлены canonical requirements и provider registry;
- усилено разделение APK / Vercel backend / Neon;
- добавлены тесты 32 типов, `global_id` и ведической нумерологии;
- версия Android и API обновлена до 0.5.2.

### Дополнительная квалификация v0.5.3

- Brotherhood-32 получил отдельный встроенный 20-вопросный профиль вместо заранее заполненного demo-результата;
- эннеаграмма получила отдельный 18-вопросный встроенный профиль;
- дата рождения стала редактируемой с ограничением 18+;
- зодиак и ведическая нумерология автоматически пересчитываются после изменения даты/латинского имени;
- core personality profile и каждый завершённый тест синхронизируются через offline queue → Vercel → Neon;
- сервер отдаёт чистый `friendship_test_score`, число общих тестов и risk flags, а полный гибридный итог рассчитывается локально в APK;
- удалены персональные demo-данные из исходного кода;
- материалы Песочницы используются только как лицензируемые архитектурные/UI-ориентиры; GPL и ограниченные SDK напрямую не встраиваются.
