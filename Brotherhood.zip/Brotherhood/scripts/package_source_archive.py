#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import os
import stat
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_PARTS = {'.git', '.gradle', '.idea', '.pytest_cache', '__pycache__', 'build', '.venv', '.check', '.ci-signing'}
EXCLUDED_NAMES = {'Brotherhood.zip', 'Brotherhood.zip.sha256', 'CHECKSUMS.txt'}
FIXED_DT = (2026, 8, 1, 0, 0, 0)
INNER_WORKFLOWS = {Path('.github/workflows/android-build.yml')}


def include_file(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDED_PARTS for part in rel.parts):
        return False
    if rel.name in EXCLUDED_NAMES:
        return False
    if rel.suffix.lower() in {'.jks', '.keystore', '.p12', '.pfx', '.pem', '.key'}:
        return False
    if rel.parts[:2] == ('.github', 'workflows') and rel not in INNER_WORKFLOWS:
        return False
    if rel.suffix in {'.pyc', '.class', '.jar'} and rel.as_posix() != 'android/gradle/wrapper/gradle-wrapper.jar':
        return False
    return True


def included_files() -> list[Path]:
    return sorted(
        (p for p in ROOT.rglob('*') if p.is_file() and include_file(p)),
        key=lambda p: p.relative_to(ROOT).as_posix(),
    )


def required_directories(files: list[Path]) -> list[str]:
    dirs = {'Brotherhood/'}
    for path in files:
        rel = Path('Brotherhood') / path.relative_to(ROOT)
        parent = rel.parent
        while parent.as_posix() not in {'.', ''}:
            dirs.add(parent.as_posix().rstrip('/') + '/')
            parent = parent.parent
    return sorted(dirs)


def directory_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, FIXED_DT)
    info.create_system = 3  # Unix
    info.compress_type = zipfile.ZIP_STORED
    info.external_attr = ((stat.S_IFDIR | 0o755) << 16) | 0x10
    return info


def file_info(name: str, executable: bool) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, FIXED_DT)
    info.create_system = 3  # Unix
    info.compress_type = zipfile.ZIP_DEFLATED
    mode = 0o755 if executable else 0o644
    # Include the regular-file type bit. Omitting this produces non-standard
    # '?rw-r--r--' metadata that some strict ZIP processors reject.
    info.external_attr = (stat.S_IFREG | mode) << 16
    return info


def create_zip(destination: Path) -> None:
    files = included_files()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(
        destination,
        'w',
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=6,
        allowZip64=True,
        strict_timestamps=True,
    ) as zf:
        for dirname in required_directories(files):
            zf.writestr(directory_info(dirname), b'')
        for path in files:
            arcname = 'Brotherhood/' + path.relative_to(ROOT).as_posix()
            zf.writestr(
                file_info(arcname, os.access(path, os.X_OK)),
                path.read_bytes(),
                compress_type=zipfile.ZIP_DEFLATED,
                compresslevel=6,
            )


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--write', metavar='PATH')
    group.add_argument('--check', metavar='PATH')
    args = parser.parse_args()
    if args.write:
        target = (ROOT / args.write).resolve() if not Path(args.write).is_absolute() else Path(args.write)
        create_zip(target)
        print(f'{sha256(target)}  {target.name}')
        return 0
    expected = (ROOT / args.check).resolve() if not Path(args.check).is_absolute() else Path(args.check)
    if not expected.is_file():
        print(f'ERROR: missing {expected}', file=sys.stderr)
        return 1
    with tempfile.TemporaryDirectory() as td:
        actual = Path(td) / 'Brotherhood.zip'
        create_zip(actual)
        if actual.read_bytes() != expected.read_bytes():
            print('ERROR: Brotherhood.zip does not match canonical unpacked source.', file=sys.stderr)
            print(f'expected={sha256(expected)}', file=sys.stderr)
            print(f'generated={sha256(actual)}', file=sys.stderr)
            return 1
    print(f'PASS: Brotherhood.zip synchronized ({sha256(expected)})')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
