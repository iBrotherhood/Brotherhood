#!/usr/bin/env python3
"""Build the translation-memory template used by data-driven future locales.

Current RU/UK/EN code keeps readable inline triplets. For any future language AppLanguage.pick()
looks up the English source string in the locale pack. This script extracts those triplets and
keeps one data-only translation template, so adding a language does not require Kotlin branches.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

TRIPLE_PATTERNS = [
    re.compile(r'\.pick\(\s*"((?:\\.|[^"\\])*)"\s*,\s*"((?:\\.|[^"\\])*)"\s*,\s*"((?:\\.|[^"\\])*)"\s*\)', re.S),
    re.compile(r'\.t\(\s*"((?:\\.|[^"\\])*)"\s*,\s*"((?:\\.|[^"\\])*)"\s*,\s*"((?:\\.|[^"\\])*)"\s*\)', re.S),
    re.compile(r'LocalizedTraitText\(\s*"((?:\\.|[^"\\])*)"\s*,\s*"((?:\\.|[^"\\])*)"\s*,\s*"((?:\\.|[^"\\])*)"\s*\)', re.S),
    re.compile(r'BaseName\(\s*"((?:\\.|[^"\\])*)"\s*,\s*"((?:\\.|[^"\\])*)"\s*,\s*"((?:\\.|[^"\\])*)"\s*\)', re.S),
    re.compile(r'TypeInfo\(\s*"((?:\\.|[^"\\])*)"\s*,\s*"((?:\\.|[^"\\])*)"\s*,\s*"((?:\\.|[^"\\])*)"\s*\)', re.S),
]
FORMAT_PATTERN = re.compile(
    r'\.format\(\s*"([^"\\]+)"\s*,\s*"((?:\\.|[^"\\])*)"\s*,\s*"((?:\\.|[^"\\])*)"\s*,\s*"((?:\\.|[^"\\])*)"',
    re.S,
)


def unescape(value: str) -> str:
    return bytes(value, 'utf-8').decode('unicode_escape') if '\\' in value and all(ord(c)<128 for c in value) else value.replace('\\"','"').replace('\\n','\n').replace('\\\\','\\')


def collect(root: Path) -> dict[str, dict[str, str]]:
    triples: dict[str, dict[str, str]] = {}
    src = root / 'android/app/src/main/java'
    for path in src.rglob('*.kt'):
        text = path.read_text(encoding='utf-8')
        for pattern in TRIPLE_PATTERNS:
            for m in pattern.finditer(text):
                ru, uk, en = map(unescape, m.groups())
                triples.setdefault(en, {'ru':ru,'uk':uk,'en':en})
        for m in FORMAT_PATTERN.finditer(text):
            key, ru, uk, en = m.groups()
            ru,uk,en=map(unescape,(ru,uk,en))
            triples.setdefault(en, {'ru':ru,'uk':uk,'en':en,'stable_key':key})

    # Finite dynamically composed Brotherhood-32 public titles.
    p32=(root/'android/app/src/main/java/org/federationofavatars/brotherhood/domain/Personality32Engine.kt').read_text(encoding='utf-8')
    bases=[]
    for m in re.finditer(r'BaseName\("([^"]+)",\s*"([^"]+)",\s*"([^"]+)"\)',p32):
        bases.append(m.groups())
    for ru,uk,en in bases:
        for pru,puk,pen in [('Свободный','Вільний','Adaptive'),('Верный','Вірний','Loyal')]:
            triples[f'{pen} {en}']={'ru':f'{pru} {ru}','uk':f'{puk} {uk}','en':f'{pen} {en}'}
    for n in range(1,10):
        triples[f'Enneatype {n}']={'ru':f'Эннеатип {n}','uk':f'Еннеатип {n}','en':f'Enneatype {n}'}
    triples.setdefault('Profile forming',{'ru':'Профиль формируется','uk':'Профіль формується','en':'Profile forming'})

    # Built-in geography uses stable storage values and locale-dependent presentation labels.
    city_path=root/'shared/locales/cities.json'
    if city_path.exists():
        data=json.loads(city_path.read_text(encoding='utf-8'))
        for city in data.get('cities',[]):
            # City labels have an explicit stable key even when their English label (e.g.
            # "Online") is also used by another UI surface. The translations are identical,
            # while the stable key is required for deterministic domain lookup.
            triples[city['en']] = {
                'ru': city['ru'],
                'uk': city['uk'],
                'en': city['en'],
                'stable_key': f"city.name.{city['id']}",
            }

    # Quality labels are already stable-key translations but are included in the global template.
    qpath=root/'shared/product/quality-fit-catalog-v2.json'
    if qpath.exists():
        data=json.loads(qpath.read_text(encoding='utf-8'))
        for q in data.get('qualities',[]):
            triples.setdefault(q['en'],{'ru':q['ru'],'uk':q['uk'],'en':q['en'],'stable_key':f"quality.{q['key']}"})
    return dict(sorted(triples.items(), key=lambda kv: kv[0].casefold()))


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    args=ap.parse_args(); root=args.root.resolve()
    entries=collect(root)
    template={
        'schema_version':1,
        'purpose':'Complete translation memory for future Brotherhood locale packs. English source strings are runtime aliases for legacy inline triplets.',
        'entry_count':len(entries),
        'entries':entries,
    }
    out=root/'shared/locales/translation-template.json'
    out.write_text(json.dumps(template,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for locale in ('ru','uk','en'):
        for base in (root/'shared/locales/packs',root/'android/app/src/main/assets/i18n'):
            path=base/f'{locale}.json'
            data=json.loads(path.read_text(encoding='utf-8'))
            existing=data.get('messages',{})
            # Stable machine keys survive; generated English-source aliases are rebuilt every cycle.
            messages={k:v for k,v in existing.items() if re.fullmatch(r"[a-z][a-z0-9_.-]*\.[a-z0-9_.-]+", k)}
            for en,row in entries.items():
                messages[en]=row[locale]
                stable_key=row.get('stable_key')
                if stable_key:
                    messages[stable_key]=row[locale]
            data['messages']=dict(sorted(messages.items()))
            data['schema_version']=2
            path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # Runtime activation gate: a language is visible only when it covers every current message key.
    en_pack=json.loads((root/'shared/locales/packs/en.json').read_text(encoding='utf-8'))
    required=sorted(en_pack.get('messages',{}).keys())
    (root/'android/app/src/main/assets/i18n/required_keys.json').write_text(
        json.dumps({'schema_version':1,'required_keys':required},ensure_ascii=False,indent=2)+'\n', encoding='utf-8'
    )
    # Android and backend share the same enabled-language registry and built-in city catalog.
    (root/'android/app/src/main/assets/i18n/languages.json').write_text(
        (root/'shared/locales/supported.json').read_text(encoding='utf-8'), encoding='utf-8'
    )
    city_path=root/'shared/locales/cities.json'
    if city_path.exists():
        (root/'android/app/src/main/assets/i18n/cities.json').write_text(
            city_path.read_text(encoding='utf-8'), encoding='utf-8'
        )
    print(json.dumps({'translation_entries':len(entries),'required_keys':len(required),'current_locales':['ru','uk','en']},ensure_ascii=False))
    return 0

if __name__=='__main__': raise SystemExit(main())
