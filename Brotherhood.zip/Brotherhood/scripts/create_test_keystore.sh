#!/usr/bin/env bash
set -Eeuo pipefail

OUT="${1:-Brotherhood-test-signing.jks}"
ALIAS="${BROTHERHOOD_TEST_KEY_ALIAS:-brotherhood-test}"
: "${BROTHERHOOD_TEST_STORE_PASSWORD:?Set BROTHERHOOD_TEST_STORE_PASSWORD}"
: "${BROTHERHOOD_TEST_KEY_PASSWORD:=$BROTHERHOOD_TEST_STORE_PASSWORD}"

if [ -e "$OUT" ]; then
  echo "ERROR: $OUT already exists; refusing to overwrite a signing key." >&2
  exit 1
fi

keytool -genkeypair \
  -keystore "$OUT" \
  -storepass "$BROTHERHOOD_TEST_STORE_PASSWORD" \
  -keypass "$BROTHERHOOD_TEST_KEY_PASSWORD" \
  -alias "$ALIAS" \
  -keyalg RSA \
  -keysize 3072 \
  -validity 10000 \
  -dname "CN=Brotherhood Test Signing, OU=Android, O=Brotherhood, C=UA"

chmod 600 "$OUT"
echo "Created: $OUT"
echo "GitHub secret BROTHERHOOD_TEST_KEYSTORE_B64:"
base64 -w 0 "$OUT"
echo
