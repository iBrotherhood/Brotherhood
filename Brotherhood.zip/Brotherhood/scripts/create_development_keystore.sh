#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

OUT="${1:-Brotherhood-development-signing.jks}"
ALIAS="${BROTHERHOOD_DEV_KEY_ALIAS:-brotherhood-development}"

: "${BROTHERHOOD_DEV_KEYSTORE_PASSWORD:?Set BROTHERHOOD_DEV_KEYSTORE_PASSWORD}"
: "${BROTHERHOOD_DEV_KEY_PASSWORD:=$BROTHERHOOD_DEV_KEYSTORE_PASSWORD}"

if [ -e "$OUT" ]; then
  echo "ERROR: $OUT already exists; refusing to overwrite a signing key." >&2
  exit 1
fi

keytool -genkeypair \
  -keystore "$OUT" \
  -storetype JKS \
  -storepass "$BROTHERHOOD_DEV_KEYSTORE_PASSWORD" \
  -keypass "$BROTHERHOOD_DEV_KEY_PASSWORD" \
  -alias "$ALIAS" \
  -keyalg RSA \
  -keysize 4096 \
  -validity 10000 \
  -dname "CN=Brotherhood Development Signing Key, OU=Android Development, O=Brotherhood"

chmod 600 "$OUT"

echo "Created Brotherhood Development signing keystore: $OUT"
echo "Alias: $ALIAS"
echo
echo "Certificate SHA-256:"
keytool -list -v \
  -keystore "$OUT" \
  -storepass "$BROTHERHOOD_DEV_KEYSTORE_PASSWORD" \
  -alias "$ALIAS" \
  | sed -n 's/^[[:space:]]*SHA256:[[:space:]]*/SHA256: /p'
echo
echo "Private key material was NOT printed."
echo "Create the Base64 transport file locally with:"
echo "  base64 -w 0 \"$OUT\" > \"$OUT.b64\""
