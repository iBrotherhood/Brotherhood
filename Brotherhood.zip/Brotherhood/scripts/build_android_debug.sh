#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/../android"
./gradlew assembleDebug
