from app.main import app

# Vercel discovers the exported ASGI application named `app`.
