from math import floor
from .models import (
    AccountRatingRequest,
    AccountRatingResponse,
    CompatibilityRequest,
    CompatibilityResponse,
    IncidentStatus,
    TrustSummary,
)
from .storage import BASE_TRUST, INCIDENTS, VERIFIED_INTERACTIONS
from .assessment_registry import PROFILE_SECTION_CODES, SAFETY_CRITICAL_TEST_IDS, SIMILARITY_TEST_IDS, VALID_TEST_IDS


def trust_summary(global_id: int) -> TrustSummary:
    related = [item for item in INCIDENTS if item.subject_global_id == global_id]
    confirmed = [item for item in related if item.status == IncidentStatus.CONFIRMED]
    pending = [item for item in related if item.status in {IncidentStatus.PENDING, IncidentStatus.UNDER_REVIEW, IncidentStatus.APPEALED}]
    score = max(0, min(100, BASE_TRUST.get(global_id, 70) + sum(item.score_impact for item in confirmed)))
    return TrustSummary(
        global_id=global_id,
        global_id_display=f"{global_id:010d}",
        score=score,
        verified_interactions=VERIFIED_INTERACTIONS.get(global_id, 0),
        confirmed_incidents=len(confirmed),
        pending_incidents=len(pending),
    )


def account_rating(payload: AccountRatingRequest) -> AccountRatingResponse:
    valid_profile_sections = set(payload.completed_profile_section_codes) & PROFILE_SECTION_CODES
    valid_completed = set(payload.completed_test_ids) & VALID_TEST_IDS
    profile_points = len(valid_profile_sections) * 5.0
    test_points = len(valid_completed) * 0.5
    return AccountRatingResponse(
        total=min(100.0, profile_points + test_points),
        profile_points=profile_points,
        test_points=test_points,
        completed_profile_sections=len(valid_profile_sections),
        completed_tests=len(valid_completed),
    )


def compatibility(payload: CompatibilityRequest) -> CompatibilityResponse:
    common = (set(payload.my_scores) & set(payload.candidate_scores) & VALID_TEST_IDS)
    if not common:
        score = round(payload.shared_interest_percent * 0.45 + payload.trust_score * 0.55)
        return CompatibilityResponse(score=score, tests_score=0, common_tests=0, confidence=10, risk_flags=[])

    similarity_ids = SIMILARITY_TEST_IDS
    safety_ids = SAFETY_CRITICAL_TEST_IDS
    weighted = 0.0
    total_weight = 0.0
    flags: list[str] = []
    for test_id in common:
        mine = max(0, min(100, payload.my_scores[test_id]))
        other = max(0, min(100, payload.candidate_scores[test_id]))
        similarity = 100 - abs(mine - other)
        contribution = similarity if test_id in similarity_ids else similarity * 0.35 + min(mine, other) * 0.65
        weight = 1.8 if test_id in safety_ids else 1.0
        weighted += contribution * weight
        total_weight += weight
        if test_id in safety_ids and other < 35:
            flags.append(f"{test_id}: повышенный риск по самооценке кандидата")

    tests_score = round(weighted / total_weight)
    score = round(tests_score * 0.75 + payload.shared_interest_percent * 0.10 + payload.trust_score * 0.15)
    if flags:
        score = min(score, 64)
    return CompatibilityResponse(
        score=max(0, min(100, score)),
        tests_score=max(0, min(100, tests_score)),
        common_tests=len(common),
        confidence=max(10, min(100, floor(len(common) * 100 / 100))),
        risk_flags=flags[:5],
    )
