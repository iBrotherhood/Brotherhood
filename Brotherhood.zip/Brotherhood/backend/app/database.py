from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Any, Iterator


def database_url() -> str | None:
    value = os.getenv("DATABASE_URL", "").strip()
    return value or None


def is_database_configured() -> bool:
    return database_url() is not None


@contextmanager
def connection() -> Iterator[Any]:
    url = database_url()
    if not url:
        raise RuntimeError("DATABASE_URL is not configured")
    try:
        import psycopg
    except ImportError as exc:
        raise RuntimeError("psycopg is not installed; install backend/requirements.txt") from exc
    with psycopg.connect(url, connect_timeout=8, autocommit=False) as conn:
        yield conn


def database_health() -> dict[str, str | bool]:
    if not is_database_configured():
        return {"configured": False, "status": "not_configured"}
    try:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute("select current_database(), current_user")
                db_name, db_user = cur.fetchone()
        return {"configured": True, "status": "ok", "database": str(db_name), "user": str(db_user)}
    except Exception:
        # Do not leak connection strings or driver details through a public health endpoint.
        return {"configured": True, "status": "unavailable"}
