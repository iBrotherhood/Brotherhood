from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from urllib.parse import parse_qsl, urlencode, urlparse
from uuid import uuid4

import httpx
from fastapi import HTTPException

from .database import connection
from .models import AuthProvider, EmailCodeRequest, EmailCodeVerifyRequest, ProviderCredentialExchange, TelegramOidcFinishRequest
from .repository import storage_mode


@dataclass(frozen=True)
class VerifiedProviderIdentity:
    provider: AuthProvider
    subject: str
    email: str | None = None
    email_verified: bool = False
    display_name: str | None = None
    initiating_device_id: str | None = None


_MEMORY_EMAIL_CHALLENGES: dict[str, tuple[bytes, datetime, int]] = {}
_MEMORY_LAST_EMAIL_CODE: dict[str, str] = {}
_MEMORY_TELEGRAM_OIDC: dict[bytes, tuple[str, str, str, datetime]] = {}


def _required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise HTTPException(status_code=503, detail=f"{name} is not configured")
    return value


def _normalize_email(value: str) -> str:
    normalized = value.strip().casefold()
    if len(normalized) > 320 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", normalized):
        raise HTTPException(status_code=400, detail="Invalid email address")
    return normalized


def _challenge_secret() -> bytes:
    value = os.getenv("AUTH_CHALLENGE_SECRET", "").strip()
    if value:
        return value.encode("utf-8")
    if storage_mode() == "memory":
        return b"brotherhood-memory-test-challenge-secret"
    raise HTTPException(status_code=503, detail="AUTH_CHALLENGE_SECRET is not configured")


def _code_hash(email: str, code: str) -> bytes:
    return hmac.new(_challenge_secret(), f"email\n{email}\n{code}".encode("utf-8"), hashlib.sha256).digest()


def verify_google_id_token(credential: str, nonce: str | None = None) -> VerifiedProviderIdentity:
    audience = _required_env("GOOGLE_CLIENT_ID")
    try:
        from google.auth.transport import requests as google_requests
        from google.oauth2 import id_token
    except ImportError as exc:
        raise HTTPException(status_code=503, detail="Google verification dependency is unavailable") from exc
    try:
        info = id_token.verify_oauth2_token(credential, google_requests.Request(), audience)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail="Invalid Google credential") from exc
    subject = str(info.get("sub", "")).strip()
    if not subject:
        raise HTTPException(status_code=401, detail="Google credential has no subject")
    if nonce is not None and not hmac.compare_digest(str(info.get("nonce", "")), nonce):
        raise HTTPException(status_code=401, detail="Google credential nonce mismatch")
    return VerifiedProviderIdentity(
        provider=AuthProvider.GOOGLE,
        subject=subject,
        email=str(info.get("email")) if info.get("email") else None,
        email_verified=bool(info.get("email_verified", False)),
        display_name=str(info.get("name")) if info.get("name") else None,
    )


def _telegram_oidc_settings() -> tuple[str, str, str]:
    redirect_uri = _required_env("TELEGRAM_REDIRECT_URI")
    parsed = urlparse(redirect_uri)
    if parsed.scheme != "https" or not parsed.netloc:
        raise HTTPException(status_code=503, detail="TELEGRAM_REDIRECT_URI must be an HTTPS backend callback")
    return (
        _required_env("TELEGRAM_CLIENT_ID"),
        _required_env("TELEGRAM_CLIENT_SECRET"),
        redirect_uri,
    )


def telegram_app_callback_uri() -> str:
    value = os.getenv("TELEGRAM_APP_CALLBACK_URI", "brotherhood://telegram-login/callback").strip()
    parsed = urlparse(value)
    if not parsed.scheme or not parsed.netloc:
        raise HTTPException(status_code=503, detail="TELEGRAM_APP_CALLBACK_URI is invalid")
    return value


def _pkce_challenge(verifier: str) -> str:
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


def _state_hash(state: str) -> bytes:
    return hashlib.sha256(state.encode("utf-8")).digest()


def begin_telegram_oidc(device_id: str) -> str:
    client_id, _, redirect_uri = _telegram_oidc_settings()
    state = secrets.token_urlsafe(32)
    verifier = secrets.token_urlsafe(64)
    nonce = secrets.token_urlsafe(32)
    state_digest = _state_hash(state)
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=5)
    if storage_mode() == "memory":
        _MEMORY_TELEGRAM_OIDC[state_digest] = (verifier, nonce, device_id, expires_at)
    else:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO auth_oidc_challenges(provider,state_hash,code_verifier,nonce,redirect_uri,device_id,expires_at)
                    VALUES('telegram'::auth_provider,%s,%s,%s,%s,%s,%s)
                    """,
                    (state_digest, verifier, nonce, redirect_uri, device_id, expires_at),
                )
            conn.commit()
    query = urlencode({
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": "openid profile",
        "state": state,
        "nonce": nonce,
        "code_challenge": _pkce_challenge(verifier),
        "code_challenge_method": "S256",
    })
    return f"https://oauth.telegram.org/auth?{query}"


def _take_telegram_oidc_state(state: str) -> tuple[str, str, str]:
    digest = _state_hash(state)
    now = datetime.now(timezone.utc)
    if storage_mode() == "memory":
        row = _MEMORY_TELEGRAM_OIDC.pop(digest, None)
        if not row or row[3] <= now:
            raise HTTPException(status_code=401, detail="Invalid or expired Telegram login state")
        return row[0], row[1], row[2]
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT challenge_id,code_verifier,nonce,redirect_uri,device_id
                FROM auth_oidc_challenges
                WHERE provider='telegram'::auth_provider AND state_hash=%s
                  AND consumed_at IS NULL AND expires_at>now()
                LIMIT 1 FOR UPDATE
                """,
                (digest,),
            )
            row = cur.fetchone()
            if not row:
                raise HTTPException(status_code=401, detail="Invalid or expired Telegram login state")
            configured_redirect = _required_env("TELEGRAM_REDIRECT_URI")
            if not hmac.compare_digest(str(row[3]), configured_redirect):
                raise HTTPException(status_code=401, detail="Telegram redirect configuration changed")
            cur.execute("UPDATE auth_oidc_challenges SET consumed_at=now() WHERE challenge_id=%s", (row[0],))
        conn.commit()
    return str(row[1]), str(row[2]), str(row[4])


def exchange_telegram_oidc_code(payload: TelegramOidcFinishRequest) -> VerifiedProviderIdentity:
    if not payload.code or not payload.state:
        raise HTTPException(status_code=400, detail="Telegram authorization code and state are required")
    client_id, client_secret, redirect_uri = _telegram_oidc_settings()
    verifier, nonce, initiating_device_id = _take_telegram_oidc_state(payload.state)
    basic = base64.b64encode(f"{client_id}:{client_secret}".encode("utf-8")).decode("ascii")
    try:
        response = httpx.post(
            "https://oauth.telegram.org/token",
            headers={"Authorization": f"Basic {basic}", "Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type": "authorization_code",
                "code": payload.code,
                "redirect_uri": redirect_uri,
                "client_id": client_id,
                "code_verifier": verifier,
            },
            timeout=8.0,
        )
        response.raise_for_status()
        id_token = str(response.json().get("id_token", ""))
        if not id_token:
            raise ValueError("Telegram token response has no id_token")
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Telegram authorization code could not be exchanged") from exc
    verified = verify_telegram_oidc_token(id_token, nonce)
    return VerifiedProviderIdentity(
        provider=verified.provider,
        subject=verified.subject,
        email=verified.email,
        email_verified=verified.email_verified,
        display_name=verified.display_name,
        initiating_device_id=initiating_device_id,
    )


def verify_telegram_oidc_token(credential: str, nonce: str | None = None) -> VerifiedProviderIdentity:
    audience = _required_env("TELEGRAM_CLIENT_ID")
    try:
        import jwt
    except ImportError as exc:
        raise HTTPException(status_code=503, detail="Telegram OIDC verification dependency is unavailable") from exc
    try:
        key = jwt.PyJWKClient("https://oauth.telegram.org/.well-known/jwks.json").get_signing_key_from_jwt(credential)
        info = jwt.decode(
            credential,
            key.key,
            algorithms=["RS256", "ES256"],
            audience=audience,
            issuer="https://oauth.telegram.org",
            options={"require": ["exp", "iat", "iss", "aud", "sub"]},
        )
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Invalid Telegram credential") from exc
    if nonce is not None and not hmac.compare_digest(str(info.get("nonce", "")), nonce):
        raise HTTPException(status_code=401, detail="Telegram credential nonce mismatch")
    return VerifiedProviderIdentity(
        provider=AuthProvider.TELEGRAM,
        subject=str(info["sub"]),
        display_name=str(info.get("name")) if info.get("name") else None,
    )


def verify_telegram_init_data(init_data: str, max_age_seconds: int = 300) -> VerifiedProviderIdentity:
    """Verify Telegram Mini App initData using the Bot API HMAC construction."""
    bot_token = _required_env("TELEGRAM_BOT_TOKEN")
    fields = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = fields.pop("hash", "")
    if not received_hash:
        raise HTTPException(status_code=401, detail="Telegram initData has no hash")
    check_string = "\n".join(f"{key}={fields[key]}" for key in sorted(fields))
    secret_key = hmac.new(b"WebAppData", bot_token.encode("utf-8"), hashlib.sha256).digest()
    expected = hmac.new(secret_key, check_string.encode("utf-8"), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received_hash):
        raise HTTPException(status_code=401, detail="Invalid Telegram initData")
    try:
        auth_date = int(fields.get("auth_date", "0"))
    except ValueError as exc:
        raise HTTPException(status_code=401, detail="Invalid Telegram auth_date") from exc
    now = int(datetime.now(timezone.utc).timestamp())
    if auth_date <= 0 or abs(now - auth_date) > max_age_seconds:
        raise HTTPException(status_code=401, detail="Expired Telegram initData")
    try:
        user = json.loads(fields.get("user", "{}"))
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=401, detail="Invalid Telegram user payload") from exc
    subject = str(user.get("id", "")).strip()
    if not subject:
        raise HTTPException(status_code=401, detail="Telegram initData has no user id")
    display_name = " ".join(part for part in [str(user.get("first_name", "")).strip(), str(user.get("last_name", "")).strip()] if part) or None
    return VerifiedProviderIdentity(provider=AuthProvider.TELEGRAM, subject=subject, display_name=display_name)


def verify_facebook_access_token(credential: str) -> VerifiedProviderIdentity:
    app_id = _required_env("FACEBOOK_APP_ID")
    app_secret = _required_env("FACEBOOK_APP_SECRET")
    try:
        response = httpx.get(
            "https://graph.facebook.com/debug_token",
            params={"input_token": credential, "access_token": f"{app_id}|{app_secret}"},
            timeout=8.0,
        )
        response.raise_for_status()
        data = response.json().get("data", {})
    except Exception as exc:
        raise HTTPException(status_code=503, detail="Facebook verification unavailable") from exc
    if not data.get("is_valid") or str(data.get("app_id")) != app_id or not data.get("user_id"):
        raise HTTPException(status_code=401, detail="Invalid Facebook credential")
    return VerifiedProviderIdentity(provider=AuthProvider.FACEBOOK, subject=str(data["user_id"]))


def verify_provider_credential(payload: ProviderCredentialExchange) -> VerifiedProviderIdentity:
    if payload.provider == AuthProvider.GOOGLE:
        return verify_google_id_token(payload.credential, payload.nonce)
    if payload.provider == AuthProvider.TELEGRAM:
        if "auth_date=" in payload.credential and "hash=" in payload.credential:
            return verify_telegram_init_data(payload.credential)
        return verify_telegram_oidc_token(payload.credential, payload.nonce)
    if payload.provider == AuthProvider.FACEBOOK:
        return verify_facebook_access_token(payload.credential)
    raise HTTPException(status_code=400, detail="Use the dedicated email/passkey authentication endpoint")


def request_email_code(payload: EmailCodeRequest) -> str:
    email = _normalize_email(payload.email)
    code = f"{secrets.randbelow(1_000_000):06d}"
    digest = _code_hash(email, code)
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=10)
    if storage_mode() == "memory":
        _MEMORY_EMAIL_CHALLENGES[email] = (digest, expires_at, 0)
        _MEMORY_LAST_EMAIL_CODE[email] = code
    else:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute("UPDATE auth_email_challenges SET consumed_at=now() WHERE email_normalized=%s AND consumed_at IS NULL", (email,))
                cur.execute(
                    "INSERT INTO auth_email_challenges(email_normalized,code_hash,expires_at) VALUES(%s,%s,%s) RETURNING challenge_id",
                    (email, digest, expires_at),
                )
                challenge_id = cur.fetchone()[0]
            conn.commit()
        try:
            _deliver_email_code(email, code, payload.locale)
        except HTTPException:
            # Never leave an undelivered OTP active: delivery failure invalidates this exact challenge.
            with connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("UPDATE auth_email_challenges SET consumed_at=now() WHERE challenge_id=%s", (challenge_id,))
                conn.commit()
            raise
    return email


def _deliver_email_code(email: str, code: str, locale: str) -> None:
    api_key = _required_env("RESEND_API_KEY")
    sender = _required_env("BROTHERHOOD_EMAIL_FROM")
    subject = {"ru": "Код входа Brotherhood", "uk": "Код входу Brotherhood"}.get(locale.split("-", 1)[0].lower(), "Brotherhood sign-in code")
    body = {"ru": f"Ваш код входа: {code}", "uk": f"Ваш код входу: {code}"}.get(locale.split("-", 1)[0].lower(), f"Your sign-in code: {code}")
    try:
        response = httpx.post(
            "https://api.resend.com/emails",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={"from": sender, "to": [email], "subject": subject, "text": body},
            timeout=8.0,
        )
        response.raise_for_status()
    except Exception as exc:
        raise HTTPException(status_code=503, detail="Email delivery unavailable") from exc


def verify_email_code(payload: EmailCodeVerifyRequest) -> str:
    email = _normalize_email(payload.email)
    digest = _code_hash(email, payload.code)
    now = datetime.now(timezone.utc)
    if storage_mode() == "memory":
        row = _MEMORY_EMAIL_CHALLENGES.get(email)
        if not row or row[1] <= now or row[2] >= 5 or not hmac.compare_digest(row[0], digest):
            if row:
                _MEMORY_EMAIL_CHALLENGES[email] = (row[0], row[1], row[2] + 1)
            raise HTTPException(status_code=401, detail="Invalid or expired email code")
        _MEMORY_EMAIL_CHALLENGES.pop(email, None)
        _MEMORY_LAST_EMAIL_CODE.pop(email, None)
        return email

    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT challenge_id, code_hash, attempts FROM auth_email_challenges
                WHERE email_normalized=%s AND consumed_at IS NULL AND expires_at>now()
                ORDER BY created_at DESC LIMIT 1 FOR UPDATE
                """,
                (email,),
            )
            row = cur.fetchone()
            if not row or int(row[2]) >= 5 or not hmac.compare_digest(bytes(row[1]), digest):
                if row:
                    cur.execute("UPDATE auth_email_challenges SET attempts=LEAST(attempts+1,10) WHERE challenge_id=%s", (row[0],))
                    conn.commit()
                raise HTTPException(status_code=401, detail="Invalid or expired email code")
            cur.execute("UPDATE auth_email_challenges SET consumed_at=now() WHERE challenge_id=%s", (row[0],))
        conn.commit()
    return email
