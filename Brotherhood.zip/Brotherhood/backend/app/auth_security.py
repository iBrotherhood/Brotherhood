from __future__ import annotations

import hashlib
import hmac
import os
import secrets
from datetime import datetime, timedelta, timezone

from fastapi import Header, HTTPException

from .database import connection
from .models import AuthProvider, SessionIssueResponse
from .repository import storage_mode

_MEMORY_SESSIONS: dict[str, int] = {"debug-local-session": 1}


def _token_hash(token: str) -> bytes:
    return hashlib.sha256(token.encode("utf-8")).digest()


def _internal_secret() -> str:
    return os.getenv("INTERNAL_AUTH_SECRET", "").strip()


def require_internal_secret(provided: str | None) -> None:
    # Local memory mode is explicitly a test/development runtime.
    if storage_mode() == "memory":
        return
    expected = _internal_secret()
    if not expected:
        raise HTTPException(status_code=503, detail="INTERNAL_AUTH_SECRET is not configured")
    if not provided or not hmac.compare_digest(provided, expected):
        raise HTTPException(status_code=403, detail="Forbidden")


def issue_session(global_id: int, provider: AuthProvider, ttl_hours: int = 24 * 30) -> SessionIssueResponse:
    token = secrets.token_urlsafe(32)
    expires_at = datetime.now(timezone.utc) + timedelta(hours=ttl_hours)
    if storage_mode() == "memory":
        _MEMORY_SESSIONS[token] = global_id
    else:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO auth_sessions(global_id,provider,token_hash,expires_at)
                    VALUES(%s,%s::auth_provider,%s,%s)
                    """,
                    (global_id, provider.value, _token_hash(token), expires_at),
                )
            conn.commit()
    return SessionIssueResponse(
        access_token=token,
        token_type="bearer",
        global_id=global_id,
        global_id_display=f"{global_id:010d}",
        expires_at=expires_at,
    )


def resolve_session(authorization: str | None) -> int | None:
    if not authorization or not authorization.startswith("Bearer "):
        return None
    token = authorization.removeprefix("Bearer ").strip()
    if not token:
        return None
    if storage_mode() == "memory":
        return _MEMORY_SESSIONS.get(token)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT global_id FROM auth_sessions
                WHERE token_hash=%s AND revoked_at IS NULL AND expires_at > now()
                ORDER BY created_at DESC LIMIT 1
                """,
                (_token_hash(token),),
            )
            row = cur.fetchone()
            return int(row[0]) if row else None


def session_global_id(authorization: str | None = Header(default=None, alias="Authorization")) -> int | None:
    value = resolve_session(authorization)
    if storage_mode() == "postgres" and value is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    return value


def require_owner(session_id: int | None, claimed_global_id: int) -> None:
    if storage_mode() == "postgres" and session_id != claimed_global_id:
        raise HTTPException(status_code=403, detail="global_id does not belong to authenticated session")
