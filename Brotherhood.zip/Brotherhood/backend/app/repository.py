from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Iterable
from uuid import UUID

from .database import connection, is_database_configured
from .models import (
    AssessmentDimensionResult,
    AssessmentResultRecord,
    AssessmentResultUpsert,
    AuthProvider,
    Community,
    CommunityCreate,
    CommunityKind,
    CompatibilityRequest,
    IdentityResolveRequest,
    IdentityResolveResponse,
    IncidentStatus,
    MessageCreate,
    MessageRecord,
    NumerologyProfile,
    Person,
    Personality32,
    ProfileRecord,
    ProfileUpsert,
    TrustIncident,
    TrustIncidentCreate,
    TrustSummary,
)
from .services import compatibility
from . import storage as memory


def gid(value: int) -> str:
    if value < 1 or value > 9_999_999_999:
        raise ValueError("global_id outside canonical range")
    return f"{value:010d}"


def storage_mode() -> str:
    configured = os.getenv("BROTHERHOOD_STORAGE_MODE", "auto").strip().lower()
    if configured not in {"auto", "postgres", "memory"}:
        raise RuntimeError("BROTHERHOOD_STORAGE_MODE must be auto, postgres or memory")
    if configured == "memory":
        return "memory"
    if configured == "postgres":
        if not is_database_configured():
            raise RuntimeError("BROTHERHOOD_STORAGE_MODE=postgres but DATABASE_URL is missing")
        return "postgres"
    return "postgres" if is_database_configured() else "memory"


def production_storage_ready() -> bool:
    return storage_mode() == "postgres"


def _secret(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"{name} is required for PostgreSQL encrypted fields")
    return value


def resolve_identity(payload: IdentityResolveRequest) -> IdentityResolveResponse:
    if storage_mode() == "memory":
        return memory.resolve_identity(payload)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT global_id FROM user_identities WHERE provider=%s::auth_provider AND tenant=%s AND provider_subject=%s",
                (payload.provider.value, payload.tenant, payload.provider_subject),
            )
            row = cur.fetchone()
            if row:
                return IdentityResolveResponse(global_id=row[0], global_id_display=gid(row[0]), created=False)
            cur.execute("INSERT INTO users DEFAULT VALUES RETURNING global_id")
            global_id = cur.fetchone()[0]
            cur.execute(
                """
                INSERT INTO user_identities(global_id, provider, tenant, provider_subject, verified_at)
                VALUES (%s, %s::auth_provider, %s, %s, now())
                """,
                (global_id, payload.provider.value, payload.tenant, payload.provider_subject),
            )
        conn.commit()
    return IdentityResolveResponse(global_id=global_id, global_id_display=gid(global_id), created=True)


def upsert_profile(global_id: int, payload: ProfileUpsert) -> ProfileRecord:
    if storage_mode() == "memory":
        return memory.upsert_profile(global_id, payload)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO cities(country_code, region_name, name)
                VALUES (%s, %s, %s)
                ON CONFLICT (country_code, region_name, name)
                DO UPDATE SET name=EXCLUDED.name
                RETURNING city_id
                """,
                (payload.country_code.upper(), payload.region_name or "", payload.city),
            )
            city_id = cur.fetchone()[0]
            cur.execute(
                """
                INSERT INTO profiles(
                    global_id, display_name, birth_date, latin_name, city_id, about,
                    friendship_goals, interests, values_profile, lifestyle_profile,
                    boundaries, visibility, completed_profile_sections, locale, updated_at
                ) VALUES (
                    %s,%s,%s,%s,%s,%s,%s::jsonb,%s::jsonb,%s::jsonb,%s::jsonb,%s::jsonb,%s,%s,%s,now()
                )
                ON CONFLICT (global_id) DO UPDATE SET
                    display_name=EXCLUDED.display_name,
                    birth_date=EXCLUDED.birth_date,
                    latin_name=EXCLUDED.latin_name,
                    city_id=EXCLUDED.city_id,
                    about=EXCLUDED.about,
                    friendship_goals=EXCLUDED.friendship_goals,
                    interests=EXCLUDED.interests,
                    values_profile=EXCLUDED.values_profile,
                    lifestyle_profile=EXCLUDED.lifestyle_profile,
                    boundaries=EXCLUDED.boundaries,
                    visibility=EXCLUDED.visibility,
                    completed_profile_sections=EXCLUDED.completed_profile_sections,
                    locale=EXCLUDED.locale,
                    updated_at=now()
                """,
                (
                    global_id,
                    payload.display_name,
                    payload.birth_date,
                    payload.latin_name,
                    city_id,
                    payload.about,
                    json.dumps(payload.friendship_goals, ensure_ascii=False),
                    json.dumps(payload.interests, ensure_ascii=False),
                    json.dumps(payload.values, ensure_ascii=False),
                    json.dumps(payload.lifestyle, ensure_ascii=False),
                    json.dumps(payload.boundaries, ensure_ascii=False),
                    payload.visibility,
                    payload.completed_profile_sections,
                    payload.locale,
                ),
            )
        conn.commit()
    result = get_profile(global_id)
    if result is None:
        raise RuntimeError("profile upsert failed")
    return result


def get_profile(global_id: int) -> ProfileRecord | None:
    if storage_mode() == "memory":
        return memory.get_profile(global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT p.global_id, p.display_name, p.birth_date, p.latin_name,
                       c.name, c.country_code, NULLIF(c.region_name,''), p.about,
                       p.friendship_goals, p.interests, p.values_profile, p.lifestyle_profile,
                       p.boundaries, p.visibility, p.completed_profile_sections, p.locale
                FROM profiles p
                LEFT JOIN cities c ON c.city_id=p.city_id
                WHERE p.global_id=%s
                """,
                (global_id,),
            )
            row = cur.fetchone()
    if not row:
        return None
    return ProfileRecord(
        global_id=row[0],
        global_id_display=gid(row[0]),
        display_name=row[1],
        birth_date=row[2],
        latin_name=row[3],
        city=row[4] or "",
        country_code=(row[5] or "ZZ").strip(),
        region_name=row[6],
        about=row[7] or "",
        friendship_goals=list(row[8] or []),
        interests=list(row[9] or []),
        values=list(row[10] or []),
        lifestyle=list(row[11] or []),
        boundaries=dict(row[12] or {}),
        visibility=row[13],
        completed_profile_sections=row[14],
        locale=row[15],
    )


def _assessment_score_map_postgres(cur, global_id: int) -> dict[str, int]:
    cur.execute(
        "SELECT assessment_code, scores FROM assessment_results WHERE global_id=%s AND assessment_code BETWEEN 'f001' AND 'f100'",
        (global_id,),
    )
    result: dict[str, int] = {}
    for code, scores in cur.fetchall():
        data = scores if isinstance(scores, dict) else json.loads(scores)
        score = data.get("total_score")
        if isinstance(score, int):
            result[code] = max(0, min(100, score))
    return result


def _trust_summary_postgres(cur, global_id: int) -> TrustSummary:
    cur.execute(
        """
        SELECT
          count(*) FILTER (WHERE status IN ('confirmed','final')),
          count(*) FILTER (WHERE status IN ('pending','under_review','appealed')),
          COALESCE(sum(score_impact) FILTER (WHERE status IN ('confirmed','final')), 0)
        FROM trust_incidents WHERE subject_global_id=%s
        """,
        (global_id,),
    )
    confirmed, pending, impact = cur.fetchone()
    cur.execute(
        "SELECT count(*) FROM verified_interactions WHERE first_global_id=%s OR second_global_id=%s",
        (global_id, global_id),
    )
    interactions = cur.fetchone()[0]
    # New accounts start neutral at 70; confirmed evidence can only reduce this value.
    score = max(0, min(100, 70 + int(impact or 0)))
    return TrustSummary(
        global_id=global_id,
        global_id_display=gid(global_id),
        score=score,
        verified_interactions=int(interactions),
        confirmed_incidents=int(confirmed),
        pending_incidents=int(pending),
    )


def trust_summary(global_id: int) -> TrustSummary:
    if storage_mode() == "memory":
        return memory.trust_summary(global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            return _trust_summary_postgres(cur, global_id)


def list_people(city: str, radius_km: int, requester_global_id: int | None = None) -> list[Person]:
    if storage_mode() == "memory":
        return memory.list_people(city, radius_km, requester_global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT p.global_id, p.display_name,
                       extract(year from age(current_date, p.birth_date))::int AS age,
                       c.name, p.interests, p.values_profile, p.lifestyle_profile,
                       pp.brotherhood32_code, pp.brotherhood32_scores,
                       pp.enneagram_type, pp.zodiac_sign, pp.vedic_numerology,
                       COALESCE(ar.total_rating,0)::int
                FROM profiles p
                JOIN users u ON u.global_id=p.global_id AND u.status='active'
                LEFT JOIN cities c ON c.city_id=p.city_id
                LEFT JOIN personality_profiles pp ON pp.global_id=p.global_id
                LEFT JOIN account_ratings ar ON ar.global_id=p.global_id
                WHERE p.visibility='discoverable' AND c.name=%s
                  AND (%s IS NULL OR p.global_id <> %s)
                ORDER BY ar.total_rating DESC NULLS LAST, p.updated_at DESC
                LIMIT 200
                """,
                (city, requester_global_id, requester_global_id),
            )
            rows = cur.fetchall()
            requester_scores = _assessment_score_map_postgres(cur, requester_global_id) if requester_global_id else {}
            requester_interests: list[str] = []
            if requester_global_id:
                cur.execute("SELECT interests FROM profiles WHERE global_id=%s", (requester_global_id,))
                r = cur.fetchone()
                requester_interests = list((r and r[0]) or [])

            result: list[Person] = []
            for row in rows:
                global_id = int(row[0])
                interests = list(row[4] or [])
                trust = _trust_summary_postgres(cur, global_id)
                candidate_scores = _assessment_score_map_postgres(cur, global_id)
                shared_interest = _overlap(requester_interests, interests) if requester_global_id else 0
                comp = compatibility(CompatibilityRequest(
                    my_scores=requester_scores,
                    candidate_scores=candidate_scores,
                    shared_interest_percent=shared_interest,
                    trust_score=trust.score,
                )) if requester_global_id else None
                scores = dict(row[8] or {})
                personality = None
                if row[7] and scores:
                    personality = Personality32(
                        code=row[7],
                        title=str(scores.get("title", row[7])),
                        social_energy=int(scores.get("social_energy", 50)),
                        perception=int(scores.get("perception", 50)),
                        decision_style=int(scores.get("decision_style", 50)),
                        life_rhythm=int(scores.get("life_rhythm", 50)),
                        bond_style=int(scores.get("bond_style", 50)),
                    )
                numerology_data = dict(row[11] or {})
                numerology = None
                if numerology_data.get("soul_number") and numerology_data.get("destiny_number"):
                    numerology = NumerologyProfile(
                        soul_number=int(numerology_data["soul_number"]),
                        destiny_number=int(numerology_data["destiny_number"]),
                        name_number=int(numerology_data["name_number"]) if numerology_data.get("name_number") else None,
                        maturity_number=int(numerology_data.get("maturity_number", numerology_data["destiny_number"])),
                    )
                result.append(Person(
                    global_id=global_id,
                    global_id_display=gid(global_id),
                    name=row[1],
                    age=max(18, int(row[2] or 18)),
                    city=row[3] or city,
                    distance_km=0,  # city-level search; exact coordinates are deliberately not exposed
                    compatibility=comp.score if comp else 0,
                    trust_score=trust.score,
                    account_rating=int(row[12] or 0),
                    interests=interests,
                    values=list(row[5] or []),
                    lifestyle=list(row[6] or []),
                    personality32=personality,
                    enneagram_type=row[9],
                    zodiac=row[10],
                    numerology=numerology,
                    friendship_test_score=comp.tests_score if comp else 0,
                    common_tests=comp.common_tests if comp else 0,
                    compatibility_risk_flags=comp.risk_flags if comp else [],
                    explanation=(
                        f"Тестовая совместимость рассчитана по {comp.common_tests} общим тестам; полный гибридный итог рассчитывает APK."
                        if comp else "Профиль доступен для совместимого подбора после входа."
                    ),
                ))
            return result


def _overlap(first: Iterable[str], second: Iterable[str]) -> int:
    a = {str(item).casefold() for item in first}
    b = {str(item).casefold() for item in second}
    return len(a & b) * 100 // max(1, len(a | b))


def list_communities(city: str, kind: CommunityKind) -> list[Community]:
    if storage_mode() == "memory":
        return memory.list_communities(city, kind)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT co.community_id::text, co.title, co.category, COALESCE(c.name,'Онлайн'),
                       count(cm.global_id) FILTER (WHERE cm.status='active') AS members,
                       co.kind::text, co.is_online, co.description, co.verified_only
                FROM communities co
                LEFT JOIN cities c ON c.city_id=co.city_id
                LEFT JOIN community_members cm ON cm.community_id=co.community_id
                WHERE co.kind=%s::community_kind AND (co.is_online OR c.name=%s)
                GROUP BY co.community_id, c.name
                ORDER BY members DESC, co.created_at DESC
                """,
                (kind.value, city),
            )
            return [Community(
                id=row[0], title=row[1], category=row[2], city=row[3], members=int(row[4]),
                kind=CommunityKind(row[5]), online=bool(row[6]), description=row[7], verified_only=bool(row[8])
            ) for row in cur.fetchall()]


def create_community(payload: CommunityCreate) -> Community:
    if storage_mode() == "memory":
        return memory.create_community(payload)
    with connection() as conn:
        with conn.cursor() as cur:
            city_id = None
            if not payload.online:
                cur.execute(
                    "INSERT INTO cities(country_code,region_name,name) VALUES('ZZ','',%s) ON CONFLICT(country_code,region_name,name) DO UPDATE SET name=EXCLUDED.name RETURNING city_id",
                    (payload.city,),
                )
                city_id = cur.fetchone()[0]
            cur.execute(
                """
                INSERT INTO communities(owner_global_id,kind,title,category,city_id,is_online,verified_only,description)
                VALUES(%s,%s::community_kind,%s,%s,%s,%s,%s,%s)
                RETURNING community_id::text
                """,
                (payload.owner_global_id, payload.kind.value, payload.title, payload.category, city_id, payload.online, payload.verified_only, payload.description),
            )
            community_id = cur.fetchone()[0]
            cur.execute(
                "INSERT INTO community_members(community_id,global_id,role) VALUES(%s,%s,'owner') ON CONFLICT DO NOTHING",
                (community_id, payload.owner_global_id),
            )
        conn.commit()
    return Community(id=community_id, title=payload.title, category=payload.category, city=payload.city, members=1,
                     kind=payload.kind, online=payload.online, description=payload.description, verified_only=payload.verified_only)


def create_incident(payload: TrustIncidentCreate) -> TrustIncident:
    if storage_mode() == "memory":
        return memory.create_incident(payload)
    key = _secret("TRUST_ENCRYPTION_KEY")
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO trust_incidents(reporter_global_id,subject_global_id,category,occurred_at,description_ciphertext)
                VALUES(%s,%s,%s,%s,pgp_sym_encrypt(%s,%s)) RETURNING incident_id::text,status::text,score_impact
                """,
                (payload.reporter_global_id, payload.subject_global_id, payload.category, payload.occurred_at, payload.description, key),
            )
            incident_id, status, score_impact = cur.fetchone()
            for ref in payload.evidence_refs:
                cur.execute(
                    "INSERT INTO incident_evidence(incident_id,storage_key,content_hash) VALUES(%s,%s,%s)",
                    (incident_id, ref, "client-provided-ref"),
                )
        conn.commit()
    return TrustIncident(id=incident_id, **payload.model_dump(), status=IncidentStatus(status), score_impact=score_impact)


def moderate_incident(incident_id: str, confirmed: bool) -> TrustIncident | None:
    if storage_mode() == "memory":
        return memory.moderate_incident(incident_id, confirmed)
    key = _secret("TRUST_ENCRYPTION_KEY")
    status = IncidentStatus.CONFIRMED if confirmed else IncidentStatus.REJECTED
    impact = -12 if confirmed else 0
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE trust_incidents SET status=%s::incident_status, score_impact=%s
                WHERE incident_id=%s
                RETURNING incident_id::text,reporter_global_id,subject_global_id,category,occurred_at,
                          pgp_sym_decrypt(description_ciphertext,%s),status::text,score_impact
                """,
                (status.value, impact, incident_id, key),
            )
            row = cur.fetchone()
            if not row:
                return None
            cur.execute("SELECT storage_key FROM incident_evidence WHERE incident_id=%s ORDER BY created_at", (incident_id,))
            evidence = [r[0] for r in cur.fetchall()]
        conn.commit()
    return TrustIncident(id=row[0], reporter_global_id=row[1], subject_global_id=row[2], category=row[3],
                         occurred_at=row[4].isoformat(), description=row[5], evidence_refs=evidence,
                         status=IncidentStatus(row[6]), score_impact=row[7])


def upsert_assessment_result(payload: AssessmentResultUpsert) -> AssessmentResultRecord:
    if storage_mode() == "memory":
        return memory.upsert_assessment_result(payload)
    score_json = payload.model_dump(mode="json")
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO assessment_results(global_id,assessment_code,assessment_version,scores,answer_consistency,idealized_self_presentation,completed_at)
                VALUES(%s,%s,%s,%s::jsonb,%s,%s,to_timestamp(%s/1000.0))
                ON CONFLICT(global_id,assessment_code,assessment_version) DO UPDATE SET
                    scores=EXCLUDED.scores,
                    answer_consistency=EXCLUDED.answer_consistency,
                    idealized_self_presentation=EXCLUDED.idealized_self_presentation,
                    completed_at=EXCLUDED.completed_at
                RETURNING result_id::text
                """,
                (payload.global_id, payload.assessment_id, payload.scoring_version, json.dumps(score_json, ensure_ascii=False),
                 payload.answer_consistency, payload.idealized_self_presentation, payload.completed_at_epoch_ms),
            )
            result_id = cur.fetchone()[0]
        conn.commit()
    return AssessmentResultRecord(id=result_id, **payload.model_dump())


def assessment_results_for_user(global_id: int) -> list[AssessmentResultRecord]:
    if storage_mode() == "memory":
        return memory.assessment_results_for_user(global_id)
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT result_id::text,scores FROM assessment_results WHERE global_id=%s ORDER BY completed_at DESC", (global_id,))
            rows = cur.fetchall()
    result: list[AssessmentResultRecord] = []
    for result_id, scores in rows:
        data = scores if isinstance(scores, dict) else json.loads(scores)
        data["id"] = result_id
        result.append(AssessmentResultRecord.model_validate(data))
    return result


def create_message(payload: MessageCreate) -> MessageRecord:
    if payload.sender_global_id == payload.recipient_global_id:
        raise ValueError("sender and recipient must differ")
    if storage_mode() == "memory":
        return memory.create_message(payload)
    key = _secret("MESSAGE_ENCRYPTION_KEY")
    first, second = sorted((payload.sender_global_id, payload.recipient_global_id))
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT c.conversation_id FROM conversations c
                JOIN conversation_members a ON a.conversation_id=c.conversation_id AND a.global_id=%s
                JOIN conversation_members b ON b.conversation_id=c.conversation_id AND b.global_id=%s
                WHERE c.conversation_type='direct'
                LIMIT 1
                """,
                (first, second),
            )
            found = cur.fetchone()
            if found:
                conversation_id = found[0]
            else:
                cur.execute("INSERT INTO conversations(conversation_type) VALUES('direct') RETURNING conversation_id")
                conversation_id = cur.fetchone()[0]
                cur.execute("INSERT INTO conversation_members(conversation_id,global_id) VALUES(%s,%s),(%s,%s)",
                            (conversation_id, first, conversation_id, second))
            cur.execute(
                """
                INSERT INTO messages(conversation_id,sender_global_id,client_message_id,body_ciphertext,created_at)
                VALUES(%s,%s,%s,pgp_sym_encrypt(%s,%s),to_timestamp(%s/1000.0))
                ON CONFLICT(sender_global_id,client_message_id) DO UPDATE SET client_message_id=EXCLUDED.client_message_id
                RETURNING message_id::text,status
                """,
                (conversation_id, payload.sender_global_id, payload.client_message_id, payload.body, key, payload.created_at_epoch_ms),
            )
            message_id, status = cur.fetchone()
        conn.commit()
    return MessageRecord(id=message_id, status=status, **payload.model_dump())


def messages_for_user(global_id: int) -> list[MessageRecord]:
    if storage_mode() == "memory":
        return memory.messages_for_user(global_id)
    key = _secret("MESSAGE_ENCRYPTION_KEY")
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT m.message_id::text,m.sender_global_id,
                       CASE WHEN m.sender_global_id=%s THEN other.global_id ELSE %s END AS recipient_global_id,
                       m.client_message_id,pgp_sym_decrypt(m.body_ciphertext,%s),m.status,
                       (extract(epoch from m.created_at)*1000)::bigint
                FROM messages m
                JOIN conversation_members me ON me.conversation_id=m.conversation_id AND me.global_id=%s
                JOIN conversation_members other ON other.conversation_id=m.conversation_id AND other.global_id<>%s
                ORDER BY m.created_at
                """,
                (global_id, global_id, key, global_id, global_id),
            )
            rows = cur.fetchall()
    return [MessageRecord(id=r[0], sender_global_id=r[1], recipient_global_id=r[2], client_message_id=r[3], body=r[4], status=r[5], created_at_epoch_ms=r[6]) for r in rows]


def upsert_personality_profile(global_id: int, payload):
    from .models import PersonalityProfileRecord
    if storage_mode() == "memory":
        memory.PERSONALITY_PROFILES[global_id] = payload
        return PersonalityProfileRecord(global_id=global_id, global_id_display=gid(global_id), **payload.model_dump())
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO personality_profiles(
                    global_id,brotherhood32_code,brotherhood32_scores,enneagram_type,enneagram_wing,
                    zodiac_sign,vedic_numerology,model_version,updated_at
                ) VALUES(%s,%s,%s::jsonb,%s,%s,%s,%s::jsonb,%s,now())
                ON CONFLICT(global_id) DO UPDATE SET
                    brotherhood32_code=EXCLUDED.brotherhood32_code,
                    brotherhood32_scores=EXCLUDED.brotherhood32_scores,
                    enneagram_type=EXCLUDED.enneagram_type,
                    enneagram_wing=EXCLUDED.enneagram_wing,
                    zodiac_sign=EXCLUDED.zodiac_sign,
                    vedic_numerology=EXCLUDED.vedic_numerology,
                    model_version=EXCLUDED.model_version,
                    updated_at=now()
                """,
                (
                    global_id,
                    payload.brotherhood32_code,
                    json.dumps(payload.brotherhood32_scores, ensure_ascii=False),
                    payload.enneagram_type,
                    payload.enneagram_wing,
                    payload.zodiac_sign,
                    json.dumps(payload.vedic_numerology, ensure_ascii=False),
                    payload.model_version,
                ),
            )
        conn.commit()
    return PersonalityProfileRecord(global_id=global_id, global_id_display=gid(global_id), **payload.model_dump())


def get_personality_profile(global_id: int):
    from .models import PersonalityProfileRecord
    if storage_mode() == "memory":
        payload = memory.PERSONALITY_PROFILES.get(global_id)
        return None if payload is None else PersonalityProfileRecord(global_id=global_id, global_id_display=gid(global_id), **payload.model_dump())
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT brotherhood32_code,brotherhood32_scores,enneagram_type,enneagram_wing,
                       zodiac_sign,vedic_numerology,model_version
                FROM personality_profiles WHERE global_id=%s
                """,
                (global_id,),
            )
            row = cur.fetchone()
    if not row:
        return None
    return PersonalityProfileRecord(
        global_id=global_id,
        global_id_display=gid(global_id),
        brotherhood32_code=row[0],
        brotherhood32_scores=dict(row[1] or {}),
        enneagram_type=row[2],
        enneagram_wing=row[3],
        zodiac_sign=row[4],
        vedic_numerology=dict(row[5] or {}),
        model_version=row[6],
    )
