from enum import StrEnum
from typing import Annotated
from datetime import date, datetime
from pydantic import BaseModel, Field, field_validator

GlobalId = Annotated[int, Field(ge=1, le=9_999_999_999)]


class AuthProvider(StrEnum):
    GOOGLE = "google"
    TELEGRAM = "telegram"
    FACEBOOK = "facebook"
    EMAIL = "email"
    PASSKEY = "passkey"
    APPLE = "apple"
    MICROSOFT = "microsoft"
    PHONE = "phone"


class SessionIssueRequest(BaseModel):
    global_id: GlobalId
    provider: AuthProvider


class SessionIssueResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    global_id: GlobalId
    global_id_display: str
    expires_at: datetime


class CommunityKind(StrEnum):
    INTEREST = "interest"
    BUSINESS = "business"


class IncidentStatus(StrEnum):
    PENDING = "pending"
    UNDER_REVIEW = "under_review"
    CONFIRMED = "confirmed"
    REJECTED = "rejected"
    APPEALED = "appealed"
    FINAL = "final"


class ProfileUpsert(BaseModel):
    display_name: str = Field(min_length=1, max_length=120)
    birth_date: date
    latin_name: str | None = Field(default=None, max_length=160)
    city: str = Field(min_length=1, max_length=120)
    country_code: str = Field(default="ZZ", pattern=r"^[A-Za-z]{2}$")
    region_name: str | None = Field(default=None, max_length=120)
    about: str = Field(default="", max_length=4000)
    friendship_goals: list[str] = []
    interests: list[str] = []
    values: list[str] = []
    lifestyle: list[str] = []
    boundaries: dict[str, object] = {}
    visibility: str = Field(default="discoverable", pattern=r"^(discoverable|connections|private)$")
    completed_profile_sections: int = Field(default=0, ge=0, le=10)
    locale: str = Field(default="ru", pattern=r"^(ru|uk|en)$")


class ProfileRecord(ProfileUpsert):
    global_id: GlobalId
    global_id_display: str

    @field_validator("global_id_display")
    @classmethod
    def validate_profile_display(cls, value: str) -> str:
        if len(value) != 10 or not value.isdigit() or value == "0000000000":
            raise ValueError("global_id_display must contain exactly 10 digits and cannot be zero")
        return value


class PersonalityProfileUpsert(BaseModel):
    brotherhood32_code: str = Field(pattern=r"^[ER][PV][LH][SF][GA]$")
    brotherhood32_scores: dict[str, int | str]
    enneagram_type: int | None = Field(default=None, ge=1, le=9)
    enneagram_wing: int | None = Field(default=None, ge=1, le=9)
    zodiac_sign: str | None = Field(default=None, max_length=32)
    vedic_numerology: dict[str, int | list[int] | None] = {}
    model_version: str = "0.5.7"


class PersonalityProfileRecord(PersonalityProfileUpsert):
    global_id: GlobalId
    global_id_display: str


class Personality32(BaseModel):
    code: str = Field(pattern=r"^[ER][PV][LH][SF][GA]$")
    title: str
    social_energy: int = Field(ge=0, le=100)
    perception: int = Field(ge=0, le=100)
    decision_style: int = Field(ge=0, le=100)
    life_rhythm: int = Field(ge=0, le=100)
    bond_style: int = Field(ge=0, le=100)


class NumerologyProfile(BaseModel):
    soul_number: int = Field(ge=1, le=9)
    destiny_number: int = Field(ge=1, le=9)
    name_number: int | None = Field(default=None, ge=1, le=9)
    maturity_number: int = Field(ge=1, le=9)


class Person(BaseModel):
    global_id: GlobalId
    global_id_display: str
    name: str
    age: int = Field(ge=18)
    city: str
    distance_km: int = Field(ge=0)
    compatibility: int = Field(ge=0, le=100)
    trust_score: int = Field(ge=0, le=100)
    account_rating: int = Field(ge=0, le=100)
    interests: list[str]
    values: list[str] = []
    lifestyle: list[str] = []
    personality32: Personality32 | None = None
    enneagram_type: int | None = Field(default=None, ge=1, le=9)
    zodiac: str | None = None
    numerology: NumerologyProfile | None = None
    friendship_test_score: int = Field(default=0, ge=0, le=100)
    common_tests: int = Field(default=0, ge=0, le=100)
    compatibility_risk_flags: list[str] = []
    explanation: str

    @field_validator("global_id_display")
    @classmethod
    def validate_display(cls, value: str) -> str:
        if len(value) != 10 or not value.isdigit() or value == "0000000000":
            raise ValueError("global_id_display must contain exactly 10 digits and cannot be zero")
        return value


class Community(BaseModel):
    id: str
    title: str
    category: str
    city: str
    members: int = Field(ge=0)
    kind: CommunityKind
    online: bool = False
    description: str
    verified_only: bool = False


class CommunityCreate(BaseModel):
    owner_global_id: GlobalId
    title: str = Field(min_length=3, max_length=100)
    category: str = Field(min_length=2, max_length=60)
    city: str
    kind: CommunityKind
    online: bool = False
    description: str = Field(min_length=10, max_length=1000)
    verified_only: bool = False


class IdentityResolveRequest(BaseModel):
    provider: AuthProvider
    provider_subject: str = Field(min_length=1, max_length=300)
    tenant: str = Field(default="default", min_length=1, max_length=80)


class IdentityResolveResponse(BaseModel):
    global_id: GlobalId
    global_id_display: str
    created: bool


class TrustIncidentCreate(BaseModel):
    reporter_global_id: GlobalId
    subject_global_id: GlobalId
    category: str
    occurred_at: str
    description: str = Field(min_length=20, max_length=4000)
    evidence_refs: list[str] = []


class TrustIncident(BaseModel):
    id: str
    reporter_global_id: GlobalId
    subject_global_id: GlobalId
    category: str
    occurred_at: str
    description: str
    evidence_refs: list[str]
    status: IncidentStatus = IncidentStatus.PENDING
    score_impact: int = 0


class TrustSummary(BaseModel):
    global_id: GlobalId
    global_id_display: str
    score: int = Field(ge=0, le=100)
    verified_interactions: int
    confirmed_incidents: int
    pending_incidents: int


class AssessmentDimensionResult(BaseModel):
    id: str
    title: str
    score: int = Field(ge=0, le=100)


class AssessmentResultUpsert(BaseModel):
    global_id: GlobalId
    assessment_id: str = Field(pattern=r"^f\d{3}$")
    scoring_version: str = "0.5.7"
    total_score: int = Field(ge=0, le=100)
    risk_score: int = Field(default=0, ge=0, le=100)
    answer_consistency: int = Field(ge=0, le=100)
    idealized_self_presentation: int = Field(ge=0, le=100)
    label: str = Field(min_length=2, max_length=200)
    summary: str = Field(min_length=10, max_length=2000)
    dimensions: list[AssessmentDimensionResult]
    completed_at_epoch_ms: int = Field(gt=0)


class AssessmentResultRecord(AssessmentResultUpsert):
    id: str


class AccountRatingRequest(BaseModel):
    completed_profile_section_codes: list[str]
    completed_test_ids: list[str]


class AccountRatingResponse(BaseModel):
    total: float = Field(ge=0, le=100)
    profile_points: float = Field(ge=0, le=50)
    test_points: float = Field(ge=0, le=50)
    completed_profile_sections: int
    completed_tests: int


class CompatibilityRequest(BaseModel):
    my_scores: dict[str, int]
    candidate_scores: dict[str, int]
    shared_interest_percent: int = Field(ge=0, le=100)
    trust_score: int = Field(ge=0, le=100)


class CompatibilityResponse(BaseModel):
    score: int = Field(ge=0, le=100)
    tests_score: int = Field(ge=0, le=100)
    common_tests: int
    confidence: int = Field(ge=0, le=100)
    risk_flags: list[str]


class MessageCreate(BaseModel):
    sender_global_id: GlobalId
    recipient_global_id: GlobalId
    client_message_id: str = Field(min_length=8, max_length=120)
    body: str = Field(min_length=1, max_length=4000)
    created_at_epoch_ms: int = Field(gt=0)


class MessageRecord(MessageCreate):
    id: str
    status: str = Field(pattern=r"^(queued|sent|delivered|read)$")
