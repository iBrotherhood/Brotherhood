# Generated canonical registry for Brotherhood v0.5.8
VALID_TEST_IDS = {f"f{number:03d}" for number in range(1, 101)}
SAFETY_CRITICAL_TEST_IDS = {'f013', 'f055', 'f062', 'f076', 'f094', 'f044', 'f046', 'f100', 'f033', 'f002', 'f017', 'f012', 'f016', 'f092', 'f010', 'f089', 'f083', 'f067', 'f032', 'f001', 'f050', 'f003', 'f052', 'f065', 'f019', 'f020', 'f049', 'f085', 'f009', 'f023', 'f068', 'f015', 'f028', 'f039', 'f030', 'f029', 'f048', 'f027', 'f036', 'f024', 'f038', 'f063', 'f018', 'f084', 'f057', 'f031', 'f082', 'f090', 'f006', 'f043', 'f047', 'f022', 'f041', 'f088', 'f064', 'f081', 'f035', 'f034', 'f007', 'f042', 'f005', 'f056', 'f060', 'f054', 'f053', 'f004', 'f087', 'f061', 'f086', 'f011', 'f026', 'f066', 'f025', 'f069'}
SIMILARITY_TEST_IDS = {'f096', 'f071', 'f094', 'f074', 'f073', 'f079', 'f080', 'f091', 'f075', 'f072', 'f097', 'f093', 'f045', 'f095', 'f099', 'f077'}
PROFILE_SECTION_CODES = {"identity", "photo", "city", "about", "friendship_goals", "interests", "boundaries", "communication", "availability", "verification"}


# Ten canonical tests per friendship dimension. Kept server-side so a mobile client cannot
# relabel tests to manipulate category compatibility.
TEST_KIND_ORDER = [
    "loyalty", "integrity", "reliability", "conflict", "boundaries",
    "support", "competition", "communication", "mutual_aid", "lifestyle",
]
TEST_KIND_BY_ID = {
    f"f{number:03d}": TEST_KIND_ORDER[(number - 1) // 10]
    for number in range(1, 101)
}
