from __future__ import annotations

import base64
import json
import os
from datetime import datetime, timedelta, timezone
from uuid import UUID, uuid4

from fastapi import HTTPException

from .auth_security import issue_session
from .database import connection
from .models import AuthProvider, PasskeyAuthenticationFinish, PasskeyOptionsResponse, PasskeyRegistrationFinish, SessionIssueResponse
from .repository import storage_mode

_MEMORY_CHALLENGES: dict[UUID, tuple[str, bytes, int | None, datetime]] = {}
_MEMORY_CREDENTIALS: dict[bytes, tuple[int, bytes, int]] = {}


def _settings() -> tuple[str, str, str]:
    rp_id = os.getenv("PASSKEY_RP_ID", "").strip()
    rp_name = os.getenv("PASSKEY_RP_NAME", "Brotherhood").strip() or "Brotherhood"
    origin = os.getenv("PASSKEY_ORIGIN", "").strip()
    if storage_mode() == "memory":
        return rp_id or "localhost", rp_name, origin or "https://localhost"
    missing = [name for name, value in (("PASSKEY_RP_ID", rp_id), ("PASSKEY_ORIGIN", origin)) if not value]
    if missing:
        raise HTTPException(status_code=503, detail=f"Passkey configuration missing: {', '.join(missing)}")
    return rp_id, rp_name, origin


def _webauthn():
    try:
        from webauthn import (
            generate_authentication_options,
            generate_registration_options,
            options_to_json,
            verify_authentication_response,
            verify_registration_response,
        )
        from webauthn.helpers.structs import (
            AuthenticatorSelectionCriteria,
            ResidentKeyRequirement,
            UserVerificationRequirement,
        )
    except ImportError as exc:
        raise HTTPException(status_code=503, detail="Passkey verification dependency is unavailable") from exc
    return (
        generate_authentication_options,
        generate_registration_options,
        options_to_json,
        verify_authentication_response,
        verify_registration_response,
        AuthenticatorSelectionCriteria,
        ResidentKeyRequirement,
        UserVerificationRequirement,
    )


def _store_challenge(kind: str, challenge: bytes, global_id: int | None) -> UUID:
    challenge_id = uuid4()
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=5)
    if storage_mode() == "memory":
        _MEMORY_CHALLENGES[challenge_id] = (kind, challenge, global_id, expires_at)
        return challenge_id
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO passkey_challenges(challenge_id,kind,challenge,global_id,expires_at) VALUES(%s,%s,%s,%s,%s)",
                (challenge_id, kind, challenge, global_id, expires_at),
            )
        conn.commit()
    return challenge_id


def _take_challenge(challenge_id: UUID, kind: str) -> tuple[bytes, int | None]:
    now = datetime.now(timezone.utc)
    if storage_mode() == "memory":
        row = _MEMORY_CHALLENGES.pop(challenge_id, None)
        if not row or row[0] != kind or row[3] <= now:
            raise HTTPException(status_code=401, detail="Invalid or expired passkey challenge")
        return row[1], row[2]
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT challenge, global_id FROM passkey_challenges
                WHERE challenge_id=%s AND kind=%s AND consumed_at IS NULL AND expires_at>now()
                FOR UPDATE
                """,
                (challenge_id, kind),
            )
            row = cur.fetchone()
            if not row:
                raise HTTPException(status_code=401, detail="Invalid or expired passkey challenge")
            cur.execute("UPDATE passkey_challenges SET consumed_at=now() WHERE challenge_id=%s", (challenge_id,))
        conn.commit()
    return bytes(row[0]), int(row[1]) if row[1] is not None else None


def registration_options(global_id: int) -> PasskeyOptionsResponse:
    rp_id, rp_name, _ = _settings()
    (
        _,
        generate_registration_options,
        options_to_json,
        _,
        _,
        AuthenticatorSelectionCriteria,
        ResidentKeyRequirement,
        UserVerificationRequirement,
    ) = _webauthn()
    options = generate_registration_options(
        rp_id=rp_id,
        rp_name=rp_name,
        user_id=str(global_id).encode("ascii"),
        user_name=f"brotherhood-{global_id:010d}",
        user_display_name=f"Brotherhood {global_id:010d}",
        authenticator_selection=AuthenticatorSelectionCriteria(
            resident_key=ResidentKeyRequirement.REQUIRED,
            user_verification=UserVerificationRequirement.REQUIRED,
        ),
    )
    challenge_id = _store_challenge("registration", bytes(options.challenge), global_id)
    return PasskeyOptionsResponse(challenge_id=challenge_id, options_json=options_to_json(options))


def finish_registration(global_id: int, payload: PasskeyRegistrationFinish) -> bool:
    rp_id, _, origin = _settings()
    _, _, _, _, verify_registration_response, _, _, _ = _webauthn()
    challenge, challenge_global_id = _take_challenge(payload.challenge_id, "registration")
    if challenge_global_id != global_id:
        raise HTTPException(status_code=403, detail="Passkey challenge owner mismatch")
    try:
        verified = verify_registration_response(
            credential=json.loads(payload.credential_json),
            expected_challenge=challenge,
            expected_rp_id=rp_id,
            expected_origin=origin,
            require_user_verification=True,
        )
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Invalid passkey registration") from exc

    credential_id = bytes(verified.credential_id)
    public_key = bytes(verified.credential_public_key)
    sign_count = int(verified.sign_count)
    if storage_mode() == "memory":
        _MEMORY_CREDENTIALS[credential_id] = (global_id, public_key, sign_count)
        return True
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO passkey_credentials(global_id,credential_id,public_key,sign_count,device_type,backed_up,last_used_at)
                VALUES(%s,%s,%s,%s,%s,%s,now())
                ON CONFLICT (credential_id) DO UPDATE SET
                    public_key=EXCLUDED.public_key,
                    sign_count=GREATEST(passkey_credentials.sign_count, EXCLUDED.sign_count),
                    device_type=EXCLUDED.device_type,
                    backed_up=EXCLUDED.backed_up,
                    last_used_at=now()
                WHERE passkey_credentials.global_id=EXCLUDED.global_id
                """,
                (
                    global_id,
                    credential_id,
                    public_key,
                    sign_count,
                    str(getattr(verified, "credential_device_type", "")) or None,
                    bool(getattr(verified, "credential_backed_up", False)),
                ),
            )
        conn.commit()
    return True


def authentication_options() -> PasskeyOptionsResponse:
    rp_id, _, _ = _settings()
    generate_authentication_options, _, options_to_json, _, _, _, _, UserVerificationRequirement = _webauthn()
    options = generate_authentication_options(
        rp_id=rp_id,
        user_verification=UserVerificationRequirement.REQUIRED,
    )
    challenge_id = _store_challenge("authentication", bytes(options.challenge), None)
    return PasskeyOptionsResponse(challenge_id=challenge_id, options_json=options_to_json(options))


def _credential_id_from_json(credential_json: str) -> bytes:
    try:
        payload = json.loads(credential_json)
        raw = str(payload.get("rawId") or payload.get("id") or "")
        if not raw:
            raise ValueError("missing credential id")
        return base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4))
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Passkey credential id is invalid") from exc


def finish_authentication(payload: PasskeyAuthenticationFinish) -> SessionIssueResponse:
    rp_id, _, origin = _settings()
    _, _, _, verify_authentication_response, _, _, _, _ = _webauthn()
    challenge, _ = _take_challenge(payload.challenge_id, "authentication")
    credential_id = _credential_id_from_json(payload.credential_json)

    if storage_mode() == "memory":
        row = _MEMORY_CREDENTIALS.get(credential_id)
        if not row:
            raise HTTPException(status_code=401, detail="Unknown passkey")
        global_id, public_key, sign_count = row
    else:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT global_id,public_key,sign_count FROM passkey_credentials WHERE credential_id=%s AND revoked_at IS NULL",
                    (credential_id,),
                )
                row = cur.fetchone()
        if not row:
            raise HTTPException(status_code=401, detail="Unknown passkey")
        global_id, public_key, sign_count = int(row[0]), bytes(row[1]), int(row[2])

    try:
        verified = verify_authentication_response(
            credential=json.loads(payload.credential_json),
            expected_challenge=challenge,
            expected_rp_id=rp_id,
            expected_origin=origin,
            credential_public_key=public_key,
            credential_current_sign_count=sign_count,
            require_user_verification=True,
        )
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Invalid passkey assertion") from exc

    new_sign_count = int(verified.new_sign_count)
    if storage_mode() == "memory":
        _MEMORY_CREDENTIALS[credential_id] = (global_id, public_key, new_sign_count)
    else:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE passkey_credentials SET sign_count=%s,last_used_at=now() WHERE credential_id=%s AND global_id=%s",
                    (new_sign_count, credential_id, global_id),
                )
            conn.commit()
    return issue_session(global_id, AuthProvider.PASSKEY, device_id=payload.device_id)
