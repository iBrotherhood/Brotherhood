from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
import os

from .models import (
    AccountRatingRequest,
    AccountRatingResponse,
    AssessmentResultRecord,
    AssessmentResultUpsert,
    CompatibilityRequest,
    CompatibilityResponse,
    Community,
    CommunityCreate,
    CommunityKind,
    IdentityResolveRequest,
    IdentityResolveResponse,
    Person,
    PersonalityProfileRecord,
    PersonalityProfileUpsert,
    ProfileRecord,
    ProfileUpsert,
    TrustIncident,
    TrustIncidentCreate,
    TrustSummary,
    MessageCreate,
    MessageRecord,
    SessionIssueRequest,
    SessionIssueResponse,
)
from .services import account_rating, compatibility
from .database import database_health
from .auth_security import issue_session, require_internal_secret, require_owner, session_global_id
from .provider_config import provider_readiness
from .repository import (
    assessment_results_for_user,
    create_community,
    create_incident,
    create_message,
    get_personality_profile,
    get_profile,
    list_communities,
    list_people,
    messages_for_user,
    moderate_incident,
    production_storage_ready,
    resolve_identity,
    storage_mode,
    trust_summary,
    upsert_personality_profile,
    upsert_assessment_result,
    upsert_profile,
)


app = FastAPI(
    title="Brotherhood API",
    version="0.5.6",
    description="Offline-first platform for male friendship compatibility, communities, global identity and moderated trust reputation.",
)

allowed_origins = [
    item.strip()
    for item in os.getenv("BROTHERHOOD_ALLOWED_ORIGINS", "http://localhost,http://127.0.0.1").split(",")
    if item.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

CITIES = ["Киев", "Львов", "Одесса", "Харьков", "Днепр", "Ужгород", "Мукачево", "Свалява", "Варшава", "Берлин"]


@app.get("/health")
def health() -> dict[str, str | bool]:
    return {"status": "ok", "service": "brotherhood-api", "version": "0.5.6", "storage": storage_mode(), "production_ready": production_storage_ready()}


@app.get("/v1/config")
def public_config() -> dict[str, object]:
    return {
        "version": "0.5.6",
        "audience": "men_18_plus",
        "relationship_scope": "platonic_male_friendship",
        "locales": ["ru", "uk", "en"],
        "themes": ["system", "light", "black"],
        "auth_providers": ["google", "telegram", "facebook", "email", "passkey"],
        "future_auth_providers": ["apple", "microsoft", "phone"],
        "personality_model": {"name": "Brotherhood-32", "type_count": 32},
        "tests": {"count": 100, "question_count": 600},
        "global_id_format": "0000000001",
        "database_access": "vercel_backend_only"
    }


@app.get("/health/database")
def health_database() -> dict[str, str | bool]:
    return database_health()


@app.get("/health/storage")
def health_storage() -> dict[str, str | bool]:
    return {"mode": storage_mode(), "production_ready": production_storage_ready()}


@app.post("/internal/identity/resolve", response_model=IdentityResolveResponse)
def identity_resolve(
    payload: IdentityResolveRequest,
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> IdentityResolveResponse:
    """Called only after a provider credential has been verified server-side."""
    require_internal_secret(internal_auth)
    return resolve_identity(payload)


@app.post("/internal/sessions/issue", response_model=SessionIssueResponse)
def session_issue(
    payload: SessionIssueRequest,
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> SessionIssueResponse:
    """Bridge used by verified Google/Telegram/Facebook adapters to issue an app session."""
    require_internal_secret(internal_auth)
    return issue_session(payload.global_id, payload.provider)


@app.get("/v1/auth/providers")
def auth_providers() -> list[dict[str, object]]:
    return provider_readiness()


@app.get("/v1/cities", response_model=list[str])
def cities(q: str | None = None) -> list[str]:
    if not q:
        return CITIES
    query = q.casefold()
    return [city for city in CITIES if query in city.casefold()]


@app.get("/v1/people", response_model=list[Person])
def people(
    city: str,
    radius_km: int = Query(default=25, ge=1, le=500),
    requester_global_id: int | None = Query(default=None, ge=1, le=9_999_999_999),
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[Person]:
    if authenticated_global_id is not None:
        if requester_global_id is not None and requester_global_id != authenticated_global_id:
            raise HTTPException(status_code=403, detail="requester_global_id does not match authenticated session")
        requester_global_id = authenticated_global_id
    return list_people(city, radius_km, requester_global_id)


@app.get("/v1/communities", response_model=list[Community])
def communities(city: str, kind: CommunityKind) -> list[Community]:
    return list_communities(city, kind)


@app.post("/v1/communities", response_model=Community, status_code=201)
def add_community(
    payload: CommunityCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> Community:
    require_owner(authenticated_global_id, payload.owner_global_id)
    return create_community(payload)


@app.post("/v1/trust/incidents", response_model=TrustIncident, status_code=201)
def add_incident(
    payload: TrustIncidentCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> TrustIncident:
    require_owner(authenticated_global_id, payload.reporter_global_id)
    if payload.reporter_global_id == payload.subject_global_id:
        raise HTTPException(status_code=400, detail="Нельзя подать жалобу на самого себя")
    return create_incident(payload)


@app.post("/v1/trust/incidents/{incident_id}/moderate", response_model=TrustIncident)
def moderate(incident_id: str, confirmed: bool) -> TrustIncident:
    incident = moderate_incident(incident_id, confirmed)
    if incident is None:
        raise HTTPException(status_code=404, detail="Инцидент не найден")
    return incident


@app.get("/v1/trust/{global_id}", response_model=TrustSummary)
def get_trust(global_id: int) -> TrustSummary:
    return trust_summary(global_id)


@app.put("/v1/profiles/{global_id}", response_model=ProfileRecord)
def save_profile(
    global_id: int,
    payload: ProfileUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ProfileRecord:
    require_owner(authenticated_global_id, global_id)
    if global_id < 1 or global_id > 9_999_999_999:
        raise HTTPException(status_code=400, detail="Некорректный global_id")
    return upsert_profile(global_id, payload)


@app.get("/v1/profiles/{global_id}", response_model=ProfileRecord)
def read_profile(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ProfileRecord:
    require_owner(authenticated_global_id, global_id)
    profile = get_profile(global_id)
    if profile is None:
        raise HTTPException(status_code=404, detail="Профиль не найден")
    return profile


@app.put("/v1/personality-profile/{global_id}", response_model=PersonalityProfileRecord)
def save_personality_profile(
    global_id: int,
    payload: PersonalityProfileUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> PersonalityProfileRecord:
    require_owner(authenticated_global_id, global_id)
    return upsert_personality_profile(global_id, payload)


@app.get("/v1/personality-profile/{global_id}", response_model=PersonalityProfileRecord)
def read_personality_profile(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> PersonalityProfileRecord:
    require_owner(authenticated_global_id, global_id)
    profile = get_personality_profile(global_id)
    if profile is None:
        raise HTTPException(status_code=404, detail="Профиль личности не найден")
    return profile


@app.put("/v1/assessment-results", response_model=AssessmentResultRecord)
def save_assessment_result(
    payload: AssessmentResultUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> AssessmentResultRecord:
    require_owner(authenticated_global_id, payload.global_id)
    return upsert_assessment_result(payload)


@app.get("/v1/assessment-results/{global_id}", response_model=list[AssessmentResultRecord])
def get_assessment_results(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[AssessmentResultRecord]:
    require_owner(authenticated_global_id, global_id)
    return assessment_results_for_user(global_id)


@app.post("/v1/account-rating", response_model=AccountRatingResponse)
def calculate_account_rating(payload: AccountRatingRequest) -> AccountRatingResponse:
    return account_rating(payload)


@app.post("/v1/compatibility", response_model=CompatibilityResponse)
def calculate_compatibility(payload: CompatibilityRequest) -> CompatibilityResponse:
    return compatibility(payload)


@app.post("/v1/messages", response_model=MessageRecord, status_code=201)
def send_message(
    payload: MessageCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> MessageRecord:
    require_owner(authenticated_global_id, payload.sender_global_id)
    if payload.sender_global_id == payload.recipient_global_id:
        raise HTTPException(status_code=400, detail="Нельзя отправить сообщение самому себе")
    return create_message(payload)


@app.get("/v1/messages/{global_id}", response_model=list[MessageRecord])
def list_messages(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[MessageRecord]:
    require_owner(authenticated_global_id, global_id)
    return messages_for_user(global_id)
