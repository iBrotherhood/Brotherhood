from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
import os

from .localization import city_values, localized_city_options, normalize_locale, public_language_catalog, supported_locale_tags
from .models import (
    AccountRatingRequest,
    AccountRatingResponse,
    AssessmentPublicReceipt,
    AssessmentResultRecord,
    AssessmentResultUpsert,
    CalibrationConsentRecord,
    CalibrationConsentUpsert,
    CompatibilityRequest,
    CompatibilityResponse,
    FriendshipOutcomeRecord,
    FriendshipOutcomeUpsert,
    Community,
    CommunityCreate,
    CommunityKind,
    IdentityResolveRequest,
    IdentityResolveResponse,
    Person,
    PersonalityProfileRecord,
    PersonalityProfileUpsert,
    ProfileAvatarRecord,
    ProfileAvatarUpsert,
    ProfileRecord,
    ProfileUpsert,
    TrustIncident,
    TrustIncidentCreate,
    TrustSummary,
    MessageCreate,
    MessageRecord,
    AppVersionManifest, AttachmentPayload, ChatMessageCreate, ChatMessageEdit, ChatMessageRecord, ConversationSummary, ConversationMemberRecord, DeviceKeyRecord, DeviceKeyUpsert, DirectConversationCreate, GroupConversationCreate, ReadReceiptRequest, MessageReactionRequest, MessageReactionRecord, TypingRequest, TypingStatus, UserBlockRequest, UserBlockStatus, ChatReportCreate, PushTokenUpsert,
    SessionIssueRequest,
    SessionIssueResponse,
)
from .services import account_rating, compatibility
from .database import database_health
from .auth_security import issue_session, require_internal_secret, require_owner, session_global_id
from .provider_config import provider_readiness
from .repository import (
    assessment_results_for_user,
    calibration_consent_for_user,
    friendship_outcomes_for_analysis,
    create_community,
    create_incident,
    create_message,
    get_personality_profile,
    get_profile,
    list_communities,
    list_people,
    messages_for_user,
    app_version_manifest, attachment_payload, chat_messages, conversations_for_user, conversation_members, add_group_member, remove_group_member, create_chat_message, create_group_conversation, device_keys_for_user, mark_chat_read, open_direct_conversation, upsert_device_key, edit_chat_message, toggle_message_reaction, delete_chat_message, set_typing, typing_users, set_user_block, is_user_blocked, has_user_block, upsert_push_token,
    moderate_incident,
    production_storage_ready,
    resolve_identity,
    storage_mode,
    trust_summary,
    upsert_personality_profile,
    upsert_assessment_result,
    upsert_calibration_consent,
    upsert_friendship_outcome,
    upsert_profile,
    upsert_profile_avatar,
)


app = FastAPI(
    title="Brotherhood API",
    version="0.5.16",
    description="Offline-first platform for male friendship compatibility, communities, global identity and moderated trust reputation.",
)

allowed_origins = [
    item.strip()
    for item in os.getenv("BROTHERHOOD_ALLOWED_ORIGINS", "http://localhost,http://127.0.0.1").split(",")
    if item.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

CITIES = list(city_values())


@app.get("/health")
def health() -> dict[str, str | bool]:
    return {"status": "ok", "service": "brotherhood-api", "version": "0.5.16", "storage": storage_mode(), "production_ready": production_storage_ready()}


@app.get("/v1/config")
def public_config() -> dict[str, object]:
    return {
        "version": "0.5.16",
        "audience": "men_18_plus",
        "relationship_scope": "platonic_male_friendship",
        "locales": list(supported_locale_tags()),
        "languages": public_language_catalog(),
        "themes": ["system", "light", "black"],
        "auth_providers": ["google", "telegram", "facebook", "email", "passkey"],
        "future_auth_providers": ["apple", "microsoft", "phone"],
        "personality_model": {"name": "Brotherhood-32", "type_count": 32},
        "tests": {"count": 100, "task_count": 600, "question_count": 600, "question_count_status": "legacy_api_alias", "format": "indirect_visual_associative", "numerology_is_test": False},
        "compatibility_layers": ["tests", "interests", "character", "values", "lifestyle", "friendship_goals", "communication", "conflict", "business", "social_format", "brotherhood32", "enneagram", "zodiac", "vedic_numerology", "geography"],
        "diagnostic_predictors": [],
        "quality_matching": {"catalog_version": "quality-fit-catalog-v2", "quality_count": 112, "assessment_model": "visual-latent-v2", "user_selects_role": True, "user_selects_qualities": True, "separate_from_compatibility": True, "raw_latent_profile_public": False},
        "weight_calibration": {"source": "friendship_outcomes", "target": "still_active_90d", "automatic_production_reweighting": False},
        "vedic_numerology": {"is_test": False, "compatibility_source": "birth_dates_only"},
        "chat": {"direct": "e2ee", "groups": "server_encrypted", "features": ["media", "reply", "reactions", "edit", "delete", "typing", "receipts", "block", "report", "group_member_management", "offline_retry"]},
        "global_id_format": "0000000001",
        "database_access": "vercel_backend_only"
    }


@app.get("/health/database")
def health_database() -> dict[str, str | bool]:
    return database_health()


@app.get("/health/storage")
def health_storage() -> dict[str, str | bool]:
    return {"mode": storage_mode(), "production_ready": production_storage_ready()}


@app.post("/internal/identity/resolve", response_model=IdentityResolveResponse)
def identity_resolve(
    payload: IdentityResolveRequest,
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> IdentityResolveResponse:
    """Called only after a provider credential has been verified server-side."""
    require_internal_secret(internal_auth)
    return resolve_identity(payload)


@app.post("/internal/sessions/issue", response_model=SessionIssueResponse)
def session_issue(
    payload: SessionIssueRequest,
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> SessionIssueResponse:
    """Bridge used by verified Google/Telegram/Facebook adapters to issue an app session."""
    require_internal_secret(internal_auth)
    return issue_session(payload.global_id, payload.provider)


@app.get("/v1/auth/providers")
def auth_providers() -> list[dict[str, object]]:
    return provider_readiness()


@app.get("/v1/cities", response_model=list[str], deprecated=True)
def cities(q: str | None = None) -> list[str]:
    """Legacy canonical city values. New clients should use /v1/city-options."""
    if not q:
        return CITIES
    query = q.casefold()
    return [city for city in CITIES if query in city.casefold()]


@app.get("/v1/city-options", response_model=list[dict[str, str]])
def city_options(
    q: str | None = None,
    locale: str = Query(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$"),
) -> list[dict[str, str]]:
    """Localized presentation labels paired with stable search/storage values."""
    return localized_city_options(normalize_locale(locale), q)


@app.get("/v1/people", response_model=list[Person])
def people(
    city: str,
    radius_km: int = Query(default=25, ge=1, le=500),
    requester_global_id: int | None = Query(default=None, ge=1, le=9_999_999_999),
    role: str = Query(default="friend", max_length=40),
    qualities: str = Query(default="", max_length=2400),
    locale: str = Query(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$"),
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[Person]:
    if authenticated_global_id is not None:
        if requester_global_id is not None and requester_global_id != authenticated_global_id:
            raise HTTPException(status_code=403, detail="requester_global_id does not match authenticated session")
        requester_global_id = authenticated_global_id
    # role is user-authored context metadata only; it never injects hidden default qualities.
    desired = [item for item in qualities.split(",") if item][:100]
    return list_people(city, radius_km, requester_global_id, desired_qualities=desired, locale=normalize_locale(locale))


@app.get("/v1/communities", response_model=list[Community])
def communities(
    city: str,
    kind: CommunityKind,
    locale: str = Query(default="ru", pattern=r"^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$"),
) -> list[Community]:
    return list_communities(city, kind, normalize_locale(locale))


@app.post("/v1/communities", response_model=Community, status_code=201)
def add_community(
    payload: CommunityCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> Community:
    require_owner(authenticated_global_id, payload.owner_global_id)
    return create_community(payload)


@app.post("/v1/trust/incidents", response_model=TrustIncident, status_code=201)
def add_incident(
    payload: TrustIncidentCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> TrustIncident:
    require_owner(authenticated_global_id, payload.reporter_global_id)
    if payload.reporter_global_id == payload.subject_global_id:
        raise HTTPException(status_code=400, detail="Нельзя подать жалобу на самого себя")
    return create_incident(payload)


@app.post("/v1/trust/incidents/{incident_id}/moderate", response_model=TrustIncident)
def moderate(incident_id: str, confirmed: bool) -> TrustIncident:
    incident = moderate_incident(incident_id, confirmed)
    if incident is None:
        raise HTTPException(status_code=404, detail="Инцидент не найден")
    return incident


@app.get("/v1/trust/{global_id}", response_model=TrustSummary)
def get_trust(global_id: int) -> TrustSummary:
    return trust_summary(global_id)


@app.put("/v1/profiles/{global_id}", response_model=ProfileRecord)
def save_profile(
    global_id: int,
    payload: ProfileUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ProfileRecord:
    require_owner(authenticated_global_id, global_id)
    if global_id < 1 or global_id > 9_999_999_999:
        raise HTTPException(status_code=400, detail="Некорректный global_id")
    return upsert_profile(global_id, payload)


@app.put("/v1/profiles/{global_id}/avatar", response_model=ProfileAvatarRecord)
def save_profile_avatar(
    global_id: int,
    payload: ProfileAvatarUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ProfileAvatarRecord:
    require_owner(authenticated_global_id, global_id)
    try:
        return upsert_profile_avatar(global_id, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/v1/profiles/{global_id}", response_model=ProfileRecord)
def read_profile(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ProfileRecord:
    require_owner(authenticated_global_id, global_id)
    profile = get_profile(global_id)
    if profile is None:
        raise HTTPException(status_code=404, detail="Профиль не найден")
    return profile


@app.put("/v1/personality-profile/{global_id}", response_model=PersonalityProfileRecord)
def save_personality_profile(
    global_id: int,
    payload: PersonalityProfileUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> PersonalityProfileRecord:
    require_owner(authenticated_global_id, global_id)
    return upsert_personality_profile(global_id, payload)


@app.get("/v1/personality-profile/{global_id}", response_model=PersonalityProfileRecord)
def read_personality_profile(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> PersonalityProfileRecord:
    require_owner(authenticated_global_id, global_id)
    profile = get_personality_profile(global_id)
    if profile is None:
        raise HTTPException(status_code=404, detail="Профиль личности не найден")
    return profile


def _assessment_receipt(item: AssessmentResultRecord) -> AssessmentPublicReceipt:
    return AssessmentPublicReceipt(
        id=item.id,
        global_id=item.global_id,
        assessment_id=item.assessment_id,
        model_version=item.scoring_version,
        completed_at_epoch_ms=item.completed_at_epoch_ms,
    )



@app.put("/v1/calibration-consent", response_model=CalibrationConsentRecord)
def set_calibration_consent(
    payload: CalibrationConsentUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> CalibrationConsentRecord:
    require_owner(authenticated_global_id, payload.global_id)
    return upsert_calibration_consent(payload)


@app.get("/v1/calibration-consent/{global_id}", response_model=CalibrationConsentRecord | None)
def get_calibration_consent(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> CalibrationConsentRecord | None:
    require_owner(authenticated_global_id, global_id)
    return calibration_consent_for_user(global_id)

@app.put("/v1/assessment-results", response_model=AssessmentPublicReceipt)
def save_assessment_result(
    payload: AssessmentResultUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> AssessmentPublicReceipt:
    require_owner(authenticated_global_id, payload.global_id)
    if payload.scoring_version != "visual-latent-v2":
        raise HTTPException(status_code=400, detail="unsupported assessment model")
    return _assessment_receipt(upsert_assessment_result(payload))


@app.get("/v1/assessment-results/{global_id}", response_model=list[AssessmentPublicReceipt])
def get_assessment_results(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[AssessmentPublicReceipt]:
    require_owner(authenticated_global_id, global_id)
    return [_assessment_receipt(item) for item in assessment_results_for_user(global_id)]


@app.get("/internal/assessment-results/{global_id}", response_model=list[AssessmentResultRecord])
def get_internal_assessment_results(
    global_id: int,
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> list[AssessmentResultRecord]:
    require_internal_secret(internal_auth)
    return assessment_results_for_user(global_id)


@app.put("/internal/friendship-outcomes", response_model=FriendshipOutcomeRecord)
def save_friendship_outcome(
    payload: FriendshipOutcomeUpsert,
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> FriendshipOutcomeRecord:
    require_internal_secret(internal_auth)
    try:
        return upsert_friendship_outcome(payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/internal/friendship-outcomes", response_model=list[FriendshipOutcomeRecord])
def export_friendship_outcomes(
    internal_auth: str | None = Header(default=None, alias="X-Internal-Auth"),
) -> list[FriendshipOutcomeRecord]:
    require_internal_secret(internal_auth)
    return friendship_outcomes_for_analysis()


@app.post("/v1/account-rating", response_model=AccountRatingResponse)
def calculate_account_rating(payload: AccountRatingRequest) -> AccountRatingResponse:
    return account_rating(payload)


@app.post("/v1/compatibility", response_model=CompatibilityResponse)
def calculate_compatibility(payload: CompatibilityRequest) -> CompatibilityResponse:
    return compatibility(payload)


@app.post("/v1/messages", response_model=MessageRecord, status_code=201)
def send_message(
    payload: MessageCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> MessageRecord:
    require_owner(authenticated_global_id, payload.sender_global_id)
    if payload.sender_global_id == payload.recipient_global_id:
        raise HTTPException(status_code=400, detail="Нельзя отправить сообщение самому себе")
    return create_message(payload)


@app.get("/v1/messages/{global_id}", response_model=list[MessageRecord])
def list_messages(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[MessageRecord]:
    require_owner(authenticated_global_id, global_id)
    return messages_for_user(global_id)


# ---- Chat Core v0.5.9 -------------------------------------------------------------

@app.get("/v1/app/version", response_model=AppVersionManifest)
def app_version() -> AppVersionManifest:
    return app_version_manifest()


@app.put("/v1/e2ee/device-key", response_model=DeviceKeyRecord)
def register_device_key(
    payload: DeviceKeyUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> DeviceKeyRecord:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return upsert_device_key(authenticated_global_id, payload)


@app.get("/v1/e2ee/device-keys/{global_id}", response_model=list[DeviceKeyRecord])
def read_device_keys(
    global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[DeviceKeyRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return device_keys_for_user(global_id)


@app.post("/v1/conversations/direct", response_model=ConversationSummary, status_code=201)
def create_direct_chat(
    payload: DirectConversationCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ConversationSummary:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return open_direct_conversation(authenticated_global_id, payload.peer_global_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/v1/conversations/group", response_model=ConversationSummary, status_code=201)
def create_group_chat(
    payload: GroupConversationCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ConversationSummary:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return create_group_conversation(authenticated_global_id, payload)


@app.put("/v1/users/{subject_global_id}/block", response_model=UserBlockStatus)
def block_user(
    subject_global_id: int,
    payload: UserBlockRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> UserBlockStatus:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        blocked = set_user_block(authenticated_global_id, subject_global_id, payload.blocked)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return UserBlockStatus(subject_global_id=subject_global_id, blocked=blocked)


@app.get("/v1/users/{subject_global_id}/block", response_model=UserBlockStatus)
def block_status(
    subject_global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> UserBlockStatus:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return UserBlockStatus(subject_global_id=subject_global_id, blocked=has_user_block(authenticated_global_id, subject_global_id))


@app.post("/v1/chat/report/{subject_global_id}", response_model=TrustIncident, status_code=201)
def report_chat_user(
    subject_global_id: int,
    payload: ChatReportCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> TrustIncident:
    from datetime import date
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    if authenticated_global_id == subject_global_id:
        raise HTTPException(status_code=400, detail="Нельзя подать жалобу на самого себя")
    return create_incident(TrustIncidentCreate(
        reporter_global_id=authenticated_global_id,
        subject_global_id=subject_global_id,
        category=payload.category,
        occurred_at=date.today().isoformat(),
        description=payload.description,
        evidence_refs=payload.evidence_refs,
    ))


@app.put("/v1/push/token")
def register_push_token(
    payload: PushTokenUpsert,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> dict[str, bool]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return {"ok": upsert_push_token(authenticated_global_id, payload)}


@app.get("/v1/conversations", response_model=list[ConversationSummary])
def list_chat_conversations(
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[ConversationSummary]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    return conversations_for_user(authenticated_global_id)


@app.get("/v1/conversations/{conversation_id}/members", response_model=list[ConversationMemberRecord])
def list_conversation_members(
    conversation_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[ConversationMemberRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return conversation_members(conversation_id, authenticated_global_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.put("/v1/conversations/{conversation_id}/members/{member_global_id}", response_model=list[ConversationMemberRecord])
def add_conversation_member(
    conversation_id: str,
    member_global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[ConversationMemberRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return add_group_member(conversation_id, authenticated_global_id, member_global_id)
    except ValueError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc


@app.delete("/v1/conversations/{conversation_id}/members/{member_global_id}", response_model=list[ConversationMemberRecord])
def remove_conversation_member(
    conversation_id: str,
    member_global_id: int,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[ConversationMemberRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return remove_group_member(conversation_id, authenticated_global_id, member_global_id)
    except ValueError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc


@app.get("/v1/conversations/{conversation_id}/messages", response_model=list[ChatMessageRecord])
def list_chat_messages(
    conversation_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[ChatMessageRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return chat_messages(conversation_id, authenticated_global_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/v1/conversations/{conversation_id}/messages", response_model=ChatMessageRecord, status_code=201)
def send_chat_message(
    conversation_id: str,
    payload: ChatMessageCreate,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ChatMessageRecord:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    try:
        return create_chat_message(conversation_id, authenticated_global_id, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/v1/chat/attachments/{attachment_id}", response_model=AttachmentPayload)
def get_chat_attachment(
    attachment_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> AttachmentPayload:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    payload = attachment_payload(attachment_id, authenticated_global_id)
    if payload is None:
        raise HTTPException(status_code=404, detail="Вложение не найдено")
    return payload




@app.put("/v1/messages/{message_id}", response_model=ChatMessageRecord)
def edit_message(
    message_id: str,
    payload: ChatMessageEdit,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> ChatMessageRecord:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        return edit_chat_message(message_id, authenticated_global_id, payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.put("/v1/messages/{message_id}/reaction", response_model=list[MessageReactionRecord])
def react_to_message(
    message_id: str,
    payload: MessageReactionRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> list[MessageReactionRecord]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        return toggle_message_reaction(message_id, authenticated_global_id, payload.emoji)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.delete("/v1/messages/{message_id}", status_code=204)
def delete_message(
    message_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
):
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    if not delete_chat_message(message_id, authenticated_global_id):
        raise HTTPException(status_code=403, detail="Only the sender can delete this message")
    return None


@app.put("/v1/conversations/{conversation_id}/typing")
def update_typing(
    conversation_id: str,
    payload: TypingRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
):
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        set_typing(conversation_id, authenticated_global_id, payload.typing)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"ok": True}


@app.get("/v1/conversations/{conversation_id}/typing", response_model=TypingStatus)
def get_typing(
    conversation_id: str,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> TypingStatus:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        return TypingStatus(global_ids=typing_users(conversation_id, authenticated_global_id))
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.put("/v1/conversations/{conversation_id}/read")
def mark_conversation_read(
    conversation_id: str,
    payload: ReadReceiptRequest,
    authenticated_global_id: int | None = Depends(session_global_id),
) -> dict[str, bool]:
    if authenticated_global_id is None:
        raise HTTPException(status_code=401, detail="Требуется сессия")
    if not mark_chat_read(conversation_id, authenticated_global_id, payload.message_id):
        raise HTTPException(status_code=404, detail="Сообщение или чат не найден")
    return {"ok": True}

