from threading import Lock
from uuid import uuid4
from .models import (
    AssessmentResultRecord,
    AssessmentResultUpsert,
    AuthProvider,
    Community,
    CommunityCreate,
    CommunityKind,
    IdentityResolveRequest,
    IdentityResolveResponse,
    IncidentStatus,
    NumerologyProfile,
    Person,
    Personality32,
    TrustIncident,
    TrustIncidentCreate,
    MessageCreate,
    MessageRecord,
)


def gid(value: int) -> str:
    if value < 1 or value > 9_999_999_999:
        raise ValueError("global_id outside canonical range")
    return f"{value:010d}"


PEOPLE = [
    Person(
        global_id=2, global_id_display=gid(2), name="Андрей", age=36, city="Киев", distance_km=4,
        compatibility=91, trust_score=94, account_rating=86,
        interests=["Футбол", "Автомобили", "Бизнес"], values=["Верность", "Справедливость"],
        lifestyle=["Активный отдых", "Встречи по выходным"],
        personality32=Personality32(code="EPLSG", title="Верный организатор", social_energy=72, perception=38, decision_style=42, life_rhythm=34, bond_style=28),
        enneagram_type=6, zodiac="LEO",
        numerology=NumerologyProfile(soul_number=6, destiny_number=6, name_number=1, maturity_number=7),
        explanation="Совпадают ценности верности, прямой стиль общения и интерес к совместным проектам."
    ),
    Person(
        global_id=3, global_id_display=gid(3), name="Максим", age=40, city="Киев", distance_km=12,
        compatibility=84, trust_score=88, account_rating=72,
        interests=["Спорт", "Путешествия", "Технологии"], values=["Свобода", "Развитие"],
        lifestyle=["Путешествия", "Онлайн-общение"],
        personality32=Personality32(code="EVLFA", title="Свободный изобретатель", social_energy=58, perception=68, decision_style=35, life_rhythm=70, bond_style=55),
        enneagram_type=7, zodiac="AQUARIUS",
        numerology=NumerologyProfile(soul_number=7, destiny_number=6, name_number=8, maturity_number=5),
        explanation="Высокая совместимость по активности, развитию и личным границам."
    ),
    Person(
        global_id=4, global_id_display=gid(4), name="Олег", age=34, city="Львов", distance_km=3,
        compatibility=79, trust_score=96, account_rating=91,
        interests=["Книги", "Футбол", "Взаимопомощь"], values=["Верность", "Вера", "Справедливость"],
        lifestyle=["Спокойный отдых", "Регулярное общение"],
        personality32=Personality32(code="RVHSG", title="Верный советник", social_energy=34, perception=62, decision_style=78, life_rhythm=28, bond_style=22),
        enneagram_type=2, zodiac="SAGITTARIUS",
        numerology=NumerologyProfile(soul_number=6, destiny_number=2, name_number=4, maturity_number=6),
        explanation="Сильное совпадение ценностей и надёжности."
    ),
]

COMMUNITIES = [
    Community(id="c1", title="Футбол по выходным", category="Футбол", city="Киев", members=128,
              kind=CommunityKind.INTEREST, online=False, description="Матчи, команды и совместные просмотры.", verified_only=True),
    Community(id="c2", title="Автомобили и путешествия", category="Автомобили", city="Киев", members=315,
              kind=CommunityKind.INTEREST, online=True, description="Маршруты, обслуживание и взаимопомощь."),
    Community(id="c3", title="Предприниматели Украины", category="Предпринимательство", city="Онлайн", members=524,
              kind=CommunityKind.BUSINESS, online=True, description="Опыт, партнёрства и проверка гипотез.", verified_only=True),
]

INCIDENTS: list[TrustIncident] = []
BASE_TRUST = {1: 92, 2: 94, 3: 88, 4: 96}
VERIFIED_INTERACTIONS = {1: 12, 2: 18, 3: 9, 4: 24}

# The executable MVP uses in-memory identity allocation. PostgreSQL uses an IDENTITY sequence.
IDENTITIES: dict[tuple[str, str, str], int] = {
    (AuthProvider.EMAIL.value, "default", "demo@brotherhood.local"): 1,
    (AuthProvider.GOOGLE.value, "default", "demo-google-2"): 2,
    (AuthProvider.TELEGRAM.value, "default", "demo-telegram-3"): 3,
    (AuthProvider.FACEBOOK.value, "default", "demo-facebook-4"): 4,
}
_identity_lock = Lock()
_next_global_id = 5


def resolve_identity(payload: IdentityResolveRequest) -> IdentityResolveResponse:
    global _next_global_id
    key = (payload.provider.value, payload.tenant, payload.provider_subject)
    with _identity_lock:
        existing = IDENTITIES.get(key)
        if existing is not None:
            return IdentityResolveResponse(global_id=existing, global_id_display=gid(existing), created=False)
        allocated = _next_global_id
        _next_global_id += 1
        IDENTITIES[key] = allocated
        BASE_TRUST.setdefault(allocated, 70)
        VERIFIED_INTERACTIONS.setdefault(allocated, 0)
        return IdentityResolveResponse(global_id=allocated, global_id_display=gid(allocated), created=True)


def create_community(payload: CommunityCreate) -> Community:
    data = payload.model_dump(exclude={"owner_global_id"})
    community = Community(id=f"c-{uuid4().hex[:10]}", members=1, **data)
    COMMUNITIES.append(community)
    return community


def create_incident(payload: TrustIncidentCreate) -> TrustIncident:
    incident = TrustIncident(id=f"i-{uuid4().hex[:10]}", **payload.model_dump())
    INCIDENTS.append(incident)
    return incident


def moderate_incident(incident_id: str, confirmed: bool) -> TrustIncident | None:
    for index, incident in enumerate(INCIDENTS):
        if incident.id == incident_id:
            updated = incident.model_copy(update={
                "status": IncidentStatus.CONFIRMED if confirmed else IncidentStatus.REJECTED,
                "score_impact": -12 if confirmed else 0,
            })
            INCIDENTS[index] = updated
            return updated
    return None


ASSESSMENT_RESULTS: dict[tuple[int, str], AssessmentResultRecord] = {}


def upsert_assessment_result(payload: AssessmentResultUpsert) -> AssessmentResultRecord:
    key = (payload.global_id, payload.assessment_id)
    existing = ASSESSMENT_RESULTS.get(key)
    record = AssessmentResultRecord(
        id=existing.id if existing else f"ar-{uuid4().hex[:10]}",
        **payload.model_dump(),
    )
    ASSESSMENT_RESULTS[key] = record
    return record


def assessment_results_for_user(global_id: int) -> list[AssessmentResultRecord]:
    return [
        item
        for (stored_global_id, _), item in ASSESSMENT_RESULTS.items()
        if stored_global_id == global_id
    ]


MESSAGES: list[MessageRecord] = []


def create_message(payload: MessageCreate) -> MessageRecord:
    if payload.sender_global_id == payload.recipient_global_id:
        raise ValueError("sender and recipient must differ")
    existing = next((item for item in MESSAGES if item.client_message_id == payload.client_message_id), None)
    if existing is not None:
        return existing
    record = MessageRecord(id=f"msg-{uuid4().hex[:12]}", status="sent", **payload.model_dump())
    MESSAGES.append(record)
    return record


def messages_for_user(global_id: int) -> list[MessageRecord]:
    return [
        item for item in MESSAGES
        if item.sender_global_id == global_id or item.recipient_global_id == global_id
    ]

# In-memory compatibility backend is retained only for local tests and offline development.
# Production automatically uses PostgreSQL when DATABASE_URL is configured.
PROFILES: dict[int, object] = {}


def upsert_profile(global_id: int, payload):
    from .models import ProfileRecord
    record = ProfileRecord(global_id=global_id, global_id_display=gid(global_id), **payload.model_dump())
    PROFILES[global_id] = record
    return record


def get_profile(global_id: int):
    return PROFILES.get(global_id)


def list_people(city: str, radius_km: int, requester_global_id: int | None = None) -> list[Person]:
    return [
        person for person in PEOPLE
        if person.city == city and person.distance_km <= radius_km and person.global_id != requester_global_id
    ]


def list_communities(city: str, kind: CommunityKind) -> list[Community]:
    return [group for group in COMMUNITIES if group.kind == kind and (group.city == city or group.online)]


def trust_summary(global_id: int):
    from .models import TrustSummary
    related = [item for item in INCIDENTS if item.subject_global_id == global_id]
    confirmed = [item for item in related if item.status == IncidentStatus.CONFIRMED]
    pending = [item for item in related if item.status in {IncidentStatus.PENDING, IncidentStatus.UNDER_REVIEW, IncidentStatus.APPEALED}]
    score = max(0, min(100, BASE_TRUST.get(global_id, 70) + sum(item.score_impact for item in confirmed)))
    return TrustSummary(
        global_id=global_id,
        global_id_display=gid(global_id),
        score=score,
        verified_interactions=VERIFIED_INTERACTIONS.get(global_id, 0),
        confirmed_incidents=len(confirmed),
        pending_incidents=len(pending),
    )

PERSONALITY_PROFILES: dict[int, object] = {}
