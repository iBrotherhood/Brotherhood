from __future__ import annotations

import importlib.util
import os

_PROVIDER_ENV = {
    "google": ("GOOGLE_CLIENT_ID",),
    "telegram": ("TELEGRAM_CLIENT_ID", "TELEGRAM_CLIENT_SECRET", "TELEGRAM_REDIRECT_URI"),
    "facebook": ("FACEBOOK_APP_ID", "FACEBOOK_APP_SECRET"),
    "email": ("AUTH_CHALLENGE_SECRET", "RESEND_API_KEY", "BROTHERHOOD_EMAIL_FROM"),
    "passkey": ("PASSKEY_RP_ID", "PASSKEY_ORIGIN"),
}

_PROVIDER_MODULE = {
    "google": "google.auth",
    "telegram": "jwt",
    "facebook": "httpx",
    "email": "httpx",
    "passkey": "webauthn",
}


def provider_readiness() -> list[dict[str, object]]:
    result: list[dict[str, object]] = []
    for provider, required in _PROVIDER_ENV.items():
        missing = [name for name in required if not os.getenv(name, "").strip()]
        dependency = _PROVIDER_MODULE[provider]
        dependency_ready = importlib.util.find_spec(dependency) is not None
        result.append({
            "provider": provider,
            "configured": not missing and dependency_ready,
            "requires_server_verification": True,
            "missing": missing,
            "dependency_ready": dependency_ready,
        })
    # Telegram Mini App is an additional verified ingress and uses the bot token; it is not
    # required for native OIDC readiness.
    telegram = next(item for item in result if item["provider"] == "telegram")
    telegram["mini_app_configured"] = bool(os.getenv("TELEGRAM_BOT_TOKEN", "").strip())
    return result
