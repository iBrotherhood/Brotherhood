from __future__ import annotations

import os

_PROVIDER_ENV = {
    "google": ("GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"),
    "telegram": ("TELEGRAM_BOT_TOKEN",),
    "facebook": ("FACEBOOK_APP_ID", "FACEBOOK_APP_SECRET"),
    "email": tuple(),
    "passkey": tuple(),
}


def provider_readiness() -> list[dict[str, object]]:
    result: list[dict[str, object]] = []
    for provider, required in _PROVIDER_ENV.items():
        configured = all(os.getenv(name, "").strip() for name in required) if required else False
        result.append({
            "provider": provider,
            "configured": configured,
            "requires_server_verification": True,
            "missing": [name for name in required if not os.getenv(name, "").strip()],
        })
    return result
