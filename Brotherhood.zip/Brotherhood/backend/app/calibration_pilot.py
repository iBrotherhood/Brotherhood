from __future__ import annotations

from dataclasses import dataclass
import hashlib
import hmac
import json
import os


class PilotEnrollmentError(ValueError):
    def __init__(self, code: str, message: str, http_status: int = 400) -> None:
        super().__init__(message)
        self.code = code
        self.http_status = http_status


def _int_env(name: str, default: int, minimum: int = 0) -> int:
    raw = os.getenv(name, str(default)).strip()
    try:
        value = int(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer") from exc
    return max(minimum, value)


def _csv(name: str, default: str) -> tuple[str, ...]:
    return tuple(dict.fromkeys(item.strip().lower() for item in os.getenv(name, default).split(",") if item.strip()))


def _locale_limits(locales: tuple[str, ...], default_per_locale: int) -> dict[str, int]:
    raw = os.getenv("BROTHERHOOD_CALIBRATION_LOCALE_LIMITS", "").strip()
    if not raw:
        return {locale: default_per_locale for locale in locales}
    try:
        loaded = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError("BROTHERHOOD_CALIBRATION_LOCALE_LIMITS must be JSON") from exc
    if not isinstance(loaded, dict):
        raise RuntimeError("BROTHERHOOD_CALIBRATION_LOCALE_LIMITS must be a JSON object")
    return {locale: max(0, int(loaded.get(locale, 0))) for locale in locales}


@dataclass(frozen=True)
class PilotConfig:
    mode: str
    cohort_id: str
    wave_id: str
    consent_version: str
    model_version: str
    stimulus_version: str
    max_participants: int
    accepted_locales: tuple[str, ...]
    locale_limits: dict[str, int]
    invite_hashes: tuple[str, ...]

    @property
    def requires_invite(self) -> bool:
        return self.mode == "closed"


def pilot_config() -> PilotConfig:
    mode = os.getenv("BROTHERHOOD_CALIBRATION_PILOT_MODE", "closed").strip().lower() or "closed"
    if mode not in {"disabled", "closed", "open"}:
        raise RuntimeError("BROTHERHOOD_CALIBRATION_PILOT_MODE must be disabled, closed or open")
    locales = _csv("BROTHERHOOD_CALIBRATION_LOCALES", "ru,uk,en")
    if not locales:
        raise RuntimeError("BROTHERHOOD_CALIBRATION_LOCALES must include at least one locale")
    per_locale = _int_env("BROTHERHOOD_CALIBRATION_DEFAULT_LOCALE_LIMIT", 6)
    hashes = tuple(
        item.strip().lower()
        for item in os.getenv("BROTHERHOOD_CALIBRATION_INVITE_SHA256", "").split(",")
        if item.strip()
    )
    for digest in hashes:
        if len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest):
            raise RuntimeError("BROTHERHOOD_CALIBRATION_INVITE_SHA256 contains an invalid SHA-256 digest")
    return PilotConfig(
        mode=mode,
        cohort_id=os.getenv("BROTHERHOOD_CALIBRATION_COHORT", "pilot-visual-v1").strip() or "pilot-visual-v1",
        wave_id=os.getenv("BROTHERHOOD_CALIBRATION_WAVE", "wave-1").strip() or "wave-1",
        consent_version=os.getenv("BROTHERHOOD_CALIBRATION_CONSENT_VERSION", "calibration-consent-v2").strip() or "calibration-consent-v2",
        model_version="visual-latent-v2",
        stimulus_version="scene-library-v4",
        max_participants=_int_env("BROTHERHOOD_CALIBRATION_MAX_PARTICIPANTS", max(1, len(locales) * per_locale), 1),
        accepted_locales=locales,
        locale_limits=_locale_limits(locales, per_locale),
        invite_hashes=hashes,
    )


def invite_digest(code: str | None) -> str | None:
    normalized = (code or "").strip()
    if not normalized:
        return None
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def validated_invite_digest(code: str | None, config: PilotConfig) -> str | None:
    if not config.requires_invite:
        return None
    digest = invite_digest(code)
    if digest is None or not config.invite_hashes:
        return None
    return digest if any(hmac.compare_digest(digest, expected) for expected in config.invite_hashes) else None


def verify_invite(code: str | None, config: PilotConfig) -> bool:
    return not config.requires_invite or validated_invite_digest(code, config) is not None
