from __future__ import annotations

from fastapi.testclient import TestClient

from app.auth_security import issue_session
from app.main import app
from app.models import AuthProvider
from app.provider_auth import _MEMORY_LAST_EMAIL_CODE, VerifiedProviderIdentity

client = TestClient(app)


def test_access_refresh_rotation_and_logout() -> None:
    issued = issue_session(1, AuthProvider.EMAIL, device_id="device-test-0001")
    first = client.get("/v1/auth/session", headers={"Authorization": f"Bearer {issued.access_token}"})
    assert first.status_code == 200
    assert first.json()["global_id"] == 1

    refreshed = client.post("/v1/auth/refresh", json={"refresh_token": issued.refresh_token, "device_id": "device-test-0001"})
    assert refreshed.status_code == 200
    replacement = refreshed.json()
    assert replacement["access_token"] != issued.access_token
    assert replacement["refresh_token"] != issued.refresh_token

    old = client.get("/v1/auth/session", headers={"Authorization": f"Bearer {issued.access_token}"})
    assert old.status_code == 401

    current_headers = {"Authorization": f"Bearer {replacement['access_token']}"}
    assert client.get("/v1/auth/session", headers=current_headers).status_code == 200
    assert client.post("/v1/auth/logout", headers=current_headers).status_code == 204
    assert client.get("/v1/auth/session", headers=current_headers).status_code == 401


def test_refresh_rejects_wrong_bound_device() -> None:
    issued = issue_session(1, AuthProvider.EMAIL, device_id="device-test-0002")
    response = client.post("/v1/auth/refresh", json={"refresh_token": issued.refresh_token, "device_id": "different-device"})
    assert response.status_code == 401


def test_email_code_creates_verified_identity_and_session() -> None:
    email = "cycle0003@example.org"
    requested = client.post("/v1/auth/email/request-code", json={"email": email, "locale": "en"})
    assert requested.status_code == 202
    code = _MEMORY_LAST_EMAIL_CODE[email]
    verified = client.post("/v1/auth/email/verify", json={"email": email, "code": code, "device_id": "device-email-0003"})
    assert verified.status_code == 200
    body = verified.json()
    assert body["provider"] == "email"
    assert len(body["global_id_display"]) == 10
    assert body["access_token"]
    assert body["refresh_token"]


def test_provider_exchange_uses_verified_subject_not_client_claim(monkeypatch) -> None:
    def verified(_payload):
        return VerifiedProviderIdentity(
            provider=AuthProvider.GOOGLE,
            subject="google-sub-cycle-0003",
            email="verified@example.org",
            email_verified=True,
        )

    monkeypatch.setattr("app.main.verify_provider_credential", verified)
    response = client.post(
        "/v1/auth/provider/exchange",
        json={"provider": "google", "credential": "x" * 32, "nonce": "nonce-00000003", "device_id": "device-google-0003"},
    )
    assert response.status_code == 200
    assert response.json()["provider"] == "google"
    assert response.json()["global_id"] >= 1


def test_provider_readiness_never_returns_secret_values(monkeypatch) -> None:
    monkeypatch.setenv("GOOGLE_CLIENT_ID", "secret-looking-client-id")
    response = client.get("/v1/auth/providers")
    assert response.status_code == 200
    rendered = response.text
    assert "secret-looking-client-id" not in rendered
    assert all("configured" in item and "missing" in item for item in response.json())


def test_user_settings_are_bound_to_global_id() -> None:
    issued = issue_session(1, AuthProvider.EMAIL, device_id="device-settings-0003")
    headers = {"Authorization": f"Bearer {issued.access_token}"}
    payload = {
        "locale": "uk",
        "theme": "dark",
        "profile_visibility": "connections",
        "preferences": {"min_trust": 70, "search_role": "friend"},
    }
    saved = client.put("/v1/settings/1", json=payload, headers=headers)
    assert saved.status_code == 200
    assert saved.json()["global_id"] == 1
    assert saved.json()["locale"] == "uk"
    loaded = client.get("/v1/settings/1", headers=headers)
    assert loaded.status_code == 200
    assert loaded.json()["preferences"]["min_trust"] == 70


def test_public_provider_exchange_rejects_arbitrary_tenant(monkeypatch) -> None:
    def verified(_payload):
        return VerifiedProviderIdentity(provider=AuthProvider.GOOGLE, subject="tenant-guard-subject")

    monkeypatch.setattr("app.main.verify_provider_credential", verified)
    response = client.post(
        "/v1/auth/provider/exchange",
        json={"provider": "google", "credential": "x" * 32, "tenant": "attacker-controlled", "device_id": "device-tenant-0003"},
    )
    assert response.status_code == 400


def test_verified_email_links_provider_identities_to_one_global_id() -> None:
    from app.models import IdentityResolveRequest
    from app.repository import resolve_identity

    email = "link-cycle-0003@example.org"
    google = resolve_identity(
        IdentityResolveRequest(provider=AuthProvider.GOOGLE, provider_subject="google-link-cycle-0003", tenant="default"),
        email_normalized=email,
    )
    email_identity = resolve_identity(
        IdentityResolveRequest(provider=AuthProvider.EMAIL, provider_subject=email, tenant="default"),
        email_normalized=email,
    )
    assert google.global_id == email_identity.global_id
    assert google.global_id_display == email_identity.global_id_display


def test_telegram_oidc_pkce_state_is_one_time(monkeypatch) -> None:
    from urllib.parse import parse_qs, urlparse

    import app.provider_auth as provider_auth
    from app.models import TelegramOidcFinishRequest

    monkeypatch.setenv("TELEGRAM_CLIENT_ID", "123456789")
    monkeypatch.setenv("TELEGRAM_CLIENT_SECRET", "server-only-secret")
    monkeypatch.setenv("TELEGRAM_REDIRECT_URI", "https://api.example.test/v1/auth/telegram/callback")
    monkeypatch.setenv("TELEGRAM_APP_CALLBACK_URI", "brotherhood://telegram-login/callback")

    authorization_url = provider_auth.begin_telegram_oidc("device-telegram-0003")
    parsed = urlparse(authorization_url)
    query = parse_qs(parsed.query)
    assert parsed.scheme == "https"
    assert parsed.netloc == "oauth.telegram.org"
    assert query["response_type"] == ["code"]
    assert query["code_challenge_method"] == ["S256"]
    assert query["redirect_uri"] == ["https://api.example.test/v1/auth/telegram/callback"]
    assert "server-only-secret" not in authorization_url
    state = query["state"][0]

    class FakeResponse:
        def raise_for_status(self) -> None:
            return None

        def json(self) -> dict[str, str]:
            return {"id_token": "telegram-id-token"}

    captured: dict[str, object] = {}

    def fake_post(url, **kwargs):
        captured["url"] = url
        captured.update(kwargs)
        return FakeResponse()

    monkeypatch.setattr(provider_auth.httpx, "post", fake_post)
    monkeypatch.setattr(
        provider_auth,
        "verify_telegram_oidc_token",
        lambda credential, nonce=None: VerifiedProviderIdentity(provider=AuthProvider.TELEGRAM, subject="telegram-cycle-0003"),
    )
    result = provider_auth.exchange_telegram_oidc_code(
        TelegramOidcFinishRequest(code="authorization-code-0003", state=state, device_id="device-telegram-0003")
    )
    assert result.subject == "telegram-cycle-0003"
    assert result.initiating_device_id == "device-telegram-0003"
    assert captured["url"] == "https://oauth.telegram.org/token"
    assert "server-only-secret" not in str(captured.get("data"))

    from fastapi import HTTPException
    import pytest

    with pytest.raises(HTTPException) as exc:
        provider_auth.exchange_telegram_oidc_code(
            TelegramOidcFinishRequest(code="authorization-code-0003", state=state, device_id="device-telegram-0003")
        )
    assert exc.value.status_code == 401


def test_telegram_https_callback_uses_device_bound_one_time_ticket(monkeypatch) -> None:
    from urllib.parse import parse_qs, urlparse

    from app.provider_auth import VerifiedProviderIdentity

    monkeypatch.setenv("TELEGRAM_APP_CALLBACK_URI", "brotherhood://telegram-login/callback")
    monkeypatch.setattr(
        "app.main.exchange_telegram_oidc_code",
        lambda payload: VerifiedProviderIdentity(
            provider=AuthProvider.TELEGRAM,
            subject="telegram-callback-cycle-0003",
            initiating_device_id="device-telegram-bound-0003",
        ),
    )
    callback = client.get(
        "/v1/auth/telegram/callback",
        params={"code": "authorization-code-callback-0003", "state": "state-callback-0003-valid"},
        follow_redirects=False,
    )
    assert callback.status_code == 302
    location = callback.headers["location"]
    assert location.startswith("brotherhood://telegram-login/callback?")
    ticket = parse_qs(urlparse(location).query)["ticket"][0]
    assert len(ticket) >= 32

    wrong = client.post(
        "/v1/auth/telegram/finish",
        json={"ticket": ticket, "device_id": "wrong-device-0003"},
    )
    assert wrong.status_code == 401

    accepted = client.post(
        "/v1/auth/telegram/finish",
        json={"ticket": ticket, "device_id": "device-telegram-bound-0003"},
    )
    assert accepted.status_code == 200
    assert accepted.json()["provider"] == "telegram"

    replay = client.post(
        "/v1/auth/telegram/finish",
        json={"ticket": ticket, "device_id": "device-telegram-bound-0003"},
    )
    assert replay.status_code == 401
