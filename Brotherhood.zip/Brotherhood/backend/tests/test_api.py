from fastapi.testclient import TestClient
from app.main import app
from app.storage import ASSESSMENT_RESULTS, INCIDENTS, IDENTITIES, MESSAGES

client = TestClient(app)


def setup_function() -> None:
    INCIDENTS.clear()
    ASSESSMENT_RESULTS.clear()
    MESSAGES.clear()


def test_health() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.json()["version"] == "0.5.6"


def test_people_are_filtered_by_city_and_radius() -> None:
    response = client.get("/v1/people", params={"city": "Киев", "radius_km": 10})
    assert response.status_code == 200
    body = response.json()
    assert [item["global_id_display"] for item in body] == ["0000000002"]
    assert body[0]["personality32"]["code"] == "EPLSG"


def test_identity_resolver_is_stable_and_allocates_global_id() -> None:
    payload = {"provider": "telegram", "tenant": "default", "provider_subject": "new-user-123"}
    first = client.post("/internal/identity/resolve", json=payload)
    second = client.post("/internal/identity/resolve", json=payload)
    assert first.status_code == 200
    assert second.status_code == 200
    assert first.json()["global_id"] == second.json()["global_id"]
    assert len(first.json()["global_id_display"]) == 10
    assert first.json()["created"] is True
    assert second.json()["created"] is False


def test_business_communities_include_online_groups() -> None:
    response = client.get("/v1/communities", params={"city": "Киев", "kind": "business"})
    assert response.status_code == 200
    assert any(item["kind"] == "business" for item in response.json())


def test_pending_incident_does_not_reduce_public_score() -> None:
    before = client.get("/v1/trust/2").json()["score"]
    created = client.post("/v1/trust/incidents", json={
        "reporter_global_id": 1,
        "subject_global_id": 2,
        "category": "breach_of_agreement",
        "occurred_at": "2026-07-30",
        "description": "Пользователь нарушил заранее принятую существенную договорённость.",
        "evidence_refs": ["evidence-private-1"]
    })
    assert created.status_code == 201
    after = client.get("/v1/trust/2").json()
    assert after["score"] == before
    assert after["pending_incidents"] == 1
    assert after["global_id_display"] == "0000000002"


def test_confirmed_incident_reduces_score() -> None:
    created = client.post("/v1/trust/incidents", json={
        "reporter_global_id": 1,
        "subject_global_id": 2,
        "category": "privacy_breach",
        "occurred_at": "2026-07-30",
        "description": "Конфиденциальная информация была передана третьему лицу без согласия.",
        "evidence_refs": ["evidence-private-2"]
    }).json()
    moderated = client.post(f"/v1/trust/incidents/{created['id']}/moderate", params={"confirmed": True})
    assert moderated.status_code == 200
    summary = client.get("/v1/trust/2").json()
    assert summary["score"] == 82
    assert summary["confirmed_incidents"] == 1


def test_assessment_result_is_upserted_and_read_back() -> None:
    payload = {
        "global_id": 1,
        "assessment_id": "f001",
        "scoring_version": "0.5.6",
        "total_score": 78,
        "risk_score": 22,
        "answer_consistency": 88,
        "idealized_self_presentation": 25,
        "label": "В целом последовательный профиль",
        "summary": "Большинство ответов согласуются с надёжным поведением и требуют подтверждения практикой.",
        "dimensions": [{"id": "word_action", "title": "Слова и поступки", "score": 82}],
        "completed_at_epoch_ms": 1785450000000
    }
    saved = client.put("/v1/assessment-results", json=payload)
    assert saved.status_code == 200
    assert saved.json()["assessment_id"] == "f001"

    listed = client.get("/v1/assessment-results/1")
    assert listed.status_code == 200
    assert any(item["total_score"] == 78 for item in listed.json())


def test_account_rating_is_fifty_fifty() -> None:
    payload = {
        "completed_profile_section_codes": [
            "identity", "photo", "city", "about", "friendship_goals",
            "interests", "boundaries", "communication", "availability", "verification"
        ],
        "completed_test_ids": [f"f{number:03d}" for number in range(1, 101)],
    }
    response = client.post("/v1/account-rating", json=payload)
    assert response.status_code == 200
    assert response.json()["profile_points"] == 50.0
    assert response.json()["test_points"] == 50.0
    assert response.json()["total"] == 100.0


def test_duplicate_and_unknown_tests_do_not_increase_rating() -> None:
    response = client.post("/v1/account-rating", json={
        "completed_profile_section_codes": ["identity", "city", "identity", "unknown"],
        "completed_test_ids": ["f001", "f001", "unknown"],
    })
    assert response.status_code == 200
    assert response.json()["completed_tests"] == 1
    assert response.json()["total"] == 10.5


def test_compatibility_uses_common_tests_and_safety_cap() -> None:
    response = client.post("/v1/compatibility", json={
        "my_scores": {"f001": 90, "f002": 90},
        "candidate_scores": {"f001": 20, "f002": 25},
        "shared_interest_percent": 100,
        "trust_score": 100,
    })
    assert response.status_code == 200
    body = response.json()
    assert body["common_tests"] == 2
    assert body["risk_flags"]
    assert body["score"] <= 64


def test_database_health_without_configuration(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    response = client.get("/health/database")
    assert response.status_code == 200
    assert response.json() == {"configured": False, "status": "not_configured"}


def test_public_config_exposes_canonical_product_model() -> None:
    response = client.get("/v1/config")
    assert response.status_code == 200
    body = response.json()
    assert body["personality_model"]["type_count"] == 32
    assert body["tests"] == {"count": 100, "question_count": 600}
    assert body["global_id_format"] == "0000000001"
    assert body["database_access"] == "vercel_backend_only"


def test_message_is_idempotent_by_client_message_id() -> None:
    payload = {
        "sender_global_id": 1,
        "recipient_global_id": 2,
        "client_message_id": "local-message-0001",
        "body": "Привет. Предлагаю сыграть в футбол в субботу.",
        "created_at_epoch_ms": 1785450000000
    }
    first = client.post("/v1/messages", json=payload)
    second = client.post("/v1/messages", json=payload)
    assert first.status_code == 201
    assert second.status_code == 201
    assert first.json()["id"] == second.json()["id"]
    listed = client.get("/v1/messages/1")
    assert len(listed.json()) == 1


def test_profile_roundtrip_in_memory_storage() -> None:
    payload = {
        "display_name": "Тестовый пользователь",
        "birth_date": "1986-04-13",
        "latin_name": "ALEX MORGAN",
        "city": "Киев",
        "country_code": "UA",
        "about": "Ищу настоящую мужскую дружбу и надёжных товарищей.",
        "friendship_goals": ["Близкий друг"],
        "interests": ["Футбол", "Бизнес"],
        "values": ["Верность", "Честность"],
        "lifestyle": ["Активный отдых"],
        "boundaries": {"privacy": "high"},
        "visibility": "discoverable",
        "completed_profile_sections": 10,
        "locale": "ru"
    }
    saved = client.put("/v1/profiles/1", json=payload)
    assert saved.status_code == 200
    assert saved.json()["global_id_display"] == "0000000001"
    read = client.get("/v1/profiles/1")
    assert read.status_code == 200
    assert read.json()["interests"] == ["Футбол", "Бизнес"]


def test_storage_health_defaults_to_memory_without_database() -> None:
    response = client.get("/health/storage")
    assert response.status_code == 200
    assert response.json()["mode"] in {"memory", "postgres"}


def test_personality_profile_roundtrip_in_memory_storage() -> None:
    payload = {
        "brotherhood32_code": "EVHFA",
        "brotherhood32_scores": {
            "title": "Adaptive Mentor",
            "social_energy": 72,
            "perception": 67,
            "decision_style": 81,
            "life_rhythm": 64,
            "bond_style": 58,
        },
        "enneagram_type": 8,
        "enneagram_wing": 7,
        "zodiac_sign": "ARIES",
        "vedic_numerology": {
            "soul_number": 4,
            "destiny_number": 5,
            "name_number": 8,
            "maturity_number": 4,
            "compatibility_vector": [4, 5, 8],
        },
        "model_version": "0.5.6",
    }
    saved = client.put("/v1/personality-profile/1", json=payload)
    assert saved.status_code == 200
    assert saved.json()["global_id_display"] == "0000000001"
    assert saved.json()["brotherhood32_code"] == "EVHFA"

    read = client.get("/v1/personality-profile/1")
    assert read.status_code == 200
    assert read.json()["vedic_numerology"]["soul_number"] == 4


def test_session_issue_creates_owner_bound_bearer_token_in_memory() -> None:
    response = client.post("/internal/sessions/issue", json={"global_id": 1, "provider": "telegram"})
    assert response.status_code == 200
    body = response.json()
    assert body["global_id_display"] == "0000000001"
    assert body["token_type"] == "bearer"
    assert len(body["access_token"]) >= 32

    profile = client.get("/v1/profiles/1", headers={"Authorization": f"Bearer {body['access_token']}"})
    # Memory mode intentionally does not require auth, but issued tokens still resolve correctly.
    assert profile.status_code in {200, 404}
