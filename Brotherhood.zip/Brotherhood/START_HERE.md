# START HERE — Brotherhood

1. Project: **Brotherhood**. Current HEAD source of truth: `PROJECT_MANIFEST.json`.
2. Read `KERNEL.md`.
3. Read cycle status: `docs/CYCLES/CYCLE_STATUS_REGISTRY.md`.
4. Read the active/next cycle in `docs/CYCLES/ACTIVE/` or `docs/CYCLES/NEXT/`.
5. Long-range roadmap: `docs/CYCLES/BROTHERHOOD_CYCLES_0001_0100.md`.
6. Operational memory: `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md` and `docs/MEMORY/OPERATIONAL_PENDING.md`.
7. Handoff: `docs/HANDOFF/CURRENT_HANDOFF.md` and `reports/generated/SESSION_HANDOFF.md`.
8. Truth order: current user instruction → CANON → KERNEL → cycle status → SSOT → NORM → runtime/tests → current reports → history.
9. Routes: `docs/AI/PROJECT_OPERATOR_KERNEL_ROUTE_MAP.md` and `ops/operator_kernel/config/routes.yaml`.
10. Startup file index: `ops/operator_kernel/cache/file_map.summary.json`.
11. Resolve a task with `python ops/operator_kernel/operator_kernel.py resolve "<request>"`; load only route-scoped required files.
12. Validate cycle ecosystem with `python ops/operator_kernel/check_cycle_ecosystem.py`.
13. Next safe action is always taken from the exact `NEXT` cycle and operational memory.

Psychological matching work additionally MUST read `docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md` and `docs/AI/CAUSAL_RELATIONSHIP_KERNEL.md`.
