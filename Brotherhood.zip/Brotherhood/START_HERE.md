# START HERE — Brotherhood

1. Project: **Brotherhood**. Current HEAD source of truth: `PROJECT_MANIFEST.json`.
2. Previous canonical source: `Brotherhood_v0_5_15.zip`; current release cycle: `Brotherhood_v0_5_16.zip`.
3. Read `KERNEL.md`.
4. Active task: `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md`.
5. Session handoff: `reports/generated/SESSION_HANDOFF.md`.
6. Truth order: current user instruction → CANON → KERNEL → SSOT → NORM → runtime/tests → reports → history.
7. Routes: `docs/AI/PROJECT_OPERATOR_KERNEL_ROUTE_MAP.md` and `ops/operator_kernel/config/routes.yaml`.
8. Startup file index: `ops/operator_kernel/cache/file_map.summary.json`.
9. Resolve a task with `python ops/operator_kernel/operator_kernel.py resolve "<request>"`; use only route-scoped required files.
10. Next safe action: complete the active task within its allowed-write boundary and run the listed validation/proof gates.

Psychological matching work additionally MUST read `docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md` and `docs/AI/CAUSAL_RELATIONSHIP_KERNEL.md`.
