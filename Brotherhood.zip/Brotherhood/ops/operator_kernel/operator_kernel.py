#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
ROUTES=ROOT/'ops/operator_kernel/config/routes.yaml'
EXCLUDE={'.git','.gradle','.idea','.pytest_cache','__pycache__','build','.venv'}

def load_routes():
    return json.loads(ROUTES.read_text(encoding='utf-8'))

def resolve(text:str):
    q=text.casefold()
    scored=[]
    for rid,r in load_routes().items():
        score=0
        for kw in r.get('keywords',[]):
            if kw.casefold() in q: score += 3
        for st in r.get('semantic_triggers',[]):
            terms=[x for x in st.casefold().split() if len(x)>3]
            score += sum(1 for x in terms if x in q)
        for nt in r.get('negative_triggers',[]):
            if nt.casefold() in q: score -= 4
        if score>0:
            priority=int(r.get('priority',0))
            rank=score + priority/10.0
            scored.append((rank,priority,rid,r))
    scored.sort(reverse=True)
    if not scored:
        return {'primary_route':'historical_reference','secondary_routes':[],'validation_routes':[],'conflicts':[],'reason':'no confident project-specific match','required_read':['KERNEL.md']}
    # Packaging/Kernel are meta-routes. If a concrete implementation/diagnostic domain also
    # matches, that domain remains primary and packaging is a validation route.
    concrete=[x for x in scored if x[2] not in {'release_packaging','kernel_archive','historical_reference'}]
    primary=(concrete[0] if concrete else scored[0])
    secondaries=[x[2] for x in scored if x[2] != primary[2] and x[2] not in {'release_packaging'} and x[0] >= max(1.0, primary[0] / 3.0)]
    validation=[]
    if any(x in q for x in ['release','archive','zip','релиз','архив','apk']):
        validation.append('release_packaging')
    reads=[]
    for rid in [primary[2],*secondaries,*validation]:
        route=load_routes().get(rid,{})
        for p in route.get('required_read',[]):
            if p not in reads: reads.append(p)
    return {'primary_route':primary[2],'secondary_routes':secondaries,'validation_routes':validation,'conflicts':[],'required_read':reads}

def files():
    out=[]
    for p in ROOT.rglob('*'):
        if not p.is_file(): continue
        rel=p.relative_to(ROOT)
        if any(part in EXCLUDE for part in rel.parts): continue
        out.append(rel.as_posix())
    return sorted(out)

def refresh_map():
    fs=files(); cache=ROOT/'ops/operator_kernel/cache'; cache.mkdir(parents=True,exist_ok=True)
    full={'root':'Brotherhood','file_count':len(fs),'files':fs}
    (cache/'file_map.json').write_text(json.dumps(full,ensure_ascii=False,indent=2),encoding='utf-8')
    anchors=[p for p in fs if p in {'START_HERE.md','KERNEL.md','PROJECT_MANIFEST.json'} or p.startswith('docs/CANON/') or p.startswith('docs/SSOT/') or p.startswith('docs/NORM/') or p.startswith('ops/operator_kernel/config/') or p.startswith('reports/generated/') or p in {'android/app/build.gradle.kts','backend/app/main.py','scripts/package_source_archive.py'}]
    digest=hashlib.sha256('\n'.join(fs).encode()).hexdigest()
    summary={'root':'Brotherhood','file_count':len(fs),'tree_index_sha256':digest,'canonical_anchors':anchors,'route_config':'ops/operator_kernel/config/routes.yaml','source_entrypoints':['android/app/src/main/java/org/federationofavatars/brotherhood/MainActivity.kt','backend/app/main.py'],'test_entrypoints':['android/app/src/test','backend/tests','tests/architecture'],'release_script':'scripts/package_source_archive.py'}
    (cache/'file_map.summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    return summary

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    r=sub.add_parser('resolve'); r.add_argument('request')
    sub.add_parser('refresh-map')
    a=ap.parse_args()
    print(json.dumps(resolve(a.request) if a.cmd=='resolve' else refresh_map(),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
