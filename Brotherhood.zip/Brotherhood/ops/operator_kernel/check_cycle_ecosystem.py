#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
ROADMAP = ROOT / "docs/CYCLES/BROTHERHOOD_CYCLES_0001_0100.md"
STATUS = ROOT / "docs/CYCLES/CYCLE_STATUS_REGISTRY.md"
AUDIT = ROOT / "docs/AUDIT/CHAT_AND_SOURCE_AUDIT_2026_08_01.md"
REQUIRED = [
    ROADMAP, STATUS, AUDIT,
    ROOT / "docs/CYCLES/CYCLE_TEMPLATE.md",
    ROOT / "docs/AI/AI_WORK_RULES.md",
    ROOT / "docs/AI/AI_WORK_NOTES.md",
    ROOT / "docs/AI/AI_DECISION_LOG.md",
    ROOT / "docs/MEMORY/OPERATIONAL_PENDING.md",
    ROOT / "docs/HANDOFF/CURRENT_HANDOFF.md",
]


def main() -> None:
    missing = [str(p.relative_to(ROOT)) for p in REQUIRED if not p.is_file()]
    if missing:
        raise SystemExit("missing required ecosystem files: " + ", ".join(missing))
    text = ROADMAP.read_text(encoding="utf-8")
    numbers = re.findall(r"^\| (\d{4}) \|", text, flags=re.M)
    expected = [f"{i:04d}" for i in range(1, 11)]
    if numbers != expected:
        raise SystemExit(f"assigned cycle range/order mismatch: {numbers}")
    if "0011–0100 = UNUSED_RESERVE" not in text:
        raise SystemExit("unused reserve range missing")
    if "APK CHECKPOINT A" not in text or "APK/AAB FINAL CHECKPOINT E" not in text:
        raise SystemExit("milestone APK policy missing")
    rules = (ROOT / "docs/AI/AI_WORK_RULES.md").read_text(encoding="utf-8")
    for token in ["SOURCE_ONLY", "APK_VISIBLE", "LIVE_E2E", "PRODUCTION_QUALIFIED"]:
        if token not in rules:
            raise SystemExit(f"evidence level missing: {token}")
    print("CYCLE_ECOSYSTEM_PASS assigned=10 completed=1 active=0002 reserve=0011-0100")


if __name__ == "__main__":
    main()
