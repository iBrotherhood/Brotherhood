from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parents[2]
ANDROID_SRC = ROOT / "android/app/src/main/java/org/federationofavatars/brotherhood"
APP_BUILD = ROOT / "android/app/build.gradle.kts"
WORKFLOW = ROOT / ".github/workflows/android-build.yml"


def text(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_universal_workflow_is_unchanged_and_accepts_runtime_api_secret():
    expected = "82cafc472125906ae8a1c8850d0cfc09aca4704956f9b570f0336d87cb5a460f"
    assert hashlib.sha256(WORKFLOW.read_bytes()).hexdigest() == expected
    workflow = WORKFLOW.read_text(encoding="utf-8")
    assert "BROTHERHOOD_API_BASE_URL: ${{ secrets.BROTHERHOOD_API_BASE_URL }}" in workflow
    assert '-PbrotherhoodApiBaseUrl="${BROTHERHOOD_API_BASE_URL:-https://example.invalid}"' in workflow


def test_android_contains_no_backend_or_provider_secrets():
    source = "\n".join(path.read_text(encoding="utf-8") for path in ANDROID_SRC.rglob("*.kt"))
    source += "\n" + APP_BUILD.read_text(encoding="utf-8")
    forbidden = [
        "DATABASE_URL",
        "TELEGRAM_CLIENT_SECRET",
        "FACEBOOK_APP_SECRET",
        "GOOGLE_CLIENT_SECRET",
        "RESEND_API_KEY",
        "AUTH_CHALLENGE_SECRET",
        "INTERNAL_AUTH_SECRET",
    ]
    for token in forbidden:
        assert token not in source


def test_android_session_is_encrypted_and_debug_token_is_not_runtime_auth():
    store = text("android/app/src/main/java/org/federationofavatars/brotherhood/auth/SessionStore.kt")
    vm = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/MainViewModel.kt")
    assert "AndroidKeyStore" in store
    assert "AES/GCM/NoPadding" in store
    assert "refreshToken" in store
    assert "debug-local-session" not in vm
    assert "sessionStore.load()" in vm
    assert "authRepository.refresh" in vm


def test_android_restores_global_id_and_persists_device_binding():
    profile = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/ProfileLocalStore.kt")
    auth = text("android/app/src/main/java/org/federationofavatars/brotherhood/network/AuthRemoteRepository.kt")
    assert 'optString("global_id")' in profile
    assert "restoredGlobalId" in profile
    assert 'getString("installation_id", null)' in auth
    assert 'putString("installation_id", generated)' in auth
    assert 'put("device_id", deviceId)' in auth


def test_android_public_auth_boundary_uses_backend_only():
    auth = text("android/app/src/main/java/org/federationofavatars/brotherhood/network/AuthRemoteRepository.kt")
    assert "v1/auth/google/config" in auth
    assert "googleClientId" in auth
    app = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    assert "viewModel.googleServerClientId()" in app
    assert "BuildConfig.GOOGLE_SERVER_CLIENT_ID" not in app
    for route in [
        "v1/auth/provider/exchange",
        "v1/auth/telegram/begin",
        "v1/auth/telegram/finish",
        "v1/auth/email/request-code",
        "v1/auth/email/verify",
        "v1/auth/refresh",
        "v1/auth/logout",
        "v1/auth/passkey/registration/options",
        "v1/auth/passkey/authentication/options",
    ]:
        assert route in auth


def test_telegram_callback_is_narrow_and_browser_safe():
    manifest = text("android/app/src/main/AndroidManifest.xml")
    activity = text("android/app/src/main/java/org/federationofavatars/brotherhood/MainActivity.kt")
    vm = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/MainViewModel.kt")
    assert 'android:launchMode="singleTask"' in manifest
    assert 'android.intent.category.BROWSABLE' in manifest
    assert "telegramRedirectScheme" in manifest and "telegramRedirectHost" in manifest
    assert "override fun onNewIntent" in activity
    assert "completeTelegramOidcCallback" in activity
    assert "BuildConfig.TELEGRAM_APP_CALLBACK_URI" in vm
    assert "uri.getQueryParameter(\"ticket\")" in vm


def test_server_sessions_are_opaque_hashed_rotating_and_owner_bound():
    auth = text("backend/app/auth_security.py")
    for token in [
        "secrets.token_urlsafe(32)",
        "secrets.token_urlsafe(48)",
        "hashlib.sha256",
        "refresh_token_hash",
        "revoked_at",
        "device_id",
        "FOR UPDATE OF s",
        "u.status='active'",
    ]:
        assert token in auth
    main = text("backend/app/main.py")
    assert 'Depends(require_authenticated_session)' in main
    assert 'require_owner(authenticated_global_id, global_id)' in main


def test_provider_verification_and_telegram_pkce_remain_server_side():
    provider = text("backend/app/provider_auth.py")
    for token in [
        "google.oauth2",
        "TELEGRAM_CLIENT_SECRET",
        "state_hash",
        "TELEGRAM_REDIRECT_URI must be an HTTPS backend callback",
        "code_verifier",
        "code_challenge",
        'code_challenge_method": "S256"',
        "https://oauth.telegram.org/token",
        "https://oauth.telegram.org/.well-known/jwks.json",
        "Basic",
        "consumed_at",
    ]:
        assert token in provider
    assert "TELEGRAM_CLIENT_SECRET" not in text("android/app/build.gradle.kts")


def test_passkeys_require_discoverable_credential_and_user_verification():
    passkeys = text("backend/app/passkey_auth.py")
    assert "ResidentKeyRequirement.REQUIRED" in passkeys
    assert "UserVerificationRequirement.REQUIRED" in passkeys
    app = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    assert "Build.VERSION.SDK_INT < Build.VERSION_CODES.P" in app
    assert "Build.VERSION.SDK_INT >= Build.VERSION_CODES.P" in app
    assert "verify_registration_response" in passkeys
    assert "verify_authentication_response" in passkeys
    assert "consumed_at" in passkeys


def test_cycle_0003_migration_covers_sessions_identities_passkeys_oidc_and_settings():
    migration = text("database/migrations/0008_auth_sessions_provider_passkeys.sql")
    for token in [
        "refresh_token_hash",
        "auth_email_challenges",
        "passkey_credentials",
        "passkey_challenges",
        "auth_oidc_challenges",
        "auth_login_tickets",
        "device_id",
        "state_hash",
        "user_settings",
        "user_identities_verified_email_idx",
    ]:
        assert token in migration


def test_verified_provider_identity_can_link_to_one_global_id_without_client_tenant_control():
    repo = text("backend/app/repository.py")
    main = text("backend/app/main.py")
    assert "pg_advisory_xact_lock" in repo
    assert "email_normalized" in repo
    assert "IdentityLinkConflict" in repo
    assert 'payload.tenant != "default"' in main
    assert "status_code=409" in main


def test_settings_sync_is_owner_bound_and_android_connected():
    main = text("backend/app/main.py")
    remote = text("android/app/src/main/java/org/federationofavatars/brotherhood/network/RemoteDataRepository.kt")
    assert '@app.put("/v1/settings/{global_id}"' in main
    assert '@app.get("/v1/settings/{global_id}"' in main
    assert "v1/settings/" in remote
    assert "syncSettings" in remote


def test_cycle_0003_dependencies_and_research_boundary_are_explicit():
    requirements = text("backend/requirements.txt")
    for dependency in ["psycopg[binary]", "google-auth", "PyJWT[crypto]", "webauthn"]:
        assert dependency in requirements
    source_map = text("docs/research/source_map/BROTHERHOOD_SOURCE_MAP_USAGE_CYCLE_0003.md")
    assert "CANON" in source_map and "SSOT" in source_map
    assert "LIVE_E2E" in source_map
    assert "Digital Asset Links" in source_map
