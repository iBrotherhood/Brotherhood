from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def kotlin_brace_balance(source: str) -> tuple[int, int]:
    """Counts braces outside strings and comments; enough to catch the GitHub EOF regression."""
    depth = 0
    minimum = 0
    i = 0
    state = "code"
    while i < len(source):
        ch = source[i]
        nxt = source[i + 1] if i + 1 < len(source) else ""
        if state == "code":
            if ch == "/" and nxt == "/":
                state = "line"; i += 2; continue
            if ch == "/" and nxt == "*":
                state = "block"; i += 2; continue
            if ch == '"' and source[i:i+3] == '"""':
                state = "triple"; i += 3; continue
            if ch == '"':
                state = "string"; i += 1; continue
            if ch == "'":
                state = "char"; i += 1; continue
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                minimum = min(minimum, depth)
            i += 1; continue
        if state == "line":
            if ch == "\n": state = "code"
            i += 1; continue
        if state == "block":
            if ch == "*" and nxt == "/": state = "code"; i += 2
            else: i += 1
            continue
        if state == "triple":
            if source[i:i+3] == '"""': state = "code"; i += 3
            else: i += 1
            continue
        if state in {"string", "char"}:
            quote = '"' if state == "string" else "'"
            if ch == "\\": i += 2; continue
            if ch == quote: state = "code"
            i += 1
    return depth, minimum


def test_brotherhood_app_has_balanced_structure_and_complete_compatibility_panel():
    app = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    assert kotlin_brace_balance(app) == (0, 0)
    assert "private fun CompatibilityPanel" in app
    assert "private fun CompatibilityMetric" in app
    panel = app.split("private fun CompatibilityPanel", 1)[1].split("private fun CompatibilityMetric", 1)[0]
    canonical_fields = {
        "friendshipTests", "character", "values", "friendshipGoals", "interests", "lifestyle",
        "communication", "conflict", "personality32", "numerology", "enneagram", "zodiac",
        "geography", "business", "socialFormat",
    }
    for field in canonical_fields:
        assert f"b.{field}" in panel
    assert "friendshipExpectations" not in panel


def test_scene_library_v4_composition_is_non_scoring_versioned_and_traced():
    factory = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/VisualAssessmentFactory.kt")
    models = text("android/app/src/main/java/org/federationofavatars/brotherhood/model/AssessmentModels.kt")
    scorer = text("android/app/src/main/java/org/federationofavatars/brotherhood/domain/AssessmentScorer.kt")
    ui = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    assert 'STIMULUS_VERSION = "scene-library-v4"' in factory
    assert "% 8" in factory and "fun compositionVariant" in factory
    assert "compositionVariant: Int" in models
    assert "compositionVariant = question.compositionVariant" in scorer
    assert "val variant = compositionVariant.coerceIn(0, 7)" in ui
    # Background composition must be shared across all four choices, not keyed by answer value.
    canvas = ui.split("private fun VisualAssociationCanvas", 1)[1].split("@Composable", 1)[0]
    assert "answerValue" not in canvas


def test_controlled_pilot_invite_is_online_only_and_never_persisted_by_android():
    remote = text("android/app/src/main/java/org/federationofavatars/brotherhood/network/RemoteDataRepository.kt")
    offline = text("android/app/src/main/java/org/federationofavatars/brotherhood/sync/OfflineFirstRepository.kt")
    settings = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/SettingsStore.kt")
    ui = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    join = remote.split("suspend fun joinCalibrationPilot", 1)[1].split("suspend fun leaveCalibrationPilot", 1)[0]
    assert 'api.put("v1/calibration-consent"' in join
    assert "offline.writeOrQueue" not in join
    assert "inviteCode.trim()" in join
    assert "invite" not in settings.lower()
    assert "rememberSaveable" not in ui.split("private fun SettingsScreen", 1)[1].split("private fun SettingsSectionTitle", 1)[0]
    assert "PasswordVisualTransformation" in ui
    assert '"PUT_CALIBRATION_CONSENT"' in offline


def test_controlled_pilot_backend_uses_hashes_quota_ack_and_unconditional_withdrawal():
    pilot = text("backend/app/calibration_pilot.py")
    repo = text("backend/app/repository.py")
    migration = text("database/migrations/0007_controlled_pilot_cohort.sql")
    assert "hashlib.sha256" in pilot and "hmac.compare_digest" in pilot
    assert "BROTHERHOOD_CALIBRATION_INVITE_SHA256" in pilot
    assert "eligibility_ack_required" in repo
    assert "pilot_full" in repo and "locale_quota_full" in repo
    assert "pg_advisory_xact_lock" in repo
    withdrawal = repo.split("# Withdrawal is unconditional", 1)[1].split("return CalibrationConsentRecord", 1)[0]
    assert "DELETE FROM assessment_calibration_attempts" in withdrawal
    assert "invite_code" not in migration
    assert "enrollment_state" in migration and "pilot_wave" in migration


def test_non_participant_client_omits_private_trace():
    remote = text("android/app/src/main/java/org/federationofavatars/brotherhood/network/RemoteDataRepository.kt")
    view_model = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/MainViewModel.kt")
    assert "if (includePrivateTrace) result.responseTrace.forEach" in remote
    assert "language.tag, calibrationOptIn" in view_model


def test_android_compile_regressions_from_run_83241548302_are_closed():
    local_store = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/AssessmentLocalStore.kt")
    core_catalog = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/CoreProfileCatalog.kt")
    view_model = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/MainViewModel.kt")
    app = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")

    assert '.put("composition_variant", row.compositionVariant)' in local_store
    assert 'compositionVariant = item.optInt("composition_variant", 0).coerceIn(0, 7)' in local_store
    assert "val compositionVariant: Int" in core_catalog
    assert "compositionVariant = VisualAssessmentFactory.compositionVariant" in core_catalog
    assert "question.compositionVariant" in app
    assert "friendshipExpectationsScore =" not in view_model


def test_android_unit_test_regressions_from_run_83256062351_are_closed():
    catalog_test = text("android/app/src/test/java/org/federationofavatars/brotherhood/AssessmentCatalogTest.kt")
    scorer_test = text("android/app/src/test/java/org/federationofavatars/brotherhood/AssessmentScorerTest.kt")
    core_test = text("android/app/src/test/java/org/federationofavatars/brotherhood/CoreProfileCatalogTest.kt")
    integrity_test = text("android/app/src/test/java/org/federationofavatars/brotherhood/CrossTestIntegrityAnalyzerTest.kt")

    legacy_members = ("pairId", ".reverse", "question.text", "situationalText")
    combined = "\n".join((catalog_test, scorer_test, core_test))
    for member in legacy_members:
        assert member not in combined

    assert "allMiniTestsUseVersionedIndirectVisualTasks" in catalog_test
    assert "VisualAssessmentFactory.STIMULUS_VERSION" in catalog_test
    assert "visual_scoring_does_not_create_moral_risk" in scorer_test
    assert "core_items_use_indirect_visual_choices" in core_test
    assert "contradictionsAcrossRelatedTestsReduceInternalConsistencyWithoutMoralRisk" in integrity_test
    assert "assertEquals(0, analysis.riskScore)" in integrity_test
    assert "analysis.flags.isEmpty()" in integrity_test
