from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[2]
ANDROID = ROOT / "android/app/src/main"


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def text(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def test_android_and_shared_language_registry_are_identical_and_data_driven():
    shared = load(ROOT / "shared/locales/supported.json")
    android = load(ANDROID / "assets/i18n/languages.json")
    assert shared == android
    assert shared["extensible"] is True
    assert shared["default"] == "ru"
    assert {row["tag"] for row in shared["languages"] if row["enabled"]} == {"ru", "uk", "en"}
    localization = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/Localization.kt")
    assert 'getJSONArray("languages")' in localization
    assert 'required_keys.json' in localization
    assert 'numerology/numerology_knowledge_v1.json' in localization
    assert 'tag !in numerologyLocales' in localization


def test_every_enabled_locale_has_complete_pack_and_numerology_coverage():
    supported = load(ROOT / "shared/locales/supported.json")
    required = set(load(ANDROID / "assets/i18n/required_keys.json")["required_keys"])
    numerology = load(ANDROID / "assets/numerology/numerology_knowledge_v1.json")
    assert len(required) >= 500
    for row in supported["languages"]:
        if not row["enabled"]:
            continue
        tag = row["tag"]
        shared_pack = load(ROOT / f"shared/locales/packs/{tag}.json")
        android_pack = load(ANDROID / f"assets/i18n/{tag}.json")
        assert shared_pack == android_pack
        assert required <= set(android_pack["messages"])
        assert tag in numerology["locales"]


def test_all_quality_labels_are_in_every_current_language_pack():
    contract = load(ROOT / "shared/product/quality-fit-catalog-v2.json")
    assert contract["quality_count"] == 112
    keys = {f"quality.{row['key']}" for row in contract["qualities"]}
    for tag in ("ru", "uk", "en"):
        messages = load(ROOT / f"shared/locales/packs/{tag}.json")["messages"]
        assert keys <= set(messages)


def test_no_enum_or_three_language_branch_is_required_to_add_future_locale():
    kotlin_root = ROOT / "android/app/src/main/java/org/federationofavatars/brotherhood"
    source = "\n".join(p.read_text(encoding="utf-8") for p in kotlin_root.rglob("*.kt"))
    assert "enum class AppLanguage" not in source
    assert "AppLanguage.entries" not in source
    assert "AppLanguage.values" not in source
    assert not re.search(r"when\s*\(\s*language\s*\)", source)
    assert "LanguageCarousel(" in source
    assert source.count("LanguageCarousel(") >= 3  # definition + auth + settings


def test_backend_locales_come_from_shared_registry_not_ru_uk_en_regex():
    main = text("backend/app/main.py")
    models = text("backend/app/models.py")
    quality = text("backend/app/quality_matching.py")
    localization = text("backend/app/localization.py")
    assert "supported_locale_tags()" in main
    assert "public_language_catalog()" in main
    assert r"^(ru|uk|en)$" not in main + models
    assert 'locale in {"ru", "uk", "en"}' not in quality
    assert "shared" in localization and "supported.json" in localization
    assert "normalize_locale" in quality


def test_database_locale_constraint_is_future_extensible():
    migration = text("database/migrations/0005_locale_pack_scalability.sql")
    assert "DROP CONSTRAINT IF EXISTS profiles_locale_check" in migration
    assert "profiles_locale_format_check" in migration
    assert "A-Za-z" in migration


def test_layout_direction_is_driven_by_locale_metadata():
    app = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    assert "LocalLayoutDirection provides layoutDirection" in app
    assert 'language.direction.equals("rtl"' in app


def test_translation_template_covers_runtime_inline_triplets_and_no_obsolete_test_copy():
    template = load(ROOT / "shared/locales/translation-template.json")
    assert template["entry_count"] >= 450
    entries = template["entries"]
    assert "600 indirect visual-associative tasks" in entries
    assert "600 questions, cross-checking and self-presentation control" not in entries
    assert "15 weighted layers plus a friendship-expectations diagnostic" not in entries

def test_language_change_refreshes_server_localized_surfaces():
    vm = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/MainViewModel.kt")
    block = vm[vm.index("fun changeLanguage"):vm.index("fun setTheme")]
    assert "settingsStore.setLanguage" in block
    assert "refreshRemoteData()" in block


def test_remote_personality_titles_are_rehydrated_from_canonical_multilingual_code():
    remote = text("android/app/src/main/java/org/federationofavatars/brotherhood/network/RemoteDataRepository.kt")
    assert "Personality32Engine.allCanonicalProfiles()" in remote
    assert "canonicalPersonality?.titleRu" in remote
    assert "canonicalPersonality?.titleUk" in remote
    assert "canonicalPersonality?.titleEn" in remote
    assert 'titleRu = personalityJson?.optString("title"' not in remote


def test_zodiac_user_facing_name_is_localized_not_enum_name():
    models = text("android/app/src/main/java/org/federationofavatars/brotherhood/model/Models.kt")
    app = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    self_analysis = text("android/app/src/main/java/org/federationofavatars/brotherhood/domain/SelfAnalysisEngine.kt")
    assert "fun label(language: AppLanguage)" in models
    assert ".zodiac.name" not in app
    assert "profile.zodiac.label(language)" in self_analysis


def test_compose_raw_text_literals_are_only_brand_symbols_or_protocol_labels():
    ui_root = ROOT / "android/app/src/main/java/org/federationofavatars/brotherhood/ui"
    allowed_prefixes = ("Brotherhood", "×", "👍", "ID ", "global_id ", "YYYY-MM-DD · 18+")
    offenders = []
    for path in ui_root.rglob("*.kt"):
        source = path.read_text(encoding="utf-8")
        for match in re.finditer(r'Text\("([^"\\]*(?:\\.[^"\\]*)*)"', source):
            value = match.group(1)
            # Pure data interpolation (names, scores, IDs, units) is language-neutral. The guard
            # targets untranslated static prose/labels embedded directly in Compose Text calls.
            if "$" in value:
                continue
            if not value.startswith(allowed_prefixes):
                offenders.append(f"{path.relative_to(ROOT)}: {value}")
    assert offenders == []


def test_zodiac_labels_participate_in_translation_memory():
    template = load(ROOT / "shared/locales/translation-template.json")["entries"]
    for label in ("Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"):
        assert label in template


def test_builtin_city_catalog_is_data_driven_and_localized_without_rewriting_storage_values():
    shared = load(ROOT / "shared/locales/cities.json")
    android = load(ANDROID / "assets/i18n/cities.json")
    assert shared == android
    rows = shared["cities"]
    assert len(rows) >= 10
    assert len({row["value"] for row in rows}) == len(rows)
    assert len({row["id"] for row in rows}) == len(rows)
    for tag in ("ru", "uk", "en"):
        messages = load(ROOT / f"shared/locales/packs/{tag}.json")["messages"]
        for row in rows:
            assert messages[f"city.name.{row['id']}"] == row[tag]
    city_catalog = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/CityCatalog.kt")
    vm = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/MainViewModel.kt")
    assert 'assets.open("i18n/cities.json")' in city_catalog
    assert 'return value' in city_catalog  # arbitrary/user-provided geography remains literal
    assert "cityCatalog.label(city, language)" in vm
