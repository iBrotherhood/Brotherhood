from pathlib import Path
import json, subprocess, sys
ROOT=Path(__file__).resolve().parents[2]

def load(name): return (ROOT/name).read_text(encoding="utf-8")
def routes(): return json.loads(load("ops/operator_kernel/config/routes.yaml"))

def test_kernel_is_active_dispatch_not_navigation_only():
    text=load("KERNEL.md").lower()
    for needle in ["top project goal","active dispatch","patch permission boundary","validation gates","runtime route resolver"]: assert needle in text
    assert "not navigation-only" in text

def test_major_routes_and_boundaries_exist():
    r=routes()
    for rid in ["psychological_visual_matching","numerology_self_analysis","compatibility_model","android_ui_feature","ci_android","backend_api","database","auth_security","release_packaging","kernel_archive"]:
        assert rid in r
        assert r[rid]["required_read"] and r[rid]["allowed_write"] and r[rid]["validation"]

def test_required_read_paths_exist():
    for route in routes().values():
        for p in route["required_read"]:
            if any(c in p for c in "*?["): continue
            assert (ROOT/p).exists(), p

def test_runtime_resolver_uses_config_and_composite_routes():
    tool=load("ops/operator_kernel/operator_kernel.py")
    assert "ROUTES=ROOT/'ops/operator_kernel/config/routes.yaml'" in tool
    out=subprocess.check_output([sys.executable,str(ROOT/'ops/operator_kernel/operator_kernel.py'),'resolve','Перенести нумерологию в Android и подготовить release APK archive'],text=True)
    data=json.loads(out)
    assert data["primary_route"]=="numerology_self_analysis"
    assert "release_packaging" in data["validation_routes"]

def test_ci_prompt_does_not_route_to_ui():
    out=subprocess.check_output([sys.executable,str(ROOT/'ops/operator_kernel/operator_kernel.py'),'resolve','Исправь GitHub Actions apksigner aapt workflow artifact upload'],text=True)
    data=json.loads(out)
    assert data["primary_route"]=="ci_android"
    assert "android_ui_feature" not in data["secondary_routes"]

def test_unknown_prompt_has_safe_fallback():
    out=subprocess.check_output([sys.executable,str(ROOT/'ops/operator_kernel/operator_kernel.py'),'resolve','абракадабра неизвестная тема'],text=True)
    data=json.loads(out)
    assert data["primary_route"]=="historical_reference"

def test_operational_memory_is_not_history_dump():
    text=load("docs/AI/AI_TEMPORARY_MEMORY_PENDING.md")
    assert len(text.splitlines()) < 80
    assert "Active task" in text


def test_psychological_matching_composite_route():
    out=subprocess.check_output([sys.executable,str(ROOT/'ops/operator_kernel/operator_kernel.py'),'resolve','Полностью изменить визуальные психологические тесты, скрытый профиль, качества для директора и подготовить release APK archive'],text=True)
    data=json.loads(out)
    assert data["primary_route"]=="psychological_visual_matching"
    assert "release_packaging" in data["validation_routes"]
