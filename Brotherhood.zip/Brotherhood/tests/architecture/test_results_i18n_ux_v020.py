import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_positive_result_contract_is_public_safe_and_visible():
    models = text("android/app/src/main/java/org/federationofavatars/brotherhood/model/MatchingModels.kt")
    projector = text("android/app/src/main/java/org/federationofavatars/brotherhood/domain/PositiveProfileProjector.kt")
    ui = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    public = models[models.index("data class PositiveAssessmentReveal"):]
    for required in ["qualityLabels", "summary", "usefulContexts", "accountDeltaPercent"]:
        assert required in public
    for forbidden in ["riskScore", "raw", "latentLoadings", "responseTrace", "inconsistency"]:
        assert forbidden not in public
    assert "PositiveProfileProjector.reveal" in text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/MainViewModel.kt")
    assert "Открыта сильная сторона" in ui
    assert "Следующий тест" in ui
    assert "Посмотреть мой профиль" in ui
    assert "Мои сильные стороны" in ui
    assert "accountDeltaPercent = if (isRetake) 0.0 else 0.5" in projector


def test_language_selector_is_unbounded_registry_driven_carousel():
    ui = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    catalog = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/Localization.kt")
    fixture = json.loads(text("shared/locales/fixtures/supported-12-languages.json"))
    assert len(fixture["languages"]) >= 12
    assert {row["direction"] for row in fixture["languages"]} == {"ltr", "rtl"}
    block = ui[ui.index("private fun LanguageCarousel"):ui.index("@Composable", ui.index("private fun LanguageCarousel") + 20)]
    assert "LazyRow" in block
    assert "items(languages" in block
    assert "contentPadding" in block
    assert "LanguageCatalog" in catalog
    assert "requiredKeys.all" in catalog
    assert "numerologyLocales" in catalog


def test_screenshot_findings_have_concrete_ui_fixes():
    ui = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    service = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/ServiceScreens.kt")
    assert "Почему подходит" in ui
    assert "Development APK устанавливается вручную" in ui
    assert "pilotExpanded" in ui
    assert "Проведите влево" in ui
    assert "Найти друга" in service
    assert "Создать группу" in service
    assert "fun ProfileSection" in ui and ".fillMaxWidth()" in ui[ui.index("fun ProfileSection"):]


def test_universal_workflow_is_version_independent_and_frozen_by_contract():
    workflow = text(".github/workflows/android-build.yml")
    assert "SOURCE_ARCHIVE: Brotherhood.zip" in workflow
    assert "EXPECTED_VERSION_NAME" not in workflow
    assert "EXPECTED_VERSION_CODE" not in workflow
    assert "SOURCE_VERSION_CODE" in workflow and "SOURCE_VERSION_NAME" in workflow
    assert "ANDROID_CI_APK_ARTIFACT_PASS" in workflow
    assert "Brotherhood-v${SAFE_VERSION_NAME}-${BUILD_CLASS}-b${VERSION_CODE}.apk" in workflow
    assert not (ROOT / ".github/workflows/android-source-build.yml").exists()


def test_canonical_psychology_and_compatibility_numbers_unchanged():
    assessment = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/AssessmentCatalog.kt")
    visual = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/VisualAssessmentFactory.kt")
    engine = text("android/app/src/main/java/org/federationofavatars/brotherhood/domain/HybridCompatibilityEngine.kt")
    assert "REQUIRED_TEST_COUNT = 100" in assessment
    assert "QUESTIONS_PER_TEST = 6" in assessment
    assert 'STIMULUS_VERSION = "scene-library-v4"' in visual
    expected = {
        '"tests" to 18.0', '"character" to 10.0', '"values" to 10.0', '"goals" to 9.0',
        '"interests" to 8.0', '"lifestyle" to 7.0', '"communication" to 7.0', '"conflict" to 7.0',
        '"personality" to 7.0', '"numerology" to 5.0', '"enneagram" to 4.0', '"zodiac" to 3.0',
        '"geography" to 2.0', '"business" to 2.0', '"social" to 1.0',
    }
    assert all(row in engine for row in expected)
    assert "require(baseWeights.values.sum().roundToInt() == 100)" in engine


def _call_argument_count(source: str, marker: str) -> list[int]:
    counts=[]
    offset=0
    while True:
        start=source.find(marker, offset)
        if start < 0: return counts
        i=start+len(marker)
        depth=1
        commas=0
        quote=None
        escaped=False
        while i < len(source) and depth:
            ch=source[i]
            if quote:
                if escaped: escaped=False
                elif ch == '\\': escaped=True
                elif ch == quote: quote=None
            else:
                if ch in {'"', "'"}: quote=ch
                elif ch == '(': depth += 1
                elif ch == ')': depth -= 1
                elif ch == ',' and depth == 1: commas += 1
            i += 1
        assert depth == 0, f"unclosed call at {start}"
        body = source[start + len(marker): i - 1].rstrip()
        counts.append(commas if body.endswith(",") else commas + 1)
        offset=i


def test_inline_three_language_helper_calls_keep_exact_arity():
    ui=text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    counts=_call_argument_count(ui, "viewModel.t(")
    assert counts and set(counts) == {3}


def test_cycle_0002_personal_results_are_visible_across_home_profile_and_self_analysis():
    ui = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    service = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/ServiceScreens.kt")
    view_model = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/MainViewModel.kt")

    for marker in [
        "Мои открытые качества",
        "Последнее открытие",
        "Следующий лучший шаг",
        "Следующий рекомендуемый тест",
        "Мой стиль взаимодействия",
        "Где мои качества особенно полезны",
        "История открытий",
        "Открыть полное познание себя",
    ]:
        assert marker in ui

    for marker in ["Открытые качества", "Где качества особенно полезны", "История открытий"]:
        assert marker in service

    # Restart persistence must hydrate the same user-visible profile/results instead of demo-resetting them.
    assert "profileStore.load(" in view_model
    assert "settingsStore.languageTag()" in view_model
    assert "assessmentStore.loadAll()" in view_model


def test_cycle_0002_people_and_groups_have_clear_adaptive_actions():
    ui = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")

    assert "Почему подходит" in ui
    assert "Соответствие выбранным качествам" in ui
    assert "Отправить запрос дружбы" in ui
    assert 'Text(viewModel.t("Пропустить", "Пропустити", "Skip"), maxLines = 1)' in ui
    assert 'Text(viewModel.t("Подробнее", "Докладніше", "Details"), maxLines = 1)' in ui

    assert "Деловое сообщество" in ui
    assert "Сообщество по интересам" in ui
    assert "Формат: онлайн" in ui
    assert "Формат: локально" in ui
    assert "Открыть сообщество" in ui
    assert "Вступить в сообщество" in ui


def test_cycle_0002_manual_install_notice_is_unconditional_and_pilot_is_collapsible():
    ui = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    settings = ui[ui.index('SettingsSectionTitle(viewModel.t("Установка версии"'):ui.index('SettingsSectionTitle(viewModel.t("Улучшение подбора"')]
    notice = settings.index("Development APK устанавливается вручную")
    optional_server_info = settings.index("if (info != null)")
    assert notice < optional_server_info

    pilot = ui[ui.index('SettingsSectionTitle(viewModel.t("Улучшение подбора"'):]
    assert "pilotExpanded = !pilotExpanded" in pilot
    assert "if (pilotExpanded)" in pilot
    assert "Прекратить участие" in pilot


def test_cycle_0002_runtime_error_fallbacks_are_locale_aware_and_do_not_leak_raw_exceptions():
    view_model = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/MainViewModel.kt")
    for marker in [
        'language.pick("Не удалось открыть защищённый чат"',
        'language.pick("Не удалось создать группу"',
        'language.pick("Не удалось поставить реакцию"',
        'language.pick("Не удалось изменить блокировку"',
        'language.pick("Не удалось отправить жалобу"',
    ]:
        assert marker in view_model

    attachment = view_model[view_model.index('"attachment.open_failed"'):view_model.index('"attachment.open_failed"') + 500]
    assert 'mapOf("error" to language.pick("ошибка", "помилка", "error"))' in attachment
    assert 'error.message' not in attachment

