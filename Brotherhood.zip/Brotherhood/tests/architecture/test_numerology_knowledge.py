from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "shared/numerology/source_vietnamese_v1.json"
PROVENANCE = ROOT / "shared/numerology/provenance_v1.json"
ASSET = ROOT / "android/app/src/main/assets/numerology/numerology_knowledge_v1.json"
HYBRID = ROOT / "android/app/src/main/java/org/federationofavatars/brotherhood/domain/HybridCompatibilityEngine.kt"
VEDIC = ROOT / "android/app/src/main/java/org/federationofavatars/brotherhood/domain/VedicNumerologyEngine.kt"


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def normalized_source_keys(section: str, source_records: dict) -> set[str]:
    keys = set(source_records[section].keys())
    if section == "birth_chart" and "" in keys:
        keys.remove("")
        keys.add("NONE")
    return keys


def test_all_supplied_records_have_ru_uk_en_runtime_entries():
    source = load(SOURCE)
    asset = load(ASSET)
    for section in ("soul_numbers", "life_paths", "birth_chart", "pyramid_peaks", "outer_numbers"):
        expected = normalized_source_keys(section, source["records"])
        assert set(asset["inventory"][section]) == expected
        for locale in ("ru", "uk", "en"):
            actual = asset["locales"][locale][section]
            assert set(actual.keys()) == expected
            for key, record in actual.items():
                assert record.get("title", "").strip(), (locale, section, key, "title")
                if section == "life_paths":
                    sections = record.get("sections", [])
                    assert len(sections) == len(source["records"][section][key]) == 5
                    assert [item["id"] for item in sections] == ["purpose", "traits", "challenges", "growth", "work"]
                    assert all(item.get("title", "").strip() and item.get("body", "").strip() for item in sections)
                else:
                    assert record.get("body", "").strip(), (locale, section, key, "body")


def test_provenance_inventory_matches_the_supplied_snapshot():
    source = load(SOURCE)
    provenance = load(PROVENANCE)
    counts = {key: len(value) for key, value in source["records"].items()}
    assert counts == {
        "soul_numbers": 11,
        "life_paths": 11,
        "birth_chart": 52,
        "pyramid_peaks": 11,
        "outer_numbers": 12,
    }
    assert provenance["source_archive_sha256"] == source["source_archive_sha256"]
    assert provenance["source_record_counts"] == counts
    assert provenance["compatibility_weight_changed"] is False
    assert provenance["friendship_compatibility_name_input"] is False


def test_compatibility_canon_is_still_date_only_and_five_percent():
    hybrid = HYBRID.read_text(encoding="utf-8")
    vedic = VEDIC.read_text(encoding="utf-8")
    assert '"numerology" to 5.0' in hybrid
    assert "Compatibility is derived ONLY from birth-date numbers" in vedic
    assert "first.nameNumber" not in vedic
    assert "second.nameNumber" not in vedic
    assert "soul * .40 + destiny * .35 + cross * .15 + dateComposite * .10" in vedic


def test_runtime_asset_is_valid_utf8_json_and_has_no_reference_code_dependency():
    raw = ASSET.read_bytes()
    raw.decode("utf-8")
    load(ASSET)
    text = ASSET.read_text(encoding="utf-8")
    assert "require(" not in text
    assert "import " not in text
    assert "eval(" not in text
    assert len(hashlib.sha256(raw).hexdigest()) == 64


def test_product_canon_keeps_assessments_psychological_and_numerology_automatic():
    requirements = load(ROOT / "shared/product/canonical-requirements.json")
    assessments = requirements["assessments"]
    assert assessments["canonical_count"] == 100
    assert assessments["canonical_question_count"] == 600
    assert assessments["domain"] == "psychological_behavioral_friendship_only"
    assert assessments["numerology_is_assessment"] is False
    assert assessments["numerology_questionnaire"] is False
    assert assessments["numerology_derivation"] == "automatic_from_birth_date_and_derived_numerological_values"
    assert assessments["name_number_role"] == "optional_descriptive_self_analysis_only_not_friendship_compatibility"

    canon = (ROOT / "docs/CANON/BROTHERHOOD_PRODUCT_CANON.md").read_text(encoding="utf-8")
    assert "100 psychological/behavioral tests / 600 tasks" in canon
    assert "Numerology is not part of this bank" in canon
