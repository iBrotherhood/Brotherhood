from pathlib import Path
import json, re
ROOT=Path(__file__).resolve().parents[2]

def text(path): return (ROOT/path).read_text(encoding='utf-8')

def test_canon_and_causal_kernel_present():
    canon=text('docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md').lower()
    causal=text('docs/AI/CAUSAL_RELATIONSHIP_KERNEL.md').lower()
    assert '100 psychological/behavioral tests × 6 tasks = 600 tasks'.lower() in canon
    assert 'numerology is not a test' in canon
    assert 'user explicitly selects' in canon
    assert 'quality fit must not mathematically mutate' in canon
    assert 'forbidden causal edges' in causal
    assert 'role selection -> implicit/default desired qualities' in causal
    assert 'legacy direct-question result -> visual-latent-v2 profile' in causal

def test_100x6_bank_is_visual_and_not_direct_self_report():
    catalog=text('android/app/src/main/java/org/federationofavatars/brotherhood/data/AssessmentCatalog.kt')
    model=text('android/app/src/main/java/org/federationofavatars/brotherhood/model/AssessmentModels.kt')
    ui=text('android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt')
    assert 'REQUIRED_TEST_COUNT = 100' in catalog
    assert 'QUESTIONS_PER_TEST = 6' in catalog
    assert 'val text:' not in model
    assert 'latentLoadings' in model
    # UI must use neutral series wording, not construct/category names during the test.
    assert 'Visual series #' in ui
    assert 'Choose the option that first feels most natural.' in ui
    assert 'hidden profile fits your request' not in ui
    assert 'kindLabel(' not in ui

def test_direct_moral_question_regression_absent():
    sources='\n'.join([
        text('android/app/src/main/java/org/federationofavatars/brotherhood/data/AssessmentCatalog.kt'),
        text('android/app/src/main/java/org/federationofavatars/brotherhood/data/VisualAssessmentFactory.kt'),
        text('android/app/src/main/java/org/federationofavatars/brotherhood/data/CoreProfileCatalog.kt'),
    ]).lower()
    forbidden=[
        'вы предадите', 'вы честный', 'вы лидер', 'поддержите друга',
        'are you loyal', 'are you honest', 'would you betray', 'are you a leader',
    ]
    for phrase in forbidden: assert phrase not in sources

def test_no_universal_bad_trait_scoring_or_public_integrity_ui():
    scorer=text('android/app/src/main/java/org/federationofavatars/brotherhood/domain/AssessmentScorer.kt')
    hybrid=text('android/app/src/main/java/org/federationofavatars/brotherhood/domain/HybridCompatibilityEngine.kt')
    ui=text('android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt')
    assert 'riskScore = 0' in scorer
    assert 'HIGH_IS_GOOD' not in catalog_runtime_text()
    assert 'compatibilityRiskFlags' not in hybrid
    assert 'integrityScreening' not in ui

def catalog_runtime_text():
    return text('android/app/src/main/java/org/federationofavatars/brotherhood/data/AssessmentCatalog.kt') + text('android/app/src/main/java/org/federationofavatars/brotherhood/domain/AssessmentScorer.kt')

def test_quality_fit_is_user_authored_and_separate():
    settings=text('android/app/src/main/java/org/federationofavatars/brotherhood/data/SettingsStore.kt')
    engine=text('android/app/src/main/java/org/federationofavatars/brotherhood/domain/QualityMatchingEngine.kt')
    hybrid=text('android/app/src/main/java/org/federationofavatars/brotherhood/domain/HybridCompatibilityEngine.kt')
    assert 'qualities = emptyList()' in text('android/app/src/main/java/org/federationofavatars/brotherhood/data/LatentTraitCatalog.kt')
    assert 'intent.qualities' in engine
    assert 'QualityMatching' not in hybrid
    assert 'search_role' in settings and 'search_qualities' in settings

def test_raw_latent_data_not_in_public_person_dto_or_public_assessment_get():
    models=text('backend/app/models.py')
    main=text('backend/app/main.py')
    person_block=models[models.index('class Person('):models.index('class CommunityKind')]
    assert 'dimensions' not in person_block
    assert 'latent' not in person_block.lower()
    assert '@app.get("/v1/assessment-results/{global_id}", response_model=list[AssessmentPublicReceipt])' in main
    assert '@app.get("/internal/assessment-results/{global_id}", response_model=list[AssessmentResultRecord])' in main

def test_visual_model_migration_quarantines_legacy_scores():
    store=text('android/app/src/main/java/org/federationofavatars/brotherhood/data/AssessmentLocalStore.kt')
    latent=text('android/app/src/main/java/org/federationofavatars/brotherhood/domain/LatentProfileEngine.kt')
    repo=text('backend/app/repository.py')
    assert "legacy-direct-v1" in store
    assert 'model_version = ?' in store
    assert 'AssessmentModelVersions.ACTIVE' in latent
    assert 'assessment_version=%s' in repo and 'visual-latent-v2' in repo

def test_canonical_weights_unchanged_and_numerology_stays_5():
    hybrid=text('android/app/src/main/java/org/federationofavatars/brotherhood/domain/HybridCompatibilityEngine.kt')
    pairs=dict(re.findall(r'"([a-z]+)" to ([0-9.]+)', hybrid.split('private val baseWeights',1)[1].split(')',1)[0]))
    assert round(sum(float(v) for v in pairs.values())) == 100
    assert float(pairs['numerology']) == 5.0
    assert len(pairs) == 15

def test_visual_tasks_cross_load_multiple_hidden_traits():
    catalog=text('android/app/src/main/java/org/federationofavatars/brotherhood/data/AssessmentCatalog.kt')
    factory=text('android/app/src/main/java/org/federationofavatars/brotherhood/data/VisualAssessmentFactory.kt')
    assert 'ordinal * 3' in catalog and 'allTraits' in catalog
    assert 'primary to signal(primary, layout)' in factory
    assert 'secondary to signal(secondary, layout)' in factory
    assert 'tertiary to signal(tertiary, layout)' in factory
    assert 'MODEL HYPOTHESES' in factory

def test_numerology_remains_outside_test_bank():
    canon=text('docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md').lower()
    project=text('docs/PROJECT_CANON_v0_5_15.md').lower()
    assert 'numerology is not a test' in canon
    assert 'overall vedic numerology weight remains exactly 5%' in project


def test_quality_catalog_supports_composite_user_selected_patterns():
    kotlin=text('android/app/src/main/java/org/federationofavatars/brotherhood/data/LatentTraitCatalog.kt')
    contract=json.loads(text('shared/product/quality-fit-catalog-v2.json'))
    backend=text('backend/app/quality_matching.py')
    assert 'data class QualityTraitTarget' in kotlin
    for key in ['demanding','disciplined','firm_decisions','uncompromising_principles','crisis_leader','strategic','operational','entrepreneurial']:
        assert f'qc("{key}"' in kotlin
        assert f"'{key}':" in backend
    assert contract['quality_count'] == 112
    demanding=next(q for q in contract['qualities'] if q['key']=='demanding')
    assert len(demanding['targets']) >= 4
    assert contract['rules']['role_injects_default_qualities'] is False

def test_visual_feature_model_has_explicit_trait_anchors():
    factory=text('android/app/src/main/java/org/federationofavatars/brotherhood/data/VisualAssessmentFactory.kt')
    for feature in ['INTENSITY','SPACING','ORDER','ASYMMETRY','DIRECTION']:
        assert feature in factory
    assert 'TraitAnchor' in factory
    assert 'One choice' not in factory  # no public one-choice conclusion language

def test_quality_fit_catalog_keys_match_android_backend_and_shared_contract():
    kotlin=text('android/app/src/main/java/org/federationofavatars/brotherhood/data/LatentTraitCatalog.kt')
    backend=text('backend/app/quality_matching.py')
    contract=json.loads(text('shared/product/quality-fit-catalog-v2.json'))
    kotlin_keys=set(re.findall(r'\bq(?:c)?\("([a-z0-9_]+)"', kotlin))
    backend_block=backend.split('QUALITY_CATALOG = {',1)[1].split('def aggregate_latent',1)[0]
    backend_keys=set(re.findall(r"^\s*'([a-z0-9_]+)':", backend_block, re.M))
    contract_keys={row['key'] for row in contract['qualities']}
    assert len(kotlin_keys) == 112
    assert contract['quality_count'] == 112
    assert kotlin_keys == backend_keys == contract_keys


def test_quality_fit_outcome_context_is_internal_versioned_and_non_mutating():
    migration=text('database/migrations/0004_quality_fit_outcome_context.sql')
    causal=text('docs/AI/CAUSAL_RELATIONSHIP_KERNEL.md')
    analysis=text('analysis/evaluate_quality_fit_outcomes.py')
    for token in ['searcher_global_id','search_role','desired_qualities','quality_fit_score','quality_fit_confidence','quality_model_version']:
        assert token in migration
    assert 'automatic_production_update' in analysis
    assert "'automatic_production_update':False" in analysis.replace(' ', '')
    assert 'outcome analysis -> silent production model mutation' in causal.lower()
    assert '30d/90d outcome -> public moral/reputation label' in causal.lower()

def test_public_ui_has_no_negative_psychological_sections_or_risk_flags():
    service=text('android/app/src/main/java/org/federationofavatars/brotherhood/ui/ServiceScreens.kt')
    app=text('android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt')
    models=text('backend/app/models.py')
    vedic=text('android/app/src/main/java/org/federationofavatars/brotherhood/domain/VedicNumerologyEngine.kt')
    assert 'Зоны роста' not in service and 'Growth areas' not in service
    assert 'На что обратить внимание' not in service and 'What to watch' not in service
    assert 'zones development' not in app.lower()
    compat=models[models.index('class CompatibilityResponse'):models.index('class FriendshipOutcomeUpsert')]
    assert 'risk_flags' not in compat
    assert 'Зона возможного напряжения' not in vedic
    assert 'Potential tension' not in vedic

def test_profile_sync_model_version_tracks_visual_profile_release():
    remote=text('android/app/src/main/java/org/federationofavatars/brotherhood/network/RemoteDataRepository.kt')
    backend=text('backend/app/models.py')
    assert 'put("model_version", "0.5.20")' in remote
    assert 'model_version: str = "0.5.20"' in backend


def test_backend_quality_catalog_exactly_matches_shared_v2_contract():
    import ast
    source = text('backend/app/quality_matching.py')
    tree = ast.parse(source)
    backend_catalog = {}
    for item in tree.body:
        if isinstance(item, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'QUALITY_CATALOG' for target in item.targets):
            backend_catalog.update(ast.literal_eval(item.value))
        elif (
            isinstance(item, ast.Expr)
            and isinstance(item.value, ast.Call)
            and isinstance(item.value.func, ast.Attribute)
            and isinstance(item.value.func.value, ast.Name)
            and item.value.func.value.id == 'QUALITY_CATALOG'
            and item.value.func.attr == 'update'
            and len(item.value.args) == 1
        ):
            backend_catalog.update(ast.literal_eval(item.value.args[0]))
    contract = json.loads(text('shared/product/quality-fit-catalog-v2.json'))
    shared = {row['key']: row for row in contract['qualities']}
    assert len(backend_catalog) == 112
    assert set(backend_catalog) == set(shared)
    for key, backend_row in backend_catalog.items():
        shared_row = shared[key]
        assert backend_row['group'] == shared_row['group']
        assert backend_row['targets'] == shared_row['targets']
        assert backend_row['ru'] == shared_row['ru']
        assert backend_row['uk'] == shared_row['uk']
        assert backend_row['en'] == shared_row['en']
