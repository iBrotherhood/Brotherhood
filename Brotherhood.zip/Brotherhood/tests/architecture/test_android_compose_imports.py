from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_service_screens_imports_text_align_when_used():
    source = (ROOT / "android/app/src/main/java/org/federationofavatars/brotherhood/ui/ServiceScreens.kt").read_text(encoding="utf-8")
    assert "TextAlign." in source
    assert "import androidx.compose.ui.text.style.TextAlign" in source


def test_universal_workflow_remains_version_independent():
    workflow = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
    assert "EXPECTED_VERSION_NAME" not in workflow
    assert "EXPECTED_VERSION_CODE" not in workflow
