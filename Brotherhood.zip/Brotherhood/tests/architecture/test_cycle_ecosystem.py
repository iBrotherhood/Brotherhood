from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]


def test_compact_cycle_plan_has_ten_assigned_cycles():
    text = (ROOT / "docs/CYCLES/BROTHERHOOD_CYCLES_0001_0100.md").read_text(encoding="utf-8")
    numbers = re.findall(r"^\| (\d{4}) \|", text, flags=re.M)
    assert numbers == [f"{i:04d}" for i in range(1, 11)]
    assert "0011–0100 = UNUSED_RESERVE" in text


def test_apk_builds_are_milestone_only():
    text = (ROOT / "docs/CYCLES/BROTHERHOOD_CYCLES_0001_0100.md").read_text(encoding="utf-8")
    assert "APK CHECKPOINT A" in text
    assert "APK CHECKPOINT B" in text
    assert "APK CHECKPOINT C" in text
    assert "APK CHECKPOINT D" in text
    assert "APK/AAB FINAL CHECKPOINT E" in text
    assert "не собирается после каждого цикла" in text


def test_audit_and_evidence_levels_exist():
    assert (ROOT / "docs/AUDIT/CHAT_AND_SOURCE_AUDIT_2026_08_01.md").is_file()
    rules = (ROOT / "docs/AI/AI_WORK_RULES.md").read_text(encoding="utf-8")
    for token in ["SOURCE_ONLY", "LOCAL_PASS", "APK_VISIBLE", "LIVE_E2E", "PRODUCTION_QUALIFIED"]:
        assert token in rules


def test_startup_and_kernel_reference_cycles():
    start = (ROOT / "START_HERE.md").read_text(encoding="utf-8")
    kernel = (ROOT / "KERNEL.md").read_text(encoding="utf-8")
    assert "docs/CYCLES/CYCLE_STATUS_REGISTRY.md" in start
    assert "BROTHERHOOD_CYCLES_0001_0100.md" in kernel
