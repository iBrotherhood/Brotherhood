from pathlib import Path
import importlib.util
import re

ROOT = Path(__file__).resolve().parents[2]


def text(rel): return (ROOT / rel).read_text(encoding="utf-8")


def load_calibrator():
    path = ROOT / "analysis/calibrate_visual_model.py"
    spec = importlib.util.spec_from_file_location("visual_calibrator", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def enum_values(source: str, enum_name: str) -> list[str]:
    block = source.split(f"enum class {enum_name}", 1)[1].split("}", 1)[0]
    values = []
    for name in re.findall(r"\b([A-Z][A-Z_]+)\b", block):
        if name not in values:
            values.append(name)
    return values


def test_visual_v2_model_stays_active_but_stimulus_library_is_v3():
    model = text("android/app/src/main/java/org/federationofavatars/brotherhood/model/AssessmentModels.kt")
    factory = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/VisualAssessmentFactory.kt")
    latent = text("android/app/src/main/java/org/federationofavatars/brotherhood/domain/LatentProfileEngine.kt")
    assert 'VISUAL_LATENT_V2 = "visual-latent-v2"' in model
    assert "ACTIVE = VISUAL_LATENT_V2" in model
    assert 'VISUAL_LATENT_V1 = "visual-latent-v1"' in model
    assert 'MODEL_VERSION = "visual-latent-v2"' in factory
    assert 'STIMULUS_VERSION = "scene-library-v3"' in factory
    assert 'stimulusVersion: String = "scene-library-v3"' in model
    assert "AssessmentModelVersions.ACTIVE" in latent


def test_scene_library_has_48_archetypes_16_paradigms_and_renderer_coverage():
    model = text("android/app/src/main/java/org/federationofavatars/brotherhood/model/AssessmentModels.kt")
    factory = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/VisualAssessmentFactory.kt")
    ui = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    scenes = enum_values(model, "VisualSceneArchetype")
    paradigms = enum_values(model, "VisualParadigm")
    assert len(scenes) == 48
    assert len(paradigms) == 16
    for name in scenes:
        assert f"VisualSceneArchetype.{name}" in factory
        assert f"VisualSceneArchetype.{name}" in ui
    for name in paradigms:
        assert f"VisualParadigm.{name}" in factory
        assert f"VisualParadigm.{name}" in ui


def test_ui_and_trace_share_one_deterministic_presentation_order_source():
    factory = text("android/app/src/main/java/org/federationofavatars/brotherhood/data/VisualAssessmentFactory.kt")
    ui = text("android/app/src/main/java/org/federationofavatars/brotherhood/ui/BrotherhoodApp.kt")
    scorer = text("android/app/src/main/java/org/federationofavatars/brotherhood/domain/AssessmentScorer.kt")
    assert "fun presentedChoices(choices: List<VisualAssessmentChoice>, seed: Int)" in factory
    assert "VisualAssessmentFactory.presentedChoices(choices, seed)" in ui
    assert "presentationSlot(question, selected.id)" in scorer
    # UI must not carry a second copy of the permutation math.
    grid = ui.split("private fun VisualChoiceGrid", 1)[1].split("@Composable", 1)[0]
    assert "seed * 31" not in grid
    assert "shuffled()" not in grid


def test_item_level_trace_is_private_opt_in_and_versioned():
    models = text("backend/app/models.py")
    main = text("backend/app/main.py")
    repo = text("backend/app/repository.py")
    migration = text("database/migrations/0006_calibration_pilot.sql")
    assert "class AssessmentResponseTrace" in models
    for field in ["presentation_slot", "response_latency_ms", "selection_changes", "question_position"]:
        assert field in models
    public = models[models.index("class AssessmentPublicReceipt"):models.index("class AccountRatingRequest")]
    assert "response_trace" not in public
    assert "dimensions" not in public
    assert '@app.get("/internal/assessment-results/{global_id}"' in main
    assert '@app.put("/v1/calibration-consent"' in main
    assert "CREATE TABLE IF NOT EXISTS assessment_calibration_attempts" in migration
    assert 'score_json["response_trace"] = []' in repo
    assert 'DELETE FROM assessment_calibration_attempts WHERE global_id=%s' in repo


def test_early_and_outcome_exports_use_separate_opt_in_attempt_store():
    early = text("analysis/visual_item_calibration_export.sql")
    outcome = text("analysis/visual_assessment_calibration_export.sql")
    for sql in [early, outcome]:
        assert "assessment_calibration_attempts" in sql
        assert "calibration_consents" in sql
        assert "cc.opt_in = true" in sql
        assert "presentation_slot" in sql
        assert "response_latency_ms" in sql
        assert "selection_changes" in sql
        assert "question_position" in sql
        assert "scene-library-v3" in sql
        assert "assessment_results" not in sql
    for token in ["desired_qualities", "quality_fit_score", "still_active_90d", "search_role"]:
        assert token in outcome
    assert "aca.completed_at <= oc.matched_at" in outcome
    assert "ORDER BY aca.completed_at DESC" in outcome


def test_calibration_is_diagnostic_only_and_detects_choice_position_and_speed_bias():
    mod = load_calibrator()
    rows = []
    # 80 observations: intentionally concentrated choice, slot and unrealistically fast response.
    for i in range(80):
        rows.append({
            "participant_global_id": str(i + 1), "attempt_id": f"a{i}", "assessment_id": "f001",
            "scoring_version": "visual-latent-v2", "stimulus_version": "scene-library-v3",
            "connection_id": f"c{i}", "locale": "ru", "cohort_id": "pilot-v1",
            "question_id": "f001q1", "choice_id": "1" if i < 60 else str(2 + (i % 3)),
            "presentation_slot": "1" if i < 60 else str(2 + (i % 3)),
            "response_latency_ms": "250", "selection_changes": "0", "question_position": "1",
            "scene_archetype": "CROSSROADS", "paradigm": "PATH",
            "still_active_90d": "true" if i % 2 else "false",
        })
    report = mod.evaluate(rows)
    assert report["automatic_production_mutation"] is False
    assert report["operational_thresholds_are_validation_claims"] is False
    row = next(x for x in report["item_diagnostics"] if x["question_id"] == "f001q1")
    assert row["status"] == "REVIEW_CANDIDATE"
    assert "choice_concentration" in row["reasons"]
    assert "presentation_slot_bias" in row["reasons"]
    assert "very_fast_response_share" in row["reasons"]


def test_calibrator_quarantines_wrong_stimulus_version_and_reports_pilot_stage():
    mod = load_calibrator()
    rows = [{
        "participant_global_id": "1", "attempt_id": "a1", "assessment_id": "f001",
        "scoring_version": "visual-latent-v2", "stimulus_version": "scene-library-v2",
        "question_id": "f001q1", "choice_id": "1", "presentation_slot": "1", "question_position": "1",
    }]
    report = mod.evaluate(rows)
    assert report["accepted_rows"] == 0
    assert report["excluded_rows"]["wrong_stimulus_version"] == 1
    assert report["pilot_stage"] == "PILOT_INTAKE"


def test_calibration_never_auto_mutates_matching_or_compatibility():
    calibrator = text("analysis/calibrate_visual_model.py")
    canon = text("docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md")
    assert "automatic_production_mutation" in calibrator
    assert '"automatic_production_mutation":False' in calibrator.replace(" ", "")
    assert "never auto" in canon.lower() or "не измен" in canon.lower()
