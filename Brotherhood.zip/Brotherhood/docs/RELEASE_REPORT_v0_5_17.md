# Brotherhood v0.5.17 — visual composition / controlled pilot release report

Android target: `versionName 0.5.17`, `versionCode 22`, `applicationId org.federationofavatars.brotherhood`.

## Scope
1. Correct Kotlin source failure from GitHub run `83237541436`.
2. Preserve `visual-latent-v2`; upgrade stimulus provenance to `scene-library-v4`.
3. Add eight non-scoring composition variants across the existing 48 scenes.
4. Prepare the first closed, quota-controlled, invitation-based real-user pilot without changing calibration architecture.

## CI incident
The first failed build task was `:app:compileDebugKotlin`. `BrotherhoodApp.kt:2617:2` reported `Expecting '}'`. The actual source section had a truncated `CompatibilityPanel` and a lost `CompatibilityMetric` declaration. The full 15-layer panel was restored. The prior run never reached tests, APK creation, signing, metadata validation or artifact upload.

## Controlled cohort
- default mode: closed;
- consent: `calibration-consent-v2`;
- suggested first wave: 18 adults, target 6 RU / 6 UK / 6 EN;
- one-use invitation codes, SHA-256 configured/stored only;
- total and locale quotas;
- raw traces only for active participants;
- withdrawal deletes raw attempts and preserves aggregate profile.

## Local qualification
- backend/architecture: 98/98 PASS;
- OpenAPI: 0.5.17 / 45 paths;
- locale generation: 610 translation entries / 741 required keys / RU-UK-EN;
- pure Kotlin core: PASS;
- GitHub Android build: pending exact-HEAD rerun.

Verdict: `LOCAL_PASS_LIVE_DEFERRED`.
