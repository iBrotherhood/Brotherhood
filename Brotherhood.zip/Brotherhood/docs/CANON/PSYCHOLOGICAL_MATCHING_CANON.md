# Brotherhood — Psychological Matching Canon

Status: ACTIVE CANON

## 1. Purpose
Brotherhood does not rank people from good to bad. It builds a private multidimensional profile and finds people whose qualities fit a user-authored request for a particular relationship or role.

## 2. User controls the search target
The user explicitly selects:
- role/context: friend, close friend, business partner, director/manager, project teammate, mentor, activity partner or custom;
- desired qualities;
- importance of each selected quality where the UI exposes importance controls.

The algorithm MUST NOT infer or inject the qualities the user supposedly needs merely from the selected role. Role is context metadata; requested qualities are authoritative. The user may also set relative importance for selected qualities.

A visible quality may map to one private coordinate or to a versioned composite pattern across several private coordinates. Composite qualities must remain auditable in the internal catalog and must never become hidden role defaults.

## 3. No universally bad qualities
There is no global bad-trait score. Both poles of a latent coordinate can be useful in different contexts.
Examples:
- high directness -> clear, candid style;
- low directness -> diplomatic style;
- high assertiveness -> forceful leadership style;
- low assertiveness -> gentle, non-imposing style;
- high risk tolerance -> bold under uncertainty;
- low risk tolerance -> cautious risk management;
- high leadership orientation -> leadership-oriented;
- low leadership orientation -> strong contributor orientation.

The system evaluates fit to a request, not moral worth.

## 4. Hidden inference boundary
Private/algorithm-only:
- raw latent coordinates;
- choice-to-trait loadings;
- cross-checks and consistency signals;
- internal uncertainty/confidence signals;
- calibration coefficients;
- diagnostic/model-development warnings.

Public/user-facing:
- positive strengths/resources;
- user-selected quality names and their explicit priorities;
- Quality Fit score to the user's own request;
- canonical Compatibility score and its approved public layer explanations;
- Trust Score as a separate system;
- Account Completeness as a separate system.

Raw latent coordinates MUST NOT be returned by public people/profile DTOs or ordinary assessment-result APIs.

## 5. Assessment bank
Exactly 100 psychological/behavioral tests × 6 tasks = 600 tasks.
Numerology is NOT a test and is not part of the 100/600 bank.

The 600 tasks must be indirect. Direct questions such as “Are you loyal?”, “Would you betray a friend?”, “Are you a leader?” or other obvious socially desirable self-descriptions are prohibited.

Primary task forms:
- visual associations;
- abstract/social compositions;
- picture-based choice;
- spatial/group arrangements;
- visual sequences;
- ambiguous scenes;
- image-based forced choice;
- symbolic/resource/path/boundary/rhythm choices.

A user must understand how to answer but must not be told which latent construct is being measured or which option is algorithmically meaningful.

## 6. No single-answer diagnosis
A single picture/choice MUST NOT produce a moral label, diagnosis or public conclusion. A latent trait is inferred only from multiple distributed signals across the bank. The same latent coordinate should be sampled in multiple task contexts separated across the bank.

Initial visual loadings are model hypotheses. They are not represented as clinically validated psychological facts until empirical validation supports them.

## 7. Quality Fit is separate
`Quality Fit` answers one question only:
“How closely does this candidate's private profile match the qualities this user explicitly requested?”

Quality Fit MUST NOT mathematically mutate:
- canonical Compatibility weights;
- Trust Score;
- Account Completeness.

A candidate can have high Quality Fit for a director role and low Quality Fit for a specific friendship request, or vice versa.

## 8. Compatibility remains separate and locked
The canonical 15-layer Compatibility model remains 100% and Vedic numerology remains 5%. User-selected desired qualities do not reweight this canonical model.

## 9. Positive public projection
Public interpretation emphasizes strengths and contextually useful qualities. Negative moral labels are forbidden.
The private model must not be falsified or erased to create positive wording; only the presentation layer is positive/contextual.

## 10. Empirical calibration and outcome validation
The active instrument is `visual-latent-v2` / `scene-library-v4`. The active personality profile store contains aggregate hidden coordinates only. Raw item-level response traces are a separate calibration dataset and may be retained server-side ONLY for a participant who explicitly opted into the current calibration consent/cohort. Ordinary assessment completion without opt-in MUST NOT create a retained raw calibration attempt. Withdrawal MUST delete that participant's retained raw calibration attempts while preserving the aggregate profile needed for ordinary product operation. Raw traces are private analytics and MUST NOT be exposed by public APIs.

A calibration trace may record the exact visual task/choice/archetype/layout, deterministic presentation slot, response latency, answer-change count and question position needed to test item/position/order bias and model quality. These signals are model-development observations, not deception scores, diagnoses or public reputation inputs.

Calibration may evaluate item choice entropy, option concentration, presentation-position bias, response-time patterns, scene/paradigm coverage, repeated-attempt stability, cross-language distribution drift and association with consented 30/90-day outcomes. Every result is observational. **Calibration NEVER automatically changes production loadings, quality targets, Compatibility weights, Trust, reputation or public labels.** A finding creates a review candidate only; an actual model change requires an explicit reviewed, versioned release.

30/90-day friendship outcomes and other consented product outcomes may be used as calibration evidence. For Quality Fit validation, the internal outcome snapshot preserves the initiating user's explicit role, selected qualities/importance, Quality Fit score/confidence and model version at connection time. Outcome analysis MUST use only candidate assessments completed on or before the connection/match timestamp; a post-match assessment must never be used to explain or predict an earlier match. This supports observational testing of `user request -> fit -> later outcome` without temporal leakage and without turning outcomes into public reputation.

### Controlled first-user cohort
The first real-data cohort is closed by default. New participation requires: current versioned consent, explicit eligibility acknowledgement, a supported instrument locale, free total/locale quota and (in closed mode) an unredeemed invitation whose plaintext is never persisted. Only the SHA-256 digest may be compared/stored for one-use enforcement. Re-enrollment in a different cohort/wave is a new enrollment and cannot inherit an old invitation bypass. Withdrawal remains unconditional even when the pilot is disabled or full.

### Composition diversity
`scene-library-v4` adds a non-scoring `composition_variant` (0..7) to each visual task. The same composition is shown behind all four answer options for that task; only the choice layout carries latent loadings. Composition variation is calibration evidence for visual-form effects and MUST NOT be interpreted as a personality signal.

## 11. Migration boundary
Pre-visual direct-question results are historical only. They MUST NOT feed `visual-latent-v2`, Quality Fit or new latent-profile calculations. Users must build the new visual profile from the new task model.

## 12. Research and claims
Brotherhood may use public-domain/licensed construct taxonomies and research as foundations. It must not copy restricted proprietary test items without rights, and it must not claim clinical diagnosis or validated predictive accuracy until the specific Brotherhood instrument has been empirically validated.
