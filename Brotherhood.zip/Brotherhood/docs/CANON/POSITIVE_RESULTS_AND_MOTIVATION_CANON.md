# Positive Results and Motivation CANON

Status: ACTIVE — v0.5.20

## 1. Required result
Every completed psychological block must immediately return visible user value: one or more positively formulated qualities, a positive summary, useful contexts, profile progress and a next action. A counter-only completion is forbidden.

## 2. Hidden/public boundary
Public results may contain positive qualities, constructive style descriptions, contexts and progress. They must never contain raw latent coordinates, loadings, consistency diagnostics, response traces, latency, moral risk or negative labels.

## 3. No bad qualities
Brotherhood does not classify traits as universally good or bad. Public language highlights strengths and context. Internal algorithms use neutral coordinates for role- and person-specific matching.

## 4. Retakes
A first unique completion contributes 0.5% to Account Completeness. A retake may refine confidence but cannot add the same 0.5% again and cannot present an old discovery as newly unlocked.

## 5. Surfaces
Positive discoveries must be reachable from: immediate result screen, Home, Profile and Self-analysis/history.
