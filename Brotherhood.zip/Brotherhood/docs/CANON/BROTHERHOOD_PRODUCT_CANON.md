# Brotherhood product canon

Status: ACTIVE CANON

- Brotherhood is an 18+ platonic male-friendship application, not a dating app.
- Main navigation: Home | People | Chats | Groups | Profile.
- `global_id` is the system owner ID; provider IDs are login identities only.
- Trust Score, Compatibility, Account Completeness and Quality Fit are four separate systems.
- Compatibility production weights remain the canonical 100% model; Vedic numerology remains **5%**.
- Vedic friendship compatibility uses two birth dates only; name-derived numbers are descriptive self-analysis only.
- Vedic/numerology is a cultural/esoteric self-analysis layer, not psychology, not a test and not a Trust signal.
- The canonical assessment bank contains exactly **100 psychological/behavioral tests / 600 tasks**. Numerology is not part of this bank.
- Psychological tasks are indirect visual/associative tasks. Direct obvious questions about loyalty, honesty, leadership, morality, support or other socially desirable qualities are prohibited.
- Detailed latent conclusions, hidden scales, cross-checks and consistency signals are internal algorithm data only.
- Public psychological interpretation is positive/contextual. Brotherhood has no universal “bad trait” taxonomy; the same trait can be useful for one role/person and unsuitable for another.
- The searching user explicitly chooses the role/context and desired qualities. The algorithm must not impose desired qualities from the role.
- Quality Fit compares a candidate's private latent profile to the user's explicit quality request and does not modify Compatibility, Trust or Account Completeness.
- One candidate may be an excellent fit for one user/role and a weak fit for another without being morally downgraded.
- Pre-visual direct-question results are historical only and may not feed `visual-latent-v2`.
- Master logo geometry is not changed without explicit user task.

Detailed psychological canon: `docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md`.
Causal graph and forbidden edges: `docs/AI/CAUSAL_RELATIONSHIP_KERNEL.md`.
