# Brotherhood Localization Canon

Status: ACTIVE CANON

1. The application is multilingual by architecture, not limited to RU/UK/EN.
2. Current enabled languages are Russian, Ukrainian and English; many additional languages are expected later.
3. Language selection is presented as a carousel.
4. Changing language changes all user-facing functions, sections, assessment instructions/results, Quality Fit labels, self-analysis and numerology content, not only navigation.
5. A future language is enabled by complete data packs and validation; matching/business algorithms do not branch on specific language names.
6. Language choice never changes hidden psychological scoring or numerical compatibility semantics; only localized presentation/input normalization changes.
7. RTL/LTR direction comes from locale metadata.
8. Built-in geographic labels are locale-dependent presentation data, while canonical search/storage city values remain stable across language changes.
9. User-authored names, messages, descriptions and arbitrary geographic strings are user data and are not silently machine-translated by a UI language switch. Bundled demo/reference content is localized because it is application-owned presentation content.
10. Language activation is fail-closed: a locale missing any required UI/domain/quality/city/numerology key is not shown in the carousel.

