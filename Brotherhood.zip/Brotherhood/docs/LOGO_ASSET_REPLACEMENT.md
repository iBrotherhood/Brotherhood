# Brotherhood canonical logo — integrated in v0.5.10

Status: **COMPLETE**

The temporary placeholder logo was removed.

Canonical master:
- `brand/BR_logo_master.svg`
- SHA-256: `cd033fbebefd67a42d98faee53878db2d6fb34893cf178c4877b0d8ea7a0c6b5`
- canvas/viewBox: `8192 × 8192`
- background: `#000000`
- mark: `#ECAF21`

Generated assets:
- `brand/BR_logo_1024.png`
- `brand/BR_logo_512.png`
- `android/app/src/main/res/drawable/ic_brotherhood_logo.xml`
- `android/app/src/main/res/drawable/ic_launcher_foreground.xml`
- `android/app/src/main/res/drawable/ic_launcher_monochrome.xml`
- adaptive icon XML for API 26+
- themed monochrome icon XML for API 33+
- Android 12+ splash resources

The full-colour logo is rendered with `Color.Unspecified` tint in Compose so Material theme colours do not alter the supplied black/gold artwork.
