# Brotherhood logo slot — v0.5.8

The application now uses a dedicated replaceable vector asset:

- `android/app/src/main/res/drawable/ic_brotherhood_logo.xml`
- launcher foreground currently mirrors the same temporary mark.

The current mark is a neutral placeholder only. When approved logo samples are supplied, replace the vector paths (or add the final adaptive-icon foreground/background assets) without changing navigation, layout, application id, `global_id`, or backend contracts.

Required final variants:

- adaptive Android launcher icon;
- monochrome Android themed icon;
- in-app mark for light theme;
- in-app mark for true-black theme;
- Play Store 512×512 artwork generated from the approved source.
