# Cycle 0003 — Real-device UX acceptance

## Status
`CONDITIONAL_NEXT`

## Activation condition
Activate only after cycle 0002 receives `ANDROID_CI_APK_ARTIFACT_PASS` and a v0.5.21 APK is installed on a real device.

## Goal
Verify only the v0.5.20/v0.5.21 user-facing changes: positive results, Home/Profile strengths, language carousel, People chips, Chats CTA, Settings manual-install text and responsive layout.

## Rule
Fix only defects proven by screenshots or device behavior. Do not add unrelated features and do not split the acceptance into artificial cycles.
