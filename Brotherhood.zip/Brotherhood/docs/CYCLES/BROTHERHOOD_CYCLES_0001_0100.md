# Brotherhood — компактный полный план циклов 0001–0100

## Главный принцип

Этот файл содержит **весь оставшийся план Brotherhood**, но не превращает каждую мелкую правку, импорт, документ, CI-run или упаковку в отдельный цикл.

- Один цикл = крупный законченный продуктовый результат с единым exit gate.
- Исправления, тесты, документация, упаковка и локальные регрессии входят в тот же цикл.
- GitHub APK не собирается после каждого цикла. APK-сборки выполняются только в заранее заданных контрольных точках.
- Циклы `0011–0100` — свободный резерв и не являются запланированной работой.

## Статусы

- `COMPLETED` — результат доказан в исходниках/локальных проверках и закрыт по своему scope.
- `ACTIVE` — текущая выполняемая работа.
- `CHECKPOINT_PENDING` — source scope готов, но обязательный внешний/runtime checkpoint ещё не доказан.
- `PLANNED` — обязательная часть полного плана.
- `UNUSED_RESERVE` — номер не назначен и не считается оставшейся работой.

## Полный план

| Цикл | Статус | Крупный результат | Что входит | APK-контрольная точка |
|---|---|---|---|---|
| 0001 | COMPLETED | Фундамент, аудит и управление проектом | Стабилизация текущего HEAD до `v0.5.21`; universal workflow; исправления подтверждённых Kotlin/CI-дефектов; восстановление AI/KERNEL/MEMORY/HANDOFF/GUARDS; полный аудит переписки и исходников; замена раздутого roadmap компактным планом. | НЕТ. Все микрофиксы поглощены фундаментом; отдельный APK ради документации не нужен. |
| 0002 | CHECKPOINT_PENDING | Полностью видимый Android UX и ценность для пользователя | Source milestone `v0.5.22`: положительный результат после каждого теста; сильные стороны/последнее открытие/следующий шаг на Home; сильные стороны, стиль, полезные контексты и история на Profile/Self-analysis; retake без повторных 0.5%; registry-driven `LazyRow` language carousel; RU/UK/EN runtime fallbacks; People/Chats/Groups/Profile/Settings исправления; честный manual-install режим. Source guards PASS; GitHub Kotlin/APK + device screenshots ещё обязательны. | **APK CHECKPOINT A**: universal GitHub workflow + реальное устройство; до этого цикл не `COMPLETED`. |
| 0003 | ACTIVE | Реальный backend, PostgreSQL, auth и синхронизация данных | Source milestone `v0.5.23`: public auth API; opaque rotating sessions/revocation/device binding; Google server verification + runtime public client config; Telegram HTTPS OIDC callback + PKCE + device-bound one-time ticket; email OTP; passkey challenge/verification; PostgreSQL migration 0008; verified provider identity → one `global_id`; server settings sync; Android encrypted session + restart restore. Local backend/architecture gates PASS. Real deployment/DB/provider credentials/Digital Asset Links remain `LIVE_E2E PENDING`. | НЕТ. Backend/API/PostgreSQL квалифицируются отдельно; Android checkpoint остаётся по roadmap. |
| 0004 | PLANNED | Живой поиск людей, Quality Fit, Compatibility и Trust | Реальные кандидаты вместо demo; Quick Discovery; skip/undo/details/request; Passport mode; фильтры; пользователь выбирает роль и качества; server-side Quality Fit; 15 слоёв Compatibility с base/personalized totals; Trust отдельно; friend-request lifecycle; причины «Почему подходит» без раскрытия latent profile. | **APK CHECKPOINT B** после end-to-end Android↔backend↔PostgreSQL. |
| 0005 | PLANNED | Полноценное общение и доставка сообщений | Direct/group chats с реальным сервером; E2EE direct chat hardening; offline outbox/retry; receipts, reply, reactions, edit/delete, typing, block/report; object storage и большие вложения; FCM; polling/backoff; device-key lifecycle; media quotas. | НЕТ. Объединяется с циклом 0006 до следующей Android-сборки. |
| 0006 | PLANNED | Сообщества, взаимопомощь, бизнес/проекты и модерация | Создание/поиск групп; роли owner/admin/member; business/project/mutual-aid flows; verified-only режимы; group moderation; приватные жалобы; подтверждённые incidents; appeals; audit log; защита от массовых ложных жалоб; согласованность с чатами и Trust. | **APK CHECKPOINT C** после совместной приёмки циклов 0005–0006. |
| 0007 | PLANNED | Психологическая система готова к реальному исследованию | 100×6 visual bank полностью доступен; композиции не раскрывают цель; positive projection и history сохраняются server-side; Quality Fit uses private profile; cohort consent/privacy/withdrawal; калибровочные exports/scripts; отсутствие auto-mutation production; stimulus review protocol. | НЕТ, если Android UI не менялся; при изменении visual renderer переносится в checkpoint D. |
| 0008 | PLANNED | Controlled pilot и доказательная калибровка | Техническая волна 2 RU + 2 UK + 2 EN; затем 6+6+6; consent/invite/quota/purge proof; entropy, position bias, latency, locale equivalence, retest; ручной review weak items; approved versioned stimulus/model revision; никакой автоматической смены production loadings. | **APK CHECKPOINT D** только после утверждённых изменений модели/визуалов. |
| 0009 | PLANNED | Security, privacy, reliability и production infrastructure | Независимый crypto review; multi-device/recovery/revocation; metadata leakage; privacy export/delete/retention; secrets; observability; backups/restore drills; load/performance; penetration tests; incident response; production topology. | НЕТ до release candidate. |
| 0010 | PLANNED | Production release и контролируемый rollout | Production signing отдельно от Development; AAB; store listing/privacy declarations; финальная локализация/accessibility; clean PostgreSQL; exact-head CI; device matrix; RC; release freeze; staged rollout; post-release monitoring и rollback plan. | **APK/AAB FINAL CHECKPOINT E**. |

## Неиспользованный резерв

`0011–0100 = UNUSED_RESERVE`.

Эти номера не активируются автоматически и не учитываются как оставшиеся циклы. Новый цикл после 0010 создаётся только по реальному post-release дефекту или новой утверждённой функции.

## Периодичность APK

Обязательные Android/GitHub контрольные сборки:

1. конец цикла `0002`;
2. конец цикла `0004`;
3. конец объединённого блока `0005–0006`;
4. конец цикла `0008`, только если изменён Android/model renderer;
5. цикл `0010` — RC/final.

Исключение: ранний APK допускается только если без Android-компиляции невозможно безопасно продолжать работу или пользователь прямо потребовал сборку.
