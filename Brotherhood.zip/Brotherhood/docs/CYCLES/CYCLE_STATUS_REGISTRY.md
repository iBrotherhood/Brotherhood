# Cycle status registry

## Текущий статус полного плана

- Всего назначенных крупных циклов: **10** (`0001–0010`).
- Завершено: **1** (`0001`).
- `0002`: **CHECKPOINT_PENDING** — source milestone `v0.5.22` готов, GitHub APK + device acceptance ещё не доказаны.
- `0003`: **ACTIVE — SOURCE MILESTONE v0.5.23 READY / LIVE_E2E PENDING**. Цикл активирован прямой командой пользователя 2026-08-08 до закрытия checkpoint 0002.
- `0004–0010`: **PLANNED**.
- Реально не завершено: **9** (`0002–0010`).
- Неиспользованный резерв: `0011–0100`; в счётчик работы не входит.
- Текущий source package HEAD: `v0.5.23 / versionCode 28`.
- Universal workflow SHA-256 остаётся `82cafc472125906ae8a1c8850d0cfc09aca4704956f9b570f0336d87cb5a460f`.

## Цикл 0003 — доказательный статус

`LOCAL_PASS` для доступных backend/architecture/source gates. Реальный PostgreSQL, migrations на живой БД, Google/Telegram/email/passkey credentials, production RP/Digital Asset Links и Android↔backend↔DB/provider путь требуют `LIVE_E2E`.

## Следующий продуктовый цикл

`0004 — Discovery / Quality Fit / Compatibility / Trust` остаётся PLANNED и не активируется автоматически до live-gate 0003, если пользователь не даст отдельную команду.

## Запрет раздувания циклов

1. Импорт, одна ошибка компиляции, документация, архивирование или один CI-run не получают отдельный product-cycle.
2. `SOURCE_ONLY`/`LOCAL_PASS` не равны `APK_VISIBLE`, `LIVE_E2E` или `PRODUCTION_QUALIFIED`.
3. Pending checkpoint 0002 не стирается из истории из-за прямого перехода пользователя к 0003.
