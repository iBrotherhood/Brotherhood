# Cycle 0003 — REAL BACKEND / DATABASE / AUTH

Status: ACTIVE — SOURCE MILESTONE v0.5.23 READY / LIVE_E2E PENDING
Activated by explicit user instruction: 2026-08-08.

## Source milestone
- FastAPI public auth endpoints for provider exchange, refresh, session, logout, email OTP, passkey and Telegram OIDC.
- PostgreSQL migration 0008 for refresh sessions, email/OIDC challenges, passkeys, device-bound login tickets and user settings.
- Provider identity remains access identity; `global_id` remains sole owner. Verified-email linking is serialized and conflicts require explicit recovery.
- Android stores session encrypted with Android Keystore, restores `global_id`, rotates refresh, synchronizes settings and never receives DB/provider secrets.
- Google Client ID is fetched as public runtime config from Brotherhood backend, so frozen GitHub workflow needs no change.
- Telegram uses registered HTTPS backend callback + PKCE; the app receives only a short-lived one-time ticket bound to the initiating device.
- Passkey server requires discoverable credential + user verification. Production Android passkey requires real RP domain + Digital Asset Links.

## Local evidence
- backend + architecture: 139 PASS.
- Python compileall: PASS.
- JSON/XML parse: PASS.
- Workflow hash: unchanged.

## Exit gates still external
- real PostgreSQL/Neon database + migration application;
- deployed HTTPS FastAPI endpoint + real `BROTHERHOOD_API_BASE_URL`;
- Google/Telegram/email/passkey production credentials/config;
- real Android ↔ backend ↔ PostgreSQL/provider path;
- passkey RP origin + Digital Asset Links.

Until these gates pass, status must not be promoted to `LIVE_E2E`.
