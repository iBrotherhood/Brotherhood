# Cycle NNNN — <name>

## Status
`RESERVED | CONDITIONAL_NEXT | NEXT | ACTIVE | COMPLETED | BLOCKED | DEFERRED_ENVIRONMENT | SUPERSEDED`

## Primary route
`<operator-kernel route>`

## Goal
One measurable outcome.

## Evidence / trigger
Exact user request, log, screenshot, test failure or planned dependency.

## Causal chain
`observation → evidence → root cause/dependency → minimal change → validation → exit gate`

## Required read
- ...

## Allowed write
- ...

## Forbidden write
- ...

## Implementation tasks
1. ...

## Validation
- ...

## Exit gate
- ...

## Changed files
- ...

## Result / proof
- command, test, artifact, hash

## Next cycle
`NNNN`
