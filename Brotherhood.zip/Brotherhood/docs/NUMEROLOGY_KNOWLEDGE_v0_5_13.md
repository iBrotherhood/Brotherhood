# Numerology knowledge integration — Brotherhood v0.5.13

## Source and permission basis
Source supplied by the user: `Numerology-main.zip`.

SHA-256: `668a114194c0baa3792bee2be0be845aad74a353c239083b07c7fb2007623c9b`

The user explicitly stated that permission has been obtained for all supplied archives. Brotherhood does not import the reference React Native runtime, images, fonts, package dependencies or application identity. Only the requested numerology data/logic is independently represented in Brotherhood.

## Full source inventory preserved

| Source group | Records | Runtime use |
|---|---:|---|
| SoulNumberData | 11 | optional descriptive name Soul Number |
| LifePathNumber | 11 | date-derived Life Path, five sections each |
| BirthChartData | 52 | date digit matrix + isolated/missing cases |
| PyramidPeakData | 11 | date-derived four Pinnacle interpretations |
| OuterNumberData | 12 | optional descriptive name Expression Number |

Exact source snapshot: `shared/numerology/source_vietnamese_v1.json`.
Machine provenance: `shared/numerology/provenance_v1.json`.
APK asset: `android/app/src/main/assets/numerology/numerology_knowledge_v1.json`.

## Localization contract
Every supplied source key has a non-empty runtime record in all three Brotherhood locales:
- Russian (`ru`);
- Ukrainian (`uk`);
- English (`en`).

The runtime copy is a semantic normalization of the supplied Vietnamese material. It preserves the source record/configuration coverage and the intended characteristic category, but is not labelled as a certified literal translation. The exact supplied text remains available in the provenance snapshot for later editorial refinement without loss of source information.

## Date-linked calculation
Numerology is **not a test and has no questionnaire**. The user does not answer numerology questions. `NumerologyReadingEngine` derives:
1. reference Life Path from the date;
2. birth-chart digit counts and the matching supplied repeated-digit keys;
3. supplied isolated/missing configurations;
4. four Pyramid/Pinnacle numbers and their displayed ages;
5. the existing canonical Brotherhood Vedic date profile.

Optional Latin-name Soul/Expression calculations are exposed only for self-description. The canonical bank of 100 tests / 600 questions remains exclusively psychological/behavioral and is separate from numerology.

## Compatibility invariant
No production weight changed.

- Vedic Numerology remains **5%** of total Brotherhood friendship compatibility.
- Its internal compatibility remains `40% soul + 35% destiny + 15% cross + 10% dateComposite`.
- Friendship compatibility consumes dates, not names.
- Name-derived fields are not Trust, Compatibility or Account Completeness inputs.

## Runtime characteristics
The localized knowledge asset is packaged inside the APK. Reading it requires no external API call, OAuth credential or production server. This keeps self-analysis available offline while leaving existing backend and identity architecture untouched.
