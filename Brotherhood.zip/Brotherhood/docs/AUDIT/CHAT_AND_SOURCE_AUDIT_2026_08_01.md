# Аудит переписки и текущего source Brotherhood

Дата: 2026-08-01
HEAD: `v0.5.21 / versionCode 26`

## 1. Главная процессная ошибка

В предыдущих отчётах я несколько раз использовал слово «реализовано», когда фактически существовал только код или документ, но не было APK/runtime evidence. Пользователь видел зелёный APK `v0.5.19`; обсуждённые positive results, новая language carousel и UX-изменения были добавлены позже в `v0.5.20`, который не скомпилировался из-за отсутствующего `TextAlign`. `v0.5.21` исправляет source, но ещё не был принят на устройстве.

Следовательно:

- `есть в source` ≠ `видно пользователю`;
- `есть API route` ≠ `развёрнут backend`;
- `есть migration` ≠ `проверен PostgreSQL`;
- `есть crypto code` ≠ `E2EE production-ready`;
- `есть workflow` ≠ `работает обновление APK`.

## 2. Что пользователь реально видел

По предоставленным скриншотам APK содержал старый UI без:

- видимого результата после теста;
- сильных сторон на Home/Profile;
- подтверждённой language carousel;
- нормального UX empty states;
- исправленных People chips;
- работающего update/backend контура.

Это подтверждает, что обсуждённый UX ещё не был принят как пользовательская реализация.

## 3. Аудит требований и фактического состояния

| Область | Обсуждённый результат | Фактическое состояние v0.5.21 | Чего ещё нет |
|---|---|---|---|
| Бренд/навигация | Brotherhood, 5 вкладок, чёрный/золотой, master logo | IMPLEMENTED/VISIBLE в старом APK | Финальная optical/device приёмка после нового milestone APK |
| 100×6 тестов | 100 скрытых visual tests, 600 tasks | IMPLEMENTED_IN_SOURCE, тесты/каталоги есть | Реальная device UX, эмпирическая валидность, cohort evidence |
| Positive results | После каждого теста сильные стороны, польза, progress, next action | IMPLEMENTED_IN_SOURCE (`PositiveProfileProjector`, result UI) | Пользователь ещё не видел; server history/live sync не квалифицированы |
| Retake | Повтор не добавляет ещё 0.5% | IMPLEMENTED_IN_SOURCE/TESTED_LOCALLY | Live persistence/idempotency с PostgreSQL |
| Home/Profile/Self-analysis | Видимые качества и история | IMPLEMENTED_IN_SOURCE | Milestone APK и реальное device подтверждение |
| Языковая карусель | Горизонтальный data-driven список, будущие языки | IMPLEMENTED_IN_SOURCE для RU/UK/EN | Device confirmation; ни один новый язык кроме RU/UK/EN не создан; RTL только fixture/architecture |
| Whole-app i18n | Все экраны/тесты/results/numerology | 748 keys × RU/UK/EN в assets | Device sweep, accessibility, отсутствие runtime gaps |
| Quick Discovery | 1 кандидат, skip/undo/details/request, filters, Passport | PARTIAL; UI/engine/demo/backend code | Реальные users, auth, request lifecycle, PostgreSQL E2E |
| Quality Fit | Роль + качества задаёт пользователь; отдельный score | PARTIAL; engine, DTO, ranking paths и UI есть | Live ranking на реальных private profiles, outcome validation, user acceptance |
| Compatibility | 15 layers, base/personalized totals, Vedic 5%, Trust отдельно | IMPLEMENTED_IN_SOURCE | Реальные данные обоих пользователей и full device/backend acceptance |
| Trust | Жалобы private; только confirmed incident влияет; appeals | PARTIAL; basic routes/models/UI | Полный moderator workflow, appeal, roles, audit log, adversarial tests |
| Profile/global_id | Один owner `global_id`, provider IDs только login | Architecture/source present | Production provider adapters, migration/live ownership proof |
| Backend | FastAPI routes, storage repository | IMPLEMENTED_IN_SOURCE | Deployment, real URL, secrets, production health, live integration |
| PostgreSQL | 0001–0007 migrations and repository paths | IMPLEMENTED_IN_SOURCE | Реальное применение migrations, constraints/RLS/concurrency/backup proof |
| Auth | Google/Telegram/Facebook/email/passkey architecture | SKELETON/PARTIAL | Реальные credentials, provider verification, session lifecycle E2E |
| Direct chat | UI/API, receipts, reply, reactions, edit/delete, offline queue | IMPLEMENTED_IN_SOURCE/PARTIAL | Live server/auth/device proof; delivery reliability; real users |
| E2EE | Custom P-256/HKDF/AES-GCM/TOFU code | SOURCE_IMPLEMENTED_NOT_QUALIFIED | Independent crypto audit, multi-device, recovery, revocation, metadata review |
| Group chat | Basic API/UI/member management | SOURCE/PARTIAL | Real backend, moderation, scale, media production storage |
| Media | Inline attachments | PARTIAL | Object storage, chunk/resume, large files/video, quotas, malware/content controls |
| Push | Token registration hook | PARTIAL | Firebase credentials and closed-app delivery |
| Communities | Demo/basic API/UI | PARTIAL | Full create/join/roles/discovery/business/mutual-aid workflows and E2E |
| Controlled pilot | Consent, invite hash, quotas, purge, scripts | ARCHITECTURE_ONLY | Real DB, invitations, 6-person wave, 18-person cohort, evidence |
| Calibration | Reports/scripts/export | TOOLING_ONLY | Real data, entropy/locale/retest results, manual approvals, versioned revision |
| APK workflow | Universal version-independent workflow | IMPLEMENTED_IN_SOURCE | Exact milestone PASS for v0.5.21; stable signing not configured |
| Updates | Install over previous APK | NOT_DONE in current debug mode | Permanent Development keystore/secrets; same cert continuity |
| Security warning | Avoid misleading promise | Correctly documented as uncontrollable by workflow | Store reputation/Play distribution; cannot be guaranteed away |
| Production | AAB/store/production signing/ops | NOT_DONE | Production topology, audit, privacy, monitoring, RC/release |
| AI ecosystem | KERNEL/AI/MEMORY/HANDOFF/GUARDS | IMPLEMENTED | Старый cycle plan был раздут; исправлен этим аудитом |

## 4. Что было заявлено слишком рано

1. Positive results и language carousel были описаны как готовые, хотя пользователь не получил APK с ними.
2. 12-language fixture был подан почти как реализация будущих языков; фактически активны только RU/UK/EN.
3. Backend/chat/E2EE/community функции в отчётах звучали как готовый продукт, хотя значительная часть остаётся source/demo без live infrastructure.
4. Был ошибочно создан roadmap на 100 мелких циклов и заявлено, что осталось только два необходимых этапа.
5. APK/CI стали запускаться слишком часто после отдельных исправлений вместо milestone cadence.

## 5. Исправленный критерий готовности

Функция может получить один из статусов:

- `SOURCE_ONLY` — код существует;
- `LOCAL_PASS` — локальные тесты подтверждают;
- `APK_VISIBLE` — функция видна в milestone APK;
- `LIVE_E2E` — работает Android↔backend↔PostgreSQL;
- `PRODUCTION_QUALIFIED` — security/reliability/deployment gates пройдены.

Слово «готово» без указания уровня запрещено.

## 6. Итог аудита

Проект не закончен. Из 10 крупных циклов завершён фундаментальный цикл 0001. Активен цикл 0002. До production после него остаётся 8 крупных циклов. Это компактный план, а не 98 искусственных задач.
