# Brotherhood Chat Core v0.5.8

## Personal chats

Personal `direct` conversations use **Brotherhood Private Chat E2EE v1** by default.

- EC P-256 identity key + signed prekey are generated on Android.
- Private keys never leave the phone and are wrapped by Android Keystore.
- The sender verifies the signed peer prekey.
- Peer identity keys are pinned with TOFU after the first successful contact; later silent server-side identity replacement is rejected.
- First contact establishes a shared secret with ephemeral ECDH.
- HKDF-SHA256 derives independent directional hash-ratchet chains.
- Every outgoing message uses a fresh ratchet-derived key and AES-256-GCM.
- Photos, audio, video and files use attachment keys derived from that message key.
- Vercel/Neon receive ciphertext, nonce and routing metadata, not personal-chat plaintext.
- The UI exposes both local and peer identity fingerprints for out-of-band comparison.

This protocol uses standard cryptographic primitives but is new application protocol code. It **must not be described as cryptographically equivalent to Telegram Secret Chats or Signal** until independent cryptographic/protocol review is completed.

Current E2EE operational scope is one active/preferred recipient device per session. Public key storage already supports multiple devices, but multi-device fan-out, key backup/recovery and independent security audit remain hardening work before a production-grade cryptographic claim.

## Chat interaction model

Implemented chat interaction contracts:

- real direct and group conversation lists;
- replies to messages;
- reactions;
- typing indicator with server expiry;
- delivered/read receipts per user;
- editing;
- sender deletion;
- offline outbox + retry;
- local cache;
- photo/audio/video/file attachments;
- system audio-recorder handoff for voice notes without broad storage access;
- E2EE attachment encryption for direct chats;
- server-side encrypted attachments for groups;
- block/unblock for direct peers;
- private report submission into the moderated trust-incident workflow;
- group-owner member add/remove management.

### E2EE editing

An E2EE edit is **not** an in-place replacement of old ciphertext. It is appended as a new chronological encrypted `edit` event whose `reply_to_message_id` points to the original message. Android decrypts the event in ratchet order and folds it into the visible original message. This avoids placing a new high ratchet counter at an old timestamp.

### E2EE deletion

Deletion creates a UI tombstone. For an E2EE record the server keeps the opaque envelope/counter required for ratchet traversal but removes attachments/reactions and never renders the deleted content in Android. Group plaintext ciphertext is cleared on deletion. A future audited protocol can define stronger cryptographic erasure semantics.

## Group chats

Groups are explicitly **not secret chats**.

- Messages and media travel over HTTPS.
- Vercel may access group plaintext transiently for moderation.
- Group body/media are encrypted at rest before Neon storage using the server message key.
- Replies, reactions, editing, typing and read/delivery receipts use the same interaction API.

## Media

Android uses system pickers. Existing audio can be attached directly. Voice recording delegates to the device's system recorder, so Brotherhood itself does not need permanent microphone access for this flow.

Current inline backend cap is 4 MiB per attachment. The message/attachment model is separated so large encrypted media can later be moved to object storage without changing conversation semantics.

## Realtime / background delivery

- Active chat uses short polling every 4 seconds.
- Offline send uses a local SQLite outbox with retry.
- `/v1/push/token` stores FCM device tokens encrypted at rest when `PUSH_TOKEN_ENCRYPTION_KEY` is configured.
- Actual notification sending is intentionally disabled until external Firebase sender credentials are supplied.

True instant delivery while the app is fully closed requires a configured push provider (FCM on Android). The application can contain the integration point, but real push cannot be activated without a Firebase project / sender credentials. Vercel is not treated as a permanent WebSocket host.
