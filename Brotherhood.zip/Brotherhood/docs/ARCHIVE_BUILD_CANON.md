# Универсальный канон сборки APK

## 1. Единственный вход GitHub CI

В корне репозитория находится только канонический вход:

```text
Brotherhood.zip
.github/workflows/android-build.yml
```

`Brotherhood.zip` побайтно идентичен соответствующему versioned source archive.

## 2. Постоянный workflow

`.github/workflows/android-build.yml` создаётся и утверждается один раз. После freeze он не изменяется при повышении `versionName` или `versionCode`.

Workflow:

1. проверяет целостность `Brotherhood.zip`;
2. распаковывает единственную верхнюю директорию `Brotherhood/`;
3. находит Gradle project;
4. запускает `testDebugUnitTest`, `compileDebugKotlin`, `assembleDebug`;
5. проверяет APK v2 signature;
6. извлекает фактические metadata из Gradle и APK;
7. проверяет фиксированные инварианты `applicationId`, `minSdk`, `targetSdk`;
8. динамически формирует имя APK/artifact из фактической версии;
9. публикует artifact;
10. выводит `ANDROID_CI_APK_ARTIFACT_PASS`.

Запрещены `EXPECTED_VERSION_NAME`, `EXPECTED_VERSION_CODE` и ручное изменение YAML на каждом релизе.

## 3. Ограничения

Workflow не устраняет предупреждения AVG, Play Protect, Unknown Sources или отсутствие update continuity при смене сертификата. В `NON_CANONICAL_DEBUG` допускается только WARN по continuity; metadata остаются fail-closed.

## 4. Обновление архива

```bash
python scripts/package_source_archive.py --write Brotherhood.zip
python scripts/package_source_archive.py --check Brotherhood.zip
sha256sum Brotherhood.zip > Brotherhood.zip.sha256
```
