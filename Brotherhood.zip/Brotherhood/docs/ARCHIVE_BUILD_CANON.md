# Двойной канон сборки APK

## 1. Главный источник

Главный канонический источник проекта — распакованный код в GitHub:

```text
android/
backend/
database/
docs/
scripts/
.github/workflows/
```

## 2. Текущая тестовая сборка из архива

В корне GitHub лежит:

```text
Brotherhood.zip
.github/workflows/android-build.yml
```

Внешний workflow `android-build.yml` доступен GitHub до распаковки. Он:

1. проверяет `Brotherhood.zip`;
2. распаковывает архив во временную папку;
3. находит `android/settings.gradle(.kts)`;
4. запускает `testDebugUnitTest` и `assembleDebug`;
5. публикует APK как GitHub Artifact.

## 3. Workflow внутри Brotherhood.zip

Сам `Brotherhood.zip` содержит:

```text
.github/workflows/android-source-build.yml
```

После распаковки архива в GitHub этот workflow собирает APK напрямую из:

```text
android/
```

Он запускается вручную через `Actions → Build Brotherhood APK from unpacked source → Run workflow`.

## 4. Почему нужны два workflow

- GitHub не видит workflow, лежащий только внутри ZIP, пока ZIP не распакован и его содержимое не закоммичено.
- Поэтому для текущей сборки из `Brotherhood.zip` внешний `android-build.yml` обязан лежать вне архива.
- Внутренний `android-source-build.yml` нужен для будущего режима, когда код уже распакован в репозитории.

## 5. Синхронизация архива

После изменения канонического распакованного кода:

```bash
python scripts/package_source_archive.py --write Brotherhood.zip
python scripts/package_source_archive.py --check Brotherhood.zip
sha256sum Brotherhood.zip > Brotherhood.zip.sha256
```

`Brotherhood.zip` включает внутренний source-workflow, но не включает внешний zip-workflow, чтобы после распаковки не возникала зависимость от вложенного архива.
