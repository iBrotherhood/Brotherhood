# Brotherhood project canon v0.5.13

## Identity and version
- `applicationId = org.federationofavatars.brotherhood`
- `versionName = 0.5.13`
- `versionCode = 18`
- canonical owner identifier: `global_id`, display format `0000000001`

## Product scope
Brotherhood is for platonic male friendship 18+, not dating. Trust, Compatibility and Account Completeness remain mathematically separate.

## Compatibility
The weighted production model remains unchanged at 100%:

| Layer | Weight |
|---|---:|
| psychological/behavioral friendship tests | 18% |
| character | 10% |
| values | 10% |
| friendship goals | 9% |
| interests | 8% |
| lifestyle | 7% |
| communication | 7% |
| conflict/repair | 7% |
| Brotherhood-32 | 7% |
| Vedic numerology | **5%** |
| Enneagram | 4% |
| zodiac | 3% |
| geography | 2% |
| business/mutual aid | 2% |
| social format | 1% |

`Friendship Expectations` remains a shadow diagnostic from `f065` and `f071–f080`; it has no production percentage and does not alter the 100% model.

## Vedic friendship compatibility — locked
Friendship compatibility uses only two dates of birth:
- soul: 40%;
- destiny: 35%;
- cross: 15%;
- date composite: 10%.

Name-derived numbers are descriptive self-analysis fields only. They do not enter friendship compatibility. Overall Vedic Numerology weight remains exactly **5%**.

## Numerology self-analysis knowledge v1
The complete set of records available in the user-supplied `Numerology-main.zip` is preserved and connected to the Android self-analysis module:
- Soul Number: 11 records;
- Life Path: 11 records, each with five characteristic sections;
- Birth Chart: 52 records/configurations;
- Pyramid/Pinnacle: 11 records;
- Outer/Expression Number: 12 records.

Exact supplied Vietnamese source content is preserved in `shared/numerology/source_vietnamese_v1.json` for provenance. APK runtime uses `android/app/src/main/assets/numerology/numerology_knowledge_v1.json`, normalized semantically for RU/UK/EN with one runtime entry for every supplied source key. The localized text is not represented as a certified/verbatim translation.

Date-derived runtime mapping follows the supplied reference logic:
- Life Path: sum birth-date digits and reduce while preserving `10`, `11`, `22`;
- Birth Chart: count digits `1..9`, ignoring zero, then select the supplied repeated-digit characteristic key;
- isolated/missing keys: `1CL`, `3CL`, `7CL`, `9CL`, `Not7`, `Not9` according to the supplied chart relationships;
- four Pinnacles: month/day/year roots, supplied top-number reductions, first displayed age `36 - Life Path`, then `+9` years;
- optional name Soul/Expression: supplied Pythagorean A–Z mapping; descriptive only.

## Assessments, Trust and profile
The v0.5.12 assessment/outcome/avatar behavior remains unchanged: exactly 100 psychological/behavioral friendship tests / 600 questions. Numerology, Zodiac, Brotherhood-32 and Enneagram are separate derived/profile systems and do not add tests to that 100-test bank. Trust remains separated from Compatibility, Account Completeness remains separated from both, and avatar stays bounded to the existing security limits.

## Branding / Android security
No change to the master logo, application ID, permission canon, Production signing or signing secrets. No broad media/storage permission and no `REQUEST_INSTALL_PACKAGES` are introduced.
