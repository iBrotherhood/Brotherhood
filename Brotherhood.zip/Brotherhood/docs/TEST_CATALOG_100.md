# Brotherhood 100×6 hidden visual assessment registry

Status: INTERNAL. This is not a user-facing catalogue of traits.

- Exactly 100 psychological/behavioral blocks.
- Exactly 6 indirect visual/associative tasks per block = 600 tasks.
- Active model: `visual-latent-v2`.
- Numerology is not a test and is absent from this registry.
- A block is a coverage stratum, not a claim that the user is being directly tested for one named quality.
- Every task cross-loads multiple hidden coordinates; coordinates recur across distant blocks.
- No `critical`, `bad`, `dangerous`, `high-is-good` or moral-failure flag exists in this registry.
- UI displays only neutral “Visual series #N”; internal stratum/traits are never shown during assessment.
- Each selected response records a private `visual-latent-v2` item trace for calibration; that trace is internal-only and never part of the public profile/API.
- Scene/stimulus provenance is versioned (`scene-library-v4`) so empirical calibration cannot silently mix incompatible stimulus generations.

## Coverage strata

| Blocks | Internal coverage stratum | Example latent families | Publicly disclosed during test |
|---|---|---|:---:|
| `f001`–`f010` | `relational_continuity` | continuity / reciprocity / privacy / autonomy | NO |
| `f011`–`f020` | `principles_and_strategy` | principles / fairness / rule orientation / pragmatism | NO |
| `f021`–`f030` | `execution_reliability` | planning / perseverance / time / adaptation | NO |
| `f031`–`f040` | `conflict_and_repair` | conflict engagement / repair / tact / self-control | NO |
| `f041`–`f050` | `boundaries_and_closeness` | autonomy / boundaries / confidentiality / openness | NO |
| `f051`–`f060` | `support_style` | support / empathy / reciprocity / resource style | NO |
| `f061`–`f070` | `status_and_competition` | competition / leadership / status / cooperation | NO |
| `f071`–`f080` | `communication_rhythm` | contact / response pace / directness / humour / ambiguity | NO |
| `f081`–`f090` | `business_and_mutual_aid` | money / initiative / risk / planning / fairness / innovation | NO |
| `f091`–`f100` | `lifestyle_and_change` | spontaneity / family / social rhythm / curiosity / adaptation | NO |

## Block registry

| Block | Tasks | Model | Internal/public boundary |
|---|---:|---|---|
| `f001` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f002` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f003` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f004` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f005` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f006` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f007` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f008` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f009` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f010` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f011` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f012` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f013` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f014` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f015` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f016` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f017` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f018` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f019` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f020` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f021` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f022` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f023` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f024` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f025` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f026` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f027` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f028` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f029` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f030` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f031` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f032` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f033` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f034` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f035` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f036` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f037` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f038` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f039` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f040` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f041` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f042` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f043` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f044` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f045` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f046` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f047` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f048` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f049` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f050` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f051` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f052` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f053` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f054` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f055` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f056` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f057` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f058` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f059` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f060` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f061` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f062` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f063` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f064` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f065` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f066` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f067` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f068` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f069` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f070` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f071` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f072` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f073` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f074` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f075` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f076` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f077` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f078` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f079` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f080` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f081` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f082` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f083` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f084` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f085` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f086` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f087` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f088` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f089` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f090` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f091` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f092` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f093` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f094` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f095` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f096` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f097` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f098` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f099` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |
| `f100` | 6 | `visual-latent-v2` | hidden multidimensional evidence; public result positive/contextual only |

Detailed invariants: `docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md`.
Causal/forbidden edges: `docs/AI/CAUSAL_RELATIONSHIP_KERNEL.md`.
