# Kernel enforcement matrix

| Rule | Type | Trigger | Route | Blocking | Evidence | Failure |
|---|---|---|---|---|---|---|
| Read START_HERE/KERNEL | instruction | session_start | all | yes | startup state | stop edits |
| Resolve route before edit | hook | pre_edit | all | yes | resolver result | deny out-of-scope edit |
| Preserve compatibility canon | test | pre_pack | compatibility/numerology | yes | unit/architecture test | block package |
| 100×6 remains indirect visual/associative | test | pre_pack | psychological_visual_matching | yes | architecture + Kotlin smoke | block package |
| No direct socially desirable trait questions | test | post_edit/pre_pack | psychological_visual_matching | yes | phrase/structure regression | block package |
| User chooses qualities; role injects none | test | post_edit/pre_pack | psychological_visual_matching | yes | empty-default + Quality Fit regression | block package |
| Raw latent/diagnostics never enter public API/UI | test | post_edit/pre_pack | psychological_visual_matching/backend_api | yes | API/UI privacy regression | block package |
| No public negative psychological/risk projection | test | post_edit/pre_pack | psychological_visual_matching | yes | UI/OpenAPI regression | block package |
| Legacy direct results cannot feed visual-latent-v2 | test | pre_pack | psychological_visual_matching | yes | migration/quarantine regression | block package |
| Outcome analytics cannot mutate production automatically | instruction+test | analysis/pre_pack | psychological_visual_matching | yes | causal kernel + analysis script regression | block package |
| Keep routes config runtime-primary | test | pre_pack | kernel | yes | architecture test | block package |
| Refresh file map | hook | pre_pack | release | yes | cache count/digest | block package |
| Independent verification | skill+test | release | release | yes | verifier report | block package |
