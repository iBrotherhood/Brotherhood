# Brotherhood keywords and anchors

| Keyword / trigger | Query class | Route | Where fixed | Must read | Allowed write | Forbidden write | Validation |
|---|---|---|---|---|---|---|---|
| психологические тесты / визуальные тесты / картинки / ассоциации / качества / Quality Fit / скрытый профиль | implementation | psychological_visual_matching | `docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md` + causal kernel | psychological canon, causal kernel, assessment/quality-fit source | scoped assessment/matching/UI/backend/tests/docs | Compatibility weights, Trust, signing/brand | 100×6, privacy, separation, legacy quarantine |
| нумерология / numerology / дата рождения / birth chart / life path / pyramid | implementation | numerology_self_analysis | `docs/CANON/BROTHERHOOD_PRODUCT_CANON.md` | Vedic engine, numerology assets/UI | numerology domain, related UI/software-validation/docs | compatibility weights, Trust | core tests, asset/schema tests |
| compatibility / совместимость / веса | implementation | compatibility_model | `docs/PROJECT_CANON_v0_5_15.md` + CANON | compatibility engines/docs | scoped compatibility files | Trust/Completeness | weight/regression tests |
| Android / Compose / UI / UX / экран | implementation | android_ui_feature | UI/product canon | target composables/ViewModel | Android UI/tests | signing/CI unless task requires | Kotlin/static/GitHub CI |
| CI / GitHub Actions / APK / apksigner / aapt | diagnostics | ci_android | CI workflow + signing docs | workflow/logs | workflow only if proven | Android source after BUILD SUCCESSFUL | YAML/bash/parser regression |
| backend / API / FastAPI | implementation | backend_api | architecture/auth boundaries | exact backend files | backend/tests/docs | Android/DB outside need | pytest/OpenAPI |
| database / PostgreSQL / migration | implementation | database | schema/migration NORM | schema/migrations | DB scoped | unrelated runtime | migration/static/DB gate |
| auth / session / OAuth / global_id / provider | implementation | auth_security | auth boundary + product canon | auth source/contracts | auth scoped | owner-ID drift | auth/security tests |
| release / archive / zip / version | packaging | release_packaging | archive build canon | package script/manifest | metadata/reports/package | business canon | CRC/parity/hash |
| kernel / route / START_HERE | architecture | kernel_archive | KERNEL + master prompt | operator files | kernel/tooling/tests | product runtime | architecture tests |
| historical / reference / sandbox | research | historical_reference | historical docs | requested reference only | reports | active truth | provenance check |

Canonical spellings: `Quality Fit`, `SearchIntent`, `visual-latent-v2`, `Brotherhood`, `global_id`, `Trust Score`, `Compatibility`, `Account Completeness`, `Brotherhood-32`, `Enneagram`, `Vedic numerology`, `NON_CANONICAL_DEBUG`. Forbidden drift includes dating-app framing, provider-ID ownership and name-based Vedic friendship score.
