# AI next actions

1. Keep cycle 0003 at `LOCAL_PASS` until a real backend/PostgreSQL/provider environment exists.
2. Deploy exact `v0.5.23`, set server secrets/config, apply migrations through `0008`, then run live auth/session/settings E2E.
3. Configure GitHub secret `BROTHERHOOD_API_BASE_URL` to the real HTTPS backend; universal workflow already consumes it and must not be edited.
4. Configure Google Client ID, Telegram Client ID/Secret + HTTPS callback, email delivery and passkey RP origin/Digital Asset Links.
5. Independently complete cycle-0002 APK/device checkpoint when the user supplies GitHub build evidence/screenshots.
6. Do not activate cycle 0004 automatically before cycle-0003 LIVE_E2E unless explicitly instructed by the user.
