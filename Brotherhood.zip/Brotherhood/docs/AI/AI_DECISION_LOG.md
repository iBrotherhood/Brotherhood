# AI decision log

| ID | Date | Decision | Reason | Consequence |
|---|---|---|---|---|
| D-0001 | 2026-08-01 | Establish cycles 0001–0100 starting from current governance restoration rather than inventing historical cycle mappings. | Earlier releases did not use a reliable canonical cycle number. | No false reconstruction of past work; future sequence is stable. |
| D-0002 | 2026-08-01 | Keep app metadata at v0.5.20/versionCode 25 for cycle 0001. | Documentation-only correction; no runtime change. | Archive hash changes, APK metadata does not. |
| D-0003 | 2026-08-01 | Assign TextAlign source correction to cycle 0002. | Proven by GitHub run 83283873357. | Frozen universal workflow remains unchanged. |
| D-0004 | 2026-08-01 | Treat `docs/CYCLES/BROTHERHOOD_CYCLES_0001_0100.md` as canonical roadmap and `CYCLE_STATUS_REGISTRY.md` as operational status. | Separates stable numbering from fast-changing state. | Kernel startup must read both. |
| D-0005 | 2026-08-01 | Treat 0001–0100 as reserved capacity, not mandatory work. | User prohibited cycles for cycles. | Only evidence-based ACTIVE/NEXT cycles count as remaining work. |
| D-0006 | 2026-08-01 | Keep universal workflow byte-identical in cycle 0002. | Failure is a proven Kotlin import defect. | Future run replaces only Brotherhood.zip. |


## 2026-08-01 — compact roadmap and milestone-build policy
Decision: only cycles 0001–0010 are assigned. 0011–0100 are unused reserve. Microfix cycles are superseded as planning units. Android APK is built only at declared checkpoints, not after every source/archive change.
Reason: user explicitly requires the full plan in cycles without artificial expansion and reports that discussed features were never visible in a real APK.
| D-0007 | 2026-08-08 | Treat APK Source Map v002 as research-only donor evidence, never as current Brotherhood SSOT. | Its embedded `project_ssot` describes an older NON_CANONICAL_DEBUG APK. | Current truth remains START_HERE/KERNEL/CANON/SSOT/source; no foreign architecture is transplanted. |
| D-0008 | 2026-08-08 | Bump source milestone to `v0.5.22 / versionCode 27`. | Cycle 0002 changes user-visible runtime UX/i18n behavior, not documentation only. | GitHub workflow reads metadata dynamically; YAML remains unchanged. |
| D-0009 | 2026-08-08 | Keep cycle 0002 ACTIVE after source milestone. | Exit gate still requires GitHub Kotlin/APK PASS and real-device screenshots. | Feature source contracts may be `LOCAL_PASS`, but none is promoted to `APK_VISIBLE`. |



## 2026-08-08 — cycle 0003 decisions
- `v0.5.23 / versionCode 28` bump is justified by runtime/API/database/Android auth changes.
- Google Client ID is public runtime configuration delivered by Brotherhood backend; workflow is not modified.
- Telegram OIDC uses HTTPS backend callback + device-bound one-time app ticket instead of assuming BotFather accepts a custom-scheme OIDC redirect.
- Verified-email identity linking is allowed only from server-verified evidence, serialized with transaction advisory locks; ambiguous ownership becomes explicit recovery conflict.
- Passkey production remains gated by real RP origin and Digital Asset Links.
