# AI work notes

## 2026-08-01 — ecosystem restoration

- The v0.5.20 package already contained a substantial Operator Kernel ecosystem: CANON, SSOT, NORM, routes, capsules, hooks, agents, skills, healer guards and temporary memory.
- Missing critical element: canonical numbered cycles directory and 0001–0100 roadmap.
- User explicitly requires cycle-based planning and persistent AI work rules/notes.
- Decision: restore documentation/governance only; do not change runtime or version.
- Current CI evidence after v0.5.20: run `83283873357` fails on missing `TextAlign` import; this is assigned to cycle 0002.
- Universal workflow remains frozen and must not be edited for that source error.

## 2026-08-01 — cycle 0002 local implementation
- Added missing TextAlign import proven by run 83283873357.
- Universal workflow hash was preserved.
- Added import regression guard.
- Clarified that 0001–0100 are reserved slots, not 100 mandatory cycles.
- Current committed work is only active 0002 and conditional 0003.

## 2026-08-01 — full chat/source audit and compact cycle correction
- User rejected the 100-microcycle interpretation and per-fix APK cadence.
- Confirmed that v0.5.20 UX changes were source-only and never reached a successful user APK because compile failed; v0.5.21 has not yet passed milestone device acceptance.
- Replaced the over-segmented roadmap with 10 large cycles covering the entire path to production.
- Defined APK checkpoints only at cycles 0002, 0004, 0006, optional 0008 and final 0010.
- Added evidence-level vocabulary SOURCE_ONLY/LOCAL_PASS/APK_VISIBLE/LIVE_E2E/PRODUCTION_QUALIFIED.

## 2026-08-08 — cycle 0002 evidence audit and source milestone v0.5.22
- Exact baseline `Brotherhood_v0_5_21(1).zip` SHA-256 matched `9212a38098b1dc785d85f668677008cce0d509ea72c7d9cd89daf2e2e3be603e`.
- Startup ZIP audit: CRC/top-root/path traversal/symlink/nested-archive/cache/secrets checks passed; `.env.example` contained templates only.
- Operator Kernel routed the request through i18n/localization + Android UI + psychological results + cycle planning; `.github` remained outside write scope.
- Audit found real PARTIAL gaps on Home/Profile/Self-analysis, People CTA layout, Groups information hierarchy, unconditional manual-install notice and several localized runtime error fallbacks.
- Patched only those gaps and retained existing architecture, stores, matching models and navigation.
- Embedded supplied `APK_SOURCE_MAP_v002` under `docs/research/source_map/` as research-only evidence and documented its authority boundary.
- Runtime changes justify `v0.5.22 / versionCode 27`; workflow remains byte-identical.
- 78 architecture/targeted tests PASS; JSON/XML/YAML and cycle-ecosystem guards PASS.
- Local Gradle compile remains unproven because wrapper JAR download is blocked by the container network; GitHub checkpoint A is required.



## 2026-08-08 — cycle 0003 source milestone v0.5.23
- Operator Kernel route: auth_security + backend_api + database + android_ui_feature + cycle_planning.
- Replaced Android hardcoded runtime auth with encrypted session/refresh flow and restart `global_id` restoration.
- Added server-verified Google, Telegram OIDC/PKCE, email OTP and passkey flows; preserved old internal endpoints for compatibility.
- Universal workflow remained byte-identical.
- Local combined backend+architecture result: 139 PASS.
- `LIVE_E2E` not claimed: no real DB/deployment/provider credentials were available in this execution environment.
