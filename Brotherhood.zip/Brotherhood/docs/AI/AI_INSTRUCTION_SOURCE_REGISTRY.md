# AI instruction source registry

| Source | Scope | Status | Priority | Action |
|---|---|---|---|---|
| Current user instruction | current task | CANONICAL | 1 | obey |
| `START_HERE.md` | startup | ACTIVE_ADAPTER | 2 | load |
| `KERNEL.md` | project dispatch | CANONICAL | 3 | load |
| `docs/CANON/**` | stable project canon | CANONICAL | 4 | route-scoped |
| `docs/SSOT/**` | current state | CANONICAL | 5 | route-scoped |
| `docs/NORM/**` | mandatory rules | CANONICAL | 6 | route-scoped |
| historical reports/docs | reference | HISTORICAL | 20 | never override active truth |
| `docs/CYCLES/**` | numbered execution plan/status | CANONICAL_OPERATIONAL | 7 | load active/next cycle |
| `docs/MEMORY/**` | layered project memory | ACTIVE_ADAPTER | 8 | route-scoped |
