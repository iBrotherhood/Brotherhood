# Kernel memory governance

Layers: CANONICAL (`KERNEL`, CANON/SSOT/NORM/ADR), PROJECT_SHARED (verified reusable engineering facts), LOCAL_PRIVATE (machine-specific, never package secrets), OPERATIONAL_PENDING (active unresolved task only), HISTORICAL (closed reports/reference). Promote verified stable facts from pending to canonical/SSOT/NORM and remove duplicates from pending.
