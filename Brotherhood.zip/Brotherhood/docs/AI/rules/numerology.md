---
rule_id: numerology_self_analysis
paths: ["android/app/src/main/**/numerology/**", "android/app/src/main/assets/numerology/**", "shared/numerology/**"]
routes: ["numerology_self_analysis"]
---
Preserve 5% Vedic friendship compatibility and date-only compatibility. Reference/name-derived numerology is descriptive self-analysis only. Localize user-visible knowledge RU/UK/EN. Validate all source keys are represented.
