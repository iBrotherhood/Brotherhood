---
rule_id: operator_kernel
paths: ["START_HERE.md", "KERNEL.md", "docs/AI/**", "docs/CANON/**", "docs/SSOT/**", "docs/NORM/**", "docs/healer/**", "ops/operator_kernel/**", "tests/architecture/**"]
routes: ["kernel_archive"]
---
Keep Kernel dispatch-capable but compact. Runtime routes config is primary. Never require full archive reads.
