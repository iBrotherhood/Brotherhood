---
rule_id: android_feature
paths: ["android/**"]
routes: ["android_ui_feature"]
---
Preserve applicationId, minSdk/targetSdk, signing and permissions unless explicitly required. Use Compose patterns already in the app. Full Android qualification remains GitHub CI when local Gradle is unavailable.
