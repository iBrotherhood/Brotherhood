---
rule_id: release_packaging
paths: ["PROJECT_MANIFEST.json", "README*", "CHANGELOG.md", "scripts/package_source_archive.py", "reports/**"]
routes: ["release_packaging"]
---
Use sequential versioning for source changes. `Brotherhood.zip` == versioned source bytes. Canonical nested `Brotherhood/Brotherhood.zip` must match source bytes. Exclude secrets/cache/private keys.
