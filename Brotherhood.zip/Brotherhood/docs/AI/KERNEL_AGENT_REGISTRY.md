# Kernel agent registry

Contracts are machine-readable in `ops/operator_kernel/config/agents.yaml`. Roles: Explorer read-only; Planner read/report; Implementer scoped edit; Verifier read/test/diff only; Packager package/report only; Healer guard/report only. Verifier never fixes the implementation it verifies.
