# AI causal work graph

## Core chain
`user request/log/screenshot → route → active cycle → evidence → root cause/dependency → allowed write → validation → proof → status transition → next cycle`

## Required edges
- confirmed source error → source correction + regression;
- workflow-only defect → workflow correction without app version bump;
- product request → functional cycle + version bump;
- docs/governance gap → kernel/cycle correction without runtime change;
- live dependency unavailable → `DEFERRED_ENVIRONMENT`, not fabricated PASS.

## Forbidden edges
- green GitHub UI → production-ready claim;
- antivirus warning → permission/security bypass;
- role name → automatically imposed desired qualities;
- one visual answer → diagnosis;
- raw latent profile → public API;
- calibration correlation → automatic model mutation;
- missing cycle number → arbitrary reuse of a previous number;
- historical report → override of current CANON/SSOT.
