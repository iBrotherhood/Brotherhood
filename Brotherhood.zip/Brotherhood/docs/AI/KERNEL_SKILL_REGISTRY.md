# Kernel skill registry

Machine registry: `ops/operator_kernel/config/skills.yaml`. Safe audit/test/build/map/report skills may be model-or-user invoked. External side effects (deploy, publish, push, merge, production migration, messaging, DNS, on-chain) are `user_only`.
