# Brotherhood AI archive ecosystem index

## Startup
- `START_HERE.md`
- `KERNEL.md`
- `docs/CYCLES/CYCLE_STATUS_REGISTRY.md`
- active/next cycle file
- `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md`
- `reports/generated/SESSION_HANDOFF.md`

## Planning
- `docs/CYCLES/BROTHERHOOD_CYCLES_0001_0100.md`
- `docs/CYCLES/CYCLE_TEMPLATE.md`
- `docs/AI/AI_NEXT_ACTIONS.md`
- `docs/AI/AI_DECISION_LOG.md`

## Rules and dispatch
- `docs/AI/AI_WORK_RULES.md`
- `docs/AI/AI_CHANGE_PROTOCOL.md`
- `docs/AI/AI_INSTRUCTION_SOURCE_REGISTRY.md`
- `docs/AI/PROJECT_OPERATOR_KERNEL_ROUTE_MAP.md`
- `ops/operator_kernel/config/routes.yaml`
- `ops/operator_kernel/config/hooks.yaml`
- `ops/operator_kernel/config/agents.yaml`
- `ops/operator_kernel/config/skills.yaml`

## Stable truth
- `docs/CANON/**`
- `docs/SSOT/**`
- `docs/NORM/**`
- `docs/ADR/**`

## Memory
- `docs/MEMORY/CANONICAL_MEMORY.md`
- `docs/MEMORY/PROJECT_SHARED_MEMORY.md`
- `docs/MEMORY/OPERATIONAL_PENDING.md`
- `docs/MEMORY/HISTORICAL_MEMORY_INDEX.md`
- compatibility adapter: `docs/AI/AI_TEMPORARY_MEMORY_PENDING.md`

## Guards and healer
- `docs/GUARDS/README.md`
- `docs/healer/**`
- `ops/operator_kernel/check_cycle_ecosystem.py`
- `tests/architecture/test_cycle_ecosystem.py`

## Handoff and evidence
- `docs/HANDOFF/CURRENT_HANDOFF.md`
- `reports/generated/SESSION_HANDOFF.md`
- `reports/generated/INDEPENDENT_VERIFICATION_*.md`
- `reports/change_cycle_*.md`

## History
Completed reports and superseded facts are historical reference and never override active CANON/SSOT/cycle status.

## Research references
- `docs/research/source_map/APK_SOURCE_MAP_v002.md`
- `docs/research/source_map/APK_SOURCE_MAP_v002.json`
- `docs/research/source_map/BROTHERHOOD_SOURCE_MAP_USAGE_CYCLE_0002.md`

Research references are non-authoritative and never override current CANON/SSOT/source.



## Cycle 0003 source-map usage
`docs/research/source_map/BROTHERHOOD_SOURCE_MAP_USAGE_CYCLE_0003.md` records bounded donor/web-source usage. It is research evidence only and cannot override CANON/SSOT/NORM/source.
