# Brotherhood Causal Relationship Kernel

Status: ACTIVE OPERATOR ANCHOR
Purpose: prevent semantic drift between tests, hidden inference, user intent, Compatibility, Trust and public presentation.

## A. Primary search causal chain

```text
USER
  -> selects role/context
  -> selects desired qualities + optional importance
  -> SearchIntent

QUALITY CATALOG
  -> simple quality: one target coordinate
  OR
  -> composite quality: several target coordinates + internal weights
  -> versioned QualityDefinition

CANDIDATE
  -> completes indirect visual/associative tasks
  -> choices
  -> hidden multi-trait loadings
  -> distributed evidence
  -> private LatentProfile + confidence

SearchIntent + QualityDefinition + candidate LatentProfile
  -> per-target coordinate distances
  -> per-quality simple/composite fit
  -> user-importance-weighted Quality Fit
  -> ranking for THIS user's request
  -> public positive matched-quality labels
```

Role does not inject target qualities. The user-authored quality list is the target.

## B. Visual inference causal chain

```text
visual/associative task
  -> user chooses an intuitively closer composition
  -> choice contributes small hidden loadings to multiple coordinates
  -> the same coordinate is sampled again in distant/different tasks
  -> aggregation + internal consistency/confidence
  -> private latent coordinate
```

One choice is weak evidence. Repeated distributed evidence is the model input.

## C. Public projection chain

```text
private latent profile
  -> context-neutral positive pole mapping
  -> strongest supported positive resources
  -> public strengths
```

The public layer never emits raw latent scores, negative labels or “bad person” classifications.

## D. Canonical Compatibility chain — separate system

```text
15 canonical layers
  -> fixed base weights totaling 100%
  -> baseTotal
  -> existing user-goal personalization rules (where already canonical)
  -> personalizedTotal
```

Quality Fit is NOT a 16th compatibility layer and does not change these weights.

## E. Numerology chain — separate system

```text
birth date A + birth date B
  -> soul/destiny/cross/dateComposite
  -> Vedic friendship compatibility
  -> 5% canonical Compatibility layer
```

Name-derived number -> descriptive self-analysis only.
There is NO edge: `name number -> friendship compatibility`.
Numerology is NOT part of 100/600 psychological tests.

## F. Trust chain — separate system

```text
verified interactions + confirmed moderation incidents
  -> Trust Score
```

Complaint alone -> private moderation record.
There is NO edge: `raw complaint -> public reputation penalty`.

## G. Account Completeness chain — separate system

```text
unique completed current-model tests -> up to 50%
completed profile sections -> up to 50%
```

There is NO edge: `Account Completeness -> personality quality`.

## H. Outcome-calibration chain

```text
user-authored role/context + desired qualities + importance
  -> frozen SearchIntent snapshot at connection time
private visual-latent-v2 candidate profile
  -> frozen Quality Fit score + confidence + quality model version
connection
  -> only pre-match calibration attempts are eligible for outcome analysis
  -> controlled 30d/90d outcome + message-count observation
  -> offline observational validation / calibration report
  -> reviewed proposal
  -> explicit versioned model change only if approved
```

This makes `request -> measured fit -> later outcome` testable while preserving the distinction between association and causation. There is NO edge: `outcome regression -> automatic production reweighting`. Outcome data is internal analytics and never a public reputation source.


## I. Calibration-consent causal chain

```text
user explicitly opts in
  -> versioned calibration consent + cohort
  -> future visual item traces may be retained in separate private calibration storage
  -> aggregate personality profile remains in normal profile storage

user does not opt in
  -> aggregate profile may still operate normally
  -> raw item-level calibration trace is not retained server-side

user withdraws
  -> retained raw calibration attempts for that user are deleted
  -> aggregate profile remains available for normal Brotherhood functionality
```

Calibration consent changes research-data retention only. It does not change matching scores, Compatibility, Trust, Account Completeness or public profile content.

## J. Localization causal chain

```text
user selects locale in carousel
  -> AppLanguage.tag + direction
  -> complete locale pack validation
  -> whole-app UI/domain presentation
  -> Quality Fit labels / assessment instructions / self-analysis / numerology / status text
  -> built-in city/demo labels use locale-specific presentation while stable search/storage values remain unchanged
```

Language changes presentation, not hidden scoring semantics. A locale with incomplete required keys or numerology coverage is not activated. There is NO edge: `locale -> different latent scoring`.

## K. Forbidden causal edges

1. `low/high latent value -> bad person` — FORBIDDEN.
2. `single visual choice -> diagnosis/moral conclusion` — FORBIDDEN.
3. `raw latent coordinates -> public UI/person DTO/public assessment GET` — FORBIDDEN.
4. `role selection -> implicit/default desired qualities` — FORBIDDEN.
5. `selected qualities -> mutation of canonical Compatibility weights` — FORBIDDEN.
6. `selected qualities -> Trust Score` — FORBIDDEN.
7. `selected qualities -> Account Completeness` — FORBIDDEN.
8. `complaint -> reputation penalty without confirmed moderation incident` — FORBIDDEN.
9. `name number -> friendship compatibility` — FORBIDDEN.
10. `numerology -> psychological-test count` — FORBIDDEN.
11. `legacy direct-question result -> visual-latent-v2 profile` — FORBIDDEN.
12. `internal consistency signal -> public negative warning` — FORBIDDEN.
13. `theory-informed visual loading -> claim of validated psychological fact` — FORBIDDEN until validated.
14. `composite quality -> universal personality verdict` — FORBIDDEN; it is only a fit template for a user-selected request.
15. `search role -> composite quality preset` — FORBIDDEN unless the user explicitly selected that quality.
16. `30d/90d outcome -> public moral/reputation label` — FORBIDDEN.
17. `observational outcome association -> causal psychological claim` — FORBIDDEN without appropriate validation.
18. `outcome analysis -> silent production model mutation` — FORBIDDEN.
19. `language change -> only navigation labels while domain/test/numerology text stays old` — FORBIDDEN.
20. `locale -> different psychological/compatibility scoring semantics` — FORBIDDEN.
21. `incomplete locale pack -> visible language carousel option` — FORBIDDEN.
22. `visual item response trace -> public user/profile API` — FORBIDDEN.
23. `calibration correlation -> automatic production loading change` — FORBIDDEN.
24. `locale change -> rewrite canonical city/search/storage value` — FORBIDDEN.
25. `locale change -> silently machine-translate arbitrary user-authored content` — FORBIDDEN.
26. `no calibration opt-in -> retained raw item-level calibration attempt` — FORBIDDEN.
27. `calibration withdrawal -> retain that user's raw calibration attempts` — FORBIDDEN.
28. `post-match assessment -> predictor/explanation of an earlier match outcome` — FORBIDDEN (temporal leakage).
29. `presentation slot / response latency -> public honesty/deception label` — FORBIDDEN.

## L. Required invariants

- 100 psychological/behavioral tests, 600 indirect tasks.
- No visible target-construct names during assessment.
- No universal bad-trait scalar.
- Both trait poles have context-positive meaning.
- Quality Fit exists only when the user selected qualities; empty request must not silently inject defaults.
- A composite quality must be computed from its declared internal target coordinates; no single coordinate may impersonate a multi-construct quality.
- Server/public DTOs expose only safe outputs.
- Old direct-question scores are quarantined from the new latent model.
