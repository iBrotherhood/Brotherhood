# AI TEMPORARY MEMORY — ACTIVE

Status: v0.5.17 locally qualified; exact-HEAD GitHub CI pending

## Active task
Qualify the source fix proven by GitHub run 83237541436, complete `scene-library-v4` composition diversity and controlled first-user cohort, then package v0.5.17.

## Confirmed implementation state
- first real log failure: `BrotherhoodApp.kt:2617:2 Expecting '}'`; full `CompatibilityPanel` and `CompatibilityMetric` restored;
- model remains `visual-latent-v2`; stimulus provenance is `scene-library-v4`;
- 48 scenes / 16 paradigms / 8 non-scoring composition recipes across 600 tasks;
- controlled cohort defaults closed; consent v2, total/locale quota, one-use invite digest, explicit acknowledgement;
- plaintext invite is online-only and never persisted;
- withdrawal is unconditional and deletes raw attempts;
- non-participant client omits raw trace; server strips unexpected trace;
- Compatibility weights and Vedic 5% unchanged.

## Completed verification
- Python/backend/architecture regression currently PASS;
- pure Kotlin core smoke currently PASS;
- full Android Gradle/APK remains GitHub CI gate.

## Exact next safe action
Package v0.5.17 and run canonical GitHub CI to `ANDROID_CI_APK_ARTIFACT_PASS`; then open only the controlled invitation cohort defined by the active protocol.
