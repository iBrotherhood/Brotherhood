# AI TEMPORARY MEMORY — PENDING

## Active task

Finalize and package Brotherhood v0.5.20 after the results/i18n/UX cycle.

## Current implemented state

- Positive public-safe result after each completed visual psychological block.
- First unique completion contributes +0.5%; retake contributes +0.0% and refines the profile.
- Strengths visible on Home and Profile; discovery history available.
- Candidate cards explain why a person fits the current request.
- Chats empty state has direct actions.
- Language selector is registry-driven `LazyRow`; current complete packs RU/UK/EN; 12-language scalability fixture exists.
- Settings show honest manual Development APK installation and a collapsed optional calibration pilot.
- One version-independent universal `.github/workflows/android-build.yml` replaces per-version workflow edits.

## Local validation completed

- Backend + architecture pytest: 106 PASS.
- Pure Kotlin unit runner: 32 PASS.
- OpenAPI: 0.5.20 / 45 paths.
- Locale generator: 617 entries / 748 required keys / RU-UK-EN.
- JSON/XML/Python/YAML/bash/security/parser checks: PASS.

## Deferred gate

Full Android Compose/APK exact-HEAD build must run through the frozen GitHub workflow using the final `Brotherhood.zip`.

## Exact next safe action

Generate final manifest/file maps, deterministic source/canonical archives and run GitHub CI without changing the universal workflow.
