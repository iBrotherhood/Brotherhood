# AI Temporary Memory — Pending

Status: ACTIVE OPERATIONAL MEMORY — v0.5.16 calibration-pilot release candidate

## Active task
Complete and qualify the expanded scene-library-v3 stimulus bank and real-data calibration pipeline for first Brotherhood users without changing canonical Compatibility or exposing raw psychological evidence.

## Implemented in this cycle
- `visual-latent-v2` remains the scoring model; stimulus provenance upgraded to `scene-library-v3`;
- 48 scene archetypes and 16 visual paradigms are actually exercised across the 600-task bank;
- deterministic hidden option order with recorded `presentation_slot`;
- first-selection latency, answer-change count and randomized task position are captured for calibration diagnostics;
- active aggregate profile storage is separated from raw item-level calibration attempts;
- raw server retention requires explicit `calibration-consent-v1` opt-in; withdrawal purges retained raw attempts while preserving ordinary aggregate profile functionality;
- separate early-pilot and 30/90-day outcome SQL exports;
- outcome export enforces pre-match temporal eligibility;
- offline report adds position-bias, latency, locale, retest and pilot-readiness diagnostics;
- calibration runner uses private file permissions and purges row-level CSV by default;
- production model mutation remains forbidden and manual/versioned only.

## Current local evidence
- Python/backend/architecture regression: pending final rerun after version/docs synchronization;
- Kotlin stimulus smoke: PASS — 100 tests / 600 tasks / 50 traits / 48 scenes / 16 paradigms / 4 presentation slots;
- real PostgreSQL migration/export: environment-deferred;
- full Android APK/Compose build: GitHub CI gate.

## Pending only
1. Complete version/SSOT/i18n/OpenAPI synchronization and final regression.
2. Deterministic source + GitHub Canonical packaging.
3. GitHub Android CI / APK artifact qualification.
4. Run migration/export against real PostgreSQL when available.
5. Collect real opt-in pilot data; do not claim empirical validation before evidence exists.

No permission exists for automatic production reweighting, raw-trace publication, moral scoring, or reputation effects from calibration data.
