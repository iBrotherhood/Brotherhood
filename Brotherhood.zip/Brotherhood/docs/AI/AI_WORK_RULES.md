# AI work rules — Brotherhood

1. Продолжать от current HEAD; не начинать проект заново без доказанной необходимости.
2. Один numbered cycle — крупный продуктовый результат, а не импорт, документ, архив, CI-run или единичный дефект.
3. Технические hotfixes включаются в текущий крупный цикл либо записываются как maintenance note.
4. Использовать уровни доказательства: `SOURCE_ONLY → LOCAL_PASS → APK_VISIBLE → LIVE_E2E → PRODUCTION_QUALIFIED`.
5. Запрещено писать «реализовано/готово» без указания уровня и evidence.
6. Отчёт или README не доказывает runtime. Проверять исходники, tests и соответствующий gate.
7. APK/GitHub build выполняется только в roadmap checkpoints: 0002, 0004, после 0005–0006, 0008 при Android/model изменениях, 0010 final.
8. Исключение для внепланового APK: без compile evidence невозможно безопасно продолжить либо пользователь прямо требует сборку.
9. Universal workflow заморожен; в следующих циклах меняется только `Brotherhood.zip`, если новый лог не докажет дефект workflow.
10. Green build не доказывает backend/PostgreSQL/credentials/store reputation/production readiness.
11. AVG/Play Protect warning не исправляется workflow; обходы защиты запрещены.
12. Preserve canons: platonic male friendship 18+, `global_id`, separate Trust/Compatibility/Completeness/Quality Fit, Vedic 5%, hidden visual assessment, positive public projection.
13. Никогда не раскрывать raw latent coordinates, calibration traces, private warnings или moral labels.
14. После крупного цикла обновлять roadmap/status, decision log, work notes, handoff, manifest/file maps.
15. Unknown facts marked `UNKNOWN`/`NEEDS_REVIEW`; ничего не выдумывать.
