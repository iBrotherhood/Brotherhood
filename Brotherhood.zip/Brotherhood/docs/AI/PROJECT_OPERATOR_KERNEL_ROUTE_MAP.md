# Brotherhood Operator Kernel route map

Runtime-primary definitions are in `ops/operator_kernel/config/routes.yaml`. Major routes:
- `numerology_self_analysis`: automatically derived date-based numerology plus optional name-derived descriptive fields, localized knowledge assets and software validation checks; no user questionnaire/test is part of numerology.
- `compatibility_model`: fixed production compatibility layers/weights; sensitive to canon drift.
- `android_ui_feature`: Compose/ViewModel/UI assets without CI/signing changes.
- `ci_android`: GitHub build/signature/metadata/artifact chain only.
- `backend_api`, `database`, `auth_security`, `release_packaging`, `kernel_archive`, `historical_reference`.
Composite request keeps the highest-scoring primary route and every other nonzero critical route; release validation is added when packaging is requested.

## psychological_visual_matching
Indirect visual/associative psychological profiling + user-authored desired-quality matching. Must read psychological CANON and causal kernel. Quality Fit is separate from Compatibility/Trust/Completeness; raw latent data stays internal.
