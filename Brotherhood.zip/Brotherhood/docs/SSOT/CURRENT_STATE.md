# Current state SSOT

Fast-changing facts are sourced from:
- Version/applicationId/SDK: `android/app/build.gradle.kts`.
- Backend API version: `backend/app/main.py`.
- Product package metadata: `PROJECT_MANIFEST.json`.
- Android CI workflow: `.github/workflows/android-source-build.yml` (source) and canonical outer workflows.
- Current migrations: `database/migrations/`.
- Latest generated verification: `reports/generated/operator_kernel_setup_report.json` and current release report.

Do not copy these volatile values into KERNEL unless necessary for routing.
