# Brotherhood current state SSOT

Current source package: `v0.5.23 / versionCode 28`.
Application ID: `org.federationofavatars.brotherhood`; minSdk 26; targetSdk 36.

Cycle 0002: source milestone ready; GitHub APK/device acceptance pending.
Cycle 0003: ACTIVE — source milestone ready, `LOCAL_PASS`; real deployment/PostgreSQL/provider/Android E2E remains `LIVE_E2E PENDING`.
Cycles 0004–0010: PLANNED. Cycles 0011–0100: UNUSED_RESERVE.

Auth source state: `global_id` owner; verified provider identities resolve to it; opaque hashed access/refresh sessions; refresh rotation/revocation/device binding; server-only provider secrets; Android encrypted session; Google runtime public client config; Telegram HTTPS OIDC+PKCE with device-bound one-time completion ticket; email OTP; passkey server verification; settings sync.

No claim of `APK_VISIBLE`, `LIVE_E2E` or `PRODUCTION_QUALIFIED` is made without the corresponding external evidence.
