# Assessments — Brotherhood v0.5.19

## Канон

В Brotherhood существует ровно `100 × 6 = 600` непрямых психологических/поведенческих заданий. Нумерология не относится к тестам и рассчитывается автоматически.

Активная модель: `visual-latent-v2`.

## Пользовательский UX

Пользователь видит только нейтральную визуальную серию и четыре визуальных варианта. В интерфейсе не показываются:

- название скрытой шкалы;
- направление scoring;
- «правильный» ответ;
- отрицательные выводы;
- raw latent coordinates;
- consistency/cross-check diagnostics.

Пользовательское действие: выбрать вариант, который первым кажется наиболее естественным.

## Internal-only данные

Алгоритмически могут храниться и использоваться:

- многомерные choice loadings;
- latent coordinates;
- evidence count;
- consistency/confidence;
- model version;
- calibration metadata.

Они не возвращаются обычным public assessment API.

## Completeness

Каждая уникально завершённая текущая серия даёт `+0.5%` Account Completeness. Повторное прохождение той же серии не должно повторно повышать полноту. Максимум от 100 серий — 50%; ещё 50% дают 10 профильных секций × 5%.

Account Completeness не является Trust Score, Compatibility или Quality Fit.
