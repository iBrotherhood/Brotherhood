# Diia Open Source review for Brotherhood v0.5.9

## Decision

Diia Open Source is used as an architectural reference, not as a source for mechanical code copying. The reviewed Diia repositories declare EUPL licensing, therefore Brotherhood keeps its own implementation unless a later legal/licensing decision explicitly approves reuse.

## Useful patterns

- `android-diia`: compact primary bottom navigation, badges, accessibility semantics, orientation-aware UI and state-preserving navigation. Brotherhood adopts the product principles: few first-class destinations, visible chat badges, explicit labels, touch targets and persistent selected tab.
- `be-auth-service`: provider-strategy authorization. This matches Brotherhood's `global_id` above Google/Telegram/Facebook provider identities.
- `be-pkg-i18n`: localization as an independent package/domain. Brotherhood keeps RU/UK/EN in an expandable locale registry.
- `be-diia-queue`: queue as a separate infrastructure concern. Brotherhood applies this to offline mutations and chat outbox/retry.
- `be-pkg-crypto`: crypto/auth functionality as a separated package boundary. Brotherhood keeps E2EE and server-side crypto isolated and does not copy Diia crypto implementation.
- `be-diia-logger`, `be-diia-metrics`, `be-pkg-healthcheck`, `be-pkg-errors`, `be-pkg-validators`: useful next infrastructure layer for production observability, structured errors, health checks and validation.

## Not adopted

- Government document/service business logic is irrelevant to Brotherhood.
- Mongo/Redis topology is not copied; Brotherhood remains Vercel/FastAPI + Neon/PostgreSQL until scaling requires otherwise.
- No Diia branding, assets or proprietary/business-specific flows are used.

## UX correction triggered by review

The v0.5.8 features existed but were hidden behind icon-only secondary navigation. v0.5.9 exposes them on the Brotherhood Home dashboard and promotes Chats to a first-class bottom tab.
