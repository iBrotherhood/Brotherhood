# Brotherhood — Real-data calibration pilot protocol

Status: ACTIVE NORM — first-user calibration pipeline

## 1. Scope
This protocol applies only to empirical development of the private `visual-latent-v2` instrument with `scene-library-v3`. It does not alter canonical Compatibility, Trust, Account Completeness or public reputation.

## 2. Consent and storage boundary
- Ordinary product use does not require calibration opt-in.
- Aggregate hidden profile coordinates may be stored for normal matching.
- Raw item-level traces may be retained server-side only after explicit `calibration-consent-v1` opt-in.
- Raw calibration attempts are stored separately in `assessment_calibration_attempts`.
- Withdrawing calibration consent deletes retained raw attempts for that participant and does not delete the ordinary aggregate profile.
- Raw traces are internal/private analytics and are never exposed through public people/profile/assessment endpoints.

## 3. Captured pilot evidence
A consented attempt may retain:
- assessment/model/stimulus version;
- instrument locale and cohort;
- visual question/scene/paradigm;
- selected choice and deterministic presentation slot;
- first-selection latency;
- answer-change count;
- randomized task position;
- visual layout features;
- aggregate hidden coordinates and internal consistency;
- later, where available, frozen search intent / Quality Fit and controlled 30/90-day outcome.

These fields are calibration evidence, not a deception detector or moral score.

## 4. Two analysis phases
### Early pilot
Use `analysis/visual_item_calibration_export.sql` before 30/90-day outcomes exist. Review:
- option concentration and entropy;
- presentation-position bias;
- response-time patterns;
- answer-change patterns;
- scene/paradigm coverage;
- locale distribution drift;
- repeated-attempt descriptive stability.

### Outcome phase
Use `analysis/visual_assessment_calibration_export.sql` only when controlled outcomes exist. The query selects only candidate attempts completed on or before `matched_at`. Post-match assessment data is excluded to prevent temporal leakage.

## 5. Review semantics
Thresholds in `calibrate_visual_model.py` are operational pilot-review heuristics, not validated psychological cut-offs. A flag means `REVIEW_CANDIDATE`, never “bad item”, “bad user”, diagnosis or causal proof.

No calibration script may automatically change:
- visual loadings;
- quality targets;
- 15-layer Compatibility weights;
- Vedic 5% weight;
- Trust/reputation;
- public labels.

Any production change requires a separate reviewed, versioned release with regression evidence.

## 6. Private execution
Recommended commands:

```bash
export DATABASE_URL='postgresql://...'
CALIBRATION_MODE=early analysis/run_calibration_pipeline.sh
```

For outcome analysis:

```bash
CALIBRATION_MODE=outcome analysis/run_calibration_pipeline.sh
```

The runner uses `umask 077` and purges the private CSV by default after producing the JSON report. Set `KEEP_PRIVATE_CSV=1` only in a controlled analytics environment when row-level inspection is genuinely required.

## 7. Pilot stages
The report uses operational stages only:
- `PILOT_INTAKE`;
- `EARLY_DIAGNOSTICS`;
- `ITEM_REVIEW_READY_OUTCOMES_PENDING`;
- `OUTCOME_ANALYSIS_READY`.

These labels describe data availability, not proof of validity.

## 8. Scientific discipline
Image/forced-choice assessment can be studied as a psychometric format, but Brotherhood's own visual loadings remain hypotheses until the specific instrument demonstrates suitable reliability, construct validity, language/cultural equivalence and outcome usefulness in Brotherhood data. Current research and ITC guidance are foundations for validation design, not substitutes for Brotherhood-specific evidence.
