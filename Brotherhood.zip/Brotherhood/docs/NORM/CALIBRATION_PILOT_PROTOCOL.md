# Brotherhood — Controlled real-data calibration pilot protocol

Status: ACTIVE NORM — v0.5.17 first controlled real-user cohort

## 1. Scope
This protocol governs empirical development of private `visual-latent-v2` with `scene-library-v4`. It never alters canonical Compatibility, Vedic 5%, Quality Fit templates, Trust, Account Completeness or public reputation automatically.

## 2. Cohort mode and first wave
Production default is `closed`. Enrollment is allowed only when all conditions are true:
- current `calibration-consent-v2`;
- explicit participant acknowledgement;
- supported instrument locale;
- total and locale quota available;
- valid unredeemed invitation in closed mode.

Recommended first controlled wave: 18 adult Brotherhood users, target 6 RU / 6 UK / 6 EN. Before this wave, an optional internal functional wave of 6 users (2 per language) may verify enrollment, withdrawal and data flow only. These counts are operational targets, not proof of psychometric validity.

## 3. Invitation security
- Generate invitations with `analysis/generate_pilot_invites.py`.
- Distribute plaintext codes through a controlled channel.
- Configure only SHA-256 digests in `BROTHERHOOD_CALIBRATION_INVITE_SHA256`.
- Plaintext codes MUST NOT be committed, logged, queued offline, stored in SharedPreferences or stored in PostgreSQL.
- The database stores only a redeemed digest to enforce one use.
- A previous cohort/wave enrollment does not bypass invitation rules for a new cohort/wave.

## 4. Consent and storage boundary
- Ordinary product use does not require pilot participation.
- Aggregate hidden coordinates remain in ordinary profile storage.
- Raw six-item response traces are retained only for an active enrolled participant and only when assessment locale equals enrollment locale.
- Non-participant clients omit raw traces; the server also strips unexpected traces.
- Raw attempts live separately in `assessment_calibration_attempts`.
- Withdrawal is unconditional, sets enrollment to `withdrawn` and deletes retained raw attempts while preserving the aggregate profile.
- Public endpoints never expose raw traces, latent coordinates or invite information.

## 5. Stimulus evidence
A consented trace may include model/stimulus version, locale/cohort/wave, scene, paradigm, selected choice, deterministic presentation slot, response latency, answer-change count, question position, layout features and `composition_variant`.

`composition_variant` is a non-scoring visual recipe shared by all four answer options in one task. It is used only to test whether frames, grids, rings, directional guides or other scene composition differences affect response distributions.

## 6. Analysis phases
### Early pilot
Use `analysis/visual_item_calibration_export.sql` and review option concentration, entropy, position bias, latency, answer changes, scene/paradigm/composition coverage, locale drift and descriptive retest stability.

### Outcome phase
Use `analysis/visual_assessment_calibration_export.sql` only after controlled outcomes exist. Only attempts completed on or before `matched_at` are eligible; post-match assessments are excluded.

## 7. Review semantics
All thresholds are operational review heuristics. A flag means `REVIEW_CANDIDATE`, never diagnosis, deception, moral defect or causal proof. Production changes require a separate reviewed/versioned release and regression evidence.

## 8. Private execution
```bash
export DATABASE_URL='postgresql://...'
CALIBRATION_MODE=early analysis/run_calibration_pipeline.sh
```

The runner uses `umask 077` and deletes private CSV by default after report generation. Keep row-level exports only in a controlled analytics environment.

## 9. Exit/hold gates for first wave
Hold expansion when any of the following is unresolved: enrollment/withdrawal failure, raw trace without opt-in, invite plaintext persistence, public latent leakage, severe locale imbalance, invalid stimulus version, incomplete trace rows, or position/composition effects large enough to make item interpretation unreliable.

Passing these operational gates allows the next controlled wave; it does not certify psychological validity.
