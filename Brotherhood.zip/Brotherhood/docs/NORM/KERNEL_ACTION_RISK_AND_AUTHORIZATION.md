# Action risk and authorization

Classes: LOCAL_REVERSIBLE, LOCAL_DESTRUCTIVE, SHARED_REVERSIBLE, EXTERNAL_SIDE_EFFECT, PRODUCTION_LIVE, IRREVERSIBLE. Current local source edits/testing/packaging are LOCAL_REVERSIBLE. Git push/merge/publish/deploy/production migration/DNS/external messages/on-chain actions are user-only external actions and require separate explicit authorization. One permission does not authorize unrelated future side effects.
