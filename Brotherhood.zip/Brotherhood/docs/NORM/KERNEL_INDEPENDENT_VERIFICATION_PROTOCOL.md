# Independent verification protocol

Verifier is read/test/diff only and must not modify source. For each check record command, observed output, expected, actual and verdict. Required for package/release, Kernel/routes, Android feature, backend/API, DB, auth/security. Include at least one negative/adversarial probe. Valid verdicts: PASS, FAIL, PARTIAL_ENVIRONMENT, LOCAL_PASS_LIVE_DEFERRED, BLOCKED_NEEDS_USER_DECISION.
