# Brotherhood Localization and Language Pack Norm

Status: ACTIVE NORM — v0.5.19

## 1. One runtime language state
The selected `AppLanguage.tag` is the single user-facing locale state. Changing it must change every localized user surface: navigation, sections, settings, discovery, chat labels, assessments, public psychological results, Quality Fit labels, self-analysis, numerology, update/status messages and future localized modules.

## 2. Carousel
Language selection is a horizontal carousel driven by `shared/locales/supported.json` / mirrored Android `assets/i18n/languages.json`. Do not hardcode an enum list in UI.

## 3. Future languages are data, not branches
Adding a language must not require adding `when(language)` / enum branches throughout application code. Activation requires:
1. a language record with BCP-47-like tag, native name and `ltr|rtl` direction;
2. a complete `shared/locales/packs/<tag>.json` mirrored into APK assets;
3. all required runtime translation keys from `assets/i18n/required_keys.json`;
4. a complete numerology locale block;
5. i18n coverage tests PASS.

An incomplete language must not appear in the runtime carousel.

## 4. Translation sources
- Stable dynamic messages use machine keys such as `quality.<key>`, `chat.e2ee_fingerprint`, `assessment.visual_series`.
- Existing readable RU/UK/EN inline triplets are supported through the generated translation memory `shared/locales/translation-template.json`; future packs translate their English source aliases.
- `scripts/update_locale_catalog.py` regenerates the translation template, current pack aliases, `required_keys.json`, and the Android language registry mirror.

## 5. Numerology
Numerology is not a test. Its knowledge asset must have a complete locale block for every enabled language. Missing numerology coverage blocks language activation rather than silently presenting a partially translated experience.

## 6. Directionality
`direction=rtl` must set Compose `LocalLayoutDirection` for the whole app. Locale metadata, not hardcoded language names, controls direction.

## 7. Backend and database
Backend enabled locale tags come from `shared/locales/supported.json`. Quality labels are translated through locale packs. Database locale validation checks syntax, not a fixed RU/UK/EN enum.

## 8. Forbidden drift
- language change -> only menu labels: FORBIDDEN;
- enabled locale with incomplete UI/domain/numerology coverage: FORBIDDEN;
- fixed `^(ru|uk|en)$` validation in active backend/runtime: FORBIDDEN;
- future locale requiring widespread source branching: FORBIDDEN;
- untranslated hidden model identifiers exposed as user text: FORBIDDEN.

## 9. Built-in geography and user data
Built-in city catalog entries use a stable canonical `value` for storage/search and a locale-dependent `label` from `shared/locales/cities.json` + locale packs. Switching language MUST NOT rewrite the canonical stored/search value. Arbitrary user-entered city strings, profile text, names, messages and community content remain literal user data unless an explicit translation feature is introduced later. Bundled DEBUG/demo fixtures are application-owned and therefore must localize with the selected language.

## 10. Coverage gate extension
`city.name.*` keys are part of `required_keys.json`. The locale generator must materialize declared stable keys, not only English-source aliases. A locale missing any required stable domain key is disabled rather than partially rendered.

