# Brotherhood v0.5.14 — psychological matching release report

Date: 2026-08-01  
Android: `versionName 0.5.14`, `versionCode 19`  
Application ID: `org.federationofavatars.brotherhood`

## Scope completed

This release implements the agreed Brotherhood psychological matching canon without changing the fixed 15-layer Compatibility weights, Trust, Account Completeness, branding, production signing, or `applicationId`.

### Cycle 1 — canon and causal Kernel
- fixed the psychological matching canon in `docs/CANON/PSYCHOLOGICAL_MATCHING_CANON.md`;
- added `docs/AI/CAUSAL_RELATIONSHIP_KERNEL.md` with allowed and forbidden causal edges;
- added ADR, route capsule, healer guard, enforcement gates and architecture regressions;
- preserved Kernel as the active route/boundary dispatcher rather than duplicating full project history.

### Cycle 2 — hidden multidimensional profile
- active assessment/scoring provenance: `visual-latent-v1`;
- 50 private neutral/contextual coordinates;
- no universal good/bad trait direction;
- legacy direct-question results are retained as history but are quarantined from the new profile.

### Cycle 3 — 100 × 6 indirect visual/associative bank
- exactly 100 psychological/behavioral blocks × 6 = 600 tasks;
- no direct self-report trait statement in the canonical task model;
- four visual choices per task;
- each choice contributes small loadings to multiple hidden coordinates;
- one choice can never create a public diagnosis or moral label;
- visual mappings are model hypotheses pending empirical validation.

### Cycle 4 — user-authored Quality Fit and positive projection
- user selects role/context, desired qualities and importance;
- role injects no default qualities;
- 84 selectable RU/UK/EN qualities;
- simple and composite quality templates are supported;
- examples of composite patterns: demanding, disciplined, firm decisions, uncompromising principles, crisis leader, strategic, operational, entrepreneurial, consensus builder;
- Quality Fit is separate from Compatibility, Trust and Account Completeness;
- public assessment API does not return raw latent coordinates or psychological risk flags;
- public self-analysis no longer exposes growth-deficit/negative-warning sections;
- public Vedic summary is positive/contextual rather than tension-labelled.
- retired the old v0.5.12 fixed-ID Friendship Expectations shadow; expectation preferences are now expressed through user-selected Quality Fit qualities.

### Cycle 5 — outcome validation loop
- migration `0004_quality_fit_outcome_context.sql` snapshots the initiating user's explicit SearchIntent, Quality Fit score/confidence and quality model version at connection time;
- 30/90-day outcomes remain internal analytics, not public reputation;
- `analysis/evaluate_quality_fit_outcomes.py` produces observational evidence only;
- automatic production mutation is explicitly forbidden.

## Research anchors
- ITC/ATP technology-based assessment guidance: fair/valid digital design, delivery and scoring; current guideline version updated July 2025.
- IPIP: public-domain construct/item pool used as a research vocabulary reference, not copied as Brotherhood's direct questionnaire UX.
- O*NET Work Styles: current work/leadership construct research input; occupational ratings are not treated as Brotherhood user scores.
- 2026 friendship study (369 friend quads, N=1,476): generic Big Five similarity was not a reliable friendship-satisfaction rule, supporting Brotherhood's decision not to make global personality similarity the sole matching law.

See `docs/research/PSYCHOMETRIC_FOUNDATIONS_v0_5_14.md` and `docs/research/SANDBOX_PSYCHOLOGY_REFERENCES_v0_5_14.md`.

## Local verification
- backend + architecture regression: **64/64 PASS**;
- pure Kotlin core compile: **PASS** (26 files; only pre-existing unused-parameter warnings);
- Kotlin smoke: **PASS** — 100 tests / 600 tasks / 50 latent coordinates / 84 qualities;
- OpenAPI generation: **PASS**, backend version `0.5.14`, 41 paths;
- JSON parse: **27 PASS**;
- Android XML parse: **15 PASS**;
- canonical workflow YAML: **4 PASS**;
- workflow shell `bash -n`: **28 run blocks PASS**;
- AAPT metadata parser regression: **PASS**;
- APKSigner digest parser regression: **PASS**;
- private signing-key file scan: **PASS**;
- Android manifest security canon: **PASS**.

## Deferred verification
- local archive does not contain `android/gradle/wrapper/gradle-wrapper.jar`;
- full Android/Compose/Gradle/APK qualification is therefore **DEFERRED TO EXISTING GITHUB CI**;
- PostgreSQL migration execution is not claimed locally without a real PostgreSQL qualification environment.

## Release claim boundary
`v0.5.14` is a working implementation of the Brotherhood model and release source, not a claim that the new visual instrument is already clinically or psychometrically validated. Empirical reliability/validity and outcome calibration remain evidence-driven future cycles.
