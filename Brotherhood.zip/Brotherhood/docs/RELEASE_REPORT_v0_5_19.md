# Brotherhood v0.5.19 — Android unit-test corrective release

Android target: `versionName 0.5.19`, `versionCode 24`, `applicationId org.federationofavatars.brotherhood`.

## Proven failure
GitHub run `83256062351` passed main Kotlin compilation and failed at `:app:compileDebugUnitTestKotlin` because unit tests referenced removed direct-question fields: `pairId`, `reverse`, `text`, and `situationalText`.

## Corrections
- rewrote assessment catalog tests for four-choice versioned visual tasks;
- rewrote scorer tests for neutral latent scoring and zero moral-risk/idealization output;
- rewrote Brotherhood-32/Enneagram tests for visual loadings rather than fixed answer positions;
- rewrote cross-test integrity expectations so contradictions reduce internal consistency without public risk flags;
- added exact regression guards for run `83256062351`;
- synchronized source/canonical version gates to 0.5.19 / 24.

## Preserved canon
No production psychological loadings, Compatibility weights, Vedic 5%, Quality Fit, Trust, controlled-pilot architecture, applicationId, signing policy or CI logic were changed.

## Local verdict
All 30 pure Android unit tests pass in a local Kotlin runner. Full Gradle/APK qualification remains the exact-HEAD GitHub CI gate.
