# Brotherhood project canon v0.5.22

- `versionName = 0.5.22`
- `versionCode = 27`
- `applicationId = org.federationofavatars.brotherhood`

## Cycle scope

1. Positive user result after every visual psychological block.
2. Positive discoveries on Home/Profile/Self-analysis, including latest discovery, next best step, useful contexts and discovery history.
3. Data-driven horizontally scrollable RU/UK/EN language carousel with complete-pack activation gates.
4. Screenshot-driven UX corrections for candidate fit explanation, adaptive People CTA, non-passive chat empty state, differentiated Groups cards, aligned Profile result blocks, honest manual Development installation UI and collapsible pilot section.
5. Runtime error fallbacks are locale-aware and do not expose raw exception text.
6. The universal version-independent `android-build.yml` remains frozen and byte-identical.

## Preserved canon

100×6 tasks, `visual-latent-v2`, `scene-library-v4`, 50 latent coordinates, 112 selectable qualities, 48 scenes, 16 paradigms, 8 compositions, 15 Compatibility weights, Vedic Numerology 5%, Trust/Compatibility/Account Completeness/Quality Fit separation, `global_id`, brand geometry, E2EE boundaries and calibration architecture remain unchanged.

## Evidence boundary

This version is a source milestone until GitHub APK build and device screenshots complete the cycle-0002 APK acceptance gate. Source/local checks may establish `LOCAL_PASS`; they do not establish `APK_VISIBLE`.
