# Guards index

## Machine guards
- `ops/operator_kernel/check_cycle_ecosystem.py`
- `tests/architecture/test_cycle_ecosystem.py`
- existing `tests/architecture/**`

## Healer guards
See `docs/healer/**` for Kernel demotion, overload, route staleness, full-read regression, memory pollution and archive mixing.

## Cycle guard invariants
- exactly 100 unique cycles;
- range exactly 0001–0100;
- current and next status files exist;
- START_HERE and KERNEL link the cycle registry;
- route config includes `cycle_planning`;
- operational memory names the exact next cycle.
