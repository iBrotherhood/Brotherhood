# Brotherhood psychometric and work-style foundations — v0.5.14

Status: RESEARCH ANCHOR, not a claim that Brotherhood itself is already psychometrically validated.

## 1. Technology-based assessment

International Test Commission / Association of Test Publishers guidance for technology-based assessment (updated July 2025) emphasizes fair and valid design, delivery and scoring in digital environments. Brotherhood therefore versions the assessment model, separates experimental visual loadings from validated claims and treats validation as an evidence task rather than an assumption.

Source: https://www.intestcom.org/page/16

## 2. Personality construct vocabulary

The official International Personality Item Pool (IPIP) currently provides more than 3,000 public-domain items and more than 250 scales, together with reliability/validity resources. Brotherhood uses construct families as research anchors. It does not copy the direct self-report UX into the canonical 100×6 bank because the Brotherhood canon requires indirect visual/associative tasks.

Sources:
- https://ipip.ori.org/
- https://ipip.ori.org/ReliabilityValidity.htm
- https://ipip.ori.org/newPermission.htm

## 3. Interpersonal structure

The interpersonal-circumplex tradition treats agency and communion as broad axes of interpersonal behaviour. Brotherhood uses this literature as one source for separating assertiveness/leadership/autonomy from cooperation/closeness rather than collapsing them into a good/bad score.

Research anchor: https://pmc.ncbi.nlm.nih.gov/articles/PMC10862970/

## 4. Friendship: do not assume global personality similarity is the answer

A 2026 study of 369 friendship groups (N=1,476) found no evidence that Big Five similarity itself predicted friendship satisfaction across the analysed models. This supports Brotherhood's decision not to make generic personality similarity the sole or universal rule. Brotherhood keeps canonical Compatibility separate and adds user-authored Quality Fit: the user specifies what qualities matter for this particular search.

Source: https://journals.sagepub.com/doi/10.1177/19485506261450240

## 5. Work/business qualities

The current O*NET 30.3 Database describes 21 Work Styles and provides occupation-level Work Style Impact/Distinctiveness information plus Work Style↔Work Activity and Work Style↔Work Context linkages. O*NET research revised the Work Styles taxonomy using literature review, NLP clustering and subject-matter-expert linkage work. Brotherhood uses selected construct-level vocabulary as research input for business/leadership qualities; it does not treat O*NET occupational ratings as Brotherhood user scores.

Sources:
- https://www.onetcenter.org/dictionary/30.3/json/work_styles.html
- https://www.onetcenter.org/reports/Work_Styles_New.html
- https://www.onetcenter.org/reports/Higher_Order_Styles.html
- https://www.onetcenter.org/dictionary/30.3/text/work_styles_to_work_context.html
- https://www.onetcenter.org/dictionary/30.3/text/work_styles_to_work_activities.html

O*NET 30.3 Database content is available under CC BY 4.0 with attribution requirements.
Source: https://www.onetcenter.org/license_db.html

Attribution: This project includes adapted construct-level information informed by the O*NET 30.3 Database by the U.S. Department of Labor, Employment and Training Administration (USDOL/ETA), used under CC BY 4.0. O*NET® is a trademark of USDOL/ETA. Brotherhood modifications have not been approved, endorsed or tested by USDOL/ETA.

## 6. Brotherhood's visual/associative model

Indirect visual choice is a product and measurement hypothesis, not a shortcut around psychometrics. The current model deliberately avoids obvious socially desirable self-descriptions, but hiddenness alone does not create validity.

The current visual feature families are:
- interpersonal distance / grouping;
- network density;
- path / direction;
- balance / resource allocation;
- boundary permeability;
- rhythm / order;
- structure / asymmetry;
- focus / intensity;
- change / ambiguity.

Each option contributes small loadings to multiple private coordinates. The same coordinate is sampled across distant tasks and contexts. A single answer never produces a diagnosis, moral label or public negative conclusion.

## 7. Quality ontology

v0.5.14 contains 50 private latent coordinates and 84 selectable positive/contextual search qualities. Qualities may be simple (one target coordinate) or composite (multiple target coordinates). Examples of composite business/leadership patterns include demanding, disciplined, firm in decisions, uncompromising on principles, crisis leadership, strategic, operational, entrepreneurial and consensus-building patterns.

The ontology is versioned and extensible; it is broad but is NOT claimed to be an exhaustive list of every human personality quality.

## 8. Validation roadmap

1. freeze bank/model/version for each validation cohort;
2. inspect response distributions and option functioning;
3. remove options/tasks that are near-random, redundant or transparently keyed;
4. test-retest reliability for coordinates intended to be relatively stable;
5. latent/factor structure analysis where appropriate;
6. convergent/discriminant studies against suitable public-domain measures;
7. RU/UK/EN semantic and measurement-equivalence checks;
8. differential item/option functioning checks where sample size permits;
9. predictive validation against consented friendship/business-role outcomes;
10. calibration report -> reviewed proposal -> explicit new model version;
11. never auto-update production scoring from a quarterly regression without review.
