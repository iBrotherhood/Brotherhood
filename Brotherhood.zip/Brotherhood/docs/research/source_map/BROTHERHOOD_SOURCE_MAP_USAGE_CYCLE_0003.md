# Brotherhood source-map usage — cycle 0003

Status: ACTIVE RESEARCH REFERENCE
Date: 2026-08-08

## Authority boundary

The preserved `APK_SOURCE_MAP_v002.md` / `.json` remain research/donor evidence only. They do not override `START_HERE → KERNEL → active CANON/SSOT/NORM → active cycle → actual source/tests` and they do not authorize a parallel auth/backend architecture.

Cycle 0003 continues the existing FastAPI/PostgreSQL/Compose tree. No external repository has been copied into Brotherhood.

## Existing map entries used

1. `APK_SOURCE_MAP_v002` Android references
   - Use: confirm that external Android projects are architecture/UX donors only.
   - Decision: preserve Brotherhood Compose/ViewModel/repository structure; auth is added at the current boundaries rather than replacing screens or data models.

2. `APK_SOURCE_MAP_v002` social/discovery donors
   - Use: product-behavior reference only.
   - Decision: none of their identity, matching or reputation models replaces Brotherhood `global_id`, Quality Fit, Compatibility or Trust.

## Official web sources actively re-verified for cycle 0003

1. Android Developers — Credential Manager / Sign in with Google
   - https://developer.android.com/identity/sign-in/credential-manager-siwg-implementation
   - Decision: Android acquires a Google ID token through Credential Manager with a cryptographic nonce; the token is sent to Brotherhood backend and is never accepted as an unverified user ID.

2. Google for Developers — Authenticate with a backend server
   - https://developers.google.com/identity/sign-in/android/backend-auth
   - Decision: the backend validates ID-token authenticity/audience and uses the verified `sub` as the provider subject. Plain client-supplied Google user IDs are not trusted.

3. Android Developers — create/use passkeys
   - https://developer.android.com/identity/passkeys/create-passkeys
   - https://developer.android.com/reference/kotlin/androidx/credentials/CreatePublicKeyCredentialRequest
   - Decision: the Android client uses Credential Manager public-key credential requests; private passkey keys remain with the credential provider. Brotherhood backend stores/verifies only public credential material and challenges.
   - Deployment prerequisite: production Android passkeys require Digital Asset Links for the real relying-party domain and Android 9+ support; this cannot be marked LIVE_E2E until the production RP domain/assetlinks.json are configured.

4. py_webauthn documentation / current package
   - https://duo-labs.github.io/py_webauthn/registration.html
   - https://pypi.org/project/webauthn/
   - Decision: registration requires a resident/discoverable credential and user verification; authentication requires user verification. Server challenges are single-use.

5. Telegram — Log In With Telegram / OIDC
   - https://core.telegram.org/bots/telegram-login
   - Decision: use Authorization Code Flow with PKCE. Android opens the authorization URL; the Telegram Client Secret never enters the APK; server exchanges the code and validates the resulting ID token (`iss`, `aud`, expiry, signature and nonce). Redirect URI is fixed by deployment configuration.

6. PostgreSQL 16 — transaction advisory locks
   - https://www.postgresql.org/docs/16/functions-admin.html
   - Decision: identity first-login/link races are serialized with transaction-level advisory locks around canonical provider/email resources, avoiding duplicate `global_id` allocation under concurrent verified logins.

7. Neon — serverless Postgres / pooling
   - https://neon.com/use-cases/serverless-apps
   - Decision: `DATABASE_URL` remains server-only; serverless deployments use the pooled Postgres endpoint. Android has no direct PostgreSQL access or database credential.

8. FastAPI — security primitives
   - https://fastapi.tiangolo.com/tutorial/security/
   - Decision: Brotherhood keeps Bearer access tokens at its API boundary and its own opaque rotating refresh tokens. Provider credentials are verified before issuing an application session.

## Concrete cycle-0003 decisions

- `global_id` remains the sole domain owner; external provider subjects remain access identities only.
- Public provider exchange cannot select an arbitrary identity tenant.
- Verified email may link a new provider identity to an existing unambiguous `global_id`; conflicting verified ownership is rejected for explicit recovery instead of silent merging.
- Access and refresh tokens are random opaque values; only SHA-256 token hashes are stored in PostgreSQL.
- Refresh tokens rotate one-time, remain device-bound when a device ID exists, and cannot refresh suspended/deleted users.
- Android session material is encrypted with a non-exportable Android Keystore AES-GCM key; provider/database secrets are not persisted in Android storage. The public Google OAuth Client ID is obtained at runtime from Brotherhood backend instead of requiring a workflow edit.
- Telegram OIDC state is stored server-side only as a hash; verifier/nonce are short-lived and the state is consumed once. Telegram redirects to a registered HTTPS backend callback; Android receives only a short-lived, one-time completion ticket bound to the initiating device.
- Email OTP is HMAC-hashed server-side, attempt-limited, expires after ten minutes and is invalidated if delivery fails.
- Passkey challenge state is server-side and one-use. Registration requires a discoverable resident credential + user verification.
- `user_settings` is persisted server-side by `global_id` and synchronized through the existing Android repository/offline-first boundaries.
- No matching weights, psychometric model counts, trust semantics, communities, E2EE model or cycle-0002 UX is replaced by this work.

## Evidence boundary

This source map supports implementation choices; it does not prove production operation. Until a real deployment has a PostgreSQL database, applied migrations, provider credentials, registered Google/Telegram redirect configuration, mail delivery and a valid WebAuthn relying-party origin, those paths remain `SOURCE_ONLY` / `LOCAL_PASS` as applicable and **not** `LIVE_E2E`.
