# Brotherhood source-map usage — cycle 0002

Status: ACTIVE RESEARCH REFERENCE
Date: 2026-08-08

## Authority boundary

`APK_SOURCE_MAP_v002.md` and `APK_SOURCE_MAP_v002.json` are preserved byte-for-byte from the supplied research bundle. Their old `project_ssot` section describes a previously inspected NON_CANONICAL_DEBUG APK and is **not** authoritative for the current Brotherhood source tree.

Current project truth remains:

`START_HERE → KERNEL → active CANON/SSOT/NORM → active cycle → actual source/tests`.

External sources are donor/reference evidence only. They never authorize replacing Brotherhood architecture or copying code without license/security review.

## Sources actively used in cycle 0002

1. APK Source Map v002 / `SRC-001 Mentalys Android App`
   - Use: architecture/UX reference only.
   - Decision: do not transplant its View-oriented architecture into Brotherhood Compose. Preserve current Compose/ViewModel/storage stack.

2. APK Source Map v002 / `SRC-014 Alovoa`
   - Use: discovery/community product-pattern reference only.
   - Decision: Brotherhood remains platonic male friendship; no dating semantics or foreign matching model is imported.

3. APK Source Map v002 / `SRC-002 VedAstro`
   - Use: numerology/astrology provenance reference only.
   - Decision: cycle 0002 does not change the canonical Vedic 5% compatibility weight or numerology calculation model.

4. Android Developers — Jetpack Compose lazy lists
   - URL: https://developer.android.com/develop/ui/compose/lists
   - Use: confirms `LazyRow` is the appropriate data-driven horizontal list primitive for an extensible language selector and horizontally scrollable chips.

5. Android Developers — Compose carousel
   - URL: https://developer.android.com/develop/ui/compose/components/carousel
   - Use: reference for carousel interaction principles; Brotherhood keeps the existing `LazyRow` requirement from project CANON rather than introducing a dependency/refactor solely for Material carousel APIs.

6. Android Developers — localization/resources
   - URLs:
     - https://developer.android.com/training/basics/supporting-devices/languages
     - https://developer.android.com/develop/ui/compose/resources
   - Use: validates separation of localized presentation from core behavior and supports scalable locale handling. Brotherhood continues its existing data-pack registry because the project CANON requires future locales to be enabled by complete packs rather than screen-by-screen branches.

7. Android Developers — Compose text layout
   - URL: https://developer.android.com/develop/ui/compose/text/configure-layout
   - Use: reference for avoiding narrow-screen text clipping; cycle 0002 removes the three-equal-width Quick Discovery CTA row that could compress translated labels.

## Cycle-0002 implementation decisions derived from the map + current source audit

- Preserve `LanguageCatalog` + JSON registry; do not replace with a new localization architecture.
- Preserve `visual-latent-v2` / `scene-library-v4`; no donor scoring model is imported.
- Keep Quality Fit, Compatibility, Trust and Account Completeness separate.
- Improve only current Compose surfaces: Home result value, Profile result visibility, Self-analysis accumulation/history, People CTA/chip readability, Groups card information hierarchy, Settings manual-install truthfulness, and localized user-facing fallback errors.
- External repositories are not copied into the source archive and no new runtime dependency is introduced.

## Web re-verification 2026-08-08

Official Android Developers documentation was re-checked during this cycle: Compose lazy lists define `LazyRow` as the horizontal scrolling lazy-list primitive; Android localization guidance separates localized presentation/resources from core behavior; Compose text layout documents `maxLines`/`overflow` for constrained text. These checks support the existing Brotherhood choices and do not justify a framework/dependency replacement.

The map's external donor repositories remain reference candidates only; no donor source code or runtime dependency was copied into Brotherhood during cycle 0002.

