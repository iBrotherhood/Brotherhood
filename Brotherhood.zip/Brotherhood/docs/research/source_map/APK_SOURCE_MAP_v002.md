# APK Source Map v002

**Project:** Brotherhood  
**Checked:** 2026-08-08  
**Mode:** research-only; production project was not modified.

This is the human-readable mirror of `APK_SOURCE_MAP_v002.json`. It keeps the original user URLs immutable and separates exact sources, current resolutions, and unproven candidates.

## Integrity summary

- **user_sources:** 14
- **exact_original_active:** 2
- **resolved_current_repository:** 1
- **candidate_resolution:** 8
- **unresolved:** 3
- **elements:** 28
- **capabilities:** 20
- **project_targets:** 33
- **evidence_records:** 52

## Brotherhood project SSOT used for target mapping

- Input: `Brotherhood-v0.5.11-NON_CANONICAL_DEBUG-24.zip`
- Evidence scope: compiled APK + supplied build/signing reports; source Gradle/Kotlin tree not supplied
- applicationId: `org.federationofavatars.brotherhood`
- version: `0.5.19` (`versionCode=24`)
- build: `NON_CANONICAL_DEBUG`; debuggable=`true`
- SDK: min 26 / target 36 / compile 36
- UI observed: Jetpack Compose, Material3
- permissions observed: `android.permission.INTERNET`, `android.permission.ACCESS_COARSE_LOCATION`, `org.federationofavatars.brotherhood.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION`
- signing: V2 valid; Android Debug signer; canonical development signer not configured; update continuity not guaranteed
- **Limitation:** supplied archive contains compiled APK + reports, not the source Gradle/Kotlin tree; exact Brotherhood `.kt` paths are therefore `not_verified`.

### Verified Brotherhood targets

| ID | Verified symbol | Capabilities |
|---|---|---|
| TGT-AUTH-001 | `org.federationofavatars.brotherhood.auth.AuthGateway` | authentication |
| TGT-AUTH-002 | `org.federationofavatars.brotherhood.auth.AuthConfiguration` | authentication |
| TGT-AUTH-003 | `org.federationofavatars.brotherhood.auth.AuthResult` | authentication |
| TGT-CRYPTO-001 | `org.federationofavatars.brotherhood.crypto.PrivateChatCrypto` | chat-messaging, secure-storage |
| TGT-DATA-001 | `org.federationofavatars.brotherhood.data.AssessmentCatalog` | assessment-engine |
| TGT-DATA-002 | `org.federationofavatars.brotherhood.data.AssessmentLocalStore` | assessment-engine, local-storage |
| TGT-DATA-003 | `org.federationofavatars.brotherhood.data.BrotherhoodCacheStore` | local-storage |
| TGT-DATA-004 | `org.federationofavatars.brotherhood.data.ProfileLocalStore` | local-storage |
| TGT-DATA-005 | `org.federationofavatars.brotherhood.data.ProfileAvatarStore` | profile-media, local-storage |
| TGT-DATA-006 | `org.federationofavatars.brotherhood.data.SettingsStore` | settings-preferences, local-storage |
| TGT-DATA-007 | `org.federationofavatars.brotherhood.data.NumerologyKnowledgeCatalog` | numerology |
| TGT-DOM-001 | `org.federationofavatars.brotherhood.domain.AssessmentScorer` | assessment-engine |
| TGT-DOM-002 | `org.federationofavatars.brotherhood.domain.NumerologyReadingEngine` | numerology |
| TGT-DOM-003 | `org.federationofavatars.brotherhood.domain.VedicNumerologyEngine` | numerology |
| TGT-DOM-004 | `org.federationofavatars.brotherhood.domain.FriendshipCompatibilityEngine` | discovery-matching, vedic-compatibility |
| TGT-DOM-005 | `org.federationofavatars.brotherhood.domain.HybridCompatibilityEngine` | discovery-matching, vedic-compatibility |
| TGT-DOM-006 | `org.federationofavatars.brotherhood.domain.QualityMatchingEngine` | discovery-matching |
| TGT-DOM-007 | `org.federationofavatars.brotherhood.domain.SelfAnalysisEngine` | assessment-engine, personality-assessment |
| TGT-DOM-008 | `org.federationofavatars.brotherhood.domain.ZodiacEngine` | vedic-compatibility |
| TGT-LOC-001 | `org.federationofavatars.brotherhood.location.CityLocationResolver` | location-maps |
| TGT-NET-001 | `org.federationofavatars.brotherhood.network.BrotherhoodApi` | networking-http |
| TGT-NET-002 | `org.federationofavatars.brotherhood.network.ChatRemoteRepository` | chat-messaging, networking-http |
| TGT-NET-003 | `org.federationofavatars.brotherhood.network.RemoteDataRepository` | networking-http |
| TGT-UI-001 | `org.federationofavatars.brotherhood.ui.MainViewModel` | state-management |
| TGT-UI-002 | `ChatScreen` | chat-messaging |
| TGT-UI-003 | `MessagesScreen` | chat-messaging |
| TGT-UI-004 | `SettingsScreen` | settings-preferences |
| TGT-UI-005 | `TestsScreen` | assessment-engine |
| TGT-UI-006 | `SelfAnalysisScreen` | assessment-engine, personality-assessment |
| TGT-UI-007 | `QuickDiscoveryCard` | discovery-matching, swipe-discovery-ui |
| TGT-UPDATE-001 | `checkForUpdate` | app-update |
| TGT-I18N-001 | `not_applicable` | — |
| TGT-NUM-DATA-001 | `not_applicable` | numerology |

## Source resolution overview

| ID | Original user URL | Resolution status | Current/candidate | License status | Priority |
|---|---|---|---|---|---|
| SRC-001 | https://github.com/Mentalys/mentalys-app-android | `resolved-current-repository` | https://github.com/Mentalys-App/mentalys-app-android | verified-current-repository | P1 |
| SRC-002 | https://github.com/VedAstro/VedAstro | `active` | https://github.com/VedAstro/VedAstro | verified | P0 |
| SRC-003 | https://github.com/tomasz-kolek/Personality-Test | `unresolved` | not_resolved | requires-verification | P2 |
| SRC-004 | https://github.com/nikitakapoor/Numerology | `unresolved` | not_resolved | requires-verification | P1 |
| SRC-005 | https://github.com/alexthegr8/Big-Five-Personality-Test | `candidate-resolution` | https://github.com/adriantache/Big-Five-Personality-Test | requires-verification-for-original; candidate MIT | P1 |
| SRC-006 | https://github.com/qflock/android-java-dating-app | `candidate-resolution` | https://github.com/problemsolver-eng/android-java-dating-app; https://github.com/GoldenBoyPapoy/android-java-dating-app | requires-verification | P1 |
| SRC-007 | https://github.com/DostiPak/DostiPak | `candidate-resolution` | https://github.com/ABDULKARIMALBAIK/DostiPak | requires-verification-for-original; candidate MIT | P2 |
| SRC-008 | https://github.com/skgadi/tindev | `candidate-resolution` | https://github.com/CarlosLevir/Tindev | requires-verification-for-original; candidate README states MIT | P2 |
| SRC-009 | https://github.com/alex-kruger/tinder-react-native | `candidate-resolution` | https://github.com/stevenpersia/tinder-react-native | requires-verification-for-original; candidate page shows MIT | P3 |
| SRC-010 | https://github.com/filippm/tinder-clone | `unresolved` | not_resolved | requires-verification | P3 |
| SRC-011 | https://github.com/pegava/pegava-dating-app | `candidate-resolution-archived` | https://github.com/GSTJ/pegava-dating-app | requires-verification-for-original; candidate CC0-1.0 | P2 |
| SRC-012 | https://github.com/aungpyaephyo1412/Complete-Dating-App | `candidate-resolution` | https://github.com/mohamedYassser/Complete-Dating-App; https://github.com/helloharendra/Complete-Dating-App | requires-verification | P2 |
| SRC-013 | https://github.com/humbble/humbble | `candidate-resolution` | https://github.com/Prakashchandra-007/humbble | requires-verification-for-original; candidate MIT | P2 |
| SRC-014 | https://github.com/Alovoa/alovoa | `active` | https://github.com/Alovoa/alovoa | verified | P1 |

## Normalized capability map

### assessment-engine (`CAP-001`)

Assessment/questionnaire definition, scoring and result production.
Implementations/evidence entries: none verified.

### personality-assessment (`CAP-002`)

Personality trait/profile assessment flows.
Implementations/evidence entries: `ELM-025`.

### numerology (`CAP-003`)

Numerology calculations and interpretation data.
Implementations/evidence entries: `ELM-008`, `ELM-009`, `ELM-010`.

### vedic-compatibility (`CAP-004`)

Vedic/astrological compatibility and match scoring.
Implementations/evidence entries: `ELM-011`, `ELM-012`.

### discovery-matching (`CAP-005`)

Candidate discovery/ranking/matching.
Implementations/evidence entries: `ELM-018`, `ELM-026`, `ELM-027`.

### swipe-discovery-ui (`CAP-006`)

Swipe/card interaction for discovery.
Implementations/evidence entries: `ELM-015`, `ELM-028`.

### authentication (`CAP-007`)

Authentication/client identity flow.
Implementations/evidence entries: `ELM-016`.

### local-storage (`CAP-008`)

Persistent local application data.
Implementations/evidence entries: `ELM-002`.

### settings-preferences (`CAP-009`)

Persistent user settings/preferences.
Implementations/evidence entries: `ELM-003`.

### networking-http (`CAP-010`)

HTTP client/API access.
Implementations/evidence entries: `ELM-004`.

### navigation (`CAP-011`)

Application navigation/routing.
Implementations/evidence entries: `ELM-007`, `ELM-017`.

### camera-media (`CAP-012`)

Camera/image/media capture or presentation.
Implementations/evidence entries: `ELM-005`.

### location-maps (`CAP-013`)

Location resolution and map integration.
Implementations/evidence entries: `ELM-006`, `ELM-022`.

### chat-messaging (`CAP-014`)

Direct/group messaging client patterns.
Implementations/evidence entries: none verified.

### secure-storage (`CAP-015`)

Security-sensitive local secret/session storage.
Implementations/evidence entries: `ELM-021`.

### profile-media (`CAP-016`)

Profile/avatar image selection/manipulation.
Implementations/evidence entries: `ELM-023`.

### app-update (`CAP-017`)

Client update delivery/checking.
Implementations/evidence entries: `ELM-024`.

### state-management (`CAP-018`)

Client state management/persistence.
Implementations/evidence entries: `ELM-014`.

### license-compliance (`CAP-019`)

License gate that constrains implementation mode.
Implementations/evidence entries: `ELM-019`.

### build-release (`CAP-020`)

Android/mobile build and dependency architecture.
Implementations/evidence entries: `ELM-001`, `ELM-013`, `ELM-020`.

## Detailed source records

## SRC-001 — Mentalys Android App

- **Archive name:** `mentalys-app-android-master.zip`
- **Original user source:** https://github.com/Mentalys/mentalys-app-android
- **Original URL status:** `missing-at-original-url`
- **Resolution status:** `resolved-current-repository`
- **Current URL:** https://github.com/Mentalys-App/mentalys-app-android
- **Continuity:** high-confidence current project resolution; historical transfer event not independently reconstructed
- **Default branch:** `master`
- **Audited commit:** `2146bebf5c9c936246adee914d17ee2366a5f3ac`
- **Last activity:** `2025-02-24`
- **Archived:** `False`
- **Maintenance:** inactive-or-low-activity; requires verification before production adoption
- **License:** `MIT` — verified-current-repository
- **Category:** Android reference app / mental-health assessment
- **Purpose:** Android application reference for persistence, networking, camera/media, location/maps, navigation and build setup.
- **Capabilities:** `build-release`, `local-storage`, `settings-preferences`, `networking-http`, `camera-media`, `location-maps`, `navigation`
- **Classification:** `architecture-reference`, `sample-reference`, `ux-reference`, `build-reference`
- **Brotherhood targets:** `TGT-DATA-002`, `TGT-DATA-003`, `TGT-DATA-004`, `TGT-DATA-006`, `TGT-NET-001`, `TGT-LOC-001`
- **Recommendation:** P1 architecture/reference source. Do not transplant its View-based architecture over Brotherhood Compose; evaluate individual patterns only.
- **Blocking conditions:**
  - Brotherhood source Gradle tree was not supplied
  - Existing storage/network implementations must be inspected before adding dependencies
- **Evidence:** `EVD-001`, `EVD-002`, `EVD-003`, `EVD-004`, `EVD-005`

### Verified/candidate elements

#### ELM-001 — Mentalys Android build profile

- Capability: `build-release`
- Evidence grade/status: **A** / `verified-code`
- Description: Verified application Gradle configuration: compileSdk 35, minSdk 24, targetSdk 35, Kotlin/JVM 11, viewBinding and BuildConfig enabled.
- Implementation: `build-reference`
- Verified source path: `app/build.gradle.kts@2146bebf5c9c936246adee914d17ee2366a5f3ac`
- Verified symbol: `android/defaultConfig/buildFeatures`
- Dependencies: AGP 8.7.2; Kotlin 2.0.20; KSP 2.0.20-1.0.24
- Brotherhood targets: none
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Decision: P2 build reference only; Brotherhood already targets SDK 36 and uses Compose.
- Evidence: `EVD-003`, `EVD-004`, `EVD-005`

#### ELM-002 — Mentalys Room persistence stack

- Capability: `local-storage`
- Evidence grade/status: **A** / `verified-code`
- Description: Room runtime/ktx/compiler/paging dependencies are declared in the verified Gradle files.
- Implementation: `architecture-reference`
- Verified source path: `app/build.gradle.kts@2146bebf5c9c936246adee914d17ee2366a5f3ac`
- Verified symbol: `dependencies: androidx.room runtime/ktx/compiler/paging`
- Dependencies: androidx.room 2.6.1 + KSP
- Brotherhood targets: `TGT-DATA-002`, `TGT-DATA-004`, `TGT-DATA-003`
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - Need Brotherhood source tree and storage schema
  - Need migration/data-loss plan
- Decision: P1 candidate architecture only; do not add Room until existing store implementation is known.
- Evidence: `EVD-003`, `EVD-004`, `EVD-005`

#### ELM-003 — Mentalys DataStore preferences stack

- Capability: `settings-preferences`
- Evidence grade/status: **A** / `verified-code`
- Description: AndroidX DataStore Preferences and AndroidX Preference dependencies are explicitly declared.
- Implementation: `architecture-reference`
- Verified source path: `app/build.gradle.kts@2146bebf5c9c936246adee914d17ee2366a5f3ac`
- Verified symbol: `dependencies: androidx.datastore.preferences + androidx.preference`
- Dependencies: androidx.datastore:datastore-preferences 1.1.1; androidx.preference 1.2.1
- Brotherhood targets: `TGT-DATA-006`
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - Inspect SettingsStore source and persistence format
- Decision: P1 reference. Prefer existing project mechanism unless source audit proves a concrete need.
- Evidence: `EVD-003`, `EVD-004`, `EVD-005`

#### ELM-004 — Mentalys Retrofit/OkHttp networking stack

- Capability: `networking-http`
- Evidence grade/status: **A** / `verified-code`
- Description: Retrofit, Gson converter, OkHttp and logging-interceptor dependencies are declared.
- Implementation: `architecture-reference`
- Verified source path: `app/build.gradle.kts@2146bebf5c9c936246adee914d17ee2366a5f3ac`
- Verified symbol: `dependencies: retrofit/okhttp/logging-interceptor`
- Dependencies: Retrofit 2.11.0; OkHttp 4.12.0; converter-gson 2.11.0
- Brotherhood targets: `TGT-NET-001`, `TGT-NET-003`
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - Inspect Brotherhood network source/API contracts
  - TLS/logging/security review
  - Measure dependency impact
- Decision: P2: do not add a networking stack merely because reference app uses it.
- Evidence: `EVD-003`, `EVD-004`, `EVD-005`

#### ELM-005 — Mentalys CameraX stack

- Capability: `camera-media`
- Evidence grade/status: **A** / `verified-code`
- Description: CameraX camera2/lifecycle/view dependencies are declared.
- Implementation: `architecture-reference`
- Verified source path: `app/build.gradle.kts@2146bebf5c9c936246adee914d17ee2366a5f3ac`
- Verified symbol: `dependencies: camera-camera2/camera-lifecycle/camera-view`
- Dependencies: CameraX 1.4.0
- Brotherhood targets: `TGT-DATA-005`
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - Confirm actual camera requirement
  - Permission/privacy UX review
- Decision: P3 unless a real Brotherhood camera feature is specified.
- Evidence: `EVD-003`, `EVD-004`, `EVD-005`

#### ELM-006 — Mentalys Maps and location stack

- Capability: `location-maps`
- Evidence grade/status: **A** / `verified-code`
- Description: Google Play Services Maps and Location dependencies are declared.
- Implementation: `architecture-reference`
- Verified source path: `app/build.gradle.kts@2146bebf5c9c936246adee914d17ee2366a5f3ac`
- Verified symbol: `dependencies: play-services-maps/play-services-location`
- Dependencies: play-services-location 21.3.0; play-services-maps 19.0.0
- Brotherhood targets: `TGT-LOC-001`
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - Confirm whether map rendering is required
  - Location permission/minimization review
- Decision: P2 location reference; Maps dependency is not justified without a verified map target.
- Evidence: `EVD-003`, `EVD-004`, `EVD-005`

#### ELM-007 — Mentalys Fragment Navigation stack

- Capability: `navigation`
- Evidence grade/status: **A** / `verified-code`
- Description: AndroidX Navigation Fragment/UI KTX dependencies are declared in a Views/ViewBinding app.
- Implementation: `architecture-reference`
- Verified source path: `app/build.gradle.kts@2146bebf5c9c936246adee914d17ee2366a5f3ac`
- Verified symbol: `dependencies: navigation-fragment-ktx/navigation-ui-ktx`
- Dependencies: AndroidX Navigation 2.8.3
- Brotherhood targets: none
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - None for reference; BLOCKED as direct architecture replacement without separate migration decision
- Decision: P3 reference only; do not replace Compose navigation/routing with Fragment stack.
- Evidence: `EVD-003`, `EVD-004`, `EVD-005`


## SRC-002 — VedAstro

- **Archive name:** `VedAstro-master.zip`
- **Original user source:** https://github.com/VedAstro/VedAstro
- **Original URL status:** `active`
- **Resolution status:** `active`
- **Current URL:** https://github.com/VedAstro/VedAstro
- **Continuity:** exact original repository
- **Default branch:** `master`
- **Audited commit:** `50bd1041e1e6440a49702f593b4a1ec9367f6e3d`
- **Last activity:** `2026-07-26`
- **Archived:** `False`
- **Maintenance:** active-observed
- **License:** `MIT` — verified
- **Category:** Vedic astrology / numerology / compatibility engine
- **Purpose:** Open-source Vedic astrology calculations, numerology, match/compatibility calculations, API/library reference.
- **Capabilities:** `numerology`, `vedic-compatibility`
- **Classification:** `copy-and-adapt`, `architecture-reference`, `sample-reference`, `algorithm-reference`
- **Brotherhood targets:** `TGT-DATA-007`, `TGT-DOM-002`, `TGT-DOM-003`, `TGT-DOM-004`, `TGT-DOM-005`, `TGT-DOM-008`, `TGT-NUM-DATA-001`
- **Recommendation:** P0 thematic reference. Exact algorithms are production candidates only after method-by-method correctness, domain, licensing and regression validation; C# code is not an Android dependency.
- **Blocking conditions:**
  - Cross-language adaptation must be tested against source fixtures/tests
  - Astrology/numerology interpretation semantics must be explicitly selected by product requirements
- **Evidence:** `EVD-006`, `EVD-007`, `EVD-008`, `EVD-009`, `EVD-010`

### Verified/candidate elements

#### ELM-008 — VedAstro BirthNumber

- Capability: `numerology`
- Evidence grade/status: **A** / `verified-code`
- Description: Reduces the day-of-month digits until a single digit is produced.
- Implementation: `copy-and-adapt`
- Verified source path: `Library/Logic/Calculate/Numerology.cs@50bd1041e1e6440a49702f593b4a1ec9367f6e3d`
- Verified symbol: `Calculate.BirthNumber(Time)`
- Dependencies: VedAstro Library Time abstraction; LINQ
- Brotherhood targets: `TGT-DOM-003`, `TGT-DOM-002`
- States: ['input-birth-time', 'single-digit-result']
- Security: No security-sensitive operation in inspected method; domain correctness tests required.
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - Cross-check with Brotherhood numerology canon
  - Golden-vector tests before production
- Decision: P0 reference/port candidate because exact algorithm is verified and target engines exist.
- Evidence: `EVD-008`, `EVD-010`

#### ELM-009 — VedAstro DestinyNumber

- Capability: `numerology`
- Evidence grade/status: **A** / `verified-code`
- Description: Sums digits from date/month/year text and repeatedly reduces to one digit.
- Implementation: `copy-and-adapt`
- Verified source path: `Library/Logic/Calculate/Numerology.cs@50bd1041e1e6440a49702f593b4a1ec9367f6e3d`
- Verified symbol: `Calculate.DestinyNumber(Time)`
- Dependencies: VedAstro Time.StdDateMonthYearText; LINQ
- Brotherhood targets: `TGT-DOM-003`, `TGT-DOM-002`
- States: ['input-birth-time', 'single-digit-result']
- Security: No security-sensitive operation in inspected method.
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - Validate date parsing/format assumptions
  - Golden-vector comparison
- Decision: P0 reference/port candidate.
- Evidence: `EVD-008`, `EVD-010`

#### ELM-010 — VedAstro Chaldean NameNumber

- Capability: `numerology`
- Evidence grade/status: **A** / `verified-code`
- Description: Implements a Chaldean letter-value mapping, mixed alphanumeric handling and special handling for initials.
- Implementation: `copy-and-adapt`
- Verified source path: `Library/Logic/Calculate/Numerology.cs@50bd1041e1e6440a49702f593b4a1ec9367f6e3d`
- Verified symbol: `Calculate.NameNumber(string)`
- Dependencies: System.Text.RegularExpressions; dictionaries
- Brotherhood targets: `TGT-DOM-002`, `TGT-DATA-007`
- States: ['numeric-input', 'mixed-alphanumeric-input', 'alphabetic-name-input', 'integer-result']
- Security: Names are personal data; do not log raw names; privacy review required in Brotherhood.
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - Define multilingual/transliteration canon
  - Privacy/logging review
  - Golden-vector tests
- Decision: P1: algorithmically relevant, but not production-ready for multilingual Brotherhood without explicit language policy.
- Evidence: `EVD-008`

#### ELM-011 — VedAstro MatchReportFactory

- Capability: `vedic-compatibility`
- Evidence grade/status: **A** / `verified-code`
- Description: Creates a compatibility report by running a list of match calculators, isolating calculator failures, applying exceptions, calculating Kuta score and embeddings.
- Implementation: `architecture-reference`
- Verified source path: `Library/Logic/Factory/MatchReportFactory.cs@50bd1041e1e6440a49702f593b4a1ec9367f6e3d`
- Verified symbol: `MatchReportFactory.GetNewMatchReport(Person, Person, string)`
- Dependencies: VedAstro Person/MatchPrediction/Calculate domain model
- Brotherhood targets: `TGT-DOM-004`, `TGT-DOM-005`
- States: ['calculator-run', 'calculator-failed->empty-prediction', 'report-built', 'exceptions-applied', 'score-calculated']
- Security: Birth data is sensitive personal data; storage/network handling must remain under Brotherhood privacy/security controls.
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - Domain semantics review
  - Gender/model assumptions review
  - Golden comparison set
  - License notices if code is ported
- Decision: P0 architecture/reference candidate for compatibility engine, not direct dependency.
- Evidence: `EVD-009`

#### ELM-012 — VedAstro Kuta calculator set

- Capability: `vedic-compatibility`
- Evidence grade/status: **A** / `verified-code`
- Description: Verified calculator list includes GrahaMaitram, Rajju, NadiKuta, VasyaKuta, DinaKuta, GunaKuta, Mahendra, StreeDeergha, RasiKuta, VedhaKuta, Varna, YoniKuta, LagnaAndHouse7Good, KujaDosa, BadConstellations and SexEnergy.
- Implementation: `architecture-reference`
- Verified source path: `Library/Logic/Factory/MatchReportFactory.cs@50bd1041e1e6440a49702f593b4a1ec9367f6e3d`
- Verified symbol: `MatchReportFactory calculator methods`
- Dependencies: VedAstro Calculate ephemeris/domain functions
- Brotherhood targets: `TGT-DOM-004`, `TGT-DOM-005`
- States: ['good', 'bad', 'neutral', 'empty-on-calculator-failure']
- Security: Birth time/location and relationship inference are sensitive; requires privacy/product review.
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - Method-by-method domain validation
  - Source citations/attribution
  - Test vectors
- Decision: P1: mine individual rules selectively; do not port the whole factory blindly.
- Evidence: `EVD-009`


## SRC-003 — Personality-Test

- **Archive name:** `Personality-Test-master.zip`
- **Original user source:** https://github.com/tomasz-kolek/Personality-Test
- **Original URL status:** `missing-at-original-url`
- **Resolution status:** `unresolved`
- **Current URL:** not_resolved
- **Continuity:** not_verified
- **Default branch:** `unknown`
- **Audited commit:** `unknown`
- **Last activity:** `unknown`
- **Archived:** `unknown`
- **Maintenance:** unknown
- **License:** `unknown` — requires-verification
- **Category:** personality assessment
- **Purpose:** User-declared personality-test source; exact current contents unavailable.
- **Capabilities:** `personality-assessment`, `assessment-engine`
- **Classification:** `blocked`, `historical-reference`
- **Brotherhood targets:** `TGT-DATA-001`, `TGT-DOM-001`, `TGT-DOM-007`, `TGT-UI-005`, `TGT-UI-006`
- **Recommendation:** BLOCKED for code reuse; retain as historical registry entry until original archive or canonical successor is verified.
- **Blocking conditions:**
  - Repository unavailable at original URL
  - License unknown
  - No verified canonical continuation
- **Evidence:** `EVD-031`

## SRC-004 — Numerology

- **Archive name:** `Numerology-main.zip`
- **Original user source:** https://github.com/nikitakapoor/Numerology
- **Original URL status:** `missing-at-original-url`
- **Resolution status:** `unresolved`
- **Current URL:** not_resolved
- **Continuity:** not_verified
- **Default branch:** `unknown`
- **Audited commit:** `unknown`
- **Last activity:** `unknown`
- **Archived:** `unknown`
- **Maintenance:** unknown
- **License:** `unknown` — requires-verification
- **Category:** numerology
- **Purpose:** User-declared numerology source.
- **Capabilities:** `numerology`
- **Classification:** `blocked`, `historical-reference`
- **Brotherhood targets:** `TGT-DATA-007`, `TGT-DOM-002`, `TGT-DOM-003`, `TGT-NUM-DATA-001`
- **Recommendation:** BLOCKED for copying; use VedAstro as the currently verified implementation source until this original source is recovered.
- **Blocking conditions:**
  - Repository unavailable at original URL
  - License unknown
  - No canonical continuation verified
- **Evidence:** `EVD-032`

## SRC-005 — Big-Five-Personality-Test

- **Archive name:** `Big-Five-Personality-Test-master.zip`
- **Original user source:** https://github.com/alexthegr8/Big-Five-Personality-Test
- **Original URL status:** `missing-at-original-url`
- **Resolution status:** `candidate-resolution`
- **Current URL:** not_resolved
- **Continuity:** not_verified
- **Candidate URLs (not canonical replacements):**
  - https://github.com/adriantache/Big-Five-Personality-Test
- **Default branch:** `unknown-for-original`
- **Audited commit:** `unknown-for-original`
- **Last activity:** `unknown-for-original`
- **Archived:** `unknown-for-original`
- **Maintenance:** original unknown; candidate last observed commit 2021-01-12
- **License:** `unknown-for-original` — requires-verification-for-original; candidate MIT
- **Category:** Big Five personality assessment
- **Purpose:** Potential Big Five/IPIP questionnaire and scoring reference.
- **Capabilities:** `personality-assessment`, `assessment-engine`, `local-storage`
- **Classification:** `candidate`, `assessment-reference`
- **Brotherhood targets:** `TGT-DATA-001`, `TGT-DATA-002`, `TGT-DOM-001`, `TGT-DOM-007`, `TGT-UI-005`, `TGT-UI-006`
- **Recommendation:** P1 candidate reference only. The adriantache repository is technically relevant, but cannot be declared the successor of the user source without provenance evidence.
- **Blocking conditions:**
  - Original repository continuity not established
  - Do not attribute candidate MIT license to missing original
  - Psychometric scoring/translation changes require validation
- **Evidence:** `EVD-033`, `EVD-040`, `EVD-041`

### Verified/candidate elements

#### ELM-025 — Big Five 50-item IPIP assessment candidate

- Capability: `personality-assessment`; secondary: `assessment-engine`, `local-storage`
- Evidence grade/status: **B** / `verified-official-repository-docs-for-candidate`
- Candidate repository only: https://github.com/adriantache/Big-Five-Personality-Test
- Description: Candidate README verifies a 50-item IPIP Big Five test, Kotlin rewrite, corrected scoring, MVVM and Room; translation is intentionally not offered because unvalidated translation could skew psychometric results.
- Implementation: `architecture-reference`
- Verified source path: `README.md@master`
- Verified symbol: `repository-level feature/architecture statement`
- Dependencies: Room/MVVM stated by README; exact current dependency versions not verified
- Brotherhood targets: `TGT-DATA-001`, `TGT-DATA-002`, `TGT-DOM-001`, `TGT-DOM-007`, `TGT-UI-005`, `TGT-UI-006`
- States: requires-verification from source code
- Security: low security sensitivity; assessment data privacy still requires review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT for candidate only (Original user-source license remains unknown; candidate license must not be back-propagated to original.)
- Blocking conditions:
  - Provenance continuity unresolved
  - Validate scoring against selected Big Five/IPIP instrument
  - Do not translate items without validated psychometric methodology
- Decision: P1 assessment reference candidate; method/instrument validation is more important than UI reuse.
- Evidence: `EVD-040`, `EVD-041`


## SRC-006 — android-java-dating-app

- **Archive name:** `android-java-dating-app-main.zip`
- **Original user source:** https://github.com/qflock/android-java-dating-app
- **Original URL status:** `missing-at-original-url`
- **Resolution status:** `candidate-resolution`
- **Current URL:** not_resolved
- **Continuity:** not_verified
- **Candidate URLs (not canonical replacements):**
  - https://github.com/problemsolver-eng/android-java-dating-app
  - https://github.com/GoldenBoyPapoy/android-java-dating-app
- **Default branch:** `unknown-for-original`
- **Audited commit:** `unknown-for-original`
- **Last activity:** `unknown-for-original`
- **Archived:** `unknown-for-original`
- **Maintenance:** unknown
- **License:** `unknown-for-original` — requires-verification
- **Category:** Android Java dating reference app
- **Purpose:** Potential native Android Java/XML dating UX source: swipe, match, chat, profile, settings.
- **Capabilities:** `swipe-discovery-ui`, `discovery-matching`, `chat-messaging`, `profile-media`, `navigation`
- **Classification:** `candidate`, `ux-reference`, `sample-reference`
- **Brotherhood targets:** `TGT-UI-002`, `TGT-UI-003`, `TGT-UI-007`, `TGT-DOM-006`
- **Recommendation:** P2 UX/sample reference. Brotherhood is Compose, so Java/XML code should not be adopted as framework architecture.
- **Blocking conditions:**
  - Original provenance unresolved
  - Candidate license not established in this pass
  - Need source-level review before copying any code/assets
- **Evidence:** `EVD-034`, `EVD-042`, `EVD-050`

## SRC-007 — DostiPak

- **Archive name:** `DostiPak-main.zip`
- **Original user source:** https://github.com/DostiPak/DostiPak
- **Original URL status:** `missing-at-original-url`
- **Resolution status:** `candidate-resolution`
- **Current URL:** not_resolved
- **Continuity:** not_verified
- **Candidate URLs (not canonical replacements):**
  - https://github.com/ABDULKARIMALBAIK/DostiPak
- **Default branch:** `unknown-for-original`
- **Audited commit:** `unknown-for-original`
- **Last activity:** `unknown-for-original`
- **Archived:** `unknown-for-original`
- **Maintenance:** unknown
- **License:** `unknown-for-original` — requires-verification-for-original; candidate MIT
- **Category:** Flutter/Firebase dating reference candidate
- **Purpose:** Dating product/UX reference with swipe, match, messaging, filters, location, push and account flows.
- **Capabilities:** `swipe-discovery-ui`, `discovery-matching`, `chat-messaging`, `authentication`, `location-maps`, `profile-media`, `app-update`
- **Classification:** `candidate`, `ux-reference`, `architecture-reference`
- **Brotherhood targets:** `TGT-AUTH-001`, `TGT-LOC-001`, `TGT-NET-002`, `TGT-UI-002`, `TGT-UI-003`, `TGT-UI-007`, `TGT-UPDATE-001`
- **Recommendation:** P2 UX/reference only. Candidate is Flutter/Firebase and must not become a native Compose dependency.
- **Blocking conditions:**
  - Original continuity unresolved
  - Candidate features must be treated as reference, not proof of original source
  - Security/privacy review required for auth/location/chat patterns
- **Evidence:** `EVD-035`, `EVD-043`, `EVD-044`

### Verified/candidate elements

#### ELM-026 — DostiPak dating flow catalogue candidate

- Capability: `discovery-matching`; secondary: `swipe-discovery-ui`, `chat-messaging`, `authentication`, `location-maps`, `app-update`
- Evidence grade/status: **B** / `verified-official-repository-docs-for-candidate`
- Candidate repository only: https://github.com/ABDULKARIMALBAIK/DostiPak
- Description: Candidate README documents swipe left/right, match dialog, text/image chat, phone authentication, report/delete/hide profile, GPS distance filters, push notifications and update redirection.
- Implementation: `ux-reference`
- Verified source path: `README.md@main`
- Verified symbol: `repository-level feature list`
- Dependencies: Firebase/Cloud Firestore stated; exact package versions not_verified
- Brotherhood targets: `TGT-AUTH-001`, `TGT-LOC-001`, `TGT-NET-002`, `TGT-UI-002`, `TGT-UI-003`, `TGT-UI-007`, `TGT-UPDATE-001`
- States: requires-verification from source code
- Security: auth/chat/location are security-sensitive; reference code cannot be transplanted without audit
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT for candidate only (Do not attribute to missing original)
- Blocking conditions:
  - Original provenance unresolved
  - Separate security/privacy audit
  - Native Compose redesign required
- Decision: P2 feature/UX catalogue only.
- Evidence: `EVD-043`, `EVD-044`


## SRC-008 — tindev

- **Archive name:** `tindev-main.zip`
- **Original user source:** https://github.com/skgadi/tindev
- **Original URL status:** `missing-at-original-url`
- **Resolution status:** `candidate-resolution`
- **Current URL:** not_resolved
- **Continuity:** not_verified
- **Candidate URLs (not canonical replacements):**
  - https://github.com/CarlosLevir/Tindev
- **Default branch:** `unknown-for-original`
- **Audited commit:** `unknown-for-original`
- **Last activity:** `unknown-for-original`
- **Archived:** `unknown-for-original`
- **Maintenance:** unknown
- **License:** `unknown-for-original` — requires-verification-for-original; candidate README states MIT
- **Category:** dating/discovery reference
- **Purpose:** Potential swipe/discovery/matching and real-time architecture reference.
- **Capabilities:** `swipe-discovery-ui`, `discovery-matching`, `chat-messaging`, `networking-http`
- **Classification:** `candidate`, `architecture-reference`, `ux-reference`
- **Brotherhood targets:** `TGT-UI-007`, `TGT-DOM-006`, `TGT-NET-002`
- **Recommendation:** P2 architecture/UX reference. Candidate React Native/Node/MongoDB/Socket.IO stack is not directly compatible as native Android dependency.
- **Blocking conditions:**
  - Original continuity unresolved
  - Do not infer original license from candidate
  - Backend architecture relevance must be evaluated independently
- **Evidence:** `EVD-036`, `EVD-045`, `EVD-051`

### Verified/candidate elements

#### ELM-027 — TinDev realtime dating architecture candidate

- Capability: `discovery-matching`; secondary: `chat-messaging`, `networking-http`, `swipe-discovery-ui`
- Evidence grade/status: **B** / `verified-official-repository-docs-for-candidate`
- Candidate repository only: https://github.com/CarlosLevir/Tindev
- Description: Candidate README verifies a monorepo with mobile React Native, web React, Node backend, MongoDB and Socket.IO realtime layer.
- Implementation: `architecture-reference`
- Verified source path: `README.md@master`
- Verified symbol: `repository-level architecture statement`
- Dependencies: React Native; Node.js; MongoDB; Socket.IO (versions not_verified)
- Brotherhood targets: `TGT-DOM-006`, `TGT-NET-002`, `TGT-UI-007`
- States: requires-verification
- Security: realtime/auth/server boundaries require separate audit
- Accessibility: requires-verification
- Performance: requires-measurement
- License: candidate README states MIT (Original license unknown)
- Blocking conditions:
  - Original provenance unresolved
  - Server protocol/security review
  - Do not transplant React Native stack
- Decision: P2 architecture reference only.
- Evidence: `EVD-045`, `EVD-051`


## SRC-009 — tinder-react-native

- **Archive name:** `tinder-react-native-master.zip`
- **Original user source:** https://github.com/alex-kruger/tinder-react-native
- **Original URL status:** `missing-at-original-url`
- **Resolution status:** `candidate-resolution`
- **Current URL:** not_resolved
- **Continuity:** not_verified
- **Candidate URLs (not canonical replacements):**
  - https://github.com/stevenpersia/tinder-react-native
- **Default branch:** `unknown-for-original`
- **Audited commit:** `unknown-for-original`
- **Last activity:** `unknown-for-original`
- **Archived:** `unknown-for-original`
- **Maintenance:** candidate explicitly unmaintained
- **License:** `unknown-for-original` — requires-verification-for-original; candidate page shows MIT
- **Category:** React Native dating UX reference
- **Purpose:** Swipe/card and discovery screen UX reference.
- **Capabilities:** `swipe-discovery-ui`, `navigation`
- **Classification:** `candidate`, `ux-reference`, `historical-reference`
- **Brotherhood targets:** `TGT-UI-007`
- **Recommendation:** P3 visual/interaction reference only. Candidate itself warns Android has serious UI problems and is unmaintained.
- **Blocking conditions:**
  - Original continuity unresolved
  - Candidate is unmaintained
  - Android UI issues explicitly acknowledged by candidate maintainer
- **Evidence:** `EVD-037`, `EVD-046`, `EVD-052`

### Verified/candidate elements

#### ELM-028 — Tinder React Native swipe UX candidate

- Capability: `swipe-discovery-ui`; secondary: `navigation`
- Evidence grade/status: **B** / `verified-official-repository-docs-for-candidate`
- Candidate repository only: https://github.com/stevenpersia/tinder-react-native
- Description: Candidate provides Explore, Matches, Messages and Profile screens, but its maintainer explicitly states it is no longer maintained and Android has serious UI problems.
- Implementation: `ux-reference`
- Verified source path: `README.md@master`
- Verified symbol: `repository-level maintenance/platform warning`
- Dependencies: React Native; exact versions not_verified
- Brotherhood targets: `TGT-UI-007`
- States: requires-verification
- Security: not primary use
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT for candidate page (Original license unknown)
- Blocking conditions:
  - Do not use as production dependency/code baseline
  - Use only visual interaction concepts after native redesign
- Decision: P3 historical UX reference.
- Evidence: `EVD-046`, `EVD-052`


## SRC-010 — tinder-clone

- **Archive name:** `tinder-clone-master.zip`
- **Original user source:** https://github.com/filippm/tinder-clone
- **Original URL status:** `missing-at-original-url`
- **Resolution status:** `unresolved`
- **Current URL:** not_resolved
- **Continuity:** not_verified
- **Default branch:** `unknown`
- **Audited commit:** `unknown`
- **Last activity:** `unknown`
- **Archived:** `unknown`
- **Maintenance:** unknown
- **License:** `unknown` — requires-verification
- **Category:** dating UX reference
- **Purpose:** User-declared Tinder clone reference.
- **Capabilities:** `swipe-discovery-ui`, `discovery-matching`
- **Classification:** `blocked`, `historical-reference`
- **Brotherhood targets:** `TGT-UI-007`
- **Recommendation:** BLOCKED for code/assets. No canonical current repository established.
- **Blocking conditions:**
  - Repository unavailable at original URL
  - License unknown
  - No canonical replacement
- **Evidence:** `EVD-038`

## SRC-011 — Pegava dating app

- **Archive name:** `pegava-dating-app-master.zip`
- **Original user source:** https://github.com/pegava/pegava-dating-app
- **Original URL status:** `missing-at-original-url`
- **Resolution status:** `candidate-resolution-archived`
- **Current URL:** not_resolved
- **Continuity:** not_verified
- **Candidate URLs (not canonical replacements):**
  - https://github.com/GSTJ/pegava-dating-app
- **Default branch:** `unknown-for-original`
- **Audited commit:** `unknown-for-original`
- **Last activity:** `unknown-for-original`
- **Archived:** `unknown-for-original; candidate archived=true`
- **Maintenance:** candidate archived/reference-only
- **License:** `unknown-for-original` — requires-verification-for-original; candidate CC0-1.0
- **Category:** React Native / Expo dating reference
- **Purpose:** Dating UI/state/navigation reference.
- **Capabilities:** `build-release`, `state-management`, `navigation`, `swipe-discovery-ui`
- **Classification:** `candidate`, `ux-reference`, `historical-reference`
- **Brotherhood targets:** `TGT-UI-001`, `TGT-UI-007`
- **Recommendation:** P3/reference-only. Candidate is archived and points to Pegada for production-ready work; do not add its old Expo stack to Brotherhood.
- **Blocking conditions:**
  - Original continuity unresolved
  - Candidate archived
  - Old React Native/Expo dependency stack
  - Production use should evaluate successor independently
- **Evidence:** `EVD-011`, `EVD-012`, `EVD-013`, `EVD-047`

### Verified/candidate elements

#### ELM-013 — Pegava Expo/React Native client stack

- Capability: `build-release`
- Evidence grade/status: **A** / `verified-code`
- Description: Archived client package manifest pins Expo 48 and React Native 0.71.3 with TypeScript 4.9.4.
- Implementation: `historical-reference`
- Verified source path: `package.json@85785d49f51f9b9b030e8ab65ee9be5da63bab08`
- Verified symbol: `dependencies/devDependencies`
- Dependencies: Expo 48; React Native 0.71.3; TypeScript 4.9.4
- Brotherhood targets: none
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: CC0-1.0 (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - BLOCKED as production dependency
- Decision: P3 historical reference only.
- Evidence: `EVD-011`, `EVD-012`, `EVD-013`

#### ELM-014 — Pegava React Navigation + Redux persistence stack

- Capability: `state-management`
- Evidence grade/status: **A** / `verified-code`
- Description: Manifest declares React Navigation 6.x, Redux Toolkit/Redux, redux-persist and redux-saga.
- Implementation: `ux-reference`
- Verified source path: `package.json@85785d49f51f9b9b030e8ab65ee9be5da63bab08`
- Verified symbol: `dependencies: @react-navigation/*, redux*, @reduxjs/toolkit`
- Dependencies: React Navigation; Redux Toolkit; redux-persist; redux-saga
- Brotherhood targets: `TGT-UI-001`
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: CC0-1.0 (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - Do not import RN state stack
- Decision: P3: use only as historical UX/state reference.
- Evidence: `EVD-013`


## SRC-012 — Complete-Dating-App

- **Archive name:** `Complete-Dating-App-main.zip`
- **Original user source:** https://github.com/aungpyaephyo1412/Complete-Dating-App
- **Original URL status:** `missing-at-original-url`
- **Resolution status:** `candidate-resolution`
- **Current URL:** not_resolved
- **Continuity:** not_verified
- **Candidate URLs (not canonical replacements):**
  - https://github.com/mohamedYassser/Complete-Dating-App
  - https://github.com/helloharendra/Complete-Dating-App
- **Default branch:** `unknown-for-original`
- **Audited commit:** `unknown-for-original`
- **Last activity:** `unknown-for-original`
- **Archived:** `unknown-for-original`
- **Maintenance:** unknown
- **License:** `unknown-for-original` — requires-verification
- **Category:** dating reference app
- **Purpose:** User-declared complete dating app reference.
- **Capabilities:** `discovery-matching`, `chat-messaging`, `profile-media`
- **Classification:** `candidate`, `historical-reference`
- **Brotherhood targets:** `TGT-UI-002`, `TGT-UI-003`, `TGT-UI-007`
- **Recommendation:** BLOCKED for copying until ancestry and license are resolved; same-name repositories are only candidates.
- **Blocking conditions:**
  - Original unavailable
  - Multiple ambiguous copies
  - License/provenance not established
- **Evidence:** `EVD-039`, `EVD-049`

## SRC-013 — Humbble

- **Archive name:** `humbble-main.zip`
- **Original user source:** https://github.com/humbble/humbble
- **Original URL status:** `missing-at-original-url`
- **Resolution status:** `candidate-resolution`
- **Current URL:** not_resolved
- **Continuity:** not_verified
- **Candidate URLs (not canonical replacements):**
  - https://github.com/Prakashchandra-007/humbble
- **Default branch:** `unknown-for-original`
- **Audited commit:** `unknown-for-original`
- **Last activity:** `unknown-for-original`
- **Archived:** `unknown-for-original; candidate not archived`
- **Maintenance:** candidate activity observed 2025-11-08
- **License:** `unknown-for-original` — requires-verification-for-original; candidate MIT
- **Category:** React Native / Expo dating reference
- **Purpose:** Swipe/match/chat and authentication/navigation UX reference.
- **Capabilities:** `swipe-discovery-ui`, `authentication`, `navigation`, `chat-messaging`
- **Classification:** `candidate`, `ux-reference`, `sample-reference`
- **Brotherhood targets:** `TGT-AUTH-001`, `TGT-UI-002`, `TGT-UI-003`, `TGT-UI-007`
- **Recommendation:** P2 reference. Candidate is cross-platform Expo and Appwrite-oriented; patterns may be studied, dependencies should not be transplanted into native Compose by default.
- **Blocking conditions:**
  - Original continuity unresolved
  - Backend/auth security model requires separate audit
  - React Native/Expo dependency mismatch with Brotherhood
- **Evidence:** `EVD-014`, `EVD-015`, `EVD-016`, `EVD-017`, `EVD-048`

### Verified/candidate elements

#### ELM-015 — Humbble deck swiper dependency

- Capability: `swipe-discovery-ui`
- Evidence grade/status: **A** / `verified-code`
- Description: Current candidate repository package manifest declares react-native-deck-swiper 2.0.17.
- Implementation: `ux-reference`
- Verified source path: `package.json@393c9ddc795fa97767cbb59d8bb01fc1884ad879`
- Verified symbol: `dependency react-native-deck-swiper`
- Dependencies: react-native-deck-swiper 2.0.17; gesture-handler; reanimated
- Brotherhood targets: `TGT-UI-007`
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - Source usage path not yet verified
  - Native Compose implementation must remain local/Android-native
- Decision: P2 UX reference; do not add React Native dependency to Brotherhood.
- Evidence: `EVD-014`, `EVD-016`, `EVD-017`

#### ELM-016 — Humbble Appwrite client dependency

- Capability: `authentication`
- Evidence grade/status: **A** / `verified-code`
- Description: Current candidate repository package manifest declares Appwrite 20.0.0; latest commit message also references sign-in/sign-up screens using Appwrite as template DB.
- Implementation: `sample-reference`
- Verified source path: `package.json@393c9ddc795fa97767cbb59d8bb01fc1884ad879`
- Verified symbol: `dependency appwrite`
- Dependencies: appwrite 20.0.0
- Brotherhood targets: `TGT-AUTH-001`
- States: not_verified
- Security: Authentication/backend code is security-sensitive; no direct transfer without separate threat model and endpoint/session audit.
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - BLOCKED for production use until security and architecture decision
  - Verify exact source usage
- Decision: P3 reference only; existing Brotherhood auth boundary takes precedence.
- Evidence: `EVD-015`, `EVD-016`, `EVD-017`

#### ELM-017 — Humbble Expo Router/navigation profile

- Capability: `navigation`
- Evidence grade/status: **A** / `verified-code`
- Description: Manifest uses expo-router entry and declares Expo Router 4.0.19 plus React Navigation 7.x.
- Implementation: `ux-reference`
- Verified source path: `package.json@393c9ddc795fa97767cbb59d8bb01fc1884ad879`
- Verified symbol: `main=expo-router/entry; dependencies expo-router/@react-navigation`
- Dependencies: Expo Router 4.0.19; React Navigation 7.x
- Brotherhood targets: none
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MIT (low-to-moderate; verify notices/attribution before copy)
- Blocking conditions:
  - No direct dependency integration
- Decision: P3 navigation UX reference only.
- Evidence: `EVD-016`


## SRC-014 — Alovoa

- **Archive name:** `alovoa-master.zip`
- **Original user source:** https://github.com/Alovoa/alovoa
- **Original URL status:** `active`
- **Resolution status:** `active`
- **Current URL:** https://github.com/Alovoa/alovoa
- **Continuity:** exact original repository
- **Default branch:** `master`
- **Audited commit:** `408e45fbcd34a284ba55f3fe04753cd048b2b46b`
- **Last activity:** `2026-04-29`
- **Archived:** `False`
- **Maintenance:** active-observed
- **License:** `AGPL-3.0` — verified
- **Category:** open-source dating platform / server
- **Purpose:** Full dating-platform architecture/reference including server-side discovery/user/account patterns.
- **Capabilities:** `discovery-matching`, `authentication`, `chat-messaging`, `license-compliance`
- **Classification:** `architecture-reference`, `security-reference`, `license-sensitive-reference`
- **Brotherhood targets:** `TGT-AUTH-001`, `TGT-DOM-006`, `TGT-NET-002`
- **Recommendation:** P1 architecture/reference. Direct copying/adaptation of AGPL-covered server code into a differently licensed distributed product is BLOCKED pending explicit license strategy.
- **Blocking conditions:**
  - AGPL-3.0 compliance decision required before code reuse
  - Security-sensitive server patterns require independent audit
- **Evidence:** `EVD-018`, `EVD-019`, `EVD-020`

### Related source `SRC-014A` — Alovoa Expo mobile client

- URL: https://github.com/Alovoa/alovoa-expo
- Relationship: official mobile client linked to Alovoa project
- Branch/SHA: `master` / `10b74ab11db1af16385b4f951d5fb07b8f0a841c`
- Last activity: `2026-06-14`
- License: `MPL-2.0`
- Stack: Expo 54.0.35 / React Native 0.81.5 / React 19.1.0
- Evidence: `EVD-021`, `EVD-022`, `EVD-023`, `EVD-024`

### Verified/candidate elements

#### ELM-018 — Alovoa dating platform architecture

- Capability: `discovery-matching`
- Evidence grade/status: **C** / `verified-repository`
- Description: Active open-source dating platform repository; useful as an architectural/reference source for profile/discovery/matching/server contracts. Specific source symbols are not yet promoted to Grade A in v001.
- Implementation: `architecture-reference`
- Verified source path: `repository@408e45fbcd34a284ba55f3fe04753cd048b2b46b`
- Verified symbol: `not_verified`
- Dependencies: not_verified
- Brotherhood targets: `TGT-DOM-006`, `TGT-NET-001`
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: AGPL-3.0 (requires-review)
- Blocking conditions:
  - AGPL legal gate before any code copy/adaptation
  - Exact source symbols must be verified before implementation
- Decision: P1 architecture reference; code copy BLOCKED unless AGPL obligations are explicitly accepted.
- Evidence: `EVD-018`, `EVD-019`, `EVD-020`

#### ELM-019 — Alovoa AGPL-3.0 code license gate

- Capability: `license-compliance`
- Evidence grade/status: **A** / `verified-code`
- Description: Primary Alovoa repository LICENSE is GNU Affero General Public License v3.
- Implementation: `blocked`
- Verified source path: `LICENSE@408e45fbcd34a284ba55f3fe04753cd048b2b46b`
- Verified symbol: `GNU AFFERO GENERAL PUBLIC LICENSE Version 3`
- Dependencies: not_applicable
- Brotherhood targets: none
- States: not_verified
- Security: not_applicable
- Accessibility: requires-verification
- Performance: requires-measurement
- License: AGPL-3.0 (requires-review)
- Blocking conditions:
  - Legal/license compatibility decision required before covered code reuse
- Decision: BLOCKED for production copy/adapt by default; reference-only use remains available.
- Evidence: `EVD-020`

#### ELM-020 — Alovoa Expo current mobile dependency profile

- Capability: `build-release`
- Evidence grade/status: **A** / `verified-code`
- Description: Official mobile package manifest at current audit commit uses Expo 54.0.35, React Native 0.81.5, React 19.1.0 and TypeScript 5.9.2.
- Implementation: `sample-reference`
- Verified source path: `package.json@10b74ab11db1af16385b4f951d5fb07b8f0a841c`
- Verified symbol: `dependencies/devDependencies`
- Dependencies: Expo 54.0.35; React Native 0.81.5; TypeScript 5.9.2
- Brotherhood targets: none
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MPL-2.0 (requires-review)
- Blocking conditions:
  - No direct dependency integration
- Decision: P2 contemporary mobile reference, not a stack migration candidate.
- Evidence: `EVD-021`, `EVD-022`, `EVD-023`, `EVD-024`

#### ELM-021 — Alovoa Expo SecureStore dependency

- Capability: `secure-storage`
- Evidence grade/status: **A** / `verified-code`
- Description: Official mobile package manifest declares expo-secure-store ~15.0.8.
- Implementation: `security-reference`
- Verified source path: `package.json@10b74ab11db1af16385b4f951d5fb07b8f0a841c`
- Verified symbol: `dependency expo-secure-store`
- Dependencies: expo-secure-store ~15.0.8
- Brotherhood targets: `TGT-CRYPTO-001`, `TGT-AUTH-001`
- States: not_verified
- Security: Security-sensitive: package presence does not prove how keys/tokens are stored. Exact usage must be audited before deriving a pattern.
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MPL-2.0 (requires-review)
- Blocking conditions:
  - Verify exact Alovoa usage
  - Audit Brotherhood key/session storage
  - Android Keystore design review
- Decision: P1 security reference only.
- Evidence: `EVD-023`, `EVD-024`

#### ELM-022 — Alovoa Expo location dependency

- Capability: `location-maps`
- Evidence grade/status: **A** / `verified-code`
- Description: Official mobile package manifest declares expo-location 19.0.7.
- Implementation: `ux-reference`
- Verified source path: `package.json@10b74ab11db1af16385b4f951d5fb07b8f0a841c`
- Verified symbol: `dependency expo-location`
- Dependencies: expo-location 19.0.7
- Brotherhood targets: `TGT-LOC-001`
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MPL-2.0 (requires-review)
- Blocking conditions:
  - Verify exact Alovoa permission/location flow before borrowing UX
- Decision: P2 reference.
- Evidence: `EVD-023`

#### ELM-023 — Alovoa Expo image/profile media dependencies

- Capability: `profile-media`
- Evidence grade/status: **A** / `verified-code`
- Description: Official mobile manifest declares expo-image-picker and expo-image-manipulator.
- Implementation: `ux-reference`
- Verified source path: `package.json@10b74ab11db1af16385b4f951d5fb07b8f0a841c`
- Verified symbol: `dependencies expo-image-picker/expo-image-manipulator`
- Dependencies: expo-image-picker ~17.0.11; expo-image-manipulator ~14.0.8
- Brotherhood targets: `TGT-DATA-005`
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MPL-2.0 (requires-review)
- Blocking conditions:
  - Verify Android photo/media requirements and privacy handling
- Decision: P2 UX reference.
- Evidence: `EVD-023`

#### ELM-024 — Alovoa Expo updates dependency

- Capability: `app-update`
- Evidence grade/status: **A** / `verified-code`
- Description: Official mobile manifest declares expo-updates ~29.0.18.
- Implementation: `architecture-reference`
- Verified source path: `package.json@10b74ab11db1af16385b4f951d5fb07b8f0a841c`
- Verified symbol: `dependency expo-updates`
- Dependencies: expo-updates ~29.0.18
- Brotherhood targets: `TGT-UPDATE-001`
- States: not_verified
- Security: requires-review
- Accessibility: requires-verification
- Performance: requires-measurement
- License: MPL-2.0 (requires-review)
- Blocking conditions:
  - Do not replace native update mechanism with Expo
- Decision: P3; use only for conceptual update UX comparison.
- Evidence: `EVD-023`


## Decision matrix

| Capability | Priority | Preferred source(s) | Decision rationale | Production gates |
|---|---|---|---|---|
| `numerology` | **P0** | `SRC-002` | VedAstro has exact code paths and tests; SRC-004 is unresolved. | cross-language regression tests; domain semantic decision; license notice compliance |
| `vedic-compatibility` | **P0** | `SRC-002` | VedAstro MatchReportFactory/Kuta code is exact and current; maps directly to Brotherhood compatibility engines as reference/adaptation. | method-by-method validation; sex/gender assumptions review; product semantics; test vectors |
| `personality-assessment` | **P1** | `SRC-005` | Original SRC-005 is missing, but a technically relevant same-name candidate documents 50-item IPIP and scoring architecture; continuity remains unresolved. | instrument provenance; psychometric scoring validation; translation policy; privacy |
| `local-storage` | **P1** | `SRC-001` | Mentalys has verified Room/DataStore declarations, but Brotherhood already has local stores whose source implementation was not supplied. | inspect existing stores; migration/data-loss plan; avoid unnecessary dependency |
| `networking-http` | **P2** | `SRC-001` | Mentalys has verified Retrofit/OkHttp setup; Brotherhood currently exposes BrotherhoodApi and RemoteDataRepository but exact implementation is unknown. | inspect current HTTP stack; TLS/logging/security review; dependency size measurement |
| `swipe-discovery-ui` | **P2** | `SRC-006`, `SRC-007`, `SRC-008`, `SRC-009`, `SRC-011`, `SRC-013` | Multiple references exist but are mostly Java/XML, Flutter or React Native. Use as UX references, then implement natively in Brotherhood Compose. | native Compose design; accessibility; gesture conflict testing; performance |
| `chat-messaging` | **P2** | `SRC-007`, `SRC-008`, `SRC-013`, `SRC-014` | Useful reference patterns exist, but Brotherhood already contains ChatRemoteRepository and PrivateChatCrypto; security boundaries take precedence. | protocol review; crypto/session review; privacy/logging review; background delivery design |
| `license-compliance` | **BLOCKED** | `SRC-014` | Alovoa main repository is AGPL-3.0. Architecture study is allowed; code reuse is blocked pending explicit licensing strategy. | license counsel/strategy; separate covered-code analysis |

## Evidence register

| Evidence | Source | Type | URL / artifact | Confirms | Confidence |
|---|---|---|---|---|---|
| EVD-001 | SRC-001 | GitHub repository metadata/search | https://github.com/Mentalys-App/mentalys-app-android | Resolves current Mentalys repository and default branch/public state; original owner URL unavailable. | high |
| EVD-002 | SRC-001 | GitHub commit | https://github.com/Mentalys-App/mentalys-app-android/commit/2146bebf5c9c936246adee914d17ee2366a5f3ac | Latest commit observed for current repository in this audit. | high |
| EVD-003 | SRC-001 | GitHub source file | https://github.com/Mentalys-App/mentalys-app-android/blob/2146bebf5c9c936246adee914d17ee2366a5f3ac/app/build.gradle.kts | Android SDK levels, plugins, build features and dependency declarations. | high |
| EVD-004 | SRC-001 | GitHub source file | https://github.com/Mentalys-App/mentalys-app-android/blob/2146bebf5c9c936246adee914d17ee2366a5f3ac/gradle/libs.versions.toml | Exact dependency/plugin versions at audited commit. | high |
| EVD-005 | SRC-001 | GitHub license | https://github.com/Mentalys-App/mentalys-app-android/blob/2146bebf5c9c936246adee914d17ee2366a5f3ac/LICENSE | MIT license file exists in current resolved repository. | high |
| EVD-006 | SRC-002 | GitHub repository/current activity | https://github.com/VedAstro/VedAstro | Repository exists, public, default master, current activity observed July 2026. | high |
| EVD-007 | SRC-002 | GitHub commit | https://github.com/VedAstro/VedAstro/commit/50bd1041e1e6440a49702f593b4a1ec9367f6e3d | Audited current commit SHA. | high |
| EVD-008 | SRC-002 | GitHub source file | https://github.com/VedAstro/VedAstro/blob/50bd1041e1e6440a49702f593b4a1ec9367f6e3d/Library/Logic/Calculate/Numerology.cs | Exact BirthNumber, DestinyNumber, NameNumber and NameNumberPrediction implementations. | high |
| EVD-009 | SRC-002 | GitHub source file | https://github.com/VedAstro/VedAstro/blob/50bd1041e1e6440a49702f593b4a1ec9367f6e3d/Library/Logic/Factory/MatchReportFactory.cs | Exact compatibility report factory and Kuta calculators. | high |
| EVD-010 | SRC-002 | GitHub search/source path | https://github.com/VedAstro/VedAstro/blob/50bd1041e1e6440a49702f593b4a1ec9367f6e3d/LibraryTests/Logic/Calculate/NumerologyTests.cs | Numerology test file exists at audited commit. | high |
| EVD-011 | SRC-011 | GitHub repository metadata | https://github.com/GSTJ/pegava-dating-app | Candidate resolved repository; archived=true. Original pegava/ owner continuity not proven. | medium |
| EVD-012 | SRC-011 | GitHub commit | https://github.com/GSTJ/pegava-dating-app/commit/85785d49f51f9b9b030e8ab65ee9be5da63bab08 | Current audit commit says repository is archived and points to Pegada. | high |
| EVD-013 | SRC-011 | GitHub package manifest | https://github.com/GSTJ/pegava-dating-app/blob/85785d49f51f9b9b030e8ab65ee9be5da63bab08/package.json | Expo/React Native/navigation/Redux dependency profile. | high |
| EVD-014 | SRC-013 | GitHub repository metadata | https://github.com/Prakashchandra-007/humbble | Candidate current Humbble repository. Original humbble/ owner continuity requires verification. | medium |
| EVD-015 | SRC-013 | GitHub commit | https://github.com/Prakashchandra-007/humbble/commit/393c9ddc795fa97767cbb59d8bb01fc1884ad879 | Latest commit observed in current audit. | high |
| EVD-016 | SRC-013 | GitHub package manifest | https://github.com/Prakashchandra-007/humbble/blob/393c9ddc795fa97767cbb59d8bb01fc1884ad879/package.json | Expo Router, Appwrite, deck-swiper, WebView and React Native dependency profile. | high |
| EVD-017 | SRC-013 | GitHub license | https://github.com/Prakashchandra-007/humbble/blob/393c9ddc795fa97767cbb59d8bb01fc1884ad879/LICENSE | MIT license for resolved repository. | high |
| EVD-018 | SRC-014 | GitHub repository metadata | https://github.com/Alovoa/alovoa | Primary Alovoa repository exists and is not archived. | high |
| EVD-019 | SRC-014 | GitHub commit | https://github.com/Alovoa/alovoa/commit/408e45fbcd34a284ba55f3fe04753cd048b2b46b | Latest commit observed in audit. | high |
| EVD-020 | SRC-014 | GitHub license | https://github.com/Alovoa/alovoa/blob/408e45fbcd34a284ba55f3fe04753cd048b2b46b/LICENSE | AGPL-3.0 license text at audited commit. | high |
| EVD-021 | SRC-014A | GitHub repository metadata | https://github.com/Alovoa/alovoa-expo | Official mobile repository linked from Alovoa project. | high |
| EVD-022 | SRC-014A | GitHub commit | https://github.com/Alovoa/alovoa-expo/commit/10b74ab11db1af16385b4f951d5fb07b8f0a841c | Latest commit observed in audit. | high |
| EVD-023 | SRC-014A | GitHub package manifest | https://github.com/Alovoa/alovoa-expo/blob/10b74ab11db1af16385b4f951d5fb07b8f0a841c/package.json | Current Expo 54/React Native 0.81.5 client dependency profile. | high |
| EVD-024 | SRC-014A | GitHub license | https://github.com/Alovoa/alovoa-expo/blob/10b74ab11db1af16385b4f951d5fb07b8f0a841c/LICENSE | MPL-2.0 license text at audited commit. | high |
| EVD-025 | PROJECT | supplied build report | Brotherhood-v0.5.11-NON_CANONICAL_DEBUG-24.zip::BUILD_SIGNING_REPORT.txt | Application ID/version/build class/SDK/signing continuity facts. | high |
| EVD-026 | PROJECT | supplied AAPT badging | Brotherhood-v0.5.11-NON_CANONICAL_DEBUG-24.zip::AAPT_BADGING.txt | SDK, permissions, launchable activity, native ABIs. | high |
| EVD-027 | PROJECT | supplied apksigner report | Brotherhood-v0.5.11-NON_CANONICAL_DEBUG-24.zip::APKSIGNER_VERIFY.txt | APK signature schemes and signer certificate digests. | high |
| EVD-028 | PROJECT | APK META-INF | Brotherhood-v0.5.11-NON_CANONICAL_DEBUG-24.zip::APK/META-INF/*.version | Observed AndroidX/Compose/coroutines version markers and AGP app metadata. | high |
| EVD-029 | PROJECT | APK DEX symbols | Brotherhood-v0.5.11-NON_CANONICAL_DEBUG-24.zip::APK/classes*.dex | Brotherhood package classes and selected method/composable symbols used for project targets. | high |
| EVD-030 | PROJECT | APK assets | Brotherhood-v0.5.11-NON_CANONICAL_DEBUG-24.zip::APK/assets/ | i18n and numerology data assets. | high |
| EVD-031 | SRC-003 | GitHub exact repository metadata lookup | https://github.com/tomasz-kolek/Personality-Test | Exact repository lookup returned 404 during audit; no canonical replacement established. | high |
| EVD-032 | SRC-004 | GitHub exact repository metadata lookup | https://github.com/nikitakapoor/Numerology | Exact repository lookup returned 404 during audit; no canonical replacement established. | high |
| EVD-033 | SRC-005 | GitHub exact repository metadata lookup | https://github.com/alexthegr8/Big-Five-Personality-Test | Exact repository lookup returned 404 during audit; no canonical replacement established. | high |
| EVD-034 | SRC-006 | GitHub exact repository metadata lookup | https://github.com/qflock/android-java-dating-app | Exact repository lookup returned 404 during audit; no canonical replacement established. | high |
| EVD-035 | SRC-007 | GitHub exact repository metadata lookup | https://github.com/DostiPak/DostiPak | Exact repository lookup returned 404 during audit; no canonical replacement established. | high |
| EVD-036 | SRC-008 | GitHub exact repository metadata lookup | https://github.com/skgadi/tindev | Exact repository lookup returned 404 during audit; no canonical replacement established. | high |
| EVD-037 | SRC-009 | GitHub exact repository metadata lookup | https://github.com/alex-kruger/tinder-react-native | Exact repository lookup returned 404 during audit; no canonical replacement established. | high |
| EVD-038 | SRC-010 | GitHub exact repository metadata lookup | https://github.com/filippm/tinder-clone | Exact repository lookup returned 404 during audit; no canonical replacement established. | high |
| EVD-039 | SRC-012 | GitHub exact repository metadata lookup | https://github.com/aungpyaephyo1412/Complete-Dating-App | Exact repository lookup returned 404 during audit; no canonical replacement established. | high |
| EVD-040 | SRC-005 | GitHub candidate repository + README | https://github.com/adriantache/Big-Five-Personality-Test | Same-name Android Big Five implementation exists; README verifies 50-item IPIP, Kotlin rewrite, MVVM/Room and psychometric translation warning. Continuity from alexthegr8 is NOT established. | medium |
| EVD-041 | SRC-005 | GitHub candidate license | https://github.com/adriantache/Big-Five-Personality-Test/blob/master/LICENSE | Candidate repository is MIT licensed. This does not establish the license of the missing original alexthegr8 repository. | high |
| EVD-042 | SRC-006 | GitHub candidate repository + README | https://github.com/problemsolver-eng/android-java-dating-app | Same-name Android/Java dating UI repository exists; README describes Android Studio Java/XML template, swipe/match/chat/profile/settings layouts. Continuity from qflock is NOT established. | medium |
| EVD-043 | SRC-007 | GitHub candidate repository + README | https://github.com/ABDULKARIMALBAIK/DostiPak | Same-name DostiPak repository exists; README verifies Flutter/Firebase dating features including swipe, match, chat, filters, geolocation, push and account actions. Continuity from DostiPak/DostiPak is NOT established. | medium |
| EVD-044 | SRC-007 | GitHub candidate license | https://github.com/ABDULKARIMALBAIK/DostiPak/blob/main/LICENSE | Candidate DostiPak repository exposes an MIT license. This does not establish the missing original repository license. | medium |
| EVD-045 | SRC-008 | GitHub candidate repository + README | https://github.com/CarlosLevir/Tindev | TinDev candidate is a monorepo with backend/frontend/mobile using React, React Native, Node, MongoDB and Socket.IO; MIT stated. Continuity from skgadi is NOT established. | medium |
| EVD-046 | SRC-009 | GitHub candidate repository + README | https://github.com/stevenpersia/tinder-react-native | React Native Tinder clone candidate is explicitly unmaintained; README warns Android has serious UI problems and points to a newer Expo project. Continuity from alex-kruger is NOT established. | medium |
| EVD-047 | SRC-011 | GitHub current candidate repository page | https://github.com/GSTJ/pegava-dating-app | Repository is a React Native/Expo Pegava example, CC0-1.0, and points to Pegada for production-ready work; GitHub metadata marks it archived. | high |
| EVD-048 | SRC-013 | GitHub current candidate repository page | https://github.com/Prakashchandra-007/humbble | Humbble candidate is React Native/Expo, MIT, with swipe/match/chat goals; continuity from humbble/humbble is NOT established. | medium |
| EVD-049 | SRC-012 | GitHub repository search | https://github.com/search?q=Complete-Dating-App&type=repositories | Multiple Complete-Dating-App copies/candidates exist; no evidence establishes a canonical continuation of aungpyaephyo1412/Complete-Dating-App. | medium |
| EVD-050 | SRC-006 | GitHub repository search | https://github.com/search?q=android-java-dating-app&type=repositories | Multiple same-name Android Java dating repositories exist; ancestry/canonical continuation from qflock is unresolved. | medium |
| EVD-051 | SRC-008 | GitHub repository search | https://github.com/search?q=tindev&type=repositories | Multiple TinDev clones exist; no searched repository is automatically promoted to successor of skgadi/tindev. | medium |
| EVD-052 | SRC-009 | GitHub repository search | https://github.com/search?q=tinder-react-native&type=repositories | Multiple Tinder React Native projects exist; none is proven successor of alex-kruger/tinder-react-native. | medium |

## Next deep pass

- Obtain Brotherhood Gradle/Kotlin source archive to replace DEX-only targets with exact source paths.
- Deep-diff VedAstro numerology and Kuta methods against Brotherhood NumerologyReadingEngine/VedicNumerologyEngine/compatibility engines.
- Resolve provenance of SRC-005/SRC-006/SRC-007/SRC-008/SRC-009/SRC-011/SRC-012/SRC-013 before any code copying.
- If Big Five is selected, freeze a specific validated instrument/scoring version before UX work.

## Canonical rule

**SOURCE → VERIFIED ELEMENT → CAPABILITY → EVIDENCE → PROJECT TARGET → DECISION → ТЗ → IMPLEMENTATION**
