# Brotherhood compatibility model v0.5.8

Brotherhood never hides friendship matching behind one unexplained number. The Android client calculates independent compatibility layers and then shows two transparent totals:

1. **Base compatibility** — the same canonical weights for everyone.
2. **Compatibility for you** — the base model with bounded weight adjustments derived from the user's explicit friendship goals.

`Trust Score` is displayed next to compatibility but is **not included in either compatibility total**.

## Canonical layers and base weights

| Layer | Weight |
|---|---:|
| 100 friendship tests | 18% |
| Character | 10% |
| Values | 10% |
| Friendship goals | 9% |
| Interests | 8% |
| Lifestyle | 7% |
| Communication style | 7% |
| Conflict / repair style | 7% |
| Brotherhood-32 | 7% |
| Vedic numerology | 5% |
| Enneagram | 4% |
| Zodiac | 3% |
| Geography / availability | 2% |
| Business / mutual aid | 2% |
| Social format | 1% |
| **Total** | **100%** |

## Test layer

The server returns only compatibility derived from tests both users have actually completed plus category scores and risk flags. It does not mix interests, Trust Score, numerology or personality into this value.

The Android client then derives the separate character / communication / conflict / business layers from the relevant test categories. The user can see all layers independently.

## Vedic numerology

Vedic numerology is **not a test and never counts toward the 100 tests**. There is no questionnaire. The friendship-compatibility engine calculates its numeric profile mathematically from the two birth dates only. It exposes soul-number, destiny-number, cross-date and birth-date-composite links. There is no questionnaire and no name-based score in Vedic friendship compatibility.

It is presented as a cultural/esoteric interpretive model, not scientific psychological diagnosis, and never affects Trust Score.

## Personalized compatibility

The personal total can slightly raise weights related to explicit goals such as close friendship, mutual aid, sport/travel, business/projects or intellectual/spiritual communication. The base total remains visible so the personalization is auditable.

Confirmed compatibility risk flags cap the personalized recommendation instead of being silently averaged away. Confirmed reputation remains a separate Trust Score.
