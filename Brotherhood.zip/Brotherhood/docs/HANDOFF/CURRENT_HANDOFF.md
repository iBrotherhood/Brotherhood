# Current handoff — Brotherhood

Current source HEAD: `v0.5.23 / versionCode 28`.

Cycle 0003 source milestone is prepared on the existing FastAPI/PostgreSQL/Compose architecture. Backend/auth/database/Android static and local unit/architecture gates pass. Universal workflow is unchanged.

Do not claim LIVE_E2E until: real PostgreSQL is available and migration 0008 is applied; exact backend is deployed over HTTPS; Google/Telegram/email/passkey production configuration exists; Android uses the deployed `BROTHERHOOD_API_BASE_URL`; real login/session/settings persistence is observed end-to-end.

Cycle 0002 APK/device acceptance remains pending by explicit deferral, not completed. Cycle 0004 is only PLANNED.

GitHub run `84786542178` failed during Gradle Kotlin DSL script compilation before Android tasks: `java.net.URI(...)` was not resolved in the script and the later `it` error was cascading. Current source uses Gradle `uri(...)`; targeted regression guard passes. Universal workflow and version remain unchanged. Exact GitHub rerun is required before compile/build status can be promoted.
