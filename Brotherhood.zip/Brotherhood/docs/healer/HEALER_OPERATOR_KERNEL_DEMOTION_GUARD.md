# HEALER OPERATOR KERNEL DEMOTION GUARD

KERNEL must remain an active dispatch layer with goals, routes, anchors, boundaries and validation; navigation-only regression is release-blocking.
