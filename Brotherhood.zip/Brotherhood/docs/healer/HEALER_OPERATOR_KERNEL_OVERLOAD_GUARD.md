# HEALER OPERATOR KERNEL OVERLOAD GUARD

Move encyclopedic detail/history out of KERNEL into CANON/SSOT/NORM/rules/reports; keep dispatch facts only.
