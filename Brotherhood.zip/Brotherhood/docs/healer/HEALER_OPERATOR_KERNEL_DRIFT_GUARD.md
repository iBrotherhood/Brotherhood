# HEALER OPERATOR KERNEL DRIFT GUARD

Detect canon/route/write-boundary drift; compare changed files to route anchors; block package until resolved.
