# HEALER OPERATOR KERNEL FULL READ REGRESSION GUARD

Startup must use summary index and route-scoped reads; full archive reading is never the default.
