# Healer — Psychological Matching Drift Guard

Block release if any of these regressions occur:
- direct socially desirable self-report questions return to the canonical 100×6 bank;
- a user-visible screen exposes internal assessment kind/latent trait/raw score/consistency diagnostic;
- any code path assigns a universal bad-person score from latent traits;
- a role injects desired qualities not explicitly selected by the user;
- Quality Fit mutates canonical Compatibility weights, Trust or Account Completeness;
- public people/profile/assessment endpoints expose raw latent coordinates;
- public compatibility/self-analysis UI or DTOs expose negative psychological labels, risk flags, growth deficits or hidden diagnostics;
- pre-visual legacy scores feed `visual-latent-v2`;
- numerology is counted as a psychological test or name number enters friendship compatibility;
- a theory-informed visual loading is documented as clinically/psychometrically validated without evidence.

Treatment: identify exact drift, restore canon, add/update regression test, rerun independent verification.
