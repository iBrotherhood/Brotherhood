# Brotherhood brand canon — v0.5.10

Canonical product name: **Brotherhood**

## Master logo

- Source of truth: `brand/BR_logo_master.svg`
- Master canvas/viewBox: `8192 × 8192`
- Background: `#000000`
- Mark: `#ECAF21`
- Geometry: shield + BR monogram, exactly as supplied by the user.

Generated derivatives:
- `brand/BR_logo_1024.png`
- `brand/BR_logo_512.png`
- Android `@drawable/ic_brotherhood_logo`
- adaptive launcher foreground
- Android 13+ monochrome launcher icon
- Android 12+ splash artwork

No Material tint is allowed over the canonical full-color logo.
The launcher foreground is scaled inside Android adaptive-icon safe area, but the master geometry is not modified.
