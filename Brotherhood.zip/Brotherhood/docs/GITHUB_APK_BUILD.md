# GitHub Actions: сборка APK из Brotherhood.zip

## Структура репозитория

GitHub распознаёт workflow только вне исходного архива:

```text
Brotherhood.zip
.github/
  workflows/
    android-build.yml
```

`Brotherhood.zip` содержит корень проекта с каталогами `android`, `backend`, `docs` и другими файлами. Workflow распаковывает архив во временный каталог GitHub runner, автоматически находит `settings.gradle.kts`, устанавливает JDK 17 и Android SDK 36, запускает unit-тесты и собирает debug APK.

## Когда запускается

- вручную через **Actions → Build Brotherhood APK from ZIP → Run workflow**;
- автоматически после изменения `Brotherhood.zip` или самого workflow в ветках `main`/`master`.

## Результат

После успешной сборки внизу страницы запуска появляется артефакт:

```text
Brotherhood-APK-<номер_сборки>
```

Внутри:

- `Brotherhood-debug-<номер_сборки>.apk`;
- `APK_SHA256SUMS.txt`;
- `Brotherhood.zip.sha256`;
- `BUILD_INFO.txt`.

Это тестовый устанавливаемый APK. Для публикации в Google Play нужен подписанный release AAB и постоянный закрытый ключ подписи.

## Правила безопасности

- workflow имеет только разрешение `contents: read`;
- архив предварительно проверяется командой `unzip -t`;
- неоднозначный архив с несколькими Gradle-корнями отклоняется;
- Gradle Wrapper JAR загружается только проверенным downloader с закреплённым SHA-256, если JAR отсутствует;
- APK сопровождается контрольной суммой и данными исходного commit.
