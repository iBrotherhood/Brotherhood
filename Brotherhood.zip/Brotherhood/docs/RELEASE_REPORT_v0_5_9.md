# Brotherhood v0.5.9 — UX visibility and Diia Open Source review

## Why v0.5.8 looked unchanged

GitHub Actions log `logs_83056531528.zip` proves APK artifact `Brotherhood-APK-6` was built from `Brotherhood.zip` SHA-256 `febf183d3740b46fed5b6b987b967212aa3778a7190aebcaffc00830b686f39a`, which is the v0.5.8 source archive. The issue was therefore not an old APK. The new functions existed but were placed behind low-discoverability entry points:

- Chats: icon-only action in the top app bar.
- Self analysis: one button inside Profile.
- Detailed compatibility: only inside a candidate detail screen.
- Service Hub: icon-only top action.
- Trust and Tests occupied bottom tabs, while the broader new product functions had no central dashboard.

## v0.5.9 correction

Primary navigation is now:

1. Home
2. People
3. Chats
4. Groups
5. Profile

Home directly exposes:

- Chats with unread badge;
- 15-layer friendship compatibility;
- Know Yourself;
- 100 assessments;
- Trust & reputation;
- Brotherhood-32;
- Enneagram;
- Zodiac;
- Vedic Numerology;
- communities/business;
- all services.

Tests and Trust remain full screens, opened from the Home dashboard and Service Hub. The selected main tab is persisted locally.

## Product naming

Android launcher label and all locale `app_name` resources are now exactly `Brotherhood`.

## Diia Open Source

Reviewed repositories include `android-diia`, `be-auth-service`, `be-pkg-i18n`, `be-diia-queue` and `be-pkg-crypto`. Their EUPL code is not copied into Brotherhood. Useful architecture/product ideas are applied through independent implementation: compact first-class navigation, badges, accessibility-oriented labels, provider strategy, dedicated i18n/queue/crypto boundaries, and future observability/health-check packages.

## Qualification

- Backend: 24/24 tests PASS.
- Pure Kotlin compatibility/personality core: compile PASS.
- JSON/XML/YAML parse: PASS before archive packaging.
- Full Android Compose/Gradle compile: required GitHub Actions gate for v0.5.9.
