# Brotherhood v0.5.11 — CI and Development signing report

## Source HEAD

- Previous source: `Brotherhood_v0_5_10.zip`
- New version: `0.5.11`
- Android versionCode: `16`
- Android applicationId: `org.federationofavatars.brotherhood`

## Incoming GitHub Actions failure

The uploaded v0.5.10 log reached:

- ZIP verification: PASS
- archive extraction: PASS
- JDK setup: PASS
- Android SDK 36 setup: PASS
- Gradle setup: PASS
- Kotlin task: `:app:compileDebugKotlin`

The build then failed with a JVM platform declaration clash in `MainViewModel`:

```text
setProfileVisibility(ProfileVisibility)
```

Kotlin generated the property setter for `profileVisibility`, while the class also declared a function named `setProfileVisibility(ProfileVisibility)`. Both compile to the same JVM signature.

### Fix

The ViewModel action is now:

```text
changeProfileVisibility(ProfileVisibility)
```

and its UI call site is updated. `SettingsStore.setProfileVisibility(...)` remains unchanged because it belongs to a different class and does not collide.

A static Kotlin accessor-clash scan found no remaining `var x` + `fun setX(...)` collision in the source tree.

## Development signing redesign

Implemented according to the Development signing specification:

- one permanent Brotherhood Development signing identity;
- four private GitHub Secrets;
- one public repository variable containing expected certificate SHA-256;
- fail-closed canonical Development APK build;
- no canonical fallback to an ephemeral GitHub debug certificate;
- absolute runtime keystore path under `$GITHUB_WORKSPACE/.ci-signing/`;
- keystore existence/readability check;
- alias/store validation;
- keystore certificate SHA-256 verification before Gradle;
- `apksigner verify --verbose --print-certs` after build;
- APK signer fingerprint comparison after build;
- applicationId/versionCode/versionName/minSdk/targetSdk/debuggable checks;
- final APK SHA-256;
- `DEVELOPMENT_SIGNING_REPORT.txt` artifact;
- no Development-signed Release APK/AAB;
- future Production signing remains separate.

## Build class

```text
DEVELOPMENT
INTERNAL TESTING ONLY
NOT A PRODUCTION RELEASE
```

## Signing status

A real Development private key is intentionally not included in the repository or archives.

Therefore before GitHub can produce the canonical Development APK, the repository owner must configure:

### GitHub Secrets

- `BROTHERHOOD_DEV_KEYSTORE_BASE64`
- `BROTHERHOOD_DEV_KEYSTORE_PASSWORD`
- `BROTHERHOOD_DEV_KEY_ALIAS`
- `BROTHERHOOD_DEV_KEY_PASSWORD`

### GitHub Repository Variable

- `BROTHERHOOD_DEV_CERT_SHA256`

The signer SHA-256 is therefore **not invented** in this source report. GitHub Actions records the real value only after the owner configures the permanent Development key.

## AndroidManifest audit

Current manifest:

- `INTERNET` permission: required;
- `ACCESS_COARSE_LOCATION`: approximate location only;
- launcher Activity exported: `true` because it has the launcher intent filter;
- FileProvider exported: `false`;
- `allowBackup=false`;
- `usesCleartextTraffic=false`;
- no exported service;
- no exported receiver;
- no background-location permission;
- no install-packages permission;
- no attempt to bypass Play Protect or Package Installer protections.

No functional permission was changed by this signing task.

## Available local qualification

- Backend tests: `24/24 PASS`
- Kotlin JVM accessor clash scan: `PASS`
- private signing material scan: `PASS`
- JSON/XML/YAML validation: performed before packaging
- complete Android/Gradle + apksigner qualification: `PENDING_GITHUB_CI`

The final signer fingerprint and final APK SHA-256 can only be reported after GitHub builds with the real Development key.

## First migration warning

Previously installed Brotherhood debug APKs may use an ephemeral signing certificate. Android will not update such an APK with a different permanent Development signer.

For the first switch to the canonical Development signer, Android may return:

```text
INSTALL_FAILED_UPDATE_INCOMPATIBLE
```

If so, one uninstall/reinstall is required. After that one-time migration, later Development versions update in place while the same Development key, applicationId and increasing versionCode are preserved.
