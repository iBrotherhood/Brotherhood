# Android updates and signing — Brotherhood v0.5.17

The canonical Development signing policy is defined in:

`docs/ANDROID_DEVELOPMENT_SIGNING.md`

Current Development identity rules:

- `applicationId = org.federationofavatars.brotherhood`;
- `versionName = 0.5.17`;
- `versionCode = 22`;
- one permanent Brotherhood Development signing certificate;
- canonical Development GitHub builds fail closed if the key or expected certificate fingerprint is missing;
- no fallback to an ephemeral GitHub debug certificate;
- Development signing is not Production signing;
- this Development workflow does not publish Release APK/AAB.

Older GitHub debug APKs may have a different ephemeral certificate and can require one uninstall/reinstall when migrating to the permanent Development identity. After that one-time migration, later canonical Development builds update in place when they keep the same applicationId, signer and a greater versionCode.

Standard Android/Play Protect warnings for sideloaded APKs are not bypassed.
