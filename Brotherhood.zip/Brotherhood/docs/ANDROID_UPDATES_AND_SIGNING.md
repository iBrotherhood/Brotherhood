# Android updates and signing — Brotherhood v0.5.8

## Canon

Android accepts an APK as an update only when the application ID stays the same, the signing certificate matches the installed app (or a valid certificate rotation exists), and the incoming `versionCode` is not lower. Brotherhood keeps `applicationId = org.federationofavatars.brotherhood` and increments `versionCode` every release.

## One-time transition from the old GitHub debug APK

Builds up to v0.5.7 were produced with the GitHub runner's default debug signing when no persistent key was supplied. That key is not durable across ephemeral runners. Therefore a phone that has such an APK may require **one uninstall/reinstall** when the project switches to the stable Brotherhood test certificate. After that transition, every APK signed with the same stable key and a higher versionCode installs over the previous version while preserving app data.

Do not publish the test keystore or its passwords in GitHub source.

## GitHub secrets for stable test APKs

Create one long-lived test keystore with `scripts/create_test_keystore.sh`, then configure repository Actions secrets:

- `BROTHERHOOD_TEST_KEYSTORE_B64` — base64 of the JKS file;
- `BROTHERHOOD_TEST_STORE_PASSWORD`;
- `BROTHERHOOD_TEST_KEY_ALIAS`;
- `BROTHERHOOD_TEST_KEY_PASSWORD`.

The APK workflows automatically use these values. If the secrets are missing, CI still produces a debug APK but emits a warning that the certificate is ephemeral.

## Google Play production updates

For Play distribution use Google Play App Signing and an AAB. Brotherhood includes Play In-App Updates (`com.google.android.play:app-update:2.1.0`). A Play-installed build can request a flexible verified update through Google Play without requesting package-install permission.

## Direct test APK updates

For APKs downloaded from GitHub/Vercel, the app checks the backend version manifest. It may open a user-facing download link, but Brotherhood deliberately does **not** request `REQUEST_INSTALL_PACKAGES` and does not silently self-install APK files. Android remains responsible for user confirmation.

## Security warnings

Sideloaded APKs can trigger Android/Play Protect warnings regardless of app quality. They cannot legitimately be disabled by the app. The supported way to reduce warnings is:

1. stable signing certificate;
2. current target SDK;
3. minimal permissions;
4. HTTPS only;
5. Google Play Internal Testing/Internal App Sharing for testers;
6. normal Play Store distribution for production.

Brotherhood does not request broad storage access, microphone access, contacts, SMS, background location, or package-install permission. Chat media selection uses Android's system picker.
