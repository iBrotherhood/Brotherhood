# Operational pending

- HEAD: `v0.5.23 / versionCode 28`.
- Cycle 0002: GitHub APK + real-device acceptance still pending.
- Cycle 0003: `ACTIVE — SOURCE MILESTONE READY / LIVE_E2E PENDING`.
- External requirements: real PostgreSQL/Neon; migrations through 0008; deployed HTTPS FastAPI; GitHub `BROTHERHOOD_API_BASE_URL`; Google/Telegram/email credentials; passkey RP domain + Digital Asset Links; live Android auth/settings synchronization proof.
- Cycle 0004 remains PLANNED.
