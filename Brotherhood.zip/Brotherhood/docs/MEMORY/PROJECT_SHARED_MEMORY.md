# Project shared memory

- Current source app metadata: `v0.5.23 / versionCode 28`.
- Cycle 0002: source milestone ready, APK/device acceptance pending.
- Cycle 0003: source milestone implements real-auth architecture and PostgreSQL persistence contracts; local evidence 139 PASS; LIVE_E2E pending.
- Google public Client ID is runtime backend config; Telegram uses HTTPS OIDC callback + device-bound one-time ticket; passkeys require production Digital Asset Links.
- Workflow is frozen and unchanged.
