# Historical memory index

Historical release/cycle evidence is stored in:

- `docs/RELEASE_REPORT_v0_5_*.md`
- `docs/PROJECT_CANON_v0_5_*.md`
- `reports/change_cycle_*.md`
- `reports/generated/INDEPENDENT_VERIFICATION_*.md`
- `reports/historical/**`

History is reference-only and never overrides current CANON, SSOT, cycle status or explicit user instruction.

Current source milestone supersedes version metadata in `docs/PROJECT_CANON_v0_5_21.md`; that file remains historical evidence. Active source milestone canon: `docs/PROJECT_CANON_v0_5_23.md`.



## v0.5.23
Current source milestone for cycle 0003. `v0.5.22` remains the cycle-0002 source milestone and is not rewritten as APK-visible history.
