# Canonical memory

- Brotherhood is for platonic male friendship 18+, communities, mutual aid, business/projects and self-analysis; not dating.
- `global_id` is the canonical owner identity; provider IDs are login identities only.
- Trust, Compatibility, Account Completeness and Quality Fit are separate.
- Compatibility has 15 layers totaling 100%; Vedic numerology remains 5% and uses dates only for friendship compatibility.
- Psychological assessments are indirect visual/associative tasks; hidden conclusions remain internal.
- Public results emphasize positive qualities; there are no universally bad traits.
- Users choose desired qualities and roles; the system does not impose them.
- Universal Android workflow is version-independent and frozen after acceptance.
- No private signing material in source/archive/logs.
- External APK/source maps and donor repositories are research-only unless explicitly promoted; they never override current Brotherhood CANON/SSOT/source.


## Cycle 0003 stable auth boundary
`global_id` is the sole domain owner. Provider subjects are authentication identities only. Android never receives DB/provider secrets. Session tokens are opaque and server-stored only as hashes; refresh rotates and revokes. External research/source maps remain subordinate to active project authority.
