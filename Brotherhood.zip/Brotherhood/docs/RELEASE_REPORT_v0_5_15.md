# Brotherhood v0.5.15 — calibration/i18n functional release report

Android target: `versionName 0.5.15`, `versionCode 20`  
Application ID: `org.federationofavatars.brotherhood`

## Functional delta from v0.5.14
- psychological assessment provenance upgraded to `visual-latent-v2` / `scene-library-v2`;
- 24 scene archetypes and private six-item response traces support future empirical item calibration;
- offline review-only calibration tooling added;
- Quality Fit catalog expanded to 112 user-selected qualities;
- whole-app data-driven localization with RU/UK/EN current packs and future locale activation gate;
- language carousel added/retained as canonical selector;
- stable multilingual Brotherhood-32/Zodiac/Quality Fit/numerology presentation;
- built-in city labels and DEBUG fixture presentation follow locale without rewriting storage/search/user data;
- backend city-options API exposes localized label + stable value;
- physical PostgreSQL calibration export corrected to actual schema names.

## Invariants preserved
- Brotherhood is not dating.
- 100 psychological/behavioral blocks × 6 = 600 indirect tasks.
- Numerology is automatic, not a test.
- Vedic overall Compatibility weight = 5% unchanged.
- 15 canonical Compatibility layers total 100% unchanged.
- Quality Fit, Compatibility, Trust and Account Completeness remain separate.
- Role does not inject desired qualities.
- Raw latent coordinates/item traces are not public.
- `global_id` remains owner identifier.
- applicationId, signing policy and Android permission canon are unchanged.

## Qualification verdict
`LOCAL_PASS_LIVE_DEFERRED`

Local evidence: 85/85 backend+architecture tests, pure Kotlin core PASS, OpenAPI 42 paths, JSON/XML/YAML/shell/security static checks PASS. Full APK build/signature/artifact and real PostgreSQL migration execution remain external environment gates.

## Scientific status
The latent ontology and work-role vocabulary are theory-informed by public-domain/research construct families, but Brotherhood visual loadings are **not yet empirically validated**. The release provides instrumentation and a review-only calibration pipeline; it does not claim that real-world calibration has already occurred.
