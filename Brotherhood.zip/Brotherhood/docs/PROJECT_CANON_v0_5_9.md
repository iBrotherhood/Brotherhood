# Brotherhood project canon v0.5.9

- Product name: **Brotherhood** in all locales.
- Men-only 18+ platonic friendship platform.
- Primary navigation: Home / People / Chats / Groups / Profile.
- Home must visibly expose: compatibility, self-analysis, 100 assessments, Trust, Brotherhood-32, Enneagram, Zodiac, Vedic Numerology and services.
- Vedic numerology is mathematical from birth dates, never a questionnaire.
- Compatibility shows independent layers plus base and personalized total; Trust remains separate.
- `global_id` remains canonical 10-digit display ID.
- Private chats: E2EE; group/community chats: server-visible/moderatable with encryption at rest.
- Android label is `Brotherhood`; archive top directory is always `Brotherhood/`.
- GitHub unpacked source is canonical; `Brotherhood.zip` remains the test-APK transport archive.
