#!/usr/bin/env python3
"""Offline empirical diagnostics for Brotherhood visual-latent-v2 / scene-library-v4.

This tool is deliberately observational. It NEVER mutates production loadings, quality targets,
Compatibility weights, Trust, reputation or user-visible labels. Findings are REVIEW_CANDIDATE only.

Accepted input: private CSV from visual_item_calibration_export.sql (early pilot) or
visual_assessment_calibration_export.sql (30/90-day outcome analysis).
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable

MODEL_VERSION = "visual-latent-v2"
STIMULUS_VERSION = "scene-library-v4"
EXPECTED_SCENES = 48
EXPECTED_PARADIGMS = 16
MIN_ITEM_N = 50
MIN_LANGUAGE_N = 80
MAX_CHOICE_SHARE_FLAG = 0.70
MIN_ENTROPY_FLAG = 0.65
LANGUAGE_TVD_FLAG = 0.25
# Operational pilot-review heuristics, not psychometric validity thresholds.
MAX_SLOT_SHARE_FLAG = 0.40
FAST_RESPONSE_MS = 500
FAST_RESPONSE_SHARE_FLAG = 0.35
MIN_RETEST_PAIRS = 30


def _truth(value: str) -> int | None:
    v = (value or "").strip().lower()
    if v in {"true", "t", "1", "yes"}: return 1
    if v in {"false", "f", "0", "no"}: return 0
    return None


def _int(row: dict[str, str], key: str, default: int = 0) -> int:
    try: return int(float((row.get(key) or str(default)).strip()))
    except (TypeError, ValueError): return default


def normalized_entropy(counts: Counter[int]) -> float:
    total = sum(counts.values())
    if total <= 0: return 0.0
    e = 0.0
    for count in counts.values():
        if count <= 0: continue
        p = count / total
        e -= p * math.log(p)
    return e / math.log(4.0)


def distribution(counts: Counter[int]) -> list[float]:
    total = sum(counts.values()) or 1
    return [counts.get(i, 0) / total for i in range(1, 5)]


def tvd(a: list[float], b: list[float]) -> float:
    return 0.5 * sum(abs(x-y) for x, y in zip(a, b))


def _percentile(values: list[int], q: float) -> int | None:
    if not values: return None
    ordered = sorted(values)
    index = min(len(ordered)-1, max(0, round((len(ordered)-1)*q)))
    return int(ordered[index])


def _pilot_stage(participants: int, attempts: int, item_ready: int, connections: int, outcomes: Counter[int]) -> str:
    # Operational readiness stages only; they do not certify validity.
    if participants < 30 or attempts < 30:
        return "PILOT_INTAKE"
    if item_ready == 0:
        return "EARLY_DIAGNOSTICS"
    if connections >= 200 and min(outcomes.get(0,0), outcomes.get(1,0)) >= 40:
        return "OUTCOME_ANALYSIS_READY"
    return "ITEM_REVIEW_READY_OUTCOMES_PENDING"


def evaluate(rows: Iterable[dict[str, str]]) -> dict:
    all_rows = list(rows)
    rows=[]
    excluded=Counter()
    for row in all_rows:
        if (row.get("scoring_version") or MODEL_VERSION) != MODEL_VERSION:
            excluded["wrong_model_version"] += 1; continue
        if (row.get("stimulus_version") or STIMULUS_VERSION) != STIMULUS_VERSION:
            excluded["wrong_stimulus_version"] += 1; continue
        choice=_int(row,"choice_id")
        slot=_int(row,"presentation_slot")
        pos=_int(row,"question_position")
        if choice not in range(1,5): excluded["invalid_choice"] += 1; continue
        if row.get("presentation_slot") not in (None,"") and slot not in range(1,5): excluded["invalid_presentation_slot"] += 1; continue
        if row.get("question_position") not in (None,"") and pos not in range(1,7): excluded["invalid_question_position"] += 1; continue
        composition = _int(row, "composition_variant", -1)
        if composition not in range(0, 8): excluded["invalid_composition_variant"] += 1; continue
        rows.append(row)

    item_choices: dict[str, Counter[int]] = defaultdict(Counter)
    item_slots: dict[str, Counter[int]] = defaultdict(Counter)
    item_locale_choices: dict[tuple[str, str], Counter[int]] = defaultdict(Counter)
    item_latencies: dict[str, list[int]] = defaultdict(list)
    item_changes: dict[str, list[int]] = defaultdict(list)
    position_latencies: dict[int, list[int]] = defaultdict(list)
    scenes=Counter(); paradigms=Counter(); compositions=Counter(); scene_compositions=defaultdict(Counter); locales=Counter(); cohorts=Counter(); outcomes=Counter()
    participants=set(); attempts=set(); unique_connections=set()
    attempt_choices: dict[tuple[str,str,str], dict[str,int]] = defaultdict(dict)

    for row in rows:
        q=(row.get("question_id") or "").strip(); choice=_int(row,"choice_id")
        participant=(row.get("participant_global_id") or "").strip()
        attempt=(row.get("attempt_id") or "").strip()
        assessment=(row.get("assessment_id") or "").strip()
        if participant: participants.add(participant)
        if attempt: attempts.add(attempt)
        if participant and attempt and assessment and q:
            attempt_choices[(participant,assessment,attempt)][q]=choice
        if q:
            item_choices[q][choice]+=1
            locale=(row.get("locale") or "").strip().lower()
            if locale: item_locale_choices[(q,locale)][choice]+=1
            slot=_int(row,"presentation_slot")
            if slot in range(1,5): item_slots[q][slot]+=1
            latency=_int(row,"response_latency_ms",-1)
            if latency >= 0: item_latencies[q].append(latency)
            changes=_int(row,"selection_changes",-1)
            if changes >= 0: item_changes[q].append(changes)
        slotpos=_int(row,"question_position")
        latency=_int(row,"response_latency_ms",-1)
        if slotpos in range(1,7) and latency >= 0: position_latencies[slotpos].append(latency)
        if row.get("scene_archetype"): scenes[row["scene_archetype"]]+=1
        if row.get("paradigm"): paradigms[row["paradigm"]]+=1
        composition=_int(row,"composition_variant",-1)
        if composition in range(0,8):
            compositions[composition]+=1
            if row.get("scene_archetype"): scene_compositions[row["scene_archetype"]][composition]+=1
        if row.get("locale"): locales[row["locale"].lower()]+=1
        if row.get("cohort_id"): cohorts[row["cohort_id"]]+=1
        y=_truth(row.get("still_active_90d",""))
        if y is not None: outcomes[y]+=1
        if row.get("connection_id"): unique_connections.add(row["connection_id"])

    item_diagnostics=[]; review=[]; item_ready=0
    for q, counts in sorted(item_choices.items()):
        n=sum(counts.values()); dist=distribution(counts); mx=max(dist); ent=normalized_entropy(counts)
        slot_counts=item_slots.get(q,Counter()); slot_dist=distribution(slot_counts) if slot_counts else [0,0,0,0]
        max_slot=max(slot_dist) if slot_counts else None
        lat=item_latencies.get(q,[]); changes=item_changes.get(q,[])
        fast_share=(sum(v < FAST_RESPONSE_MS for v in lat)/len(lat)) if lat else None
        reasons=[]
        if n >= MIN_ITEM_N: item_ready += 1
        if n >= MIN_ITEM_N and mx > MAX_CHOICE_SHARE_FLAG: reasons.append("choice_concentration")
        if n >= MIN_ITEM_N and ent < MIN_ENTROPY_FLAG: reasons.append("low_entropy")
        if n >= MIN_ITEM_N and max_slot is not None and max_slot > MAX_SLOT_SHARE_FLAG: reasons.append("presentation_slot_bias")
        if n >= MIN_ITEM_N and fast_share is not None and fast_share > FAST_RESPONSE_SHARE_FLAG: reasons.append("very_fast_response_share")
        status="REVIEW_CANDIDATE" if reasons else "OK"
        rec={
            "question_id":q,"n":n,
            "choice_distribution":[round(x,4) for x in dist],
            "max_choice_share":round(mx,4),"normalized_entropy":round(ent,4),
            "presentation_slot_distribution":[round(x,4) for x in slot_dist],
            "max_presentation_slot_share":round(max_slot,4) if max_slot is not None else None,
            "latency_ms":{"p10":_percentile(lat,.10),"median":int(statistics.median(lat)) if lat else None,"p90":_percentile(lat,.90),"fast_share":round(fast_share,4) if fast_share is not None else None},
            "selection_changes_mean":round(statistics.mean(changes),4) if changes else None,
            "status":status,"reasons":reasons,
        }
        item_diagnostics.append(rec)
        if reasons: review.append(rec)

    language_drift=[]
    locale_names=sorted({loc for _,loc in item_locale_choices})
    for q in sorted(item_choices):
        for i,a in enumerate(locale_names):
            ca=item_locale_choices.get((q,a),Counter()); na=sum(ca.values())
            if na < MIN_LANGUAGE_N: continue
            for b in locale_names[i+1:]:
                cb=item_locale_choices.get((q,b),Counter()); nb=sum(cb.values())
                if nb < MIN_LANGUAGE_N: continue
                distance=tvd(distribution(ca),distribution(cb))
                if distance >= LANGUAGE_TVD_FLAG:
                    language_drift.append({"question_id":q,"locale_a":a,"locale_b":b,"n_a":na,"n_b":nb,"total_variation_distance":round(distance,4),"status":"REVIEW_CANDIDATE"})

    position_diagnostics={str(pos):{"n":len(vals),"median_latency_ms":int(statistics.median(vals)) if vals else None,"fast_share":round(sum(v<FAST_RESPONSE_MS for v in vals)/len(vals),4) if vals else None} for pos,vals in sorted(position_latencies.items())}

    # Retest is diagnostic only: same-stimulus choice agreement across first and latest attempts.
    grouped_attempts: dict[tuple[str,str], list[tuple[str,dict[str,int]]]] = defaultdict(list)
    for (participant,assessment,attempt), qmap in attempt_choices.items():
        grouped_attempts[(participant,assessment)].append((attempt,qmap))
    agreements=[]
    for _, attempts_for_assessment in grouped_attempts.items():
        if len(attempts_for_assessment)<2: continue
        attempts_for_assessment.sort(key=lambda x:x[0])
        first=attempts_for_assessment[0][1]; last=attempts_for_assessment[-1][1]
        common=sorted(set(first)&set(last))
        if not common: continue
        agreements.append(sum(first[q]==last[q] for q in common)/len(common))
    retest={"pairs":len(agreements),"status":"INSUFFICIENT_DATA","mean_choice_agreement":None,"note":"Descriptive stability only; no universal pass/fail cutoff is applied."}
    if agreements:
        retest["mean_choice_agreement"]=round(statistics.mean(agreements),4)
        if len(agreements)>=MIN_RETEST_PAIRS: retest["status"]="REVIEW_READY"

    predictive={"status":"INSUFFICIENT_DATA","method":"none","auc_mean":None,"note":"Association only; no production mutation is allowed."}
    if len(unique_connections)>=200 and min(outcomes.get(0,0),outcomes.get(1,0))>=40:
        try:
            from sklearn.feature_extraction import DictVectorizer
            from sklearn.linear_model import LogisticRegression
            from sklearn.model_selection import StratifiedKFold, cross_val_score
            grouped=defaultdict(dict); labels={}
            for row in rows:
                cid=row.get("connection_id",""); q=row.get("question_id",""); y=_truth(row.get("still_active_90d",""))
                if not cid or not q or y is None: continue
                grouped[cid][f"{q}=choice_{row.get('choice_id','')}"]=1; labels[cid]=y
            ids=[cid for cid in grouped if cid in labels]
            X=[grouped[cid] for cid in ids]; y=[labels[cid] for cid in ids]
            vec=DictVectorizer(sparse=True); Xm=vec.fit_transform(X)
            cv=StratifiedKFold(n_splits=5,shuffle=True,random_state=42)
            scores=cross_val_score(LogisticRegression(max_iter=2000,class_weight='balanced'),Xm,y,cv=cv,scoring='roc_auc')
            predictive={"status":"REVIEW_CANDIDATE" if float(scores.mean())>=0.60 else "WEAK_SIGNAL","method":"5-fold logistic regression on pre-match item-choice one-hot features","auc_mean":round(float(scores.mean()),4),"auc_folds":[round(float(x),4) for x in scores],"note":"Association only; not causal proof and never auto-applied."}
        except Exception as exc:
            predictive={"status":"ANALYSIS_UNAVAILABLE","method":"optional_sklearn","auc_mean":None,"note":f"{type(exc).__name__}: {exc}"}

    stage=_pilot_stage(len(participants),len(attempts),item_ready,len(unique_connections),outcomes)
    review_count=len(review)+len(language_drift)+(1 if predictive.get("status")=="REVIEW_CANDIDATE" else 0)
    return {
        "schema_version":"visual-calibration-report-v2",
        "model_version":MODEL_VERSION,"stimulus_version":STIMULUS_VERSION,
        "automatic_production_mutation":False,
        "operational_thresholds_are_validation_claims":False,
        "input_rows":len(all_rows),"accepted_rows":len(rows),"excluded_rows":dict(excluded),
        "participants":len(participants),"attempts":len(attempts),"connections":len(unique_connections),
        "pilot_stage":stage,
        "90d_outcomes":{"active":outcomes.get(1,0),"inactive":outcomes.get(0,0)},
        "locale_rows":dict(sorted(locales.items())),"cohort_rows":dict(sorted(cohorts.items())),
        "scene_coverage":{"expected":EXPECTED_SCENES,"observed":len(scenes),"counts":dict(sorted(scenes.items()))},
        "paradigm_coverage":{"expected":EXPECTED_PARADIGMS,"observed":len(paradigms),"counts":dict(sorted(paradigms.items()))},
        "composition_coverage":{"expected_variants":8,"observed":len(compositions),"counts":dict(sorted(compositions.items())),"per_scene":{k:dict(sorted(v.items())) for k,v in sorted(scene_compositions.items())}},
        "items_with_minimum_review_n":item_ready,
        "item_diagnostics":item_diagnostics,
        "question_position_diagnostics":position_diagnostics,
        "language_drift_review":language_drift,
        "retest_diagnostics":retest,
        "predictive_diagnostics":predictive,
        "review_candidate_count":review_count,
        "verdict":"REVIEW_CANDIDATES_PRESENT" if review_count else "NO_ACTIONABLE_SIGNAL_YET",
    }


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("csv",type=Path)
    ap.add_argument("--out",type=Path,default=Path("visual_calibration_report.json"))
    args=ap.parse_args()
    with args.csv.open(encoding="utf-8",newline="") as f: report=evaluate(csv.DictReader(f))
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:report[k] for k in ("model_version","stimulus_version","accepted_rows","participants","attempts","pilot_stage","review_candidate_count","verdict")},ensure_ascii=False))
    return 0

if __name__ == "__main__": raise SystemExit(main())
