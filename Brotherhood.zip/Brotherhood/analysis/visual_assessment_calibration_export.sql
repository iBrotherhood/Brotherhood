-- Brotherhood visual-latent-v2 / scene-library-v3 30/90-day outcome calibration export.
-- PRIVATE/ANALYTICS ONLY: item-level traces must never be exposed by public API.
-- Causal guard: for each connection/assessment, use only the latest candidate attempt completed
-- on or before matched_at. A post-match assessment must never be used to explain/predict that match.
WITH outcome_candidates AS (
    SELECT
        fo.connection_id,
        fo.matched_at,
        fo.searcher_global_id,
        CASE
            WHEN fo.searcher_global_id = fo.first_global_id THEN fo.second_global_id
            WHEN fo.searcher_global_id = fo.second_global_id THEN fo.first_global_id
            ELSE NULL
        END AS candidate_global_id,
        fo.search_role,
        fo.desired_qualities,
        fo.quality_fit_score,
        fo.quality_fit_confidence,
        fo.quality_model_version,
        fo.still_active_30d,
        fo.still_active_90d,
        fo.ended_reason,
        fo.messages_exchanged_30d
    FROM friendship_outcomes fo
    WHERE fo.searcher_global_id IS NOT NULL
      AND fo.quality_model_version = 'visual-latent-v2'
), eligible_attempts AS (
    SELECT
        oc.connection_id,
        aca.attempt_id,
        aca.global_id,
        aca.assessment_code,
        aca.assessment_version,
        aca.stimulus_version,
        aca.instrument_locale,
        aca.cohort_id,
        aca.consent_version,
        aca.started_at,
        aca.completed_at,
        aca.answer_consistency,
        aca.response_trace,
        ROW_NUMBER() OVER (
            PARTITION BY oc.connection_id, aca.assessment_code
            ORDER BY aca.completed_at DESC
        ) AS rn
    FROM outcome_candidates oc
    JOIN assessment_calibration_attempts aca
      ON aca.global_id = oc.candidate_global_id
     AND aca.completed_at <= oc.matched_at
     AND aca.assessment_version = 'visual-latent-v2'
     AND aca.stimulus_version = 'scene-library-v3'
    JOIN calibration_consents cc
      ON cc.global_id = aca.global_id
     AND cc.opt_in = true
     AND cc.consent_version = aca.consent_version
    WHERE oc.candidate_global_id IS NOT NULL
)
SELECT
    oc.connection_id,
    oc.matched_at,
    oc.searcher_global_id,
    oc.candidate_global_id AS participant_global_id,
    oc.search_role AS role,
    oc.desired_qualities,
    oc.quality_fit_score,
    oc.quality_fit_confidence,
    oc.still_active_30d,
    oc.still_active_90d,
    oc.ended_reason,
    oc.messages_exchanged_30d,
    ea.attempt_id::text AS attempt_id,
    ea.assessment_code AS assessment_id,
    ea.assessment_version AS scoring_version,
    ea.stimulus_version,
    ea.instrument_locale AS locale,
    ea.cohort_id,
    ea.consent_version,
    ea.started_at,
    ea.completed_at,
    GREATEST(0, EXTRACT(EPOCH FROM (ea.completed_at - ea.started_at)) * 1000)::bigint AS duration_ms,
    ea.answer_consistency,
    trace->>'question_id' AS question_id,
    (trace->>'choice_id')::int AS choice_id,
    (trace->>'presentation_slot')::int AS presentation_slot,
    (trace->>'response_latency_ms')::bigint AS response_latency_ms,
    (trace->>'selection_changes')::int AS selection_changes,
    (trace->>'question_position')::int AS question_position,
    trace->>'paradigm' AS paradigm,
    trace->>'scene_archetype' AS scene_archetype,
    trace->>'stimulus_version' AS trace_stimulus_version,
    (trace->>'visual_seed')::int AS visual_seed,
    (trace->>'intensity')::int AS intensity,
    (trace->>'spacing')::int AS spacing,
    (trace->>'order')::int AS "order",
    (trace->>'asymmetry')::int AS asymmetry,
    (trace->>'direction')::int AS direction
FROM outcome_candidates oc
JOIN eligible_attempts ea
  ON ea.connection_id = oc.connection_id
 AND ea.rn = 1
CROSS JOIN LATERAL jsonb_array_elements(ea.response_trace) AS trace
ORDER BY oc.connection_id, ea.assessment_code, question_position;
