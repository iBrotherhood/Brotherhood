#!/usr/bin/env bash
set -euo pipefail
umask 077

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="${1:-$ROOT/reports/generated/calibration_private}"
MODE="${CALIBRATION_MODE:-early}"
KEEP_PRIVATE_CSV="${KEEP_PRIVATE_CSV:-0}"

: "${DATABASE_URL:?DATABASE_URL must be set for the private PostgreSQL calibration export}"
command -v psql >/dev/null 2>&1 || { echo "psql is required" >&2; exit 2; }
command -v python >/dev/null 2>&1 || { echo "python is required" >&2; exit 2; }
mkdir -p "$OUT_DIR"

case "$MODE" in
  early)
    SQL="$ROOT/analysis/visual_item_calibration_export.sql"
    STEM="visual_calibration_early"
    ;;
  outcome)
    SQL="$ROOT/analysis/visual_assessment_calibration_export.sql"
    STEM="visual_calibration_outcome"
    ;;
  *)
    echo "CALIBRATION_MODE must be early or outcome" >&2
    exit 2
    ;;
esac

CSV="$OUT_DIR/${STEM}.private.csv"
REPORT="$OUT_DIR/${STEM}.report.json"

# Do not echo DATABASE_URL. Raw CSV is private and mode 0600 via umask.
psql "$DATABASE_URL" --csv --no-psqlrc --set=ON_ERROR_STOP=1 -f "$SQL" > "$CSV"
python "$ROOT/analysis/calibrate_visual_model.py" "$CSV" --out "$REPORT"
chmod 600 "$CSV" "$REPORT" 2>/dev/null || true

if [[ "$KEEP_PRIVATE_CSV" != "1" ]]; then
  rm -f "$CSV"
  echo "CALIBRATION_REPORT=$REPORT"
  echo "PRIVATE_CSV=PURGED"
else
  echo "CALIBRATION_REPORT=$REPORT"
  echo "PRIVATE_CSV=$CSV"
fi
