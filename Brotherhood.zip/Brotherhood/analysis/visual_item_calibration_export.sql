-- Brotherhood visual-latent-v2 / scene-library-v3 early-pilot calibration export.
-- PRIVATE/ANALYTICS ONLY. Contains global_id and raw item-level traces for opted-in participants.
-- Do not expose this query/result through public API or user profile endpoints.
SELECT
    aca.attempt_id::text AS attempt_id,
    aca.global_id AS participant_global_id,
    aca.assessment_code AS assessment_id,
    aca.assessment_version AS scoring_version,
    aca.stimulus_version,
    aca.instrument_locale AS locale,
    aca.cohort_id,
    aca.consent_version,
    aca.started_at,
    aca.completed_at,
    GREATEST(0, EXTRACT(EPOCH FROM (aca.completed_at - aca.started_at)) * 1000)::bigint AS duration_ms,
    aca.answer_consistency,
    trace->>'question_id' AS question_id,
    (trace->>'choice_id')::int AS choice_id,
    (trace->>'presentation_slot')::int AS presentation_slot,
    (trace->>'response_latency_ms')::bigint AS response_latency_ms,
    (trace->>'selection_changes')::int AS selection_changes,
    (trace->>'question_position')::int AS question_position,
    trace->>'paradigm' AS paradigm,
    trace->>'scene_archetype' AS scene_archetype,
    trace->>'stimulus_version' AS trace_stimulus_version,
    (trace->>'visual_seed')::int AS visual_seed,
    (trace->>'intensity')::int AS intensity,
    (trace->>'spacing')::int AS spacing,
    (trace->>'order')::int AS "order",
    (trace->>'asymmetry')::int AS asymmetry,
    (trace->>'direction')::int AS direction
FROM assessment_calibration_attempts aca
JOIN calibration_consents cc
  ON cc.global_id = aca.global_id
 AND cc.opt_in = true
 AND cc.consent_version = aca.consent_version
CROSS JOIN LATERAL jsonb_array_elements(aca.response_trace) AS trace
WHERE aca.assessment_version = 'visual-latent-v2'
  AND aca.stimulus_version = 'scene-library-v3'
ORDER BY aca.completed_at, aca.attempt_id, question_position;
