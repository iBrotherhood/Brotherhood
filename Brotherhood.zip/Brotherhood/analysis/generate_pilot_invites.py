#!/usr/bin/env python3
"""Generate one-time controlled-pilot invite codes and their SHA-256 digests.

Codes are printed once to stdout for secure distribution. Only digests belong in
BROTHERHOOD_CALIBRATION_INVITE_SHA256. This tool never writes plaintext codes to the project.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import secrets
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--count", type=int, default=18)
    parser.add_argument("--prefix", default="BH-PILOT")
    parser.add_argument("--hashes-out", type=Path)
    args = parser.parse_args()
    if args.count < 1 or args.count > 500:
        parser.error("--count must be in 1..500")
    rows = []
    for index in range(1, args.count + 1):
        code = f"{args.prefix}-{index:03d}-{secrets.token_urlsafe(18)}"
        rows.append({"index": index, "code": code, "sha256": hashlib.sha256(code.encode()).hexdigest()})
    print("PLAINTEXT CODES — distribute securely and do not commit/store in project files:")
    for row in rows:
        print(f"{row['index']:03d}\t{row['code']}")
    digests = [row["sha256"] for row in rows]
    if args.hashes_out:
        args.hashes_out.write_text(json.dumps({"sha256": digests}, indent=2) + "\n", encoding="utf-8")
        print(f"SHA-256 digest file written: {args.hashes_out}")
    else:
        print("BROTHERHOOD_CALIBRATION_INVITE_SHA256=" + ",".join(digests))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
