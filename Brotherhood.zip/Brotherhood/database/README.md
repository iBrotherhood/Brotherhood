# Database — Neon PostgreSQL

Каноническая схема базы хранится отдельно от Android и применяется к Neon до production-деплоя API.

Порядок:

1. Создать проект Neon.
2. Выполнить `migrations/0001_initial.sql`.
3. После настройки Neon Auth/Data API применить `policies/0001_neon_rls.sql`.
4. Передать pooled `DATABASE_URL` только в Vercel Environment Variables.

Android APK никогда не получает пароль PostgreSQL и не подключается к Neon напрямую.
