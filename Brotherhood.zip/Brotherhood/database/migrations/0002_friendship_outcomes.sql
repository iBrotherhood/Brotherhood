-- Brotherhood v0.5.12 longitudinal friendship compatibility outcomes.
-- Internal analytics only: this table is not a public reputation or moderation source.

CREATE TABLE IF NOT EXISTS friendship_outcomes (
    connection_id text PRIMARY KEY,
    first_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    second_global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    matched_at timestamptz NOT NULL,
    layer_scores jsonb NOT NULL CHECK (jsonb_typeof(layer_scores) = 'object'),
    still_active_30d boolean,
    still_active_90d boolean,
    ended_reason text CHECK (ended_reason IS NULL OR ended_reason IN ('block','report','silent_fade','mutual_end','other')),
    messages_exchanged_30d integer CHECK (messages_exchanged_30d IS NULL OR messages_exchanged_30d >= 0),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (first_global_id < second_global_id)
);
CREATE INDEX IF NOT EXISTS friendship_outcomes_90d_idx
    ON friendship_outcomes(still_active_90d, matched_at)
    WHERE still_active_90d IS NOT NULL;
CREATE INDEX IF NOT EXISTS friendship_outcomes_pair_idx
    ON friendship_outcomes(first_global_id, second_global_id, matched_at DESC);
