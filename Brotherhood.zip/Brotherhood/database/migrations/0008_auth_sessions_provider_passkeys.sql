-- Cycle 0003: production auth/session hardening and passkey/email challenge storage.
-- Provider credentials are verified on the backend; global_id remains the sole domain owner.

ALTER TABLE auth_sessions
    ADD COLUMN IF NOT EXISTS refresh_token_hash bytea,
    ADD COLUMN IF NOT EXISTS refresh_expires_at timestamptz,
    ADD COLUMN IF NOT EXISTS device_id text,
    ADD COLUMN IF NOT EXISTS last_used_at timestamptz;

CREATE UNIQUE INDEX IF NOT EXISTS auth_sessions_refresh_token_hash_idx
    ON auth_sessions(refresh_token_hash)
    WHERE refresh_token_hash IS NOT NULL;

CREATE TABLE IF NOT EXISTS auth_email_challenges (
    challenge_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email_normalized text NOT NULL,
    code_hash bytea NOT NULL,
    expires_at timestamptz NOT NULL,
    consumed_at timestamptz,
    attempts smallint NOT NULL DEFAULT 0 CHECK (attempts BETWEEN 0 AND 10),
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS auth_email_challenges_lookup_idx
    ON auth_email_challenges(email_normalized, expires_at DESC)
    WHERE consumed_at IS NULL;

CREATE TABLE IF NOT EXISTS passkey_credentials (
    credential_id bytea PRIMARY KEY,
    global_id bigint NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    public_key bytea NOT NULL,
    sign_count bigint NOT NULL DEFAULT 0 CHECK (sign_count >= 0),
    transports jsonb NOT NULL DEFAULT '[]'::jsonb,
    device_type text,
    backed_up boolean NOT NULL DEFAULT false,
    revoked_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    last_used_at timestamptz
);
CREATE INDEX IF NOT EXISTS passkey_credentials_global_id_idx ON passkey_credentials(global_id);

CREATE TABLE IF NOT EXISTS passkey_challenges (
    challenge_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    global_id bigint REFERENCES users(global_id) ON DELETE CASCADE,
    kind text NOT NULL CHECK (kind IN ('registration', 'authentication')),
    challenge bytea NOT NULL,
    expires_at timestamptz NOT NULL,
    consumed_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS passkey_challenges_active_idx
    ON passkey_challenges(kind, expires_at)
    WHERE consumed_at IS NULL;

CREATE TABLE IF NOT EXISTS user_settings (
    global_id bigint PRIMARY KEY REFERENCES users(global_id) ON DELETE CASCADE,
    locale text NOT NULL DEFAULT 'ru',
    theme text NOT NULL DEFAULT 'system' CHECK (theme IN ('system','light','dark')),
    profile_visibility text NOT NULL DEFAULT 'discoverable' CHECK (profile_visibility IN ('discoverable','connections','private')),
    preferences jsonb NOT NULL DEFAULT '{}'::jsonb,
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS auth_oidc_challenges (
    challenge_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    provider auth_provider NOT NULL,
    state_hash bytea NOT NULL UNIQUE,
    code_verifier text NOT NULL,
    nonce text NOT NULL,
    redirect_uri text NOT NULL,
    device_id text NOT NULL,
    expires_at timestamptz NOT NULL,
    consumed_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS auth_oidc_challenges_active_idx
    ON auth_oidc_challenges(provider, expires_at)
    WHERE consumed_at IS NULL;

CREATE INDEX IF NOT EXISTS user_identities_verified_email_idx
    ON user_identities(email_normalized, global_id)
    WHERE email_normalized IS NOT NULL AND verified_at IS NOT NULL;


CREATE TABLE IF NOT EXISTS auth_login_tickets (
    ticket_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_hash BYTEA NOT NULL UNIQUE,
    global_id BIGINT NOT NULL REFERENCES users(global_id) ON DELETE CASCADE,
    provider auth_provider NOT NULL,
    device_id TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    consumed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS auth_login_tickets_active_idx ON auth_login_tickets(expires_at) WHERE consumed_at IS NULL;
