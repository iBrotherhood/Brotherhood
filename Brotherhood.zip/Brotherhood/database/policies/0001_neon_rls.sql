-- Apply after Neon Auth and Data API are enabled.
-- auth.user_id() returns the authenticated Neon Auth user ID.

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE personality_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessment_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversation_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY profiles_discovery_read ON profiles
FOR SELECT USING (
    visibility = 'discoverable'
    OR EXISTS (
        SELECT 1 FROM auth_links l
        WHERE l.auth_user_id = auth.user_id() AND l.global_id = profiles.global_id
    )
);

CREATE POLICY profiles_owner_write ON profiles
FOR ALL USING (
    EXISTS (
        SELECT 1 FROM auth_links l
        WHERE l.auth_user_id = auth.user_id() AND l.global_id = profiles.global_id
    )
) WITH CHECK (
    EXISTS (
        SELECT 1 FROM auth_links l
        WHERE l.auth_user_id = auth.user_id() AND l.global_id = profiles.global_id
    )
);

CREATE POLICY personality_owner_read_write ON personality_profiles
FOR ALL USING (
    EXISTS (SELECT 1 FROM auth_links l WHERE l.auth_user_id = auth.user_id() AND l.global_id = personality_profiles.global_id)
) WITH CHECK (
    EXISTS (SELECT 1 FROM auth_links l WHERE l.auth_user_id = auth.user_id() AND l.global_id = personality_profiles.global_id)
);

CREATE POLICY assessment_owner_read_write ON assessment_results
FOR ALL USING (
    EXISTS (SELECT 1 FROM auth_links l WHERE l.auth_user_id = auth.user_id() AND l.global_id = assessment_results.global_id)
) WITH CHECK (
    EXISTS (SELECT 1 FROM auth_links l WHERE l.auth_user_id = auth.user_id() AND l.global_id = assessment_results.global_id)
);

CREATE POLICY memberships_member_read ON community_members
FOR SELECT USING (
    EXISTS (SELECT 1 FROM auth_links l WHERE l.auth_user_id = auth.user_id() AND l.global_id = community_members.global_id)
    OR status = 'active'
);

CREATE POLICY connections_participant_access ON connections
FOR ALL USING (
    EXISTS (
        SELECT 1 FROM auth_links l
        WHERE l.auth_user_id = auth.user_id()
          AND l.global_id IN (connections.first_global_id, connections.second_global_id)
    )
) WITH CHECK (
    EXISTS (
        SELECT 1 FROM auth_links l
        WHERE l.auth_user_id = auth.user_id()
          AND l.global_id IN (connections.first_global_id, connections.second_global_id)
    )
);

CREATE POLICY conversation_members_participant_access ON conversation_members
FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM auth_links l
        WHERE l.auth_user_id = auth.user_id()
          AND l.global_id = conversation_members.global_id
    )
);

CREATE POLICY messages_participant_read ON messages
FOR SELECT USING (
    EXISTS (
        SELECT 1
        FROM conversation_members cm
        JOIN auth_links l ON l.global_id = cm.global_id
        WHERE cm.conversation_id = messages.conversation_id
          AND l.auth_user_id = auth.user_id()
    )
);

CREATE POLICY messages_sender_insert ON messages
FOR INSERT WITH CHECK (
    EXISTS (
        SELECT 1
        FROM conversation_members cm
        JOIN auth_links l ON l.global_id = cm.global_id
        WHERE cm.conversation_id = messages.conversation_id
          AND cm.global_id = messages.sender_global_id
          AND l.auth_user_id = auth.user_id()
    )
);

-- Do not expose trust_incidents, evidence, moderation_decisions or auth_sessions through Data API.
-- Keep them behind a trusted edge/server function with explicit authorization and audit logging.
