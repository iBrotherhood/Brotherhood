# Brotherhood v0.5.23

Мужское Android-приложение 18+ для поиска настоящих платонических друзей на основе характера, образа жизни, ценностей, устойчивости дружбы и подтверждённой репутации.

## Cycle 0002 source milestone v0.5.23

- Home/Profile/Self-analysis показывают накопленный положительный профиль, последнее открытие, следующий шаг, полезные контексты и историю без раскрытия latent scoring.
- People сохраняет раздельные Compatibility/Quality Fit и получает читаемые narrow-screen CTA; Groups быстрее показывают тип, формат и действие.
- Language selector остаётся data-driven `LazyRow` по полным RU/UK/EN packs; исправленные runtime-error paths не падают в скрытый русский fallback и не показывают raw exception text.
- Settings всегда честно объясняет manual Development APK install; controlled pilot остаётся сворачиваемым.
- Source milestone имеет только source/local evidence до GitHub checkpoint A и реального APK screenshot acceptance.

## Канон архивов

- Исходный архив: `Brotherhood_v0_5_22.zip`.
- Полный GitHub-пакет: `Brotherhood_GitHub_Canonical_v0_5_22.zip`.
- Внутри любого выдаваемого ZIP верхняя папка всегда `Brotherhood/`.
- Канонический источник: распакованный код в GitHub.
- Единственный универсальный GitHub workflow распаковывает `Brotherhood.zip`, извлекает фактическую версию и собирает APK без изменения YAML между релизами.


## Бренд, профиль и поиск v0.5.20

- канонический логотип Brotherhood встроен из `brand/BR_logo_master.svg` (чёрный фон `#000000`, золотой знак `#ECAF21`);
- adaptive launcher icon, Android 13 monochrome icon и Android 12+ branded splash подготовлены из одного master SVG;
- вкладка «Люди» получила Quick Discovery: один кандидат за раз, пропуск, возврат последнего пропуска, подробная совместимость и запрос дружбы;
- добавлены реальные фильтры: verified-only, online-only, общий интерес, минимальный Trust, минимальная совместимость и скрытие уже запрошенных профилей;
- профиль может быть `discoverable`, `connections` или `private`; режим синхронизируется с backend;
- поиск другого города используется как Passport mode без изменения домашнего города профиля;
- в профиле добавлена статистика запросов, чатов и групп.

## Продукт

## Навигация v0.5.20

Ключевые функции больше не скрыты во вторичных меню. Нижняя навигация: **Главная / Люди / Чаты / Группы / Профиль**. Главная показывает прямые карточки: чаты, 15 взвешенных слоёв совместимости + отдельный Quality Fit по выбранным качествам, «Познание себя», 100 психологических тестов, Trust, Brotherhood-32, Enneagram, Zodiac и Vedic Numerology. Непрочитанные чаты имеют badge. Последняя выбранная вкладка сохраняется локально.

Название приложения во всех локалях и Android launcher label: **Brotherhood**.


- только мужчины 18+;
- платоническая дружба;
- 100 психологических/поведенческих тестов / 600 непрямых визуально-ассоциативных заданий;
- Brotherhood-32: 32 типа личности по пяти осям;
- характер, образ жизни, ценности;
- эннеаграмма;
- зодиак;
- ведическая нумерология;
- скрытые cross-checks согласованности профиля только для алгоритмов;
- Trust Center;
- сообщества: футбол, спорт, автомобили, путешествия, технологии, бизнес и другие;
- география по городам;
- языки управляются единым data-driven registry; текущие полные пакеты: RU / UK / EN; переключение — горизонтальная карусель, будущие языки добавляются отдельными полными language-pack без изменения matching-кода;
- светлая, чёрная и системная темы;
- `global_id`: `0000000001`, `0000000002`, …


## Совместимость v0.5.20

Пользователь видит отдельные показатели: 100 психологических тестов дружбы, интересы, характер, ценности, образ жизни, цели дружбы, стиль общения, конфликты/восстановление, бизнес/взаимопомощь, социальный формат, Brotherhood-32, Enneagram, Zodiac, Vedic Numerology и география. Затем показываются **базовая совместимость** и **совместимость именно для пользователя**. Trust Score отображается отдельно и не смешивается с психологическим совпадением.

Ведическая нумерология не является тестом: пользователь не отвечает на вопросы. Профиль рассчитывается математически из даты рождения, а дружеская совместимость этого слоя — только из двух дат рождения. Дополнительное число имени, если отображается, не входит в ведическую совместимость.

### Полный нумерологический профиль v0.5.13

В APK добавлен локальный справочник, нормализованный на RU/UK/EN по всему доступному массиву `Numerology-main.zip`: 11 характеристик Soul Number, 11 Life Path (по 5 разделов), 52 конфигурации Birth Chart, 11 Pyramid/Pinnacle и 12 Outer/Expression. Дата рождения автоматически определяет Life Path, цифровую матрицу, специальные isolated/missing-конфигурации и четыре жизненных пика. Исходный вьетнамский материал сохранён отдельно как provenance-снимок. Имя используется только для описательных Soul/Expression характеристик и не влияет на дружескую совместимость.

### Калибровка совместимости по реальным исходам

- текущие 15 весов остаются production-каноном и в сумме дают 100%; Vedic Numerology остаётся 5%;
- старый ID-зависимый `Friendship Expectations` diagnostic из v0.5.12 выведен из активной модели; ожидания пользователя представлены через явно выбранные качества в Quality Fit;
- backend хранит приватные `friendship_outcomes`: снимок canonical layers, пользовательского SearchIntent/Quality Fit/model version на момент связи, активность через 30/90 дней, сообщения за 30 дней и нейтральную причину завершения;
- `analysis/recalibrate_friendship_weights.py` строит стандартизированную logistic regression и выдаёт только кандидатные веса для ручного review; приложение не меняет production-веса автоматически.

### Скрытая визуально-ассоциативная психология v0.5.20

- активная модель: `visual-latent-v2`, stimulus provenance: `scene-library-v4`;
- библиотека содержит 48 нейтральных сценовых архетипов, 16 визуальных парадигм и 8 неоцениваемых композиционных вариантов;
- банк остаётся ровно 100 психологических/поведенческих тестов × 6 = 600 заданий;
- прямые вопросы о верности, честности, лидерстве, поддержке и других очевидных качествах удалены из канонического банка;
- пользователь выбирает между изображениями/композициями и не видит, какие латентные координаты измеряются;
- один выбор не является диагнозом: качества строятся из распределённых сигналов по множеству заданий;
- оба полюса каждой координаты имеют допустимую контекстную интерпретацию — универсально плохих качеств нет;
- старые direct-question результаты сохраняются только как история и не входят в `visual-latent-v2`;
- raw latent coordinates, cross-checks, response trace и consistency signals не выдаются обычным public API;
- приватный item-level response trace сохраняет точный stimulus/choice только для внутренней эмпирической калибровки и не меняет production-loadings автоматически.

### Quality Fit — подбор по качествам пользователя

Каталог v0.5.20 содержит 112 выбираемых качеств RU/UK/EN, включая составные дружеские, деловые, управленческие и проектные паттерны. Пользователь сам выбирает роль (друг, бизнес-партнёр, директор, участник проекта и т. п.) и нужные качества. Роль не добавляет скрытые default-качества. Новый Quality Fit сравнивает выбранные качества с приватным латентным профилем кандидата и остаётся отдельным от Compatibility, Trust и Account Completeness. Публично показываются только положительно сформулированные сильные стороны и соответствие запросу.

Controlled calibration pilot: сырые item-level traces сохраняются на сервере только при явном opt-in, отдельно от рабочего агрегированного профиля; withdrawal удаляет сырые попытки. `scene-library-v4` фиксирует presentation slot, latency, answer changes и question position для диагностики position/order bias. Outcome-анализ использует только pre-match assessments и никогда не меняет production-модель автоматически.

### Аватар

Пользователь может выбрать изображение через системный picker. APK копирует его в app-private storage, уменьшает до 768 px по длинной стороне, кодирует в bounded JPEG ≤512 KiB и синхронизирует через Vercel backend. Широкое разрешение на чтение медиатеки не добавляется.

## Чаты v0.5.20

- личные: E2EE v1, fingerprints и TOFU pinning;
- группы: не секретные, доступные серверной модерации, encrypted-at-rest;
- текст, фото, аудио, видео, файлы, голос через системный recorder;
- reply, reactions, typing, edit, delete, delivered/read receipts;
- блокировка/разблокировка и закрытая жалоба на собеседника;
- управление участниками группы владельцем;
- offline outbox/retry;
- серверный hook для FCM push-токенов (реальная доставка требует внешних Firebase credentials).

E2EE v1 использует стандартные криптографические примитивы, но является собственным протоколом Brotherhood и не заявляется эквивалентом Signal/Telegram Secret Chats до независимого аудита и multi-device hardening.

## Самоанализ

Раздел «Познание себя» объединяет пройденные тесты, сильные стороны, индивидуальные стили, Brotherhood-32, Enneagram, Zodiac и Vedic Numerology, чтобы приложение было полезно и вне активного поиска друзей.

## Рейтинг аккаунта

- 50% — 10 заполненных разделов профиля × 5%;
- 50% — 100 уникальных тестов × 0,5%.

Рейтинг заполненности не равен Trust Score. Ответы влияют на совместимость, подтверждённое поведение — на репутацию.


## Локализация v0.5.20

- один runtime-язык управляет навигацией, разделами, настройками, качествами поиска, визуальными сериями, результатами, Brotherhood-32, Enneagram, Zodiac, Vedic Numerology и серверными локализованными поверхностями;
- выбор языка реализован каруселью на входе и в настройках;
- `shared/locales/supported.json` — единый registry, Android использует его зеркальную копию;
- язык активируется только при полном coverage обязательных ключей и наличии нумерологического locale-блока;
- направление интерфейса (`ltr` / `rtl`) задаётся метаданными языка, поэтому будущие RTL-языки не требуют переписывания навигации;
- добавление нового языка не меняет Compatibility, Quality Fit или психологический scoring.
- встроенные города имеют стабильное search/storage значение и локализованное отображаемое название (`Киев` / `Київ` / `Kyiv`); пользовательские тексты и произвольные географические строки язык интерфейса не переписывает;
- текущий activation gate содержит 713 обязательных runtime-ключей; неполный language-pack не появляется в карусели.

## Runtime v0.5.20

### Android

В APK находятся:

- тесты и расчётные движки;
- Brotherhood-32 / Enneagram / Zodiac / Vedic Numerology;
- локальный профиль и настройки;
- SQLite cache;
- stale-while-revalidate;
- pending mutations;
- автоматический retry/flush очереди после восстановления сети;
- remote repository для пользователей и сообществ через Vercel API;
- demo-данные разрешены только в debug-сборке как тестовый fallback.

### Backend

```text
Android APK
    ↓ HTTPS + app session
Vercel FastAPI
    ↓
Neon PostgreSQL
```

При наличии `DATABASE_URL` backend автоматически использует PostgreSQL/Neon. In-memory storage оставлен только для unit tests и локальной разработки.

Реализованы server-side:

- последовательная выдача `global_id`;
- profiles;
- assessment results;
- communities;
- trust incidents;
- encrypted private trust description;
- personal direct chats: Android-side E2EE ciphertext only;
- group chats: server-visible for moderation, encrypted at rest;
- replies, reactions, typing, editing, sender deletion and delivery/read receipts;
- auth session hash;
- owner checks по session → global_id;
- internal identity/session bridge для provider adapters.

APK никогда не содержит `DATABASE_URL`, `TRUST_ENCRYPTION_KEY`, `MESSAGE_ENCRYPTION_KEY` или provider secrets.

## Авторизация

UI и каноническая identity-модель готовы для:

- Google;
- Telegram;
- Facebook;
- email;
- Passkey;
- будущих Apple / Microsoft / phone.

Для production Google/Telegram/Facebook требуются реальные Client/App IDs, redirect URLs и secrets в Vercel. Debug APK сохраняет тестовый вход для проверки интерфейса; release не должен создавать фиктивную provider identity.

Подробности: `docs/AUTH_AND_SESSION_BOUNDARY.md`.

## Материалы Песочницы

Проверены предоставленные источники. В проект перенесены только совместимые архитектурные решения; GPL/некоммерческие SDK и чужие изображения/шрифты не включаются.

Подробности: `docs/SANDBOX_SOURCE_INTEGRATION_v0_5_3.md`.

## GitHub Actions

- `.github/workflows/android-build.yml` — единственный универсальный Android workflow: проверяет `Brotherhood.zip`, извлекает фактическую версию, запускает тесты/сборку, валидирует APK и публикует artifact. После утверждения не меняется между релизами.

## Backend tests

```bash
cd backend
pip install -r requirements.txt
pytest -q
```

## Обновление внутреннего Brotherhood.zip

```bash
python scripts/package_source_archive.py --write Brotherhood.zip
python scripts/package_source_archive.py --check Brotherhood.zip
sha256sum Brotherhood.zip > Brotherhood.zip.sha256
```

Подробный канон: `docs/PROJECT_CANON_v0_5_4.md`.
