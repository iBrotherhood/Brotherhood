# Brotherhood v0.5.6

Мужское Android-приложение 18+ для поиска настоящих платонических друзей на основе характера, образа жизни, ценностей, устойчивости дружбы и подтверждённой репутации.

## Канон архивов

- Исходный архив: `Brotherhood_v0_5_6.zip`.
- Полный GitHub-пакет: `Brotherhood_GitHub_Canonical_v0_5_6.zip`.
- Внутри любого выдаваемого ZIP верхняя папка всегда `Brotherhood/`.
- Канонический источник: распакованный код в GitHub.
- Тестовый APK: внешний GitHub workflow распаковывает `Brotherhood.zip` и собирает APK.
- Прямой GitHub APK: внутренний workflow собирает `android/` из распакованного кода.

## Продукт

- только мужчины 18+;
- платоническая дружба;
- 100 тестов / 600 вопросов;
- Brotherhood-32: 32 типа личности по пяти осям;
- характер, образ жизни, ценности;
- эннеаграмма;
- зодиак;
- ведическая нумерология;
- перекрёстный поиск противоречивой самопрезентации;
- Trust Center;
- сообщества: футбол, спорт, автомобили, путешествия, технологии, бизнес и другие;
- география по городам;
- RU / UA / EN;
- светлая, чёрная и системная темы;
- `global_id`: `0000000001`, `0000000002`, …

## Рейтинг аккаунта

- 50% — 10 заполненных разделов профиля × 5%;
- 50% — 100 уникальных тестов × 0,5%.

Рейтинг заполненности не равен Trust Score. Ответы влияют на совместимость, подтверждённое поведение — на репутацию.

## Runtime v0.5.6

### Android

В APK находятся:

- тесты и расчётные движки;
- Brotherhood-32 / Enneagram / Zodiac / Vedic Numerology;
- локальный профиль и настройки;
- SQLite cache;
- stale-while-revalidate;
- pending mutations;
- автоматический retry/flush очереди после восстановления сети;
- remote repository для пользователей и сообществ через Vercel API;
- demo-данные разрешены только в debug-сборке как тестовый fallback.

### Backend

```text
Android APK
    ↓ HTTPS + app session
Vercel FastAPI
    ↓
Neon PostgreSQL
```

При наличии `DATABASE_URL` backend автоматически использует PostgreSQL/Neon. In-memory storage оставлен только для unit tests и локальной разработки.

Реализованы server-side:

- последовательная выдача `global_id`;
- profiles;
- assessment results;
- communities;
- trust incidents;
- encrypted private trust description;
- direct messages с server-side encryption;
- auth session hash;
- owner checks по session → global_id;
- internal identity/session bridge для provider adapters.

APK никогда не содержит `DATABASE_URL`, `TRUST_ENCRYPTION_KEY`, `MESSAGE_ENCRYPTION_KEY` или provider secrets.

## Авторизация

UI и каноническая identity-модель готовы для:

- Google;
- Telegram;
- Facebook;
- email;
- Passkey;
- будущих Apple / Microsoft / phone.

Для production Google/Telegram/Facebook требуются реальные Client/App IDs, redirect URLs и secrets в Vercel. Debug APK сохраняет тестовый вход для проверки интерфейса; release не должен создавать фиктивную provider identity.

Подробности: `docs/AUTH_AND_SESSION_BOUNDARY.md`.

## Материалы Песочницы

Проверены предоставленные источники. В проект перенесены только совместимые архитектурные решения; GPL/некоммерческие SDK и чужие изображения/шрифты не включаются.

Подробности: `docs/SANDBOX_SOURCE_INTEGRATION_v0_5_3.md`.

## GitHub Actions

- `.github/workflows/android-build.yml` — распаковывает `Brotherhood.zip` и собирает тестовый APK;
- `.github/workflows/android-source-build.yml` — собирает APK из распакованного `android/`;
- `.github/workflows/source-check.yml` — проверяет backend, канон и parity ZIP;
- `.github/workflows/backend-check.yml` — API tests.

## Backend tests

```bash
cd backend
pip install -r requirements.txt
pytest -q
```

## Обновление внутреннего Brotherhood.zip

```bash
python scripts/package_source_archive.py --write Brotherhood.zip
python scripts/package_source_archive.py --check Brotherhood.zip
sha256sum Brotherhood.zip > Brotherhood.zip.sha256
```

Подробный канон: `docs/PROJECT_CANON_v0_5_4.md`.
