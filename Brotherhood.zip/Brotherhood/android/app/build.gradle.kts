plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

val brotherhoodApiBaseUrl = providers.gradleProperty("brotherhoodApiBaseUrl")
    .orElse(System.getenv("BROTHERHOOD_API_BASE_URL") ?: "https://example.invalid")

val stableSigningStore = System.getenv("BROTHERHOOD_SIGNING_STORE_FILE")
val stableSigningStorePassword = System.getenv("BROTHERHOOD_SIGNING_STORE_PASSWORD")
val stableSigningKeyAlias = System.getenv("BROTHERHOOD_SIGNING_KEY_ALIAS")
val stableSigningKeyPassword = System.getenv("BROTHERHOOD_SIGNING_KEY_PASSWORD")
val stableSigningEnabled = listOf(
    stableSigningStore,
    stableSigningStorePassword,
    stableSigningKeyAlias,
    stableSigningKeyPassword,
).all { !it.isNullOrBlank() }

android {
    namespace = "org.federationofavatars.brotherhood"
    compileSdk = 36

    defaultConfig {
        applicationId = "org.federationofavatars.brotherhood"
        minSdk = 26
        targetSdk = 36
        versionCode = 15
        versionName = "0.5.10"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "API_BASE_URL", "\"${brotherhoodApiBaseUrl.get()}\"")
    }

    signingConfigs {
        if (stableSigningEnabled) {
            create("stableTest") {
                storeFile = file(requireNotNull(stableSigningStore))
                storePassword = requireNotNull(stableSigningStorePassword)
                keyAlias = requireNotNull(stableSigningKeyAlias)
                keyPassword = requireNotNull(stableSigningKeyPassword)
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
                enableV4Signing = true
            }
        }
    }

    buildTypes {
        debug {
            if (stableSigningEnabled) {
                signingConfig = signingConfigs.getByName("stableTest")
            }
        }
        release {
            isMinifyEnabled = true
            if (stableSigningEnabled) {
                signingConfig = signingConfigs.getByName("stableTest")
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.play.app.update)
    implementation(libs.play.app.update.ktx)

    debugImplementation(libs.androidx.compose.ui.tooling)
    testImplementation(libs.junit)
}
