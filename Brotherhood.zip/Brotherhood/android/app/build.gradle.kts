plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

val brotherhoodApiBaseUrl = providers.gradleProperty("brotherhoodApiBaseUrl")
    .orElse(System.getenv("BROTHERHOOD_API_BASE_URL") ?: "https://example.invalid")
val googleServerClientId = providers.gradleProperty("googleServerClientId")
    .orElse(System.getenv("BROTHERHOOD_GOOGLE_CLIENT_ID") ?: "")
val telegramAppCallbackUri = providers.gradleProperty("telegramAppCallbackUri")
    .orElse(System.getenv("BROTHERHOOD_TELEGRAM_APP_CALLBACK_URI") ?: "brotherhood://telegram-login/callback")
val telegramAppCallback = java.net.URI(telegramAppCallbackUri.get())
require(!telegramAppCallback.scheme.isNullOrBlank() && !telegramAppCallback.host.isNullOrBlank()) {
    "telegramAppCallbackUri must contain a scheme and host"
}

val developmentSigningStore = System.getenv("BROTHERHOOD_DEV_SIGNING_STORE_FILE")
val developmentSigningStorePassword = System.getenv("BROTHERHOOD_DEV_SIGNING_STORE_PASSWORD")
val developmentSigningKeyAlias = System.getenv("BROTHERHOOD_DEV_SIGNING_KEY_ALIAS")
val developmentSigningKeyPassword = System.getenv("BROTHERHOOD_DEV_SIGNING_KEY_PASSWORD")
val developmentSigningValues = listOf(
    developmentSigningStore,
    developmentSigningStorePassword,
    developmentSigningKeyAlias,
    developmentSigningKeyPassword,
)
val developmentSigningAny = developmentSigningValues.any { !it.isNullOrBlank() }
val developmentSigningEnabled = developmentSigningValues.all { !it.isNullOrBlank() }

if (developmentSigningAny && !developmentSigningEnabled) {
    throw GradleException("Incomplete Brotherhood Development signing configuration.")
}


android {
    namespace = "org.federationofavatars.brotherhood"
    compileSdk = 36

    defaultConfig {
        applicationId = "org.federationofavatars.brotherhood"
        minSdk = 26
        targetSdk = 36
        versionCode = 28
        versionName = "0.5.23"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "API_BASE_URL", "\"${brotherhoodApiBaseUrl.get()}\"")
        buildConfigField("String", "GOOGLE_SERVER_CLIENT_ID", "\"${googleServerClientId.get()}\"")
        buildConfigField("String", "TELEGRAM_APP_CALLBACK_URI", "\"${telegramAppCallbackUri.get()}\"")
        // Compatibility alias retained for prior source clients; it is the app callback, not the Telegram OIDC redirect.
        buildConfigField("String", "TELEGRAM_REDIRECT_URI", "\"${telegramAppCallbackUri.get()}\"")
        manifestPlaceholders["telegramRedirectScheme"] = telegramAppCallback.scheme
        manifestPlaceholders["telegramRedirectHost"] = telegramAppCallback.host
        manifestPlaceholders["telegramRedirectPath"] = telegramAppCallback.path.takeIf { !it.isNullOrBlank() } ?: "/"
    }

    signingConfigs {
        if (developmentSigningEnabled) {
            create("development") {
                storeFile = file(requireNotNull(developmentSigningStore))
                storePassword = requireNotNull(developmentSigningStorePassword)
                keyAlias = requireNotNull(developmentSigningKeyAlias)
                keyPassword = requireNotNull(developmentSigningKeyPassword)
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
                enableV4Signing = true
            }
        }
    }

    buildTypes {
        debug {
            isDebuggable = true
            if (developmentSigningEnabled) {
                signingConfig = signingConfigs.getByName("development")
            }
        }
        release {
            isMinifyEnabled = true
            // Production signing is intentionally NOT configured here.
            // A future production signing identity must be introduced separately.
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.play.app.update)
    implementation(libs.play.app.update.ktx)
    implementation(libs.androidx.credentials)
    implementation(libs.androidx.credentials.play.services.auth)
    implementation(libs.googleid)

    debugImplementation(libs.androidx.compose.ui.tooling)
    testImplementation(libs.junit)
}
