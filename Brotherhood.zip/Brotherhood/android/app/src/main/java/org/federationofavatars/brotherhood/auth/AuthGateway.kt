package org.federationofavatars.brotherhood.auth

import org.federationofavatars.brotherhood.model.AuthIdentity
import org.federationofavatars.brotherhood.model.AuthProvider
import org.federationofavatars.brotherhood.model.GlobalId

data class AuthConfiguration(
    val googleServerClientId: String = "SET_IN_LOCAL_PROPERTIES",
    val telegramClientId: String = "SET_IN_LOCAL_PROPERTIES",
    val facebookAppId: String = "SET_IN_LOCAL_PROPERTIES",
    val authBaseUrl: String = "https://YOUR_NEON_AUTH_OR_EDGE_ENDPOINT"
)

sealed interface AuthResult {
    data class Success(val identity: AuthIdentity, val accessToken: String) : AuthResult
    data class RequiresConfiguration(val provider: AuthProvider, val missing: String) : AuthResult
    data class Failure(val message: String) : AuthResult
}

interface AuthGateway {
    suspend fun signIn(provider: AuthProvider): AuthResult
    suspend fun signOut()
}

class DemoAuthGateway : AuthGateway {
    override suspend fun signIn(provider: AuthProvider): AuthResult = AuthResult.Success(
        identity = AuthIdentity(provider, "demo-${provider.name.lowercase()}", GlobalId(1)),
        accessToken = "demo-local-session"
    )

    override suspend fun signOut() = Unit
}
