package org.federationofavatars.brotherhood.domain

import org.federationofavatars.brotherhood.model.EnneagramProfile

object EnneagramEngine {
    private data class TypeInfo(val ru: String, val uk: String, val en: String)
    private val types = mapOf(
        1 to TypeInfo("Реформатор", "Реформатор", "Reformer"),
        2 to TypeInfo("Помощник", "Помічник", "Helper"),
        3 to TypeInfo("Достигатель", "Досягач", "Achiever"),
        4 to TypeInfo("Индивидуалист", "Індивідуаліст", "Individualist"),
        5 to TypeInfo("Исследователь", "Дослідник", "Investigator"),
        6 to TypeInfo("Лоялист", "Лояліст", "Loyalist"),
        7 to TypeInfo("Энтузиаст", "Ентузіаст", "Enthusiast"),
        8 to TypeInfo("Защитник", "Захисник", "Challenger"),
        9 to TypeInfo("Миротворец", "Миротворець", "Peacemaker")
    )

    fun classify(scores: Map<Int, Int>): EnneagramProfile {
        require((1..9).all { scores[it] != null })
        val type = scores.maxBy { it.value }.key
        val left = if (type == 1) 9 else type - 1
        val right = if (type == 9) 1 else type + 1
        val wing = listOf(left, right).maxBy { scores.getValue(it) }
        val info = types.getValue(type)
        return EnneagramProfile(type, wing, scores.getValue(type).coerceIn(0, 100), info.ru, info.uk, info.en)
    }

    fun compatibility(first: EnneagramProfile, second: EnneagramProfile): Int {
        if (first.type == second.type) return 88
        val distance = kotlin.math.abs(first.type - second.type).let { minOf(it, 9 - it) }
        val wingBonus = if (first.wing == second.type || second.wing == first.type) 10 else 0
        return (82 - distance * 6 + wingBonus).coerceIn(35, 95)
    }
}
