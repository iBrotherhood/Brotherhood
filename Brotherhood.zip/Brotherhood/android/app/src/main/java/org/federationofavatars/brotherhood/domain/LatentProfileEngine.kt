package org.federationofavatars.brotherhood.domain

import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.LatentProfile
import org.federationofavatars.brotherhood.model.LatentTraitScore
import org.federationofavatars.brotherhood.model.AssessmentModelVersions

/** Aggregates hidden per-block coordinates into one internal profile. */
object LatentProfileEngine {
    fun build(results: Collection<AssessmentResult>): LatentProfile {
        // Hard migration boundary: legacy direct-question scores are historical only.
        val currentResults = results.filter { it.modelVersion == AssessmentModelVersions.ACTIVE }
        if (currentResults.isEmpty()) return LatentProfile(emptyMap(), 0)
        data class Weighted(val score: Int, val weight: Double)
        val rows = mutableMapOf<String, MutableList<Weighted>>()
        currentResults.forEach { result ->
            val weight = (0.35 + result.answerConsistency.coerceIn(0, 100) / 100.0 * 0.65)
            result.dimensions.forEach { dimension ->
                rows.getOrPut(dimension.id) { mutableListOf() }.add(Weighted(dimension.score, weight))
            }
        }
        val traits = rows.mapValues { (key, values) ->
            val denominator = values.sumOf { it.weight }.coerceAtLeast(.001)
            val score = (values.sumOf { it.score * it.weight } / denominator).roundToInt().coerceIn(0, 100)
            LatentTraitScore(key, score, values.size)
        }
        val coverage = (currentResults.map { it.assessmentId }.distinct().size * 100 / 100).coerceIn(0, 100)
        val evidenceFactor = traits.values.map { it.evidence.coerceAtMost(6) / 6.0 }.average().takeUnless(Double::isNaN) ?: 0.0
        val confidence = (coverage * 0.7 + evidenceFactor * 100 * 0.3).roundToInt().coerceIn(0, 100)
        return LatentProfile(traits, confidence)
    }
}
