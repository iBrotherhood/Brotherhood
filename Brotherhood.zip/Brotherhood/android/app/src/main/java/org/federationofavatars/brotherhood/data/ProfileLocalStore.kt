package org.federationofavatars.brotherhood.data

import android.content.Context
import java.time.LocalDate
import java.time.Period
import org.federationofavatars.brotherhood.domain.VedicNumerologyEngine
import org.federationofavatars.brotherhood.domain.ZodiacEngine
import org.federationofavatars.brotherhood.model.EnneagramProfile
import org.federationofavatars.brotherhood.model.Personality32Profile
import org.federationofavatars.brotherhood.model.UserProfile
import org.federationofavatars.brotherhood.model.VedicNumerologyProfile
import org.federationofavatars.brotherhood.model.ZodiacSign
import org.json.JSONArray
import org.json.JSONObject

/**
 * Stores the user-owned editable profile locally so the APK remains useful offline.
 * Server synchronization is additive; it is not required to read or edit the profile.
 */
class ProfileLocalStore(context: Context) {
    private val preferences = context.getSharedPreferences("brotherhood_profile", Context.MODE_PRIVATE)

    fun load(base: UserProfile): UserProfile {
        val raw = preferences.getString(KEY_PROFILE, null)
            ?: preferences.getString(LEGACY_KEY_PROFILE, null)
            ?: return base
        return runCatching {
            val json = JSONObject(raw)
            val birthDate = runCatching { LocalDate.parse(json.optString("birth_date", base.birthDate.toString())) }.getOrDefault(base.birthDate)
            val latinName = json.optString("latin_name", base.latinName)
            val personality = json.optJSONObject("personality32")?.toPersonality32(base.personality32) ?: base.personality32
            val enneagram = json.optJSONObject("enneagram")?.toEnneagram(base.enneagram) ?: base.enneagram
            val storedZodiac = runCatching { ZodiacSign.valueOf(json.optString("zodiac", ZodiacEngine.sign(birthDate).name)) }.getOrDefault(ZodiacEngine.sign(birthDate))
            val numerology = json.optJSONObject("numerology")?.toNumerology(VedicNumerologyEngine.calculate(birthDate, latinName))
                ?: VedicNumerologyEngine.calculate(birthDate, latinName)
            base.copy(
                name = json.optString("name", base.name),
                age = Period.between(birthDate, LocalDate.now()).years.coerceAtLeast(18),
                city = json.optString("city", base.city),
                birthDate = birthDate,
                latinName = latinName,
                description = json.optString("description", base.description),
                goals = json.optStringList("goals", base.goals),
                interests = json.optStringList("interests", base.interests),
                values = json.optStringList("values", base.values),
                lifestyle = json.optStringList("lifestyle", base.lifestyle),
                completedProfileSections = json.optInt("completed_profile_sections", base.completedProfileSections).coerceIn(0, 10),
                personality32 = personality,
                enneagram = enneagram,
                zodiac = storedZodiac,
                numerology = numerology,
            )
        }.getOrDefault(base)
    }

    fun save(profile: UserProfile) {
        val p = profile.personality32
        val e = profile.enneagram
        val n = profile.numerology
        val json = JSONObject()
            .put("global_id", profile.globalId.display)
            .put("name", profile.name)
            .put("city", profile.city)
            .put("birth_date", profile.birthDate.toString())
            .put("latin_name", profile.latinName)
            .put("description", profile.description)
            .put("goals", JSONArray(profile.goals))
            .put("interests", JSONArray(profile.interests))
            .put("values", JSONArray(profile.values))
            .put("lifestyle", JSONArray(profile.lifestyle))
            .put("completed_profile_sections", profile.completedProfileSections)
            .put("personality32", JSONObject().apply {
                put("code", p.code)
                put("title_ru", p.titleRu)
                put("title_uk", p.titleUk)
                put("title_en", p.titleEn)
                put("social_energy", p.socialEnergy)
                put("perception", p.perception)
                put("decision_style", p.decisionStyle)
                put("life_rhythm", p.lifeRhythm)
                put("bond_style", p.bondStyle)
            })
            .put("enneagram", JSONObject().apply {
                put("type", e.type)
                if (e.wing == null) put("wing", JSONObject.NULL) else put("wing", e.wing)
                put("score", e.score)
                put("title_ru", e.titleRu)
                put("title_uk", e.titleUk)
                put("title_en", e.titleEn)
            })
            .put("zodiac", profile.zodiac.name)
            .put("numerology", JSONObject().apply {
                put("soul_number", n.soulNumber)
                put("destiny_number", n.destinyNumber)
                if (n.nameNumber == null) put("name_number", JSONObject.NULL) else put("name_number", n.nameNumber)
                put("maturity_number", n.maturityNumber)
                put("compatibility_vector", JSONArray(n.compatibilityVector))
            })
        preferences.edit().putString(KEY_PROFILE, json.toString()).apply()
    }

    private fun JSONObject.optStringList(name: String, fallback: List<String>): List<String> {
        val array = optJSONArray(name) ?: return fallback
        return buildList {
            for (index in 0 until array.length()) {
                val value = array.optString(index).trim()
                if (value.isNotEmpty()) add(value)
            }
        }.ifEmpty { fallback }
    }

    private fun JSONObject.toPersonality32(fallback: Personality32Profile): Personality32Profile = runCatching {
        Personality32Profile(
            code = getString("code"),
            titleRu = optString("title_ru", fallback.titleRu),
            titleUk = optString("title_uk", fallback.titleUk),
            titleEn = optString("title_en", fallback.titleEn),
            socialEnergy = getInt("social_energy").coerceIn(0, 100),
            perception = getInt("perception").coerceIn(0, 100),
            decisionStyle = getInt("decision_style").coerceIn(0, 100),
            lifeRhythm = getInt("life_rhythm").coerceIn(0, 100),
            bondStyle = getInt("bond_style").coerceIn(0, 100),
        )
    }.getOrDefault(fallback)

    private fun JSONObject.toEnneagram(fallback: EnneagramProfile): EnneagramProfile = runCatching {
        EnneagramProfile(
            type = getInt("type").coerceIn(1, 9),
            wing = if (has("wing") && !isNull("wing")) getInt("wing").coerceIn(1, 9) else null,
            score = optInt("score", fallback.score).coerceIn(0, 100),
            titleRu = optString("title_ru", fallback.titleRu),
            titleUk = optString("title_uk", fallback.titleUk),
            titleEn = optString("title_en", fallback.titleEn),
        )
    }.getOrDefault(fallback)

    private fun JSONObject.toNumerology(fallback: VedicNumerologyProfile): VedicNumerologyProfile = runCatching {
        val vectorArray = optJSONArray("compatibility_vector")
        val vector = if (vectorArray == null) fallback.compatibilityVector else buildList {
            for (index in 0 until vectorArray.length()) add(vectorArray.getInt(index).coerceIn(1, 9))
        }
        VedicNumerologyProfile(
            soulNumber = getInt("soul_number").coerceIn(1, 9),
            destinyNumber = getInt("destiny_number").coerceIn(1, 9),
            nameNumber = if (has("name_number") && !isNull("name_number")) getInt("name_number").coerceIn(1, 9) else null,
            maturityNumber = getInt("maturity_number").coerceIn(1, 9),
            compatibilityVector = vector,
        )
    }.getOrDefault(fallback)

    private companion object {
        const val KEY_PROFILE = "profile_json_v2"
        const val LEGACY_KEY_PROFILE = "profile_json_v1"
    }
}
