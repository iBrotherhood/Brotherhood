package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.data.LatentTraitCatalog
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.LatentProfile
import org.federationofavatars.brotherhood.model.PositiveQualityMatch
import org.federationofavatars.brotherhood.model.QualityFitResult
import org.federationofavatars.brotherhood.model.SearchIntent

/**
 * User-authoritative quality matching. A visible quality may be a single latent coordinate or a
 * composite pattern across several private coordinates. The user still chooses the target; role
 * never injects defaults. This engine never changes Compatibility, Trust, or Account Completeness.
 */
object QualityMatchingEngine {
    fun calculate(intent: SearchIntent, candidate: LatentProfile, language: AppLanguage): QualityFitResult {
        if (intent.qualities.isEmpty()) return QualityFitResult(0, candidate.confidence, emptyList())
        val matches = intent.qualities.mapNotNull { desired ->
            val quality = LatentTraitCatalog.qualityByKey[desired.key] ?: return@mapNotNull null
            val rows = quality.targets.mapNotNull targetRows@ { target ->
                val trait = candidate.traits[target.traitKey] ?: return@targetRows null
                val fit = (100 - abs(trait.score - target.targetScore)).coerceIn(0, 100)
                Triple(fit, target.weight, trait.evidence)
            }
            if (rows.isEmpty()) return@mapNotNull null
            val targetWeight = rows.sumOf { it.second }.coerceAtLeast(1)
            val declaredWeight = quality.targets.sumOf { it.weight }.coerceAtLeast(1)
            val fit = (rows.sumOf { it.first * it.second }.toDouble() / targetWeight).roundToInt().coerceIn(0, 100)
            val rawEvidence = (rows.sumOf { it.third * it.second }.toDouble() / targetWeight).roundToInt().coerceAtLeast(0)
            val targetCoverage = targetWeight.toDouble() / declaredWeight
            val evidence = (rawEvidence * targetCoverage).roundToInt().coerceAtLeast(0)
            Triple(PositiveQualityMatch(quality.key, quality.label.get(language), fit), desired.importance, evidence)
        }
        if (matches.isEmpty()) return QualityFitResult(0, 0, emptyList())
        val weightSum = matches.sumOf { it.second }.coerceAtLeast(1)
        val score = (matches.sumOf { it.first.fit * it.second }.toDouble() / weightSum).roundToInt().coerceIn(0, 100)
        val evidenceConfidence = matches.map { (_, _, evidence) -> (evidence * 18).coerceAtMost(100) }.average().roundToInt()
        val confidence = ((candidate.confidence * .65) + (evidenceConfidence * .35)).roundToInt().coerceIn(0, 100)
        return QualityFitResult(score, confidence, matches.map { it.first }.sortedByDescending { it.fit })
    }
}
