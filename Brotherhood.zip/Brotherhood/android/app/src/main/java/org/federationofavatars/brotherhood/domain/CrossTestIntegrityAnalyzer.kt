package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.IntegrityScreeningResult

object CrossTestIntegrityAnalyzer {
    private data class ExpectedPair(val first: String, val second: String, val label: String)

    private val pairs = listOf(
        ExpectedPair("f001", "f068", "Верность под давлением и независимость от мнения группы"),
        ExpectedPair("f002", "f041", "Сохранение тайн и конфиденциальность разговоров"),
        ExpectedPair("f006", "f022", "Верность договорённостям и доведение обещанного до конца"),
        ExpectedPair("f007", "f057", "Неиспользование слабостей и безопасность уязвимости"),
        ExpectedPair("f009", "f039", "Защита репутации и проверка фактов"),
        ExpectedPair("f011", "f013", "Соответствие слов и правда при неудобстве"),
        ExpectedPair("f012", "f069", "Одинаковые правила и равное достоинство"),
        ExpectedPair("f015", "f043", "Отказ от манипуляции и уважение отказа"),
        ExpectedPair("f017", "f031", "Одинаковая речь и прямой разговор о проблеме"),
        ExpectedPair("f018", "f019", "Отказ от лести и честная обратная связь"),
        ExpectedPair("f024", "f035", "Ответственность за последствия и признание своей доли"),
        ExpectedPair("f033", "f064", "Отказ от публичного унижения и уважение в компании"),
        ExpectedPair("f038", "f010", "Отказ от мести и честное завершение дружбы"),
        ExpectedPair("f042", "f049", "Согласие на передачу данных и цифровая приватность"),
        ExpectedPair("f061", "f055", "Отсутствие саботажа и радость за успех друга"),
        ExpectedPair("f066", "f088", "Признание вклада и ответственность в общем проекте"),
        ExpectedPair("f081", "f083", "Честность в займах и ясные договорённости"),
        ExpectedPair("f082", "f090", "Разделение дружбы и бизнеса при расхождении"),
        ExpectedPair("f092", "f048", "Уважение семьи и семейной приватности"),
        ExpectedPair("f098", "f100", "Поддержка развития и сохранение связи через перемены")
    )

    fun analyze(results: Map<String, AssessmentResult>): IntegrityScreeningResult {
        val available = pairs.mapNotNull { pair ->
            val first = results[pair.first] ?: return@mapNotNull null
            val second = results[pair.second] ?: return@mapNotNull null
            Triple(pair, first, second)
        }
        if (available.isEmpty()) {
            return IntegrityScreeningResult(
                riskScore = 0,
                consistencyScore = 0,
                evaluatedPairs = 0,
                confidence = 0,
                label = "Недостаточно данных",
                flags = emptyList()
            )
        }

        val differences = available.map { (_, first, second) -> abs(first.totalScore - second.totalScore) }
        val consistency = (100.0 - differences.average()).roundToInt().coerceIn(0, 100)
        val idealization = available.flatMap { listOf(it.second, it.third) }
            .distinctBy { it.assessmentId }
            .map { it.idealizedSelfPresentation }
            .average()
        val risk = (((100 - consistency) * 0.70) + (idealization * 0.30)).roundToInt().coerceIn(0, 100)
        val flags = available.mapNotNull { (pair, first, second) ->
            val diff = abs(first.totalScore - second.totalScore)
            if (diff >= 35) "Противоречие: ${pair.label} ($diff пунктов)" else null
        }.take(5)
        val confidence = (available.size * 100 / pairs.size).coerceIn(0, 100)
        val label = when {
            confidence < 30 -> "Предварительная проверка"
            risk >= 65 -> "Высокий риск противоречивой самопрезентации"
            risk >= 40 -> "Заметные противоречия требуют проверки поведением"
            risk >= 20 -> "Умеренно согласованный профиль"
            else -> "Высокая согласованность ответов"
        }
        return IntegrityScreeningResult(
            riskScore = risk,
            consistencyScore = consistency,
            evaluatedPairs = available.size,
            confidence = confidence,
            label = label,
            flags = flags
        )
    }
}
