package org.federationofavatars.brotherhood.domain

import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.model.CompatibilityBreakdown
import org.federationofavatars.brotherhood.model.FriendCandidate
import org.federationofavatars.brotherhood.model.UserProfile

/**
 * Transparent multi-layer friendship compatibility.
 *
 * Trust/reputation is deliberately NOT part of the compatibility total. A person can be a strong
 * psychological match and still have a weak confirmed trust history; the UI must show both facts.
 */
object HybridCompatibilityEngine {
    private val baseWeights = linkedMapOf(
        "tests" to 18.0,
        "character" to 10.0,
        "values" to 10.0,
        "goals" to 9.0,
        "interests" to 8.0,
        "lifestyle" to 7.0,
        "communication" to 7.0,
        "conflict" to 7.0,
        "personality" to 7.0,
        "numerology" to 5.0,
        "enneagram" to 4.0,
        "zodiac" to 3.0,
        "geography" to 2.0,
        "business" to 2.0,
        "social" to 1.0,
    )

    init { require(baseWeights.values.sum().roundToInt() == 100) }

    fun calculate(
        me: UserProfile,
        candidate: FriendCandidate,
        friendshipTests: Int,
        sharedTestCount: Int,
        testCategoryScores: Map<String, Int> = candidate.testCategoryScores,
    ): CompatibilityBreakdown {
        val interests = overlap(me.interests, candidate.interests)
        val values = overlap(me.values, candidate.values)
        val lifestyle = overlap(me.lifestyle, candidate.lifestyle)
        val goals = overlap(me.goals, candidate.goals)
        val personality = Personality32Engine.compatibility(me.personality32, candidate.personality32)
        val enneagram = EnneagramEngine.compatibility(me.enneagram, candidate.enneagram)
        val zodiac = ZodiacEngine.compatibility(me.zodiac, candidate.zodiac)
        val numerology = VedicNumerologyEngine.compatibility(me.numerology, candidate.numerology)

        fun category(name: String): Int = testCategoryScores[name]?.takeIf { it > 0 } ?: friendshipTests
        val character = listOf("loyalty", "integrity", "reliability", "boundaries", "support", "competition")
            .map(::category).average().roundToInt().coerceIn(0, 100)
        val communication = category("communication")
        val conflict = category("conflict")
        val business = category("mutual_aid")
        val socialFormat = ((goals + communication) / 2.0).roundToInt().coerceIn(0, 100)
        val geography = geography(me.city, candidate.city, candidate.distanceKm)

        val layers = mapOf(
            "tests" to friendshipTests.coerceIn(0, 100),
            "character" to character,
            "values" to values,
            "goals" to goals,
            "interests" to interests,
            "lifestyle" to lifestyle,
            "communication" to communication,
            "conflict" to conflict,
            "personality" to personality,
            "numerology" to numerology,
            "enneagram" to enneagram,
            "zodiac" to zodiac,
            "geography" to geography,
            "business" to business,
            "social" to socialFormat,
        )

        val baseTotal = weighted(layers, baseWeights)
        val personalizedWeights = personalizedWeights(me.goals)
        val personalized = weighted(layers, personalizedWeights)

        return CompatibilityBreakdown(
            total = personalized,
            baseTotal = baseTotal,
            friendshipTests = friendshipTests.coerceIn(0, 100),
            interests = interests,
            character = character,
            values = values,
            lifestyle = lifestyle,
            friendshipGoals = goals,
            communication = communication,
            conflict = conflict,
            business = business,
            socialFormat = socialFormat,
            personality32 = personality,
            enneagram = enneagram,
            zodiac = zodiac,
            numerology = numerology,
            geography = geography,
            friendshipExpectations = 0, // legacy compatibility field; active expectation matching is user-authored Quality Fit
            reputation = candidate.trustScore.coerceIn(0, 100),
            confidence = (sharedTestCount.coerceIn(0, 100) * .80 + minOf(me.verifiedInteractions, 20) * 1.0)
                .roundToInt().coerceIn(0, 100),
        )
    }

    private fun weighted(layers: Map<String, Int>, weights: Map<String, Double>): Int {
        val denominator = weights.values.sum().coerceAtLeast(.001)
        return (weights.entries.sumOf { (name, weight) -> (layers[name] ?: 0) * weight } / denominator)
            .roundToInt().coerceIn(0, 100)
    }

    /** User goals tune the personal score while the base score remains available for comparison. */
    private fun personalizedWeights(goals: List<String>): Map<String, Double> {
        if (goals.isEmpty()) return baseWeights
        val result = baseWeights.toMutableMap()
        val text = goals.joinToString(" ").lowercase()
        fun add(key: String, value: Double) { result[key] = (result[key] ?: 0.0) + value }
        if (listOf("бизнес", "business", "партнер", "партнерство", "partner", "проект", "project").any(text::contains)) {
            add("business", 4.0); add("values", 1.5); add("interests", 1.0)
        }
        if (listOf("спорт", "football", "футбол", "sport", "путеше", "travel").any(text::contains)) {
            add("interests", 3.0); add("lifestyle", 2.0); add("geography", 1.0)
        }
        if (listOf("близк", "друг", "friend", "глубок", "deep", "взаимопом", "support").any(text::contains)) {
            add("character", 3.0); add("goals", 2.0); add("communication", 2.0); add("conflict", 1.0)
        }
        if (listOf("интеллект", "духов", "knowledge", "spiritual", "learning").any(text::contains)) {
            add("values", 2.0); add("personality", 1.0)
        }
        return result
    }

    private fun geography(myCity: String, otherCity: String, distanceKm: Int): Int = when {
        myCity.equals(otherCity, ignoreCase = true) -> (100 - distanceKm.coerceAtLeast(0) * 2).coerceIn(70, 100)
        distanceKm > 0 -> (100 - distanceKm * 3).coerceIn(0, 70)
        else -> 35
    }

    private fun overlap(first: List<String>, second: List<String>): Int {
        if (first.isEmpty() && second.isEmpty()) return 50
        if (first.isEmpty() || second.isEmpty()) return 35
        val a = first.map { it.trim().lowercase() }.filter(String::isNotBlank).toSet()
        val b = second.map { it.trim().lowercase() }.filter(String::isNotBlank).toSet()
        val union = (a + b).size.coerceAtLeast(1)
        return (a.intersect(b).size * 100 / union).coerceIn(0, 100)
    }
}
