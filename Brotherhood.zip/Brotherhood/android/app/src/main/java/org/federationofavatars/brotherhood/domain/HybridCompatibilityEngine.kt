package org.federationofavatars.brotherhood.domain

import org.federationofavatars.brotherhood.model.CompatibilityBreakdown
import org.federationofavatars.brotherhood.model.FriendCandidate
import org.federationofavatars.brotherhood.model.UserProfile

object HybridCompatibilityEngine {
    fun calculate(
        me: UserProfile,
        candidate: FriendCandidate,
        friendshipTests: Int,
        sharedTestCount: Int
    ): CompatibilityBreakdown {
        val values = overlap(me.values, candidate.values)
        val lifestyle = overlap(me.lifestyle, candidate.lifestyle)
        val interests = overlap(me.interests, candidate.interests)
        val personality = Personality32Engine.compatibility(me.personality32, candidate.personality32)
        val enneagram = EnneagramEngine.compatibility(me.enneagram, candidate.enneagram)
        val zodiac = ZodiacEngine.compatibility(me.zodiac, candidate.zodiac)
        val numerology = VedicNumerologyEngine.compatibility(me.numerology, candidate.numerology)
        val character = ((values + interests + personality) / 3).coerceIn(0, 100)

        val total = (
            friendshipTests * 0.35 +
            character * 0.10 +
            values * 0.12 +
            lifestyle * 0.08 +
            personality * 0.10 +
            enneagram * 0.05 +
            zodiac * 0.03 +
            numerology * 0.07 +
            candidate.trustScore * 0.10
        ).toInt().coerceIn(0, 100)

        return CompatibilityBreakdown(
            total = total,
            friendshipTests = friendshipTests,
            character = character,
            values = values,
            lifestyle = lifestyle,
            personality32 = personality,
            enneagram = enneagram,
            zodiac = zodiac,
            numerology = numerology,
            reputation = candidate.trustScore,
            confidence = (sharedTestCount.coerceIn(0, 100) * 0.8 + minOf(me.verifiedInteractions, 20) * 1.0).toInt().coerceIn(0, 100)
        )
    }

    private fun overlap(first: List<String>, second: List<String>): Int {
        val a = first.map(String::lowercase).toSet()
        val b = second.map(String::lowercase).toSet()
        val union = (a + b).size.coerceAtLeast(1)
        return (a.intersect(b).size * 100 / union).coerceIn(0, 100)
    }
}
