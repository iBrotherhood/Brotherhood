package org.federationofavatars.brotherhood.data

import java.time.LocalDate
import org.federationofavatars.brotherhood.domain.EnneagramEngine
import org.federationofavatars.brotherhood.domain.Personality32Engine
import org.federationofavatars.brotherhood.domain.VedicNumerologyEngine
import org.federationofavatars.brotherhood.domain.ZodiacEngine
import org.federationofavatars.brotherhood.model.Community
import org.federationofavatars.brotherhood.model.CommunityKind
import org.federationofavatars.brotherhood.model.FriendCandidate
import org.federationofavatars.brotherhood.model.GlobalId
import org.federationofavatars.brotherhood.model.TrustEvent
import org.federationofavatars.brotherhood.model.UserProfile

object DemoRepository {
    val cities = listOf("Киев", "Львов", "Одесса", "Харьков", "Днепр", "Ужгород", "Мукачево", "Свалява", "Варшава", "Берлин")

    private fun personality(a: Int, b: Int, c: Int, d: Int, e: Int) = Personality32Engine.classify(
        Personality32Engine.AxisInput(a, b, c, d, e)
    )

    private fun enneagram(type: Int, wing: Int? = null) = EnneagramEngine.classify(
        (1..9).associateWith { when (it) { type -> 90; wing -> 75; else -> 35 + it } }
    )

    private fun candidate(
        id: Long,
        name: String,
        age: Int,
        city: String,
        distance: Int,
        trust: Int,
        rating: Int,
        interests: List<String>,
        values: List<String>,
        lifestyle: List<String>,
        birthDate: LocalDate,
        latinName: String,
        axes: List<Int>,
        enneagramType: Int,
        seed: Int,
        online: Boolean
    ): FriendCandidate {
        val p = personality(axes[0], axes[1], axes[2], axes[3], axes[4])
        val e = enneagram(enneagramType)
        return FriendCandidate(
            globalId = GlobalId(id),
            name = name,
            age = age,
            city = city,
            distanceKm = distance,
            compatibility = 0,
            trustScore = trust,
            accountRating = rating,
            interests = interests,
            values = values,
            lifestyle = lifestyle,
            explanation = "Совместимость рассчитывается по тестам дружбы, интересам, характеру, ценностям, образу жизни, модели 32 типов, эннеаграмме, зодиаку и ведической нумерологии. Подтверждённая репутация показывается отдельно как Trust Score.",
            assessmentProfileSeed = seed,
            personality32 = p,
            enneagram = e,
            zodiac = ZodiacEngine.sign(birthDate),
            numerology = VedicNumerologyEngine.calculate(birthDate, latinName),
            verified = true,
            online = online
        )
    }

    val people = listOf(
        candidate(2, "Андрей", 36, "Киев", 4, 94, 86,
            listOf("Футбол", "Автомобили", "Бизнес"), listOf("Верность", "Справедливость", "Семья"),
            listOf("Активный отдых", "Встречи по выходным", "Безопасный риск"), LocalDate.of(1990, 8, 15), "ANDRII", listOf(72, 38, 42, 34, 28), 6, 17, true),
        candidate(3, "Максим", 40, "Киев", 12, 88, 72,
            listOf("Спорт", "Путешествия", "Технологии"), listOf("Свобода", "Развитие", "Честность"),
            listOf("Ранние подъёмы", "Путешествия", "Онлайн-общение"), LocalDate.of(1986, 2, 7), "MAKSYM", listOf(58, 68, 35, 70, 55), 7, 41, false),
        candidate(4, "Олег", 34, "Львов", 3, 96, 91,
            listOf("Книги", "Футбол", "Взаимопомощь"), listOf("Верность", "Вера", "Справедливость"),
            listOf("Спокойный отдых", "Семейные встречи", "Регулярное общение"), LocalDate.of(1992, 11, 24), "OLEH", listOf(34, 62, 78, 28, 22), 2, 73, true),
        candidate(5, "Роман", 42, "Одесса", 7, 90, 78,
            listOf("Автомобили", "Рыбалка", "Предпринимательство"), listOf("Результат", "Верность", "Ответственность"),
            listOf("Деловые встречи", "Поездки", "Редкое глубокое общение"), LocalDate.of(1984, 5, 18), "ROMAN", listOf(66, 44, 61, 52, 31), 8, 89, false),
        candidate(6, "Влад", 38, "Киев", 18, 93, 84,
            listOf("Бокс", "Стартапы", "Квантовая физика"), listOf("Сила", "Честность", "Развитие"),
            listOf("Спорт", "Проекты", "Частое общение"), LocalDate.of(1988, 1, 29), "VLAD", listOf(74, 79, 40, 61, 26), 3, 61, true),
        candidate(7, "Тарас", 41, "Ужгород", 5, 97, 95,
            listOf("Горы", "Бизнес", "Волонтёрство"), listOf("Верность", "Взаимопомощь", "Семья"),
            listOf("Горы", "Живое общение", "Совместные дела"), LocalDate.of(1985, 9, 3), "TARAS", listOf(49, 55, 66, 39, 18), 1, 53, true)
    )

    val communities = listOf(
        Community("c1", "Футбол по выходным", "Футбол", "Киев", 128, CommunityKind.INTEREST, false, "Матчи, команды и совместные просмотры.", verifiedOnly = true),
        Community("c2", "Автомобили и путешествия", "Автомобили", "Киев", 315, CommunityKind.INTEREST, true, "Маршруты, обслуживание и взаимопомощь в дороге."),
        Community("c3", "Сила и выносливость", "Спорт", "Львов", 94, CommunityKind.INTEREST, false, "Тренировки без токсичной конкуренции."),
        Community("c4", "Предприниматели Украины", "Предпринимательство", "Онлайн", 524, CommunityKind.BUSINESS, true, "Опыт, партнёрства и проверка гипотез.", verifiedOnly = true),
        Community("c5", "Ищу команду / партнёра", "Партнёрства", "Киев", 211, CommunityKind.BUSINESS, true, "Поиск сооснователей, специалистов и совместных проектов."),
        Community("c6", "Технологические стартапы", "Стартапы", "Онлайн", 407, CommunityKind.BUSINESS, true, "Продукт, разработка, продажи и масштабирование."),
        Community("c7", "Мужская взаимопомощь", "Взаимопомощь", "Ужгород", 146, CommunityKind.INTEREST, true, "Помощь делом, опытом и контактами без эксплуатации доверия.", verifiedOnly = true)
    )

    val trustEvents = listOf(
        TrustEvent("t1", "Личность подтверждена", "Особу підтверджено", "Identity verified", true, 8),
        TrustEvent("t2", "12 подтверждённых взаимодействий", "12 підтверджених взаємодій", "12 verified interactions", true, 10),
        TrustEvent("t3", "Жалоба ожидает проверки", "Скарга очікує перевірки", "Report pending review", false, 0)
    )

    private val demoBirthDate = LocalDate.of(1990, 1, 1)
    val profile = UserProfile(
        globalId = GlobalId(1),
        name = "Новый пользователь",
        age = 36,
        city = "Киев",
        birthDate = demoBirthDate,
        latinName = "USER",
        description = "Заполните профиль: цели дружбы, интересы, ценности и образ жизни.",
        goals = listOf("Близкий друг"),
        interests = listOf("Спорт", "Путешествия"),
        values = listOf("Верность", "Честность"),
        lifestyle = listOf("Живое общение"),
        trustScore = 70,
        verifiedInteractions = 0,
        completedProfileSections = 2,
        personality32 = personality(50, 50, 50, 50, 50),
        enneagram = enneagram(6),
        zodiac = ZodiacEngine.sign(demoBirthDate),
        numerology = VedicNumerologyEngine.calculate(demoBirthDate, "USER")
    )
}
