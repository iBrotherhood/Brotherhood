package org.federationofavatars.brotherhood.domain

import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AssessmentKind
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.UserProfile

data class SelfInsight(
    val title: String,
    val text: String,
    val score: Int? = null,
    val kind: InsightKind = InsightKind.INFO,
)

enum class InsightKind { STRENGTH, GROWTH, INFO, CAUTION }

data class SelfAnalysisReport(
    val completedTests: Int,
    val confidence: Int,
    val strengths: List<SelfInsight>,
    val growthAreas: List<SelfInsight>,
    val profileInsights: List<SelfInsight>,
    val caveats: List<SelfInsight>,
)

object SelfAnalysisEngine {
    private val byId = AssessmentCatalog.assessments.associateBy { it.id }

    fun build(profile: UserProfile, results: Map<String, AssessmentResult>, language: AppLanguage): SelfAnalysisReport {
        val kindScores = results.values.mapNotNull { result ->
            byId[result.assessmentId]?.kind?.let { it to result.totalScore }
        }.groupBy({ it.first }, { it.second }).mapValues { (_, values) -> values.average().toInt() }

        val strengthKinds = kindScores.entries.sortedByDescending { it.value }.take(4)
        val growthKinds = kindScores.entries.sortedBy { it.value }.take(3).filter { it.value < 65 }
        val avgConsistency = results.values.map { it.answerConsistency }.average().takeUnless(Double::isNaN)?.toInt() ?: 0
        val avgIdealized = results.values.map { it.idealizedSelfPresentation }.average().takeUnless(Double::isNaN)?.toInt() ?: 0
        val confidence = ((results.size.coerceAtMost(100) * .75) + (avgConsistency * .25)).toInt().coerceIn(0, 100)

        val strengths = strengthKinds.map { (kind, score) ->
            SelfInsight(kindTitle(kind, language), strengthText(kind, language), score, InsightKind.STRENGTH)
        }
        val growth = growthKinds.map { (kind, score) ->
            SelfInsight(kindTitle(kind, language), growthText(kind, language), score, InsightKind.GROWTH)
        }

        val p = profile.personality32
        val personalityText = when (language) {
            AppLanguage.RU -> "${p.title(language)} (${p.code}). Социальная энергия ${p.socialEnergy}%, восприятие ${p.perception}%, стиль решений ${p.decisionStyle}%, ритм ${p.lifeRhythm}%, стиль связи ${p.bondStyle}%."
            AppLanguage.UK -> "${p.title(language)} (${p.code}). Соціальна енергія ${p.socialEnergy}%, сприйняття ${p.perception}%, стиль рішень ${p.decisionStyle}%, ритм ${p.lifeRhythm}%, стиль зв'язку ${p.bondStyle}%."
            AppLanguage.EN -> "${p.title(language)} (${p.code}). Social energy ${p.socialEnergy}%, perception ${p.perception}%, decision style ${p.decisionStyle}%, rhythm ${p.lifeRhythm}%, bond style ${p.bondStyle}%."
        }
        val n = profile.numerology
        val numerologyText = when (language) {
            AppLanguage.RU -> "Число души ${n.soulNumber} (${VedicNumerologyEngine.ruler(n.soulNumber)}): ${VedicNumerologyEngine.numberDescription(n.soulNumber, language)}. Число судьбы ${n.destinyNumber} (${VedicNumerologyEngine.ruler(n.destinyNumber)}): ${VedicNumerologyEngine.numberDescription(n.destinyNumber, language)}. Ведический профиль рассчитывается математически из даты рождения и не является тестом."
            AppLanguage.UK -> "Число душі ${n.soulNumber} (${VedicNumerologyEngine.ruler(n.soulNumber)}): ${VedicNumerologyEngine.numberDescription(n.soulNumber, language)}. Число долі ${n.destinyNumber} (${VedicNumerologyEngine.ruler(n.destinyNumber)}): ${VedicNumerologyEngine.numberDescription(n.destinyNumber, language)}. Ведичний профіль математично обчислюється з дати народження і не є тестом."
            AppLanguage.EN -> "Soul number ${n.soulNumber} (${VedicNumerologyEngine.ruler(n.soulNumber)}): ${VedicNumerologyEngine.numberDescription(n.soulNumber, language)}. Destiny number ${n.destinyNumber} (${VedicNumerologyEngine.ruler(n.destinyNumber)}): ${VedicNumerologyEngine.numberDescription(n.destinyNumber, language)}. The Vedic profile is calculated mathematically from birth date and is not a test."
        }
        val enneagramText = when (language) {
            AppLanguage.RU -> "Эннеаграмма: тип ${profile.enneagram.type}${profile.enneagram.wing?.let { "w$it" } ?: ""} — ${profile.enneagram.title(language)}. Используется как описательный слой, а не диагноз."
            AppLanguage.UK -> "Еннеаграма: тип ${profile.enneagram.type}${profile.enneagram.wing?.let { "w$it" } ?: ""} — ${profile.enneagram.title(language)}. Використовується як описовий шар, а не діагноз."
            AppLanguage.EN -> "Enneagram: type ${profile.enneagram.type}${profile.enneagram.wing?.let { "w$it" } ?: ""} — ${profile.enneagram.title(language)}. It is descriptive, not diagnostic."
        }
        val zodiacText = when (language) {
            AppLanguage.RU -> "Зодиак: ${profile.zodiac.symbol} ${profile.zodiac.name}. Это дополнительный культурный слой с малым весом в подборе друзей."
            AppLanguage.UK -> "Зодіак: ${profile.zodiac.symbol} ${profile.zodiac.name}. Це додатковий культурний шар з малою вагою у підборі друзів."
            AppLanguage.EN -> "Zodiac: ${profile.zodiac.symbol} ${profile.zodiac.name}. This is an optional cultural layer with low matching weight."
        }

        val caveats = buildList {
            if (results.size < 20) add(SelfInsight(
                title = localized(language, "Мало данных", "Мало даних", "Limited data"),
                text = localized(language, "Для устойчивого самоанализа пройдите больше тестов. Система не делает вывод по одному опроснику.", "Для стійкого самоаналізу пройдіть більше тестів. Система не робить висновок за одним опитувальником.", "Complete more tests for a stable self-analysis. The app does not infer personality from one questionnaire."),
                kind = InsightKind.CAUTION
            ))
            if (avgIdealized >= 65) add(SelfInsight(
                title = localized(language, "Сильная идеализация ответов", "Сильна ідеалізація відповідей", "Highly idealized answers"),
                text = localized(language, "Часть ответов выглядит слишком безупречно. Повторите тесты позже и отвечайте о реальном поведении, а не о желаемом образе.", "Частина відповідей виглядає надто бездоганно. Повторіть тести пізніше й відповідайте про реальну поведінку, а не бажаний образ.", "Some answers look unusually idealized. Retake later and answer about real behavior rather than an ideal self-image."),
                score = avgIdealized,
                kind = InsightKind.CAUTION
            ))
        }

        return SelfAnalysisReport(
            completedTests = results.size,
            confidence = confidence,
            strengths = strengths,
            growthAreas = growth,
            profileInsights = listOf(
                SelfInsight(localized(language, "Brotherhood-32", "Brotherhood-32", "Brotherhood-32"), personalityText),
                SelfInsight(localized(language, "Эннеаграмма", "Еннеаграма", "Enneagram"), enneagramText),
                SelfInsight(localized(language, "Ведическая нумерология", "Ведична нумерологія", "Vedic numerology"), numerologyText),
                SelfInsight(localized(language, "Зодиак", "Зодіак", "Zodiac"), zodiacText),
            ),
            caveats = caveats,
        )
    }

    private fun kindTitle(kind: AssessmentKind, language: AppLanguage): String = when (kind) {
        AssessmentKind.LOYALTY -> localized(language,"Верность","Вірність","Loyalty")
        AssessmentKind.INTEGRITY -> localized(language,"Честность и последовательность","Чесність і послідовність","Integrity")
        AssessmentKind.RELIABILITY -> localized(language,"Надёжность","Надійність","Reliability")
        AssessmentKind.CONFLICT -> localized(language,"Конфликты и восстановление","Конфлікти та відновлення","Conflict repair")
        AssessmentKind.BOUNDARIES -> localized(language,"Границы и конфиденциальность","Межі та конфіденційність","Boundaries and privacy")
        AssessmentKind.SUPPORT -> localized(language,"Поддержка","Підтримка","Support")
        AssessmentKind.COMPETITION -> localized(language,"Конкуренция и статус","Конкуренція і статус","Competition and status")
        AssessmentKind.COMMUNICATION -> localized(language,"Общение","Спілкування","Communication")
        AssessmentKind.MUTUAL_AID -> localized(language,"Взаимопомощь и бизнес","Взаємодопомога та бізнес","Mutual aid and business")
        AssessmentKind.LIFESTYLE -> localized(language,"Ценности и образ жизни","Цінності та спосіб життя","Values and lifestyle")
    }

    private fun strengthText(kind: AssessmentKind, language: AppLanguage): String = localized(
        language,
        "По текущим ответам это одна из наиболее устойчивых сторон вашего профиля. Сверяйте результат с реальными поступками и обратной связью от людей.",
        "За поточними відповідями це одна з найстійкіших сторін вашого профілю. Зіставляйте результат з реальними вчинками та відгуками людей.",
        "Current answers make this one of the stronger parts of your profile. Compare it with real behavior and feedback from people who know you."
    )

    private fun growthText(kind: AssessmentKind, language: AppLanguage): String = localized(
        language,
        "Здесь ответы менее устойчивы. Это не ярлык и не недостаток: раздел можно использовать как тему для наблюдения за собой и повторного тестирования.",
        "Тут відповіді менш стійкі. Це не ярлик і не недолік: розділ можна використати як тему для самоспостереження та повторного тестування.",
        "Answers are less stable here. This is neither a label nor a defect; use it as a topic for self-observation and later retesting."
    )

    private fun localized(language: AppLanguage, ru: String, uk: String, en: String): String = when (language) {
        AppLanguage.RU -> ru
        AppLanguage.UK -> uk
        AppLanguage.EN -> en
    }
}
