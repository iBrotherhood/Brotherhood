package org.federationofavatars.brotherhood.data

import org.federationofavatars.brotherhood.model.AppLanguage

fun AppLanguage.pick(ru: String, uk: String, en: String): String = when (this) {
    AppLanguage.RU -> ru
    AppLanguage.UK -> uk
    AppLanguage.EN -> en
}
