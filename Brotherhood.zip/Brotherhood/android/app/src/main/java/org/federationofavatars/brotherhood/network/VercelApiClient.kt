package org.federationofavatars.brotherhood.network

import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** HTTPS client for the Vercel core backend. It never connects to Neon directly. */
class VercelApiClient(private val baseUrl: String) : BrotherhoodApi {
    override suspend fun get(path: String, accessToken: String): String = request("GET", path, null, accessToken)

    override suspend fun post(path: String, jsonBody: String, accessToken: String): String = request("POST", path, jsonBody, accessToken)

    override suspend fun put(path: String, jsonBody: String, accessToken: String): String = request("PUT", path, jsonBody, accessToken)

    override suspend fun delete(path: String, accessToken: String): String = request("DELETE", path, null, accessToken)

    private suspend fun request(method: String, path: String, body: String?, token: String): String = withContext(Dispatchers.IO) {
        require(baseUrl.startsWith("https://")) { "Only HTTPS endpoints are allowed" }
        val connection = URL(baseUrl.trimEnd('/') + "/" + path.trimStart('/')).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 12_000
            connection.readTimeout = 20_000
            if (token.isNotBlank()) connection.setRequestProperty("Authorization", "Bearer $token")
            connection.setRequestProperty("Accept", "application/json")
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                connection.outputStream.bufferedWriter().use { it.write(body) }
            }
            val code = connection.responseCode
            if (code == HttpURLConnection.HTTP_NO_CONTENT) return@withContext ""
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
            if (code !in 200..299) error("HTTP $code: $response")
            response
        } finally {
            connection.disconnect()
        }
    }
}
