package org.federationofavatars.brotherhood.network

import android.content.Context
import android.provider.Settings
import java.time.Instant
import java.util.UUID
import org.federationofavatars.brotherhood.auth.SessionStore
import org.federationofavatars.brotherhood.model.AuthProvider
import org.federationofavatars.brotherhood.model.GlobalId
import org.json.JSONObject

/** Backend-auth boundary. External provider credentials are sent only to Brotherhood API over HTTPS. */
class AuthRemoteRepository(context: Context) {
    private val api = VercelApiClient(ApiConfig.baseUrl)
    private val appContext = context.applicationContext
    val deviceId: String = runCatching {
        Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
            .takeIf { it.length >= 8 }
    }.getOrNull() ?: appContext.getSharedPreferences("brotherhood_device", Context.MODE_PRIVATE).let { prefs ->
        prefs.getString("installation_id", null) ?: UUID.randomUUID().toString().also { generated ->
            prefs.edit().putString("installation_id", generated).apply()
        }
    }

    suspend fun googleClientId(): String {
        val raw = JSONObject(api.get("v1/auth/google/config", ""))
        return raw.getString("client_id").also { require(it.isNotBlank()) { "Google client ID is not configured" } }
    }

    suspend fun exchangeProviderCredential(provider: AuthProvider, credential: String, nonce: String? = null): SessionStore.StoredSession {
        val body = JSONObject()
            .put("provider", provider.name.lowercase())
            .put("credential", credential)
            .put("device_id", deviceId)
            .apply { if (!nonce.isNullOrBlank()) put("nonce", nonce) }
        return parseSession(api.post("v1/auth/provider/exchange", body.toString(), ""))
    }

    suspend fun beginTelegramOidc(): String {
        val raw = JSONObject(api.post("v1/auth/telegram/begin", JSONObject().put("device_id", deviceId).toString(), ""))
        return raw.getString("authorization_url")
    }

    suspend fun finishTelegramOidc(ticket: String): SessionStore.StoredSession {
        val body = JSONObject()
            .put("ticket", ticket)
            .put("device_id", deviceId)
        return parseSession(api.post("v1/auth/telegram/finish", body.toString(), ""))
    }

    suspend fun requestEmailCode(email: String, locale: String) {
        api.post("v1/auth/email/request-code", JSONObject().put("email", email.trim()).put("locale", locale).toString(), "")
    }

    suspend fun verifyEmailCode(email: String, code: String): SessionStore.StoredSession {
        val body = JSONObject().put("email", email.trim()).put("code", code.trim()).put("device_id", deviceId)
        return parseSession(api.post("v1/auth/email/verify", body.toString(), ""))
    }

    suspend fun refresh(refreshToken: String): SessionStore.StoredSession {
        val body = JSONObject().put("refresh_token", refreshToken).put("device_id", deviceId)
        return parseSession(api.post("v1/auth/refresh", body.toString(), ""))
    }

    suspend fun logout(accessToken: String) {
        api.post("v1/auth/logout", "{}", accessToken)
    }

    suspend fun session(accessToken: String): GlobalId = GlobalId(JSONObject(api.get("v1/auth/session", accessToken)).getLong("global_id"))

    suspend fun passkeyAuthenticationOptions(): Pair<String, String> {
        val raw = JSONObject(api.post("v1/auth/passkey/authentication/options", "{}", ""))
        return raw.getString("challenge_id") to raw.getString("options_json")
    }

    suspend fun finishPasskeyAuthentication(challengeId: String, credentialJson: String): SessionStore.StoredSession {
        val body = JSONObject().put("challenge_id", challengeId).put("credential_json", credentialJson).put("device_id", deviceId)
        return parseSession(api.post("v1/auth/passkey/authentication/finish", body.toString(), ""))
    }

    suspend fun passkeyRegistrationOptions(accessToken: String): Pair<String, String> {
        val raw = JSONObject(api.post("v1/auth/passkey/registration/options", "{}", accessToken))
        return raw.getString("challenge_id") to raw.getString("options_json")
    }

    suspend fun finishPasskeyRegistration(accessToken: String, challengeId: String, credentialJson: String) {
        val body = JSONObject().put("challenge_id", challengeId).put("credential_json", credentialJson)
        api.post("v1/auth/passkey/registration/finish", body.toString(), accessToken)
    }

    private fun parseSession(raw: String): SessionStore.StoredSession {
        val json = JSONObject(raw)
        return SessionStore.StoredSession(
            accessToken = json.getString("access_token"),
            refreshToken = json.optString("refresh_token").takeIf(String::isNotBlank),
            globalId = GlobalId(json.getLong("global_id")),
            provider = AuthProvider.valueOf(json.getString("provider").uppercase()),
            expiresAtEpochSeconds = Instant.parse(json.getString("expires_at")).epochSecond,
            refreshExpiresAtEpochSeconds = json.optString("refresh_expires_at").takeIf(String::isNotBlank)?.let { Instant.parse(it).epochSecond },
            deviceId = deviceId,
        )
    }
}
