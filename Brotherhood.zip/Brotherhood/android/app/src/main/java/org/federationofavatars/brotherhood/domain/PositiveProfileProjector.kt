package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.data.LatentTraitCatalog
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.LatentProfile

/** Public-safe projection. Raw coordinates and low-fit interpretations stay private. */
object PositiveProfileProjector {
    fun topQualities(profile: LatentProfile, language: AppLanguage, limit: Int = 6): List<String> {
        if (profile.traits.isEmpty()) return emptyList()
        return LatentTraitCatalog.qualities.mapNotNull { quality ->
            val rows = quality.targets.mapNotNull targetRows@ { target ->
                val trait = profile.traits[target.traitKey] ?: return@targetRows null
                val closeness = 100 - abs(trait.score - target.targetScore)
                Triple(closeness, target.weight, trait.evidence)
            }
            if (rows.isEmpty()) return@mapNotNull null
            val weight = rows.sumOf { it.second }.coerceAtLeast(1)
            val closeness = (rows.sumOf { it.first * it.second }.toDouble() / weight).roundToInt()
            val evidence = (rows.sumOf { it.third * it.second }.toDouble() / weight).roundToInt()
            Triple(quality.label.get(language), closeness, evidence)
        }
            .sortedWith(compareByDescending<Triple<String, Int, Int>> { it.second }.thenByDescending { it.third })
            .map { it.first }
            .distinct()
            .take(limit)
    }
}
