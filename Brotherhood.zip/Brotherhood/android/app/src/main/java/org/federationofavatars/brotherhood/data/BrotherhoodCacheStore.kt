package org.federationofavatars.brotherhood.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class CacheStats(
    val entries: Int,
    val pendingMutations: Int,
    val outboxMessages: Int,
    val lastSuccessfulSyncAt: Long?
)

data class PendingMutation(
    val id: Long,
    val operation: String,
    val path: String,
    val payload: String,
    val attempts: Int
)

/**
 * Compact local database for offline-first operation.
 * Test definitions and calculation engines remain packaged in the APK; shared state is cached here.
 */
class BrotherhoodCacheStore(context: Context) : SQLiteOpenHelper(context, "brotherhood_cache.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE cache_entries(cache_key TEXT PRIMARY KEY, payload TEXT NOT NULL, entity_type TEXT NOT NULL DEFAULT 'generic', updated_at INTEGER NOT NULL, expires_at INTEGER, etag TEXT)")
        db.execSQL("CREATE INDEX cache_entries_type_updated_idx ON cache_entries(entity_type, updated_at DESC)")
        db.execSQL("CREATE TABLE pending_mutations(id INTEGER PRIMARY KEY AUTOINCREMENT, operation TEXT NOT NULL, path TEXT NOT NULL DEFAULT '', payload TEXT NOT NULL, dedupe_key TEXT, created_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT)")
        db.execSQL("CREATE UNIQUE INDEX pending_mutations_dedupe_idx ON pending_mutations(dedupe_key) WHERE dedupe_key IS NOT NULL")
        db.execSQL("CREATE INDEX pending_mutations_created_idx ON pending_mutations(created_at)")
        db.execSQL("CREATE TABLE message_outbox(local_id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, payload TEXT NOT NULL, created_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, sent_at INTEGER)")
        db.execSQL("CREATE INDEX message_outbox_unsent_idx ON message_outbox(created_at) WHERE sent_at IS NULL")
        db.execSQL("CREATE TABLE recent_entities(entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, payload TEXT NOT NULL, viewed_at INTEGER NOT NULL, PRIMARY KEY(entity_type, entity_id))")
        db.execSQL("CREATE TABLE sync_metadata(sync_key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE cache_entries ADD COLUMN entity_type TEXT NOT NULL DEFAULT 'generic'")
            db.execSQL("ALTER TABLE cache_entries ADD COLUMN etag TEXT")
            db.execSQL("ALTER TABLE pending_mutations ADD COLUMN path TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE pending_mutations ADD COLUMN dedupe_key TEXT")
            db.execSQL("ALTER TABLE pending_mutations ADD COLUMN last_error TEXT")
            db.execSQL("CREATE INDEX IF NOT EXISTS cache_entries_type_updated_idx ON cache_entries(entity_type, updated_at DESC)")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS pending_mutations_dedupe_idx ON pending_mutations(dedupe_key) WHERE dedupe_key IS NOT NULL")
            db.execSQL("CREATE TABLE IF NOT EXISTS message_outbox(local_id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, payload TEXT NOT NULL, created_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, sent_at INTEGER)")
            db.execSQL("CREATE INDEX IF NOT EXISTS message_outbox_unsent_idx ON message_outbox(created_at) WHERE sent_at IS NULL")
            db.execSQL("CREATE TABLE IF NOT EXISTS recent_entities(entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, payload TEXT NOT NULL, viewed_at INTEGER NOT NULL, PRIMARY KEY(entity_type, entity_id))")
            db.execSQL("CREATE TABLE IF NOT EXISTS sync_metadata(sync_key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at INTEGER NOT NULL)")
        }
    }

    fun put(key: String, payload: String, ttlMs: Long? = null, entityType: String = "generic", etag: String? = null) {
        val now = System.currentTimeMillis()
        writableDatabase.insertWithOnConflict(
            "cache_entries",
            null,
            ContentValues().apply {
                put("cache_key", key)
                put("payload", payload)
                put("entity_type", entityType)
                put("updated_at", now)
                if (ttlMs != null) put("expires_at", now + ttlMs) else putNull("expires_at")
                if (etag != null) put("etag", etag) else putNull("etag")
            },
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun get(key: String, allowStale: Boolean = true): String? {
        readableDatabase.query(
            "cache_entries", arrayOf("payload", "expires_at"), "cache_key = ?", arrayOf(key), null, null, null
        ).use { cursor ->
            if (!cursor.moveToFirst()) return null
            val expires = if (cursor.isNull(1)) null else cursor.getLong(1)
            if (!allowStale && expires != null && expires < System.currentTimeMillis()) return null
            return cursor.getString(0)
        }
    }

    fun enqueueMutation(operation: String, payload: String, path: String = "", dedupeKey: String? = null) {
        writableDatabase.insertWithOnConflict(
            "pending_mutations", null,
            ContentValues().apply {
                put("operation", operation)
                put("path", path)
                put("payload", payload)
                if (dedupeKey != null) put("dedupe_key", dedupeKey) else putNull("dedupe_key")
                put("created_at", System.currentTimeMillis())
            },
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun enqueueMessage(localId: String, conversationId: String, payload: String) {
        writableDatabase.insertWithOnConflict(
            "message_outbox", null,
            ContentValues().apply {
                put("local_id", localId)
                put("conversation_id", conversationId)
                put("payload", payload)
                put("created_at", System.currentTimeMillis())
            },
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun rememberEntity(entityType: String, entityId: String, payload: String) {
        writableDatabase.insertWithOnConflict(
            "recent_entities", null,
            ContentValues().apply {
                put("entity_type", entityType)
                put("entity_id", entityId)
                put("payload", payload)
                put("viewed_at", System.currentTimeMillis())
            },
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun markSuccessfulSync(at: Long = System.currentTimeMillis()) {
        writableDatabase.insertWithOnConflict(
            "sync_metadata", null,
            ContentValues().apply {
                put("sync_key", "last_successful_sync_at")
                put("value", at.toString())
                put("updated_at", at)
            },
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun clearExpired(now: Long = System.currentTimeMillis()): Int =
        writableDatabase.delete("cache_entries", "expires_at IS NOT NULL AND expires_at < ?", arrayOf((now - CachePolicy.STALE_WHILE_REVALIDATE_MS).toString()))

    fun pendingMutations(limit: Int = 50): List<PendingMutation> {
        val result = mutableListOf<PendingMutation>()
        readableDatabase.query(
            "pending_mutations",
            arrayOf("id", "operation", "path", "payload", "attempts"),
            "attempts < ?",
            arrayOf(CachePolicy.MAX_PENDING_MUTATION_ATTEMPTS.toString()),
            null, null, "created_at ASC", limit.toString()
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += PendingMutation(
                    id = cursor.getLong(0),
                    operation = cursor.getString(1),
                    path = cursor.getString(2),
                    payload = cursor.getString(3),
                    attempts = cursor.getInt(4)
                )
            }
        }
        return result
    }

    fun markMutationSuccess(id: Long) {
        writableDatabase.delete("pending_mutations", "id = ?", arrayOf(id.toString()))
    }

    fun markMutationFailure(id: Long, error: String) {
        writableDatabase.execSQL(
            "UPDATE pending_mutations SET attempts=attempts+1, last_error=? WHERE id=?",
            arrayOf<Any?>(error.take(500), id)
        )
    }

    fun pendingCount(): Int = count("pending_mutations", "1=1")

    fun stats(): CacheStats = CacheStats(
        entries = count("cache_entries", "1=1"),
        pendingMutations = count("pending_mutations", "1=1"),
        outboxMessages = count("message_outbox", "sent_at IS NULL"),
        lastSuccessfulSyncAt = readableDatabase.rawQuery(
            "SELECT value FROM sync_metadata WHERE sync_key = 'last_successful_sync_at'", null
        ).use { if (it.moveToFirst()) it.getString(0).toLongOrNull() else null }
    )

    private fun count(table: String, where: String): Int = readableDatabase.rawQuery(
        "SELECT count(*) FROM $table WHERE $where", null
    ).use { if (it.moveToFirst()) it.getInt(0) else 0 }
}
