package org.federationofavatars.brotherhood.auth

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.time.Instant
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import org.federationofavatars.brotherhood.model.AuthProvider
import org.federationofavatars.brotherhood.model.GlobalId
import org.json.JSONObject

/**
 * Persists only the app session, encrypted with a non-exportable Android Keystore AES key.
 * Provider credentials, OAuth client secrets and database credentials are never stored here.
 */
class SessionStore(private val context: Context) {
    data class StoredSession(
        val accessToken: String,
        val refreshToken: String?,
        val globalId: GlobalId,
        val provider: AuthProvider,
        val expiresAtEpochSeconds: Long,
        val refreshExpiresAtEpochSeconds: Long?,
        val deviceId: String,
    ) {
        val accessUsable: Boolean get() = accessToken.isNotBlank() && expiresAtEpochSeconds > Instant.now().epochSecond + 30
        val refreshUsable: Boolean get() = !refreshToken.isNullOrBlank() && (refreshExpiresAtEpochSeconds ?: 0L) > Instant.now().epochSecond + 30
    }

    private val file get() = context.filesDir.resolve(FILE_NAME)

    fun load(): StoredSession? = runCatching {
        if (!file.exists()) return null
        val raw = file.readBytes()
        require(raw.size > IV_SIZE)
        val iv = raw.copyOfRange(0, IV_SIZE)
        val encrypted = raw.copyOfRange(IV_SIZE, raw.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        val json = JSONObject(String(cipher.doFinal(encrypted), StandardCharsets.UTF_8))
        StoredSession(
            accessToken = json.getString("access_token"),
            refreshToken = json.optString("refresh_token").takeIf(String::isNotBlank),
            globalId = GlobalId(json.getLong("global_id")),
            provider = AuthProvider.valueOf(json.getString("provider")),
            expiresAtEpochSeconds = json.getLong("expires_at"),
            refreshExpiresAtEpochSeconds = json.optLong("refresh_expires_at", 0L).takeIf { it > 0L },
            deviceId = json.getString("device_id"),
        )
    }.getOrNull()

    fun save(session: StoredSession) {
        val json = JSONObject()
            .put("access_token", session.accessToken)
            .put("refresh_token", session.refreshToken ?: "")
            .put("global_id", session.globalId.value)
            .put("provider", session.provider.name)
            .put("expires_at", session.expiresAtEpochSeconds)
            .put("refresh_expires_at", session.refreshExpiresAtEpochSeconds ?: 0L)
            .put("device_id", session.deviceId)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(json.toString().toByteArray(StandardCharsets.UTF_8))
        val temp = context.filesDir.resolve("$FILE_NAME.tmp")
        temp.writeBytes(cipher.iv + encrypted)
        check(temp.renameTo(file) || run { file.delete(); temp.renameTo(file) }) { "Could not persist encrypted session" }
    }

    fun clear() {
        file.delete()
    }

    private fun key(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        private const val KEY_ALIAS = "brotherhood.session.v1"
        private const val FILE_NAME = "brotherhood_session.enc"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_SIZE = 12
    }
}
