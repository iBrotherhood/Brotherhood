package org.federationofavatars.brotherhood.model

enum class AssessmentKind(val title: String) {
    LOYALTY("Верность"),
    INTEGRITY("Честность и последовательность"),
    RELIABILITY("Надёжность"),
    CONFLICT("Конфликты и восстановление"),
    BOUNDARIES("Границы и конфиденциальность"),
    SUPPORT("Поддержка и эмпатия"),
    COMPETITION("Зависть, статус и конкуренция"),
    COMMUNICATION("Стиль общения"),
    MUTUAL_AID("Взаимопомощь, деньги и бизнес"),
    LIFESTYLE("Ценности и образ жизни")
}

enum class CompatibilityMode {
    SIMILARITY,
    HIGH_IS_GOOD
}

data class AssessmentQuestion(
    val id: String,
    val text: String,
    val dimension: String,
    val reverse: Boolean = false,
    val validityItem: Boolean = false,
    val pairId: String? = null
)

data class AssessmentDefinition(
    val id: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val estimatedMinutes: Int,
    val kind: AssessmentKind,
    val required: Boolean,
    val compatibilityMode: CompatibilityMode,
    val safetyCritical: Boolean,
    val accountWeightPercent: Double = 0.5,
    val dimensionTitles: Map<String, String>,
    val questions: List<AssessmentQuestion>
)

data class DimensionScore(
    val id: String,
    val title: String,
    val score: Int
)

data class AssessmentResult(
    val assessmentId: String,
    val totalScore: Int,
    val riskScore: Int,
    val label: String,
    val summary: String,
    val dimensions: List<DimensionScore>,
    val answerConsistency: Int,
    val idealizedSelfPresentation: Int,
    val completedAtEpochMs: Long = System.currentTimeMillis()
)

data class AccountRatingBreakdown(
    val total: Double,
    val profilePoints: Double,
    val testPoints: Double,
    val completedProfileSections: Int,
    val totalProfileSections: Int,
    val completedTests: Int,
    val totalTests: Int
)

data class FriendshipCompatibilityResult(
    val score: Int,
    val testsScore: Int,
    val commonTests: Int,
    val confidence: Int,
    val riskFlags: List<String>,
    val explanation: String
)


data class IntegrityScreeningResult(
    val riskScore: Int,
    val consistencyScore: Int,
    val evaluatedPairs: Int,
    val confidence: Int,
    val label: String,
    val flags: List<String>
)
