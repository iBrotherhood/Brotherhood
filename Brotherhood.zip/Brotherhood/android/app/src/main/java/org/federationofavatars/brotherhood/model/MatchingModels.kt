package org.federationofavatars.brotherhood.model

enum class SearchRole {
    FRIEND,
    CLOSE_FRIEND,
    BUSINESS_PARTNER,
    DIRECTOR,
    PROJECT_TEAMMATE,
    MENTOR,
    ACTIVITY_PARTNER,
    CUSTOM,
}

data class DesiredQuality(
    val key: String,
    val importance: Int = 3,
) {
    init { require(importance in 1..5) }
}

data class SearchIntent(
    val role: SearchRole = SearchRole.FRIEND,
    val qualities: List<DesiredQuality> = emptyList(),
)

data class LatentTraitScore(
    val key: String,
    val score: Int,
    val evidence: Int,
) {
    init {
        require(score in 0..100)
        require(evidence >= 0)
    }
}

data class LatentProfile(
    val traits: Map<String, LatentTraitScore>,
    val confidence: Int,
) {
    init { require(confidence in 0..100) }
}

data class PositiveQualityMatch(
    val qualityKey: String,
    val label: String,
    val fit: Int,
)

data class QualityFitResult(
    val score: Int,
    val confidence: Int,
    val matched: List<PositiveQualityMatch>,
) {
    init {
        require(score in 0..100)
        require(confidence in 0..100)
    }
}
