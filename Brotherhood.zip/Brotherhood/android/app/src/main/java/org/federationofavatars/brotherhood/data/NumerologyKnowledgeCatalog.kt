package org.federationofavatars.brotherhood.data

import android.content.Context
import org.federationofavatars.brotherhood.model.AppLanguage
import org.json.JSONObject

data class NumerologyKnowledgeEntry(val title: String, val body: String)

data class NumerologyKnowledgeSection(val id: String, val title: String, val body: String)

data class NumerologyLifePathEntry(
    val title: String,
    val sections: List<NumerologyKnowledgeSection>,
)

/** Loads the production APK numerology knowledge asset. No network or server round trip is needed. */
class NumerologyKnowledgeCatalog(context: Context) {
    private val root: JSONObject by lazy {
        val text = context.assets.open("numerology/numerology_knowledge_v1.json")
            .bufferedReader(Charsets.UTF_8)
            .use { it.readText() }
        JSONObject(text)
    }

    fun entry(section: String, key: String, language: AppLanguage): NumerologyKnowledgeEntry? {
        val localized = localized(language)
            .optJSONObject(section)
            ?.optJSONObject(key)
            ?: return null
        return NumerologyKnowledgeEntry(
            title = localized.optString("title"),
            body = localized.optString("body"),
        )
    }

    fun lifePath(number: Int, language: AppLanguage): NumerologyLifePathEntry? {
        val node = localized(language)
            .optJSONObject("life_paths")
            ?.optJSONObject(number.toString())
            ?: return null
        val sectionsJson = node.optJSONArray("sections") ?: return null
        val sections = buildList {
            for (index in 0 until sectionsJson.length()) {
                val item = sectionsJson.optJSONObject(index) ?: continue
                add(
                    NumerologyKnowledgeSection(
                        id = item.optString("id"),
                        title = item.optString("title"),
                        body = item.optString("body"),
                    )
                )
            }
        }
        return NumerologyLifePathEntry(node.optString("title"), sections)
    }

    fun inventory(section: String): Set<String> {
        val array = root.optJSONObject("inventory")?.optJSONArray(section) ?: return emptySet()
        return buildSet {
            for (i in 0 until array.length()) add(array.optString(i))
        }
    }

    private fun localized(language: AppLanguage): JSONObject {
        val tag = language.tag
        val locales = root.getJSONObject("locales")
        return if (locales.has(tag)) locales.getJSONObject(tag) else locales.getJSONObject("en")
    }
}
