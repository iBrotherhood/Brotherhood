package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import org.federationofavatars.brotherhood.model.Personality32Profile

object Personality32Engine {
    data class AxisInput(
        val socialEnergy: Int,
        val perception: Int,
        val decisionStyle: Int,
        val lifeRhythm: Int,
        val bondStyle: Int
    ) {
        init {
            listOf(socialEnergy, perception, decisionStyle, lifeRhythm, bondStyle)
                .forEach { require(it in 0..100) }
        }
    }

    private data class BaseName(val ru: String, val uk: String, val en: String)

    private val baseNames = listOf(
        BaseName("Инспектор", "Інспектор", "Inspector"),
        BaseName("Организатор", "Організатор", "Organizer"),
        BaseName("Стратег", "Стратег", "Strategist"),
        BaseName("Архитектор", "Архітектор", "Architect"),
        BaseName("Опекун", "Опікун", "Caretaker"),
        BaseName("Наставник", "Наставник", "Mentor"),
        BaseName("Советник", "Радник", "Counselor"),
        BaseName("Вдохновитель", "Натхненник", "Inspirer"),
        BaseName("Мастер", "Майстер", "Craftsman"),
        BaseName("Деятель", "Діяч", "Doer"),
        BaseName("Исследователь", "Дослідник", "Explorer"),
        BaseName("Изобретатель", "Винахідник", "Inventor"),
        BaseName("Миротворец", "Миротворець", "Peacemaker"),
        BaseName("Объединитель", "Об'єднувач", "Connector"),
        BaseName("Идеалист", "Ідеаліст", "Idealist"),
        BaseName("Проводник", "Провідник", "Guide")
    )

    fun classify(input: AxisInput): Personality32Profile {
        val social = input.socialEnergy >= 50
        val visionary = input.perception >= 50
        val humane = input.decisionStyle >= 50
        val flexible = input.lifeRhythm >= 50
        val adaptive = input.bondStyle >= 50

        val baseIndex =
            (if (social) 1 else 0) or
            (if (visionary) 2 else 0) or
            (if (humane) 4 else 0) or
            (if (flexible) 8 else 0)
        val base = baseNames[baseIndex]

        val code = buildString {
            append(if (social) 'E' else 'R')
            append(if (visionary) 'V' else 'P')
            append(if (humane) 'H' else 'L')
            append(if (flexible) 'F' else 'S')
            append(if (adaptive) 'A' else 'G')
        }
        return Personality32Profile(
            code = code,
            titleRu = "${if (adaptive) "Свободный" else "Верный"} ${base.ru}",
            titleUk = "${if (adaptive) "Вільний" else "Вірний"} ${base.uk}",
            titleEn = "${if (adaptive) "Adaptive" else "Loyal"} ${base.en}",
            socialEnergy = input.socialEnergy,
            perception = input.perception,
            decisionStyle = input.decisionStyle,
            lifeRhythm = input.lifeRhythm,
            bondStyle = input.bondStyle
        )
    }

    /** Returns the full canonical 32-type registry used by the UI and compatibility engine. */
    fun allCanonicalProfiles(): List<Personality32Profile> = (0 until 32).map { mask ->
        classify(
            AxisInput(
                socialEnergy = if (mask and 1 != 0) 75 else 25,
                perception = if (mask and 2 != 0) 75 else 25,
                decisionStyle = if (mask and 4 != 0) 75 else 25,
                lifeRhythm = if (mask and 8 != 0) 75 else 25,
                bondStyle = if (mask and 16 != 0) 75 else 25
            )
        )
    }.also { profiles ->
        check(profiles.size == 32 && profiles.map(Personality32Profile::code).toSet().size == 32)
    }

    fun compatibility(first: Personality32Profile, second: Personality32Profile): Int {
        val differences = listOf(
            abs(first.socialEnergy - second.socialEnergy),
            abs(first.perception - second.perception),
            abs(first.decisionStyle - second.decisionStyle),
            abs(first.lifeRhythm - second.lifeRhythm),
            abs(first.bondStyle - second.bondStyle)
        )
        val averageSimilarity = 100 - differences.average()
        // bondStyle is oriented from stable/committed (0) to adaptive/independent (100).
        // For long-term male friendship, absolute bond durability is therefore the inverse
        // of bondStyle. Keep profile similarity and durability as distinct contributions.
        val durabilityFloor = 100 - maxOf(first.bondStyle, second.bondStyle)
        return (averageSimilarity * 0.85 + durabilityFloor * 0.15).toInt().coerceIn(0, 100)
    }
}
