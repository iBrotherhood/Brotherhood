package org.federationofavatars.brotherhood.data

import org.federationofavatars.brotherhood.model.AssessmentDefinition
import org.federationofavatars.brotherhood.model.AssessmentKind
import org.federationofavatars.brotherhood.model.CompatibilityMode

/**
 * Canonical Brotherhood bank: exactly 100 psychological/behavioural blocks × 6 indirect visual
 * tasks = 600 tasks. Numerology is NOT part of this bank.
 *
 * Internal trait names are algorithm-only. The UI must show neutral block numbers and visual tasks,
 * never these constructs or their direction.
 */
object AssessmentCatalog {
    const val REQUIRED_TEST_COUNT = 100
    const val QUESTIONS_PER_TEST = 6
    const val REQUIRED_TASK_COUNT = REQUIRED_TEST_COUNT * QUESTIONS_PER_TEST
    const val ACCOUNT_POINTS_PER_TEST = 0.5

    private data class KindPlan(val kind: AssessmentKind, val traits: List<String>)

    private val plans = listOf(
        KindPlan(AssessmentKind.LOYALTY, listOf("dependability", "confidentiality", "reciprocity", "status_independence", "fairness", "independence", "trust_openness", "boundary_respect", "support_availability", "rule_orientation")),
        KindPlan(AssessmentKind.INTEGRITY, listOf("integrity_sincerity", "fairness", "dependability", "self_control", "humility", "rule_orientation", "status_independence", "directness", "attention_to_detail", "cautiousness")),
        KindPlan(AssessmentKind.RELIABILITY, listOf("dependability", "planning", "perseverance", "time_discipline", "attention_to_detail", "self_control", "decisiveness", "adaptability", "initiative", "stress_tolerance")),
        KindPlan(AssessmentKind.CONFLICT, listOf("conflict_engagement", "forgiveness", "directness", "tact", "self_control", "assertiveness", "empathy", "boundary_respect", "fairness", "ambiguity_tolerance")),
        KindPlan(AssessmentKind.BOUNDARIES, listOf("boundary_respect", "confidentiality", "autonomy", "vulnerability_comfort", "trust_openness", "humor_tolerance", "status_independence", "group_orientation", "independence", "rule_orientation")),
        KindPlan(AssessmentKind.SUPPORT, listOf("support_availability", "empathy", "reciprocity", "resource_generosity", "optimism", "vulnerability_comfort", "contact_intensity", "response_urgency", "cooperation", "family_orientation")),
        KindPlan(AssessmentKind.COMPETITION, listOf("competitiveness", "achievement_orientation", "leadership_orientation", "assertiveness", "self_confidence", "risk_tolerance", "decisiveness", "humility", "status_independence", "cooperation")),
        KindPlan(AssessmentKind.COMMUNICATION, listOf("directness", "tact", "social_energy", "contact_intensity", "response_urgency", "humor_tolerance", "empathy", "conflict_engagement", "vulnerability_comfort", "ambiguity_tolerance")),
        KindPlan(AssessmentKind.MUTUAL_AID, listOf("money_discipline", "resource_generosity", "initiative", "achievement_orientation", "risk_tolerance", "planning", "fairness", "cooperation", "leadership_orientation", "innovation")),
        KindPlan(AssessmentKind.LIFESTYLE, listOf("spontaneity", "planning", "family_orientation", "social_energy", "group_orientation", "independence", "intellectual_curiosity", "adaptability", "time_discipline", "optimism")),
    )

    val assessments: List<AssessmentDefinition> = buildList {
        plans.forEachIndexed { kindIndex, plan ->
            repeat(10) { localIndex ->
                val number = kindIndex * 10 + localIndex + 1
                val id = "f${number.toString().padStart(3, '0')}"
                val allTraits = LatentTraitCatalog.traits.map { it.key }
                add(
                    AssessmentDefinition(
                        id = id,
                        title = "Internal latent block $number",
                        subtitle = "Hidden multidimensional visual task",
                        description = "Algorithm-only construct bundle. User presentation must remain neutral.",
                        estimatedMinutes = 2,
                        kind = plan.kind,
                        required = true,
                        compatibilityMode = CompatibilityMode.SIMILARITY,
                        safetyCritical = false,
                        dimensionTitles = emptyMap(), // each task cross-loads different hidden coordinates
                        questions = (1..QUESTIONS_PER_TEST).map { ordinal ->
                            val primary = plan.traits[(localIndex + ordinal - 1) % plan.traits.size]
                            var secondary = plan.traits[(localIndex + ordinal * 3 + 1) % plan.traits.size]
                            if (secondary == primary) secondary = plan.traits[(localIndex + ordinal * 3 + 2) % plan.traits.size]
                            var tertiary = allTraits[(number * 11 + ordinal * 17) % allTraits.size]
                            if (tertiary == primary || tertiary == secondary) tertiary = allTraits[(number * 11 + ordinal * 17 + 7) % allTraits.size]
                            VisualAssessmentFactory.question(id, ordinal, primary, secondary, tertiary)
                        },
                    )
                )
            }
        }
    }

    init {
        require(assessments.size == REQUIRED_TEST_COUNT)
        require(assessments.sumOf { it.questions.size } == REQUIRED_TASK_COUNT)
        require(assessments.all { it.compatibilityMode == CompatibilityMode.SIMILARITY && !it.safetyCritical })
        require(assessments.flatMap { it.questions }.all { it.choices.size == 4 })
    }

    val byCategory: Map<AssessmentKind, List<AssessmentDefinition>> = assessments.groupBy { it.kind }
    private val byIdMap = assessments.associateBy { it.id }
    fun byId(id: String): AssessmentDefinition? = byIdMap[id]
}
