package org.federationofavatars.brotherhood.domain

import java.time.LocalDate
import kotlin.math.abs
import org.federationofavatars.brotherhood.model.VedicNumerologyProfile

object VedicNumerologyEngine {
    private val chaldean = mapOf(
        'A' to 1, 'I' to 1, 'J' to 1, 'Q' to 1, 'Y' to 1,
        'B' to 2, 'K' to 2, 'R' to 2,
        'C' to 3, 'G' to 3, 'L' to 3, 'S' to 3,
        'D' to 4, 'M' to 4, 'T' to 4,
        'E' to 5, 'H' to 5, 'N' to 5, 'X' to 5,
        'U' to 6, 'V' to 6, 'W' to 6,
        'O' to 7, 'Z' to 7,
        'F' to 8, 'P' to 8
    )

    fun calculate(date: LocalDate, latinName: String?): VedicNumerologyProfile {
        val soul = digitalRoot(date.dayOfMonth)
        val destiny = digitalRoot(date.dayOfMonth + date.monthValue + date.year.toString().sumOf { it.digitToInt() })
        val name = latinName
            ?.uppercase()
            ?.mapNotNull(chaldean::get)
            ?.takeIf { it.isNotEmpty() }
            ?.sum()
            ?.let(::digitalRoot)
        val maturity = digitalRoot(destiny + (name ?: soul))
        return VedicNumerologyProfile(
            soulNumber = soul,
            destinyNumber = destiny,
            nameNumber = name,
            maturityNumber = maturity,
            compatibilityVector = listOf(soul, destiny, name ?: soul, maturity).distinct()
        )
    }

    fun compatibility(first: VedicNumerologyProfile, second: VedicNumerologyProfile): Int {
        val directMatches = first.compatibilityVector.intersect(second.compatibilityVector.toSet()).size
        val soulDistance = abs(first.soulNumber - second.soulNumber)
        val destinyDistance = abs(first.destinyNumber - second.destinyNumber)
        return (58 + directMatches * 9 + (9 - soulDistance) * 2 + (9 - destinyDistance)).coerceIn(35, 96)
    }

    private fun digitalRoot(number: Int): Int {
        require(number >= 0)
        if (number == 0) return 0
        var current = number
        while (current > 9) current = current.toString().sumOf { it.digitToInt() }
        return current
    }
}
