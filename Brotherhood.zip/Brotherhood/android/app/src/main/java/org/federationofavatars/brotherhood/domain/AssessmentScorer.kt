package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.model.AssessmentDefinition
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.DimensionScore

object AssessmentScorer {
    fun score(definition: AssessmentDefinition, answers: Map<String, Int>): AssessmentResult {
        require(definition.questions.all { answers[it.id] in 1..5 }) {
            "Для расчёта необходимо ответить на все вопросы значениями от 1 до 5"
        }

        val scoredQuestions = definition.questions.filterNot { it.validityItem }
        val dimensions = scoredQuestions.groupBy { it.dimension }.map { (dimension, questions) ->
            val average = questions.map { question ->
                val raw = answers.getValue(question.id)
                if (question.reverse) 6 - raw else raw
            }.average()
            DimensionScore(
                id = dimension,
                title = definition.dimensionTitles[dimension] ?: definition.title,
                score = (((average - 1.0) / 4.0) * 100.0).roundToInt().coerceIn(0, 100)
            )
        }.sortedByDescending { it.score }

        val total = dimensions.map { it.score }.average().roundToInt().coerceIn(0, 100)
        val risk = if (definition.safetyCritical) 100 - total else 0
        val consistency = calculateConsistency(definition, answers)
        val idealization = calculateIdealization(definition, answers)

        val label = when {
            idealization >= 75 -> "Ответы требуют дополнительной проверки"
            definition.safetyCritical && total >= 80 -> "Высокий заявленный уровень надёжности"
            definition.safetyCritical && total >= 60 -> "Умеренно устойчивый профиль"
            definition.safetyCritical && total >= 40 -> "Смешанный профиль риска"
            definition.safetyCritical -> "Повышенный заявленный риск"
            else -> "Профиль совместимости сформирован"
        }

        val summary = if (definition.safetyCritical) {
            "Тест оценивает только самоописание. Низкий результат является сигналом осторожности, а высокий не доказывает честность. Для поиска настоящего друга система должна сопоставлять ответы с подтверждёнными взаимодействиями, историей выполнения договорённостей и решениями модерации."
        } else {
            "Результат используется для сравнения ожиданий, ценностей и стиля мужской дружбы. Он не делит людей на хороших и плохих, а показывает вероятность удобного и устойчивого взаимодействия."
        }

        return AssessmentResult(
            assessmentId = definition.id,
            totalScore = total,
            riskScore = risk,
            label = label,
            summary = summary,
            dimensions = dimensions,
            answerConsistency = consistency,
            idealizedSelfPresentation = idealization
        )
    }

    private fun calculateConsistency(definition: AssessmentDefinition, answers: Map<String, Int>): Int {
        val paired = definition.questions.filter { it.pairId != null }.groupBy { it.pairId }
        if (paired.isNotEmpty()) {
            val differences = paired.values.mapNotNull { questions ->
                if (questions.size != 2) return@mapNotNull null
                val normalized = questions.map { question ->
                    val raw = answers.getValue(question.id)
                    if (question.reverse) 6 - raw else raw
                }
                abs(normalized[0] - normalized[1])
            }
            if (differences.isNotEmpty()) {
                return (100.0 - differences.average() / 4.0 * 100.0).roundToInt().coerceIn(0, 100)
            }
        }

        // For six-question mini-tests compare the positive and reverse halves after normalization.
        val normalized = definition.questions.filterNot { it.validityItem }.map { question ->
            val raw = answers.getValue(question.id)
            if (question.reverse) 6 - raw else raw
        }
        if (normalized.size < 4) return 100
        val half = normalized.size / 2
        val first = normalized.take(half).average()
        val second = normalized.drop(half).average()
        return (100.0 - abs(first - second) / 4.0 * 100.0).roundToInt().coerceIn(0, 100)
    }

    private fun calculateIdealization(definition: AssessmentDefinition, answers: Map<String, Int>): Int {
        val validity = definition.questions.filter { it.validityItem }
        if (validity.isNotEmpty()) {
            val points: Int = validity.fold(0) { total, question ->
                total + when (answers.getValue(question.id)) {
                    5 -> 2
                    4 -> 1
                    else -> 0
                }
            }
            return ((points.toDouble() / (validity.size * 2).toDouble()) * 100.0)
                .roundToInt().coerceIn(0, 100)
        }

        // A uniform "perfect" profile on all positive and reverse statements is a soft warning.
        val extremes = definition.questions.count { answers.getValue(it.id) == if (it.reverse) 1 else 5 }
        return ((extremes.toDouble() / definition.questions.size.toDouble()) * 100.0)
            .roundToInt().coerceIn(0, 100)
    }
}
