package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.model.AssessmentDefinition
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.AssessmentResponseTrace
import org.federationofavatars.brotherhood.model.DimensionScore

/** Scores only hidden coordinates. It never classifies an answer as morally good/bad. */
object AssessmentScorer {
    fun score(
        definition: AssessmentDefinition,
        answers: Map<String, Int>,
        responseLatencyMs: Map<String, Long> = emptyMap(),
        selectionChanges: Map<String, Int> = emptyMap(),
        questionPositions: Map<String, Int> = emptyMap(),
        startedAtEpochMs: Long = System.currentTimeMillis(),
    ): AssessmentResult {
        require(definition.questions.all { answers[it.id] in 1..4 }) {
            "Every visual task requires one of four choices"
        }

        val evidence = linkedMapOf<String, MutableList<Int>>()
        definition.questions.forEach { question ->
            val selected = question.choices[answers.getValue(question.id) - 1]
            selected.latentLoadings.forEach { (trait, loading) ->
                evidence.getOrPut(trait) { mutableListOf() }.add(loading)
            }
        }

        val dimensions = evidence.map { (trait, loadings) ->
            val mean = loadings.average().coerceIn(-2.0, 2.0)
            DimensionScore(
                id = trait,
                title = trait, // algorithm-only; never render directly
                score = (50.0 + mean * 25.0).roundToInt().coerceIn(0, 100),
            )
        }.sortedBy { it.id }

        val total = dimensions.map { it.score }.average().takeUnless(Double::isNaN)?.roundToInt()?.coerceIn(0, 100) ?: 50
        val consistency = internalCoherence(definition, answers)
        val responseTrace = definition.questions.map { question ->
            val selected = question.choices[answers.getValue(question.id) - 1]
            AssessmentResponseTrace(
                questionId = question.id,
                choiceId = selected.id,
                paradigm = question.paradigm.name,
                sceneArchetype = question.sceneArchetype.name,
                stimulusVersion = question.stimulusVersion,
                visualSeed = question.visualSeed,
                intensity = selected.layout.intensity,
                spacing = selected.layout.spacing,
                order = selected.layout.order,
                asymmetry = selected.layout.asymmetry,
                direction = selected.layout.direction,
                presentationSlot = org.federationofavatars.brotherhood.data.VisualAssessmentFactory.presentationSlot(question, selected.id),
                responseLatencyMs = (responseLatencyMs[question.id] ?: 0L).coerceIn(0L, 600_000L),
                selectionChanges = (selectionChanges[question.id] ?: 0).coerceIn(0, 20),
                questionPosition = (questionPositions[question.id] ?: 0).coerceIn(0, 6),
            )
        }
        return AssessmentResult(
            assessmentId = definition.id,
            modelVersion = org.federationofavatars.brotherhood.model.AssessmentModelVersions.ACTIVE,
            stimulusVersion = org.federationofavatars.brotherhood.data.VisualAssessmentFactory.STIMULUS_VERSION,
            startedAtEpochMs = startedAtEpochMs,
            totalScore = total,
            riskScore = 0,
            label = "Профиль обновлён",
            summary = "Серия учтена в персональном подборе.",
            dimensions = dimensions,
            answerConsistency = consistency,
            responseTrace = responseTrace,
            idealizedSelfPresentation = 0,
        )
    }

    private fun internalCoherence(definition: AssessmentDefinition, answers: Map<String, Int>): Int {
        // Internal confidence signal only. It measures stability of repeated latent coordinates,
        // not honesty, goodness, or deception.
        val traitValues = mutableMapOf<String, MutableList<Int>>()
        definition.questions.forEach { question ->
            val choice = question.choices[answers.getValue(question.id) - 1]
            choice.latentLoadings.forEach { (trait, loading) -> traitValues.getOrPut(trait) { mutableListOf() }.add(loading) }
        }
        val dispersions = traitValues.values.mapNotNull { rows ->
            if (rows.size < 2) null else rows.zipWithNext().map { (a, b) -> abs(a - b) }.average()
        }
        if (dispersions.isEmpty()) return 50
        return (100.0 - dispersions.average() / 4.0 * 100.0).roundToInt().coerceIn(0, 100)
    }
}
