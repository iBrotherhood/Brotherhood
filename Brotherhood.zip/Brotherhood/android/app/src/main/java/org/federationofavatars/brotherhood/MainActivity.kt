package org.federationofavatars.brotherhood

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import org.federationofavatars.brotherhood.ui.BrotherhoodApp
import org.federationofavatars.brotherhood.ui.MainViewModel
import org.federationofavatars.brotherhood.ui.theme.BrotherhoodTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MainViewModel = viewModel()
            BrotherhoodTheme(themeMode = viewModel.themeMode) {
                BrotherhoodApp(viewModel)
            }
        }
    }
}
