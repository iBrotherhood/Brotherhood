package org.federationofavatars.brotherhood.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import org.federationofavatars.brotherhood.model.AppThemeMode

private val BrotherhoodDark = darkColorScheme(
    primary = Color(0xFFE5B95C),
    onPrimary = Color(0xFF201800),
    primaryContainer = Color(0xFF3B2E0C),
    onPrimaryContainer = Color(0xFFFFE6AE),
    secondary = Color(0xFF8EB9FF),
    onSecondary = Color(0xFF002B5D),
    background = Color(0xFF000000),
    onBackground = Color(0xFFF2F2F4),
    surface = Color(0xFF0B0C0F),
    onSurface = Color(0xFFF2F2F4),
    surfaceVariant = Color(0xFF17191E),
    onSurfaceVariant = Color(0xFFC5C7CE),
    outline = Color(0xFF4A4D55),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005)
)

private val BrotherhoodLight = lightColorScheme(
    primary = Color(0xFF66500A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE08B),
    onPrimaryContainer = Color(0xFF201800),
    secondary = Color(0xFF24558F),
    onSecondary = Color.White,
    background = Color(0xFFF7F7F9),
    onBackground = Color(0xFF191A1E),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF191A1E),
    surfaceVariant = Color(0xFFE7E8ED),
    onSurfaceVariant = Color(0xFF45474E),
    outline = Color(0xFF76777F),
    error = Color(0xFFBA1A1A),
    onError = Color.White
)


private val BrotherhoodShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun BrotherhoodTheme(
    themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val dark = when (themeMode) {
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = if (dark) BrotherhoodDark else BrotherhoodLight,
        typography = Typography(),
        shapes = BrotherhoodShapes,
        content = content
    )
}
