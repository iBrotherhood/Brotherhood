package org.federationofavatars.brotherhood.network

import android.content.Context
import org.federationofavatars.brotherhood.data.BrotherhoodCacheStore
import org.federationofavatars.brotherhood.data.CachePolicy
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.Community
import org.federationofavatars.brotherhood.model.CommunityKind
import org.federationofavatars.brotherhood.model.EnneagramProfile
import org.federationofavatars.brotherhood.model.FriendCandidate
import org.federationofavatars.brotherhood.model.GlobalId
import org.federationofavatars.brotherhood.model.Personality32Profile
import org.federationofavatars.brotherhood.model.UserProfile
import org.federationofavatars.brotherhood.model.VedicNumerologyProfile
import org.federationofavatars.brotherhood.model.ZodiacSign
import org.federationofavatars.brotherhood.sync.OfflineFirstRepository
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * Production data source. Shared state goes only through the Vercel backend.
 * Neon credentials never exist in the APK.
 */
class RemoteDataRepository(context: Context) {
    private val cache = BrotherhoodCacheStore(context.applicationContext)
    private val offline = OfflineFirstRepository(cache, VercelApiClient(ApiConfig.baseUrl))

    suspend fun people(city: String, radiusKm: Int, requester: GlobalId, token: String): List<FriendCandidate> {
        val encodedCity = URLEncoder.encode(city, StandardCharsets.UTF_8.toString())
        val path = "v1/people?city=$encodedCity&radius_km=$radiusKm&requester_global_id=${requester.value}"
        val json = offline.cachedThenNetwork(
            cacheKey = "people:$city:$radiusKm:${requester.value}",
            path = path,
            token = token,
            ttlMs = CachePolicy.PEOPLE_SEARCH_TTL_MS,
        )
        val array = JSONArray(json)
        return buildList {
            for (index in 0 until array.length()) add(parsePerson(array.getJSONObject(index)))
        }
    }

    suspend fun communities(city: String, kind: CommunityKind, token: String): List<Community> {
        val encodedCity = URLEncoder.encode(city, StandardCharsets.UTF_8.toString())
        val path = "v1/communities?city=$encodedCity&kind=${kind.name.lowercase()}"
        val json = offline.cachedThenNetwork(
            cacheKey = "communities:$city:${kind.name}",
            path = path,
            token = token,
            ttlMs = CachePolicy.COMMUNITIES_TTL_MS,
        )
        val array = JSONArray(json)
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    Community(
                        id = item.getString("id"),
                        title = item.getString("title"),
                        category = item.getString("category"),
                        city = item.optString("city", city),
                        members = item.optInt("members", 0),
                        kind = runCatching { CommunityKind.valueOf(item.optString("kind", "interest").uppercase()) }.getOrDefault(kind),
                        online = item.optBoolean("online", false),
                        description = item.optString("description", ""),
                        verifiedOnly = item.optBoolean("verified_only", false),
                    )
                )
            }
        }
    }

    suspend fun syncProfile(profile: UserProfile, language: AppLanguage, token: String): Boolean {
        val body = JSONObject().apply {
            put("display_name", profile.name)
            put("birth_date", profile.birthDate.toString())
            put("latin_name", profile.latinName)
            put("city", profile.city)
            put("country_code", "ZZ")
            put("about", profile.description)
            put("friendship_goals", JSONArray(profile.goals))
            put("interests", JSONArray(profile.interests))
            put("values", JSONArray(profile.values))
            put("lifestyle", JSONArray(profile.lifestyle))
            put("boundaries", JSONObject())
            put("visibility", "discoverable")
            put("completed_profile_sections", profile.completedProfileSections)
            put("locale", language.tag)
        }.toString()
        return offline.writeOrQueue(
            operation = "PUT_PROFILE",
            path = "v1/profiles/${profile.globalId.value}",
            json = body,
            token = token,
        )
    }

    suspend fun syncPersonalityProfile(profile: UserProfile, token: String): Boolean {
        val p = profile.personality32
        val n = profile.numerology
        val body = JSONObject().apply {
            put("brotherhood32_code", p.code)
            put("brotherhood32_scores", JSONObject().apply {
                put("title", p.titleEn)
                put("social_energy", p.socialEnergy)
                put("perception", p.perception)
                put("decision_style", p.decisionStyle)
                put("life_rhythm", p.lifeRhythm)
                put("bond_style", p.bondStyle)
            })
            put("enneagram_type", profile.enneagram.type)
            if (profile.enneagram.wing == null) put("enneagram_wing", JSONObject.NULL) else put("enneagram_wing", profile.enneagram.wing)
            put("zodiac_sign", profile.zodiac.name)
            put("vedic_numerology", JSONObject().apply {
                put("soul_number", n.soulNumber)
                put("destiny_number", n.destinyNumber)
                if (n.nameNumber == null) put("name_number", JSONObject.NULL) else put("name_number", n.nameNumber)
                put("maturity_number", n.maturityNumber)
                put("compatibility_vector", JSONArray(n.compatibilityVector))
            })
            put("model_version", "0.5.7")
        }.toString()
        return offline.writeOrQueue(
            operation = "PUT_PERSONALITY",
            path = "v1/personality-profile/${profile.globalId.value}",
            json = body,
            token = token,
        )
    }

    suspend fun syncAssessmentResult(globalId: GlobalId, result: AssessmentResult, token: String): Boolean {
        val dimensions = JSONArray().apply {
            result.dimensions.forEach { dimension ->
                put(JSONObject().apply {
                    put("id", dimension.id)
                    put("title", dimension.title)
                    put("score", dimension.score)
                })
            }
        }
        val body = JSONObject().apply {
            put("global_id", globalId.value)
            put("assessment_id", result.assessmentId)
            put("scoring_version", "0.5.7")
            put("total_score", result.totalScore)
            put("risk_score", result.riskScore)
            put("answer_consistency", result.answerConsistency)
            put("idealized_self_presentation", result.idealizedSelfPresentation)
            put("label", result.label)
            put("summary", result.summary)
            put("dimensions", dimensions)
            put("completed_at_epoch_ms", result.completedAtEpochMs)
        }.toString()
        return offline.writeOrQueue(
            operation = "PUT_ASSESSMENT",
            path = "v1/assessment-results",
            json = body,
            token = token,
        )
    }

    suspend fun flushPending(token: String): Int = offline.flushPending(token)

    fun close() = cache.close()

    private fun parsePerson(item: JSONObject): FriendCandidate {
        val globalId = GlobalId(item.getLong("global_id"))
        val personalityJson = item.optJSONObject("personality32")
        val personality = Personality32Profile(
            code = personalityJson?.optString("code", "RPLSG") ?: "RPLSG",
            titleRu = personalityJson?.optString("title", "Профиль формируется") ?: "Профиль формируется",
            titleUk = personalityJson?.optString("title", "Профіль формується") ?: "Профіль формується",
            titleEn = personalityJson?.optString("title", "Profile forming") ?: "Profile forming",
            socialEnergy = personalityJson?.optInt("social_energy", 50) ?: 50,
            perception = personalityJson?.optInt("perception", 50) ?: 50,
            decisionStyle = personalityJson?.optInt("decision_style", 50) ?: 50,
            lifeRhythm = personalityJson?.optInt("life_rhythm", 50) ?: 50,
            bondStyle = personalityJson?.optInt("bond_style", 50) ?: 50,
        )
        val enneagramType = item.optInt("enneagram_type", 6).coerceIn(1, 9)
        val numerologyJson = item.optJSONObject("numerology")
        val soul = numerologyJson?.optInt("soul_number", 1)?.coerceIn(1, 9) ?: 1
        val destiny = numerologyJson?.optInt("destiny_number", 1)?.coerceIn(1, 9) ?: 1
        val nameNumber = numerologyJson?.let { json -> if (json.has("name_number") && !json.isNull("name_number")) json.optInt("name_number").coerceIn(1, 9) else null }
        val maturity = numerologyJson?.optInt("maturity_number", destiny)?.coerceIn(1, 9) ?: destiny
        val zodiac = runCatching { ZodiacSign.valueOf(item.optString("zodiac", "ARIES")) }.getOrDefault(ZodiacSign.ARIES)
        return FriendCandidate(
            globalId = globalId,
            name = item.getString("name"),
            age = item.optInt("age", 18).coerceAtLeast(18),
            city = item.optString("city", ""),
            distanceKm = item.optInt("distance_km", 0).coerceAtLeast(0),
            compatibility = item.optInt("compatibility", 0).coerceIn(0, 100),
            trustScore = item.optInt("trust_score", 70).coerceIn(0, 100),
            accountRating = item.optInt("account_rating", 0).coerceIn(0, 100),
            interests = item.optJSONArray("interests").toStringList(),
            goals = item.optJSONArray("goals").toStringList(),
            values = item.optJSONArray("values").toStringList(),
            lifestyle = item.optJSONArray("lifestyle").toStringList(),
            explanation = item.optString("explanation", ""),
            assessmentProfileSeed = globalId.value.toInt(),
            personality32 = personality,
            enneagram = EnneagramProfile(
                type = enneagramType,
                wing = null,
                score = 50,
                titleRu = "Эннеатип $enneagramType",
                titleUk = "Еннеатип $enneagramType",
                titleEn = "Enneatype $enneagramType",
            ),
            zodiac = zodiac,
            numerology = VedicNumerologyProfile(
                soulNumber = soul,
                destinyNumber = destiny,
                nameNumber = nameNumber,
                maturityNumber = maturity,
                compatibilityVector = listOf(soul, destiny, maturity).distinct(),
            ),
            friendshipTestScore = item.optInt("friendship_test_score", 0).coerceIn(0, 100),
            commonTestCount = item.optInt("common_tests", 0).coerceIn(0, 100),
            compatibilityRiskFlags = item.optJSONArray("compatibility_risk_flags").toStringList(),
            testCategoryScores = item.optJSONObject("test_category_scores").toIntMap(),
            verified = true,
            online = false,
            serverBacked = true,
        )
    }

    private fun JSONObject?.toIntMap(): Map<String, Int> {
        if (this == null) return emptyMap()
        return buildMap {
            val keys = keys()
            while (keys.hasNext()) {
                val key = keys.next()
                put(key, optInt(key, 0).coerceIn(0, 100))
            }
        }
    }

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        return buildList {
            for (index in 0 until length()) add(optString(index))
        }.filter(String::isNotBlank)
    }
}
