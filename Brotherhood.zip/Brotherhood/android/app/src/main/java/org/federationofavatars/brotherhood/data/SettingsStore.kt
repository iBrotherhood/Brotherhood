package org.federationofavatars.brotherhood.data

import android.content.Context
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AppThemeMode
import org.federationofavatars.brotherhood.model.DiscoveryPreferences
import org.federationofavatars.brotherhood.model.MainTab
import org.federationofavatars.brotherhood.model.ProfileVisibility
import org.federationofavatars.brotherhood.model.DesiredQuality
import org.federationofavatars.brotherhood.model.SearchIntent
import org.federationofavatars.brotherhood.model.SearchRole

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("brotherhood_settings", Context.MODE_PRIVATE)

    fun languageTag(): String = prefs.getString("language", AppLanguage.RU.tag) ?: AppLanguage.RU.tag

    fun theme(): AppThemeMode = runCatching {
        AppThemeMode.valueOf(prefs.getString("theme", AppThemeMode.SYSTEM.name)!!)
    }.getOrDefault(AppThemeMode.SYSTEM)

    fun onboardingComplete(): Boolean = prefs.getBoolean("onboarding_complete", false)
    fun calibrationOptIn(): Boolean = prefs.getBoolean("calibration_opt_in", false)

    fun mainTab(): MainTab = runCatching {
        MainTab.valueOf(prefs.getString("main_tab", MainTab.HOME.name)!!)
    }.getOrDefault(MainTab.HOME)


    fun discoveryPreferences(): DiscoveryPreferences = DiscoveryPreferences(
        verifiedOnly = prefs.getBoolean("discover_verified_only", false),
        onlineOnly = prefs.getBoolean("discover_online_only", false),
        requireSharedInterests = prefs.getBoolean("discover_shared_interests", false),
        hideRequested = prefs.getBoolean("discover_hide_requested", false),
        minTrust = prefs.getInt("discover_min_trust", 0).coerceIn(0, 100),
        minCompatibility = prefs.getInt("discover_min_compatibility", 0).coerceIn(0, 100),
    )


    fun searchIntent(): SearchIntent {
        val role = runCatching { SearchRole.valueOf(prefs.getString("search_role", SearchRole.FRIEND.name)!!) }.getOrDefault(SearchRole.FRIEND)
        val qualities = prefs.getStringSet("search_qualities", emptySet()).orEmpty().mapNotNull { raw ->
            val parts = raw.split(":", limit = 2)
            val importance = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(1, 5) ?: 3
            parts.firstOrNull()?.takeIf(String::isNotBlank)?.let { DesiredQuality(it, importance) }
        }.sortedBy { it.key }
        return SearchIntent(role, qualities)
    }

    fun setSearchIntent(value: SearchIntent) {
        prefs.edit()
            .putString("search_role", value.role.name)
            .putStringSet("search_qualities", value.qualities.map { "${it.key}:${it.importance}" }.toSet())
            .apply()
    }

    fun profileVisibility(): ProfileVisibility = runCatching {
        ProfileVisibility.valueOf(prefs.getString("profile_visibility", ProfileVisibility.DISCOVERABLE.name)!!)
    }.getOrDefault(ProfileVisibility.DISCOVERABLE)

    fun skippedCandidates(): Set<Long> = prefs.getStringSet("discover_skipped", emptySet()).orEmpty()
        .mapNotNull { it.toLongOrNull() }
        .toSet()

    fun setDiscoveryPreferences(value: DiscoveryPreferences) {
        prefs.edit()
            .putBoolean("discover_verified_only", value.verifiedOnly)
            .putBoolean("discover_online_only", value.onlineOnly)
            .putBoolean("discover_shared_interests", value.requireSharedInterests)
            .putBoolean("discover_hide_requested", value.hideRequested)
            .putInt("discover_min_trust", value.minTrust.coerceIn(0, 100))
            .putInt("discover_min_compatibility", value.minCompatibility.coerceIn(0, 100))
            .apply()
    }

    fun setProfileVisibility(value: ProfileVisibility) = prefs.edit().putString("profile_visibility", value.name).apply()
    fun setSkippedCandidates(value: Set<Long>) = prefs.edit().putStringSet("discover_skipped", value.map { it.toString() }.toSet()).apply()

    fun setLanguage(value: AppLanguage) = prefs.edit().putString("language", value.tag).apply()
    fun setTheme(value: AppThemeMode) = prefs.edit().putString("theme", value.name).apply()
    fun setOnboardingComplete(value: Boolean) = prefs.edit().putBoolean("onboarding_complete", value).apply()
    fun setCalibrationOptIn(value: Boolean) = prefs.edit().putBoolean("calibration_opt_in", value).apply()
    fun setMainTab(value: MainTab) = prefs.edit().putString("main_tab", value.name).apply()
}
