package org.federationofavatars.brotherhood.data

import android.content.Context
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AppThemeMode

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("brotherhood_settings", Context.MODE_PRIVATE)

    fun language(): AppLanguage = runCatching {
        AppLanguage.valueOf(prefs.getString("language", AppLanguage.RU.name)!!)
    }.getOrDefault(AppLanguage.RU)

    fun theme(): AppThemeMode = runCatching {
        AppThemeMode.valueOf(prefs.getString("theme", AppThemeMode.SYSTEM.name)!!)
    }.getOrDefault(AppThemeMode.SYSTEM)

    fun onboardingComplete(): Boolean = prefs.getBoolean("onboarding_complete", false)

    fun setLanguage(value: AppLanguage) = prefs.edit().putString("language", value.name).apply()
    fun setTheme(value: AppThemeMode) = prefs.edit().putString("theme", value.name).apply()
    fun setOnboardingComplete(value: Boolean) = prefs.edit().putBoolean("onboarding_complete", value).apply()
}
