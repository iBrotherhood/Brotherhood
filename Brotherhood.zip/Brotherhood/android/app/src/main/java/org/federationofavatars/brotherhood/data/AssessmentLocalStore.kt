package org.federationofavatars.brotherhood.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.DimensionScore
import org.json.JSONArray
import org.json.JSONObject

class AssessmentLocalStore(context: Context) : SQLiteOpenHelper(
    context,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE assessment_results (
                assessment_id TEXT PRIMARY KEY,
                total_score INTEGER NOT NULL,
                risk_score INTEGER NOT NULL,
                label TEXT NOT NULL,
                summary TEXT NOT NULL,
                dimensions_json TEXT NOT NULL,
                answer_consistency INTEGER NOT NULL,
                idealized_self_presentation INTEGER NOT NULL,
                completed_at_epoch_ms INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS assessment_results")
        onCreate(db)
    }

    fun save(result: AssessmentResult) {
        val values = ContentValues().apply {
            put("assessment_id", result.assessmentId)
            put("total_score", result.totalScore)
            put("risk_score", result.riskScore)
            put("label", result.label)
            put("summary", result.summary)
            put("dimensions_json", dimensionsToJson(result.dimensions))
            put("answer_consistency", result.answerConsistency)
            put("idealized_self_presentation", result.idealizedSelfPresentation)
            put("completed_at_epoch_ms", result.completedAtEpochMs)
        }
        writableDatabase.insertWithOnConflict(
            "assessment_results",
            null,
            values,
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun loadAll(): Map<String, AssessmentResult> {
        val result = linkedMapOf<String, AssessmentResult>()
        readableDatabase.query(
            "assessment_results",
            null,
            null,
            null,
            null,
            null,
            "completed_at_epoch_ms DESC"
        ).use { cursor ->
            val assessmentIdIndex = cursor.getColumnIndexOrThrow("assessment_id")
            val totalIndex = cursor.getColumnIndexOrThrow("total_score")
            val riskIndex = cursor.getColumnIndexOrThrow("risk_score")
            val labelIndex = cursor.getColumnIndexOrThrow("label")
            val summaryIndex = cursor.getColumnIndexOrThrow("summary")
            val dimensionsIndex = cursor.getColumnIndexOrThrow("dimensions_json")
            val consistencyIndex = cursor.getColumnIndexOrThrow("answer_consistency")
            val idealizedIndex = cursor.getColumnIndexOrThrow("idealized_self_presentation")
            val completedIndex = cursor.getColumnIndexOrThrow("completed_at_epoch_ms")
            while (cursor.moveToNext()) {
                val item = AssessmentResult(
                    assessmentId = cursor.getString(assessmentIdIndex),
                    totalScore = cursor.getInt(totalIndex),
                    riskScore = cursor.getInt(riskIndex),
                    label = cursor.getString(labelIndex),
                    summary = cursor.getString(summaryIndex),
                    dimensions = dimensionsFromJson(cursor.getString(dimensionsIndex)),
                    answerConsistency = cursor.getInt(consistencyIndex),
                    idealizedSelfPresentation = cursor.getInt(idealizedIndex),
                    completedAtEpochMs = cursor.getLong(completedIndex)
                )
                result[item.assessmentId] = item
            }
        }
        return result
    }

    private fun dimensionsToJson(dimensions: List<DimensionScore>): String {
        val array = JSONArray()
        dimensions.forEach { dimension ->
            array.put(
                JSONObject()
                    .put("id", dimension.id)
                    .put("title", dimension.title)
                    .put("score", dimension.score)
            )
        }
        return array.toString()
    }

    private fun dimensionsFromJson(raw: String): List<DimensionScore> {
        val array = JSONArray(raw)
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    DimensionScore(
                        id = item.getString("id"),
                        title = item.getString("title"),
                        score = item.getInt("score")
                    )
                )
            }
        }
    }

    companion object {
        private const val DATABASE_NAME = "brotherhood_local.db"
        private const val DATABASE_VERSION = 2
    }
}
