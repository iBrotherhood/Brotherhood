package org.federationofavatars.brotherhood.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.AssessmentResponseTrace
import org.federationofavatars.brotherhood.model.AssessmentModelVersions
import org.federationofavatars.brotherhood.model.DimensionScore
import org.json.JSONArray
import org.json.JSONObject

class AssessmentLocalStore(context: Context) : SQLiteOpenHelper(
    context,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE assessment_results (
                assessment_id TEXT PRIMARY KEY,
                model_version TEXT NOT NULL,
                stimulus_version TEXT NOT NULL,
                started_at_epoch_ms INTEGER NOT NULL,
                total_score INTEGER NOT NULL,
                risk_score INTEGER NOT NULL,
                label TEXT NOT NULL,
                summary TEXT NOT NULL,
                dimensions_json TEXT NOT NULL,
                answer_consistency INTEGER NOT NULL,
                response_trace_json TEXT NOT NULL,
                idealized_self_presentation INTEGER NOT NULL,
                completed_at_epoch_ms INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 3) {
            // Preserve historical completion rows but explicitly quarantine all pre-visual scores.
            db.execSQL(
                "ALTER TABLE assessment_results ADD COLUMN model_version TEXT NOT NULL DEFAULT 'legacy-direct-v1'"
            )
        }
        if (oldVersion < 4) {
            // visual-latent-v1 remains historical. v2 stores exact stimulus provenance and internal
            // item-level response trace required for empirical calibration.
            db.execSQL("ALTER TABLE assessment_results ADD COLUMN stimulus_version TEXT NOT NULL DEFAULT 'legacy-stimulus'")
            db.execSQL("ALTER TABLE assessment_results ADD COLUMN response_trace_json TEXT NOT NULL DEFAULT '[]'")
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE assessment_results ADD COLUMN started_at_epoch_ms INTEGER NOT NULL DEFAULT 0")
        }
    }

    fun save(result: AssessmentResult) {
        val values = ContentValues().apply {
            put("assessment_id", result.assessmentId)
            put("model_version", result.modelVersion)
            put("stimulus_version", result.stimulusVersion)
            put("started_at_epoch_ms", result.startedAtEpochMs)
            put("total_score", result.totalScore)
            put("risk_score", result.riskScore)
            put("label", result.label)
            put("summary", result.summary)
            put("dimensions_json", dimensionsToJson(result.dimensions))
            put("answer_consistency", result.answerConsistency)
            put("response_trace_json", responseTraceToJson(result.responseTrace))
            put("idealized_self_presentation", result.idealizedSelfPresentation)
            put("completed_at_epoch_ms", result.completedAtEpochMs)
        }
        writableDatabase.insertWithOnConflict(
            "assessment_results",
            null,
            values,
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun loadAll(): Map<String, AssessmentResult> {
        val result = linkedMapOf<String, AssessmentResult>()
        readableDatabase.query(
            "assessment_results",
            null,
            "model_version = ?",
            arrayOf(AssessmentModelVersions.ACTIVE),
            null,
            null,
            "completed_at_epoch_ms DESC"
        ).use { cursor ->
            val assessmentIdIndex = cursor.getColumnIndexOrThrow("assessment_id")
            val modelVersionIndex = cursor.getColumnIndexOrThrow("model_version")
            val stimulusVersionIndex = cursor.getColumnIndexOrThrow("stimulus_version")
            val startedAtIndex = cursor.getColumnIndexOrThrow("started_at_epoch_ms")
            val totalIndex = cursor.getColumnIndexOrThrow("total_score")
            val riskIndex = cursor.getColumnIndexOrThrow("risk_score")
            val labelIndex = cursor.getColumnIndexOrThrow("label")
            val summaryIndex = cursor.getColumnIndexOrThrow("summary")
            val dimensionsIndex = cursor.getColumnIndexOrThrow("dimensions_json")
            val consistencyIndex = cursor.getColumnIndexOrThrow("answer_consistency")
            val responseTraceIndex = cursor.getColumnIndexOrThrow("response_trace_json")
            val idealizedIndex = cursor.getColumnIndexOrThrow("idealized_self_presentation")
            val completedIndex = cursor.getColumnIndexOrThrow("completed_at_epoch_ms")
            while (cursor.moveToNext()) {
                val item = AssessmentResult(
                    assessmentId = cursor.getString(assessmentIdIndex),
                    modelVersion = cursor.getString(modelVersionIndex),
                    stimulusVersion = cursor.getString(stimulusVersionIndex),
                    startedAtEpochMs = cursor.getLong(startedAtIndex).takeIf { it > 0 } ?: cursor.getLong(completedIndex),
                    totalScore = cursor.getInt(totalIndex),
                    riskScore = cursor.getInt(riskIndex),
                    label = cursor.getString(labelIndex),
                    summary = cursor.getString(summaryIndex),
                    dimensions = dimensionsFromJson(cursor.getString(dimensionsIndex)),
                    answerConsistency = cursor.getInt(consistencyIndex),
                    responseTrace = responseTraceFromJson(cursor.getString(responseTraceIndex)),
                    idealizedSelfPresentation = cursor.getInt(idealizedIndex),
                    completedAtEpochMs = cursor.getLong(completedIndex)
                )
                result[item.assessmentId] = item
            }
        }
        return result
    }


    private fun responseTraceToJson(rows: List<AssessmentResponseTrace>): String {
        val array = JSONArray()
        rows.forEach { row ->
            array.put(
                JSONObject()
                    .put("question_id", row.questionId)
                    .put("choice_id", row.choiceId)
                    .put("paradigm", row.paradigm)
                    .put("scene_archetype", row.sceneArchetype)
                    .put("stimulus_version", row.stimulusVersion)
                    .put("visual_seed", row.visualSeed)
                    .put("composition_variant", row.compositionVariant)
                    .put("intensity", row.intensity)
                    .put("spacing", row.spacing)
                    .put("order", row.order)
                    .put("asymmetry", row.asymmetry)
                    .put("direction", row.direction)
                    .put("presentation_slot", row.presentationSlot)
                    .put("response_latency_ms", row.responseLatencyMs)
                    .put("selection_changes", row.selectionChanges)
                    .put("question_position", row.questionPosition)
            )
        }
        return array.toString()
    }

    private fun responseTraceFromJson(raw: String): List<AssessmentResponseTrace> {
        val array = JSONArray(raw)
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    AssessmentResponseTrace(
                        questionId = item.getString("question_id"),
                        choiceId = item.getString("choice_id"),
                        paradigm = item.getString("paradigm"),
                        sceneArchetype = item.getString("scene_archetype"),
                        stimulusVersion = item.getString("stimulus_version"),
                        visualSeed = item.getInt("visual_seed"),
                        compositionVariant = item.optInt("composition_variant", 0).coerceIn(0, 7),
                        intensity = item.getInt("intensity"),
                        spacing = item.getInt("spacing"),
                        order = item.getInt("order"),
                        asymmetry = item.getInt("asymmetry"),
                        direction = item.getInt("direction"),
                        presentationSlot = item.optInt("presentation_slot", 1).coerceIn(1, 4),
                        responseLatencyMs = item.optLong("response_latency_ms", 0L).coerceIn(0L, 600_000L),
                        selectionChanges = item.optInt("selection_changes", 0).coerceIn(0, 20),
                        questionPosition = item.optInt("question_position", index + 1).coerceIn(1, 6),
                    )
                )
            }
        }
    }

    private fun dimensionsToJson(dimensions: List<DimensionScore>): String {
        val array = JSONArray()
        dimensions.forEach { dimension ->
            array.put(
                JSONObject()
                    .put("id", dimension.id)
                    .put("title", dimension.title)
                    .put("score", dimension.score)
            )
        }
        return array.toString()
    }

    private fun dimensionsFromJson(raw: String): List<DimensionScore> {
        val array = JSONArray(raw)
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    DimensionScore(
                        id = item.getString("id"),
                        title = item.getString("title"),
                        score = item.getInt("score")
                    )
                )
            }
        }
    }

    companion object {
        private const val DATABASE_NAME = "brotherhood_local.db"
        private const val DATABASE_VERSION = 5
    }
}
