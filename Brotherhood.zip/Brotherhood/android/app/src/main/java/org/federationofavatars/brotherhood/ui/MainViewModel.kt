package org.federationofavatars.brotherhood.ui

import android.app.Application
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.time.LocalDate
import java.time.Period
import kotlin.math.abs
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.federationofavatars.brotherhood.BuildConfig
import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.data.AssessmentLocalStore
import org.federationofavatars.brotherhood.data.CoreProfileCatalog
import org.federationofavatars.brotherhood.data.CoreProfileQuestion
import org.federationofavatars.brotherhood.data.DemoRepository
import org.federationofavatars.brotherhood.data.SettingsStore
import org.federationofavatars.brotherhood.data.ProfileLocalStore
import org.federationofavatars.brotherhood.domain.AccountRatingCalculator
import org.federationofavatars.brotherhood.domain.AssessmentScorer
import org.federationofavatars.brotherhood.domain.CrossTestIntegrityAnalyzer
import org.federationofavatars.brotherhood.domain.FriendshipCompatibilityEngine
import org.federationofavatars.brotherhood.domain.HybridCompatibilityEngine
import org.federationofavatars.brotherhood.domain.VedicNumerologyEngine
import org.federationofavatars.brotherhood.domain.SelfAnalysisEngine
import org.federationofavatars.brotherhood.crypto.PrivateChatCrypto
import org.federationofavatars.brotherhood.domain.ZodiacEngine
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AppRoute
import org.federationofavatars.brotherhood.model.AppThemeMode
import org.federationofavatars.brotherhood.model.AssessmentDefinition
import org.federationofavatars.brotherhood.model.AssessmentKind
import org.federationofavatars.brotherhood.model.AssessmentQuestion
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.AuthProvider
import org.federationofavatars.brotherhood.model.Community
import org.federationofavatars.brotherhood.model.AppUpdateInfo
import org.federationofavatars.brotherhood.model.ChatEncryptionMode
import org.federationofavatars.brotherhood.model.ChatMessage
import org.federationofavatars.brotherhood.model.ChatAttachment
import org.federationofavatars.brotherhood.model.ConversationKind
import org.federationofavatars.brotherhood.model.ConversationSummaryModel
import org.federationofavatars.brotherhood.model.PendingChatAttachment
import org.federationofavatars.brotherhood.model.CommunityKind
import org.federationofavatars.brotherhood.model.CompatibilityBreakdown
import org.federationofavatars.brotherhood.model.DiscoveryPreferences
import org.federationofavatars.brotherhood.model.FriendCandidate
import org.federationofavatars.brotherhood.model.GlobalId
import org.federationofavatars.brotherhood.model.GroupMember
import org.federationofavatars.brotherhood.model.MainTab
import org.federationofavatars.brotherhood.model.ProfileVisibility
import org.federationofavatars.brotherhood.network.RemoteDataRepository
import org.federationofavatars.brotherhood.network.ChatRemoteRepository

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val assessmentStore = AssessmentLocalStore(application)
    private val settingsStore = SettingsStore(application)
    private val profileStore = ProfileLocalStore(application)
    private val initialProfile = profileStore.load(DemoRepository.profile)
    private val remoteRepository = RemoteDataRepository(application)
    private val chatRepository = ChatRemoteRepository(application)
    private val privateChatCrypto by lazy { PrivateChatCrypto(application, profile.globalId) }
    private val sessionAccessToken = if (BuildConfig.DEBUG) "debug-local-session" else ""

    var route by mutableStateOf(AppRoute.AUTH)
        private set
    var selectedTab by mutableStateOf(settingsStore.mainTab())
        private set
    var language by mutableStateOf(settingsStore.language())
        private set
    var themeMode by mutableStateOf(settingsStore.theme())
        private set
    var authProvider by mutableStateOf<AuthProvider?>(null)
        private set
    var selectedCity by mutableStateOf(initialProfile.city)
        private set
    var radiusKm by mutableIntStateOf(25)
        private set
    var discoveryPreferences by mutableStateOf(settingsStore.discoveryPreferences())
        private set
    var profileVisibility by mutableStateOf(settingsStore.profileVisibility())
        private set
    var skippedCandidateIds by mutableStateOf(settingsStore.skippedCandidates())
        private set
    var lastSkippedCandidateId by mutableStateOf<Long?>(null)
        private set
    var communityKind by mutableStateOf(CommunityKind.INTEREST)
        private set
    var selectedAssessmentKind by mutableStateOf<AssessmentKind?>(null)
        private set
    var locationStatus by mutableStateOf<String?>(null)
        private set
    var selectedCandidateId by mutableStateOf<Long?>(null)
        private set
    var selectedCommunityId by mutableStateOf<String?>(null)
        private set
    var joinedCommunityIds by mutableStateOf<Set<String>>(emptySet())
        private set
    var connectionRequests by mutableStateOf<Set<Long>>(emptySet())
        private set
    var uiMessage by mutableStateOf<String?>(null)
        private set

    var remotePeople by mutableStateOf<List<FriendCandidate>>(emptyList())
        private set
    var remoteCommunities by mutableStateOf<List<Community>>(emptyList())
        private set
    var remoteLoading by mutableStateOf(false)
        private set
    var remoteStatus by mutableStateOf<String?>(null)
        private set

    var conversations by mutableStateOf<List<ConversationSummaryModel>>(emptyList())
        private set
    var activeConversation by mutableStateOf<ConversationSummaryModel?>(null)
        private set
    var chatMessages by mutableStateOf<List<ChatMessage>>(emptyList())
        private set
    var chatLoading by mutableStateOf(false)
        private set
    var chatSecurityFingerprint by mutableStateOf<String?>(null)
        private set
    var peerChatFingerprint by mutableStateOf<String?>(null)
        private set
    var appUpdateInfo by mutableStateOf<AppUpdateInfo?>(null)
        private set
    var replyToMessage by mutableStateOf<ChatMessage?>(null)
        private set
    var editingMessage by mutableStateOf<ChatMessage?>(null)
        private set
    var typingGlobalIds by mutableStateOf<List<GlobalId>>(emptyList())
        private set
    var activePeerBlockedByMe by mutableStateOf(false)
        private set
    var activeGroupMembers by mutableStateOf<List<GroupMember>>(emptyList())
        private set

    private var typingStopJob: Job? = null
    private var typingActiveSent = false

    var activeAssessmentId by mutableStateOf<String?>(null)
        private set
    var currentQuestionIndex by mutableIntStateOf(0)
        private set
    var assessmentAnswers by mutableStateOf<Map<String, Int>>(emptyMap())
        private set
    var currentResult by mutableStateOf<AssessmentResult?>(null)
        private set
    var completedResults by mutableStateOf(assessmentStore.loadAll())
        private set

    var activeCoreModule by mutableStateOf<String?>(null)
        private set
    var coreQuestionIndex by mutableIntStateOf(0)
        private set
    var coreAnswers by mutableStateOf<Map<String, Int>>(emptyMap())
        private set

    val cities = DemoRepository.cities
    val assessmentDefinitions: List<AssessmentDefinition>
        get() = selectedAssessmentKind?.let { AssessmentCatalog.byCategory[it].orEmpty() } ?: AssessmentCatalog.assessments
    val assessmentKinds = AssessmentKind.entries
    val trustEvents = DemoRepository.trustEvents
    var profile by mutableStateOf(initialProfile)
        private set

    val accountRating
        get() = AccountRatingCalculator.calculate(profile.completedProfileSections, completedResults.keys)

    val integrityScreening
        get() = CrossTestIntegrityAnalyzer.analyze(completedResults)

    val selfAnalysis
        get() = SelfAnalysisEngine.build(profile, completedResults, language)

    private val myAssessmentScores: Map<String, Int>
        get() = completedResults.mapValues { it.value.totalScore }

    val candidates: List<FriendCandidate>
        get() {
            val source = if (remotePeople.isNotEmpty()) remotePeople else if (BuildConfig.DEBUG) DemoRepository.people else emptyList()
            return source.filter {
                it.city == selectedCity && it.distanceKm <= radiusKm
            }.map { candidate ->
                if (candidate.serverBacked) {
                    val hybrid = HybridCompatibilityEngine.calculate(
                        me = profile,
                        candidate = candidate,
                        friendshipTests = candidate.friendshipTestScore,
                        sharedTestCount = candidate.commonTestCount
                    )
                    val cappedTotal = if (candidate.compatibilityRiskFlags.isEmpty()) hybrid.total else minOf(hybrid.total, 64)
                    candidate.copy(
                        compatibility = cappedTotal,
                        explanation = candidate.explanation + if (candidate.compatibilityRiskFlags.isEmpty()) "" else " Риски: ${candidate.compatibilityRiskFlags.joinToString()}."
                    )
                } else {
                    val candidateScores = AssessmentCatalog.assessments.associate { definition ->
                        definition.id to demoCandidateScore(candidate.assessmentProfileSeed, definition.id, definition.safetyCritical)
                    }
                    val interestPercent = overlap(profile.interests, candidate.interests)
                    val testResult = FriendshipCompatibilityEngine.calculate(
                        myScores = myAssessmentScores,
                        candidateScores = candidateScores,
                        sharedInterestPercent = interestPercent,
                        trustScore = candidate.trustScore
                    )
                    val hybrid = HybridCompatibilityEngine.calculate(
                        me = profile,
                        candidate = candidate,
                        friendshipTests = testResult.testsScore,
                        sharedTestCount = testResult.commonTests,
                        testCategoryScores = testResult.categoryScores
                    )
                    candidate.copy(
                        compatibility = hybrid.total,
                        explanation = candidate.explanation + if (testResult.riskFlags.isEmpty()) "" else " Риски: ${testResult.riskFlags.joinToString()}."
                    )
                }
            }.filter { candidate ->
                candidate.globalId.value !in skippedCandidateIds &&
                    (!discoveryPreferences.verifiedOnly || candidate.verified) &&
                    (!discoveryPreferences.onlineOnly || candidate.online) &&
                    candidate.trustScore >= discoveryPreferences.minTrust &&
                    candidate.compatibility >= discoveryPreferences.minCompatibility &&
                    (!discoveryPreferences.requireSharedInterests || overlap(profile.interests, candidate.interests) > 0) &&
                    (!discoveryPreferences.hideRequested || candidate.globalId.value !in connectionRequests)
            }.sortedByDescending(FriendCandidate::compatibility)
        }

    val selectedCandidate: FriendCandidate?
        get() = selectedCandidateId?.let { id -> candidates.firstOrNull { it.globalId.value == id } ?: if (BuildConfig.DEBUG) DemoRepository.people.firstOrNull { it.globalId.value == id } else null }

    fun compatibility(candidate: FriendCandidate): CompatibilityBreakdown {
        if (candidate.serverBacked) {
            val localBreakdown = HybridCompatibilityEngine.calculate(
                profile, candidate, candidate.friendshipTestScore, candidate.commonTestCount
            )
            return if (candidate.compatibilityRiskFlags.isEmpty()) localBreakdown else localBreakdown.copy(total = minOf(localBreakdown.total, 64))
        }
        val candidateScores = AssessmentCatalog.assessments.associate { definition ->
            definition.id to demoCandidateScore(candidate.assessmentProfileSeed, definition.id, definition.safetyCritical)
        }
        val testResult = FriendshipCompatibilityEngine.calculate(
            myScores = myAssessmentScores,
            candidateScores = candidateScores,
            sharedInterestPercent = overlap(profile.interests, candidate.interests),
            trustScore = candidate.trustScore
        )
        return HybridCompatibilityEngine.calculate(
            profile, candidate, testResult.testsScore, testResult.commonTests, testResult.categoryScores
        )
    }

    val communities: List<Community>
        get() {
            val source = if (remoteCommunities.isNotEmpty()) remoteCommunities else if (BuildConfig.DEBUG) DemoRepository.communities else emptyList()
            return source.filter {
                it.kind == communityKind && (it.city == selectedCity || it.online)
            }.map { it.copy(joined = it.id in joinedCommunityIds) }
        }

    val selectedCommunity: Community?
        get() = selectedCommunityId?.let { id -> communities.firstOrNull { it.id == id } ?: if (BuildConfig.DEBUG) DemoRepository.communities.firstOrNull { it.id == id }?.copy(joined = id in joinedCommunityIds) else null }

    val activeAssessment: AssessmentDefinition?
        get() = activeAssessmentId?.let(AssessmentCatalog::byId)

    val currentQuestion: AssessmentQuestion?
        get() = activeAssessment?.questions?.getOrNull(currentQuestionIndex)

    val coreQuestions: List<CoreProfileQuestion>
        get() = when (activeCoreModule) {
            "p32" -> CoreProfileCatalog.personality32Questions
            "enneagram" -> CoreProfileCatalog.enneagramQuestions
            else -> emptyList()
        }

    val currentCoreQuestion: CoreProfileQuestion?
        get() = coreQuestions.getOrNull(coreQuestionIndex)

    val canFinishCoreAssessment: Boolean
        get() = coreQuestions.isNotEmpty() && coreQuestions.all { coreAnswers[it.id] in 1..5 }

    val canFinishAssessment: Boolean
        get() = activeAssessment?.questions?.all { assessmentAnswers[it.id] in 1..5 } == true

    fun signIn(provider: AuthProvider) {
        if (!BuildConfig.DEBUG) {
            uiMessage = when (language) {
                AppLanguage.RU -> "Production-вход требует настроенного OAuth/Telegram провайдера на Vercel."
                AppLanguage.UK -> "Production-вхід потребує налаштованого OAuth/Telegram провайдера на Vercel."
                AppLanguage.EN -> "Production sign-in requires a configured OAuth/Telegram provider on Vercel."
            }
            return
        }
        authProvider = provider
        settingsStore.setOnboardingComplete(true)
        route = AppRoute.HOME
        refreshRemoteData()
    }

    fun signOut() {
        authProvider = null
        route = AppRoute.AUTH
    }

    fun selectTab(tab: MainTab) { selectedTab = tab; settingsStore.setMainTab(tab); route = AppRoute.HOME }
    fun selectCity(city: String) { selectedCity = city; locationStatus = when (language) { AppLanguage.RU -> "Город выбран: $city"; AppLanguage.UK -> "Місто обрано: $city"; AppLanguage.EN -> "City selected: $city" }; refreshRemoteData() }
    fun setRadius(value: Int) { radiusKm = value; refreshRemoteData() }
    fun openDiscoveryFilters() { route = AppRoute.DISCOVERY_FILTERS }
    fun updateDiscoveryPreferences(value: DiscoveryPreferences) {
        discoveryPreferences = value.copy(
            minTrust = value.minTrust.coerceIn(0, 100),
            minCompatibility = value.minCompatibility.coerceIn(0, 100),
        )
        settingsStore.setDiscoveryPreferences(discoveryPreferences)
    }
    fun setProfileVisibility(value: ProfileVisibility) {
        profileVisibility = value
        settingsStore.setProfileVisibility(value)
        syncSharedProfile()
    }

    private fun syncSharedProfile() {
        if (sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            val sent = runCatching {
                remoteRepository.syncProfile(profile, language, sessionAccessToken, profileVisibility)
            }.getOrDefault(false)
            remoteStatus = if (sent) "profile_visibility_synced" else "profile_visibility_queued"
        }
    }
    fun skipCandidate(candidate: FriendCandidate) {
        lastSkippedCandidateId = candidate.globalId.value
        skippedCandidateIds = skippedCandidateIds + candidate.globalId.value
        settingsStore.setSkippedCandidates(skippedCandidateIds)
    }
    fun undoLastSkip() {
        val id = lastSkippedCandidateId ?: return
        skippedCandidateIds = skippedCandidateIds - id
        settingsStore.setSkippedCandidates(skippedCandidateIds)
        lastSkippedCandidateId = null
    }
    fun resetSkippedCandidates() {
        skippedCandidateIds = emptySet()
        lastSkippedCandidateId = null
        settingsStore.setSkippedCandidates(emptySet())
    }
    fun selectCommunityKind(kind: CommunityKind) { communityKind = kind; refreshRemoteData() }
    fun selectAssessmentKind(kind: AssessmentKind?) { selectedAssessmentKind = kind }
    fun reportLocationFailure() { locationStatus = when (language) { AppLanguage.RU -> "Не удалось определить город. Выберите его вручную."; AppLanguage.UK -> "Не вдалося визначити місто. Оберіть його вручну."; AppLanguage.EN -> "Could not determine the city. Choose it manually." } }
    fun openSettings() { route = AppRoute.SETTINGS; checkForUpdates() }
    fun openServices() { route = AppRoute.SERVICES }
    fun openMessages() { route = AppRoute.MESSAGES; refreshConversations() }
    fun openSelfAnalysis() { route = AppRoute.SELF_ANALYSIS }
    fun openTests() { route = AppRoute.TESTS }
    fun openTrust() { route = AppRoute.TRUST }
    fun openBusinessCommunities() { communityKind = CommunityKind.BUSINESS; selectedTab = MainTab.COMMUNITIES; settingsStore.setMainTab(MainTab.COMMUNITIES); route = AppRoute.HOME }
    fun closeOverlay() { activeConversation = null; chatMessages = emptyList(); route = AppRoute.HOME }
    fun editProfile() { route = AppRoute.EDIT_PROFILE }

    fun openCandidate(candidate: FriendCandidate) {
        selectedCandidateId = candidate.globalId.value
        route = AppRoute.CANDIDATE
    }

    fun requestConnection(candidate: FriendCandidate) {
        connectionRequests = connectionRequests + candidate.globalId.value
    }

    fun showMessage(message: String) { uiMessage = message }
    fun consumeMessage() { uiMessage = null }

    fun openCommunity(community: Community) {
        selectedCommunityId = community.id
        route = AppRoute.COMMUNITY
    }

    fun toggleCommunityMembership(community: Community) {
        joinedCommunityIds = if (community.id in joinedCommunityIds) joinedCommunityIds - community.id else joinedCommunityIds + community.id
    }

    fun refreshConversations() {
        if (sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            chatLoading = true
            runCatching {
                val local = privateChatCrypto.localPublicBundle()
                chatRepository.registerDeviceKey(profile.globalId, local, sessionAccessToken)
                chatSecurityFingerprint = privateChatCrypto.fingerprint()
                chatRepository.flushOutbox(sessionAccessToken)
                conversations = chatRepository.conversations(sessionAccessToken)
            }.onFailure { remoteStatus = "chat_offline" }
            chatLoading = false
        }
    }

    fun openDirectChat(candidate: FriendCandidate) {
        if (sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            chatLoading = true
            runCatching {
                val local = privateChatCrypto.localPublicBundle()
                chatRepository.registerDeviceKey(profile.globalId, local, sessionAccessToken)
                chatSecurityFingerprint = privateChatCrypto.fingerprint()
                val conversation = chatRepository.openDirect(candidate.globalId, sessionAccessToken)
                activePeerBlockedByMe = chatRepository.peerBlockedByMe(candidate.globalId, sessionAccessToken)
                val peerKey = chatRepository.peerDeviceKeys(candidate.globalId, sessionAccessToken).firstOrNull()
                peerChatFingerprint = peerKey?.takeIf(privateChatCrypto::verifyAndPinPeer)?.let(privateChatCrypto::peerFingerprint)
                activeConversation = conversation
                route = AppRoute.CHAT
                activeGroupMembers = emptyList()
                refreshActiveChat()
            }.onFailure { uiMessage = it.message ?: "Не удалось открыть защищённый чат" }
            chatLoading = false
        }
    }

    fun openConversation(conversation: ConversationSummaryModel) {
        activeConversation = conversation
        replyToMessage = null
        editingMessage = null
        typingGlobalIds = emptyList()
        peerChatFingerprint = null
        activePeerBlockedByMe = false
        activeGroupMembers = emptyList()
        route = AppRoute.CHAT
        if (conversation.kind == ConversationKind.GROUP && sessionAccessToken.isNotBlank()) {
            refreshActiveGroupMembers()
        }
        if (conversation.encryptionMode == ChatEncryptionMode.E2EE && conversation.peerGlobalId != null && sessionAccessToken.isNotBlank()) {
            viewModelScope.launch {
                activePeerBlockedByMe = runCatching { chatRepository.peerBlockedByMe(conversation.peerGlobalId, sessionAccessToken) }.getOrDefault(false)
                val peerKey = runCatching { chatRepository.peerDeviceKeys(conversation.peerGlobalId, sessionAccessToken).firstOrNull() }.getOrNull()
                peerChatFingerprint = peerKey?.takeIf(privateChatCrypto::verifyAndPinPeer)?.let(privateChatCrypto::peerFingerprint)
            }
        }
        refreshActiveChat()
    }

    fun createGroupChat(title: String, members: List<GlobalId>) {
        if (sessionAccessToken.isBlank() || title.isBlank()) return
        viewModelScope.launch {
            runCatching {
                val conversation = chatRepository.createGroup(title.trim(), members, sessionAccessToken)
                conversations = (listOf(conversation) + conversations).distinctBy { it.id }
                activeConversation = conversation
                route = AppRoute.CHAT
                activeGroupMembers = emptyList()
                refreshActiveGroupMembers()
                refreshActiveChat()
            }.onFailure { uiMessage = it.message ?: "Не удалось создать группу" }
        }
    }

    fun refreshActiveGroupMembers() {
        val conversation = activeConversation ?: return
        if (conversation.kind != ConversationKind.GROUP || sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            runCatching { chatRepository.groupMembers(conversation.id, sessionAccessToken) }
                .onSuccess { activeGroupMembers = it }
        }
    }

    fun addActiveGroupMember(member: GlobalId) {
        val conversation = activeConversation ?: return
        if (conversation.kind != ConversationKind.GROUP || sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            runCatching { chatRepository.addGroupMember(conversation.id, member, sessionAccessToken) }
                .onSuccess { activeGroupMembers = it; refreshConversations() }
                .onFailure { uiMessage = it.message ?: "Не удалось добавить участника" }
        }
    }

    fun removeActiveGroupMember(member: GlobalId) {
        val conversation = activeConversation ?: return
        if (conversation.kind != ConversationKind.GROUP || sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            runCatching { chatRepository.removeGroupMember(conversation.id, member, sessionAccessToken) }
                .onSuccess { activeGroupMembers = it; refreshConversations() }
                .onFailure { uiMessage = it.message ?: "Не удалось удалить участника" }
        }
    }

    fun refreshActiveChat() {
        val conversation = activeConversation ?: return
        if (sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            runCatching {
                val raw = chatRepository.messages(conversation.id, sessionAccessToken)
                val decrypted = if (conversation.encryptionMode == ChatEncryptionMode.E2EE) {
                    raw.map { message ->
                        if (message.ciphertextB64 == null || message.nonceB64 == null || message.ratchetCounter == null) message
                        else runCatching {
                            message.copy(decryptedBody = privateChatCrypto.decrypt(
                                conversationId = conversation.id,
                                senderGlobalId = message.senderGlobalId,
                                ciphertextB64 = message.ciphertextB64,
                                nonceB64 = message.nonceB64,
                                counter = message.ratchetCounter,
                                senderEphemeralPublicKeyB64 = message.senderEphemeralPublicKeyB64,
                                recipientPrekeyId = message.recipientPrekeyId,
                            ))
                        }.getOrElse { message.copy(decryptedBody = "🔒 Не удалось расшифровать на этом устройстве") }
                    }
                } else raw
                chatMessages = foldEditEvents(decrypted)
                typingGlobalIds = runCatching { chatRepository.typingUsers(conversation.id, sessionAccessToken) }.getOrDefault(emptyList())
                chatMessages.lastOrNull()?.let { chatRepository.markRead(conversation.id, it.id, sessionAccessToken) }
            }.onFailure { remoteStatus = "chat_cached_or_offline" }
        }
    }

    private fun foldEditEvents(messages: List<ChatMessage>): List<ChatMessage> {
        val visible = mutableListOf<ChatMessage>()
        messages.sortedBy { it.createdAtEpochMs }.forEach { message ->
            if (message.status == "deleted") {
                return@forEach
            }
            if (message.messageType == "edit" && message.replyToMessageId != null) {
                val index = visible.indexOfFirst { it.id == message.replyToMessageId }
                if (index >= 0) {
                    val original = visible[index]
                    visible[index] = original.copy(
                        body = message.body ?: original.body,
                        decryptedBody = message.decryptedBody ?: message.body ?: original.decryptedBody,
                        editedAtEpochMs = message.editedAtEpochMs ?: message.createdAtEpochMs,
                    )
                }
            } else {
                visible += message
            }
        }
        return visible
    }

    fun openAttachment(message: ChatMessage, attachment: ChatAttachment) {
        if (sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            runCatching {
                val (mode, payload) = chatRepository.attachmentData(attachment.id, sessionAccessToken)
                val bytes = if (mode == ChatEncryptionMode.E2EE) {
                    val counter = requireNotNull(message.ratchetCounter) { "Missing E2EE message counter" }
                    val nonce = requireNotNull(attachment.nonceB64) { "Missing E2EE attachment nonce" }
                    privateChatCrypto.decryptAttachment(
                        conversationId = message.conversationId,
                        senderGlobalId = message.senderGlobalId,
                        counter = counter,
                        clientAttachmentId = attachment.clientAttachmentId,
                        nonceB64 = nonce,
                        ciphertextB64 = android.util.Base64.encodeToString(payload, android.util.Base64.NO_WRAP),
                    )
                } else payload
                val safeName = attachment.fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "attachment" }
                val directory = File(getApplication<Application>().cacheDir, "chat-attachments").apply { mkdirs() }
                val file = File(directory, "${attachment.id.take(8)}-$safeName")
                file.writeBytes(bytes)
                val uri = FileProvider.getUriForFile(
                    getApplication(),
                    "${BuildConfig.APPLICATION_ID}.files",
                    file,
                )
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, attachment.mimeType)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                getApplication<Application>().startActivity(intent)
            }.onFailure { error ->
                uiMessage = when (language) {
                    AppLanguage.RU -> "Не удалось открыть вложение: ${error.message ?: "ошибка"}"
                    AppLanguage.UK -> "Не вдалося відкрити вкладення: ${error.message ?: "помилка"}"
                    AppLanguage.EN -> "Could not open attachment: ${error.message ?: "error"}"
                }
            }
        }
    }

    fun replyTo(message: ChatMessage) {
        if (message.messageType == "edit") return
        editingMessage = null
        replyToMessage = message
    }

    fun clearReply() { replyToMessage = null }

    fun startEditing(message: ChatMessage) {
        if (message.senderGlobalId != profile.globalId || message.attachments.isNotEmpty()) return
        replyToMessage = null
        editingMessage = message
    }

    fun cancelEditing() { editingMessage = null }

    fun onChatDraftChanged(hasText: Boolean) {
        val conversation = activeConversation ?: return
        if (sessionAccessToken.isBlank()) return
        typingStopJob?.cancel()
        if (!hasText) {
            if (typingActiveSent) {
                typingActiveSent = false
                viewModelScope.launch { runCatching { chatRepository.setTyping(conversation.id, false, sessionAccessToken) } }
            }
            return
        }
        if (!typingActiveSent) {
            typingActiveSent = true
            viewModelScope.launch { runCatching { chatRepository.setTyping(conversation.id, true, sessionAccessToken) } }
        }
        typingStopJob = viewModelScope.launch {
            delay(2_500)
            typingActiveSent = false
            runCatching { chatRepository.setTyping(conversation.id, false, sessionAccessToken) }
        }
    }

    fun sendChatMessage(text: String, attachments: List<PendingChatAttachment> = emptyList()) {
        val conversation = activeConversation ?: return
        val editing = editingMessage
        if (editing != null) {
            if (text.isBlank()) return
            editChatMessage(editing, text)
            return
        }
        if (text.isBlank() && attachments.isEmpty()) return
        if (sessionAccessToken.isBlank()) return
        val clientMessageId = "android-${profile.globalId.value}-${System.currentTimeMillis()}"
        val replyId = replyToMessage?.id
        onChatDraftChanged(false)
        viewModelScope.launch {
            runCatching {
                if (conversation.encryptionMode == ChatEncryptionMode.E2EE) {
                    val peer = conversation.peerGlobalId ?: error("Direct chat peer is missing")
                    val peerKey = chatRepository.peerDeviceKeys(peer, sessionAccessToken).firstOrNull()
                        ?: error("У собеседника ещё нет ключа E2EE. Он должен хотя бы один раз открыть Brotherhood.")
                    val encrypted = privateChatCrypto.encrypt(conversation.id, peerKey, text, attachments)
                    chatRepository.sendDirect(conversation.id, clientMessageId, encrypted, sessionAccessToken, replyToMessageId = replyId)
                } else {
                    chatRepository.sendGroup(conversation.id, clientMessageId, text, attachments, sessionAccessToken, replyToMessageId = replyId)
                }
                replyToMessage = null
                refreshActiveChat()
                refreshConversations()
            }.onFailure {
                uiMessage = when (language) {
                    AppLanguage.RU -> "Сообщение сохранено в очереди. Отправка повторится при появлении сети."
                    AppLanguage.UK -> "Повідомлення збережено в черзі. Надсилання повториться після появи мережі."
                    AppLanguage.EN -> "Message queued. Sending will retry when the network returns."
                }
            }
        }
    }

    private fun editChatMessage(message: ChatMessage, text: String) {
        val conversation = activeConversation ?: return
        if (sessionAccessToken.isBlank()) return
        onChatDraftChanged(false)
        viewModelScope.launch {
            runCatching {
                if (conversation.encryptionMode == ChatEncryptionMode.E2EE) {
                    val peer = conversation.peerGlobalId ?: error("Direct chat peer is missing")
                    val peerKey = chatRepository.peerDeviceKeys(peer, sessionAccessToken).firstOrNull()
                        ?: error("Peer E2EE key is unavailable")
                    // Edit is a new chronological encrypted event, not in-place ciphertext replacement.
                    val encrypted = privateChatCrypto.encrypt(conversation.id, peerKey, text, emptyList())
                    chatRepository.editDirect(message.id, encrypted, sessionAccessToken)
                } else {
                    chatRepository.editGroup(message.id, text, sessionAccessToken)
                }
                editingMessage = null
                refreshActiveChat()
                refreshConversations()
            }.onFailure { uiMessage = it.message ?: "Не удалось отредактировать сообщение" }
        }
    }

    fun toggleReaction(message: ChatMessage, emoji: String) {
        if (sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            runCatching { chatRepository.toggleReaction(message.id, emoji, sessionAccessToken) }
                .onSuccess { refreshActiveChat() }
                .onFailure { uiMessage = it.message ?: "Не удалось поставить реакцию" }
        }
    }

    fun deleteMessage(message: ChatMessage) {
        if (message.senderGlobalId != profile.globalId || sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            runCatching { chatRepository.deleteMessage(message.id, sessionAccessToken) }
                .onSuccess {
                    if (replyToMessage?.id == message.id) replyToMessage = null
                    if (editingMessage?.id == message.id) editingMessage = null
                    refreshActiveChat()
                    refreshConversations()
                }
                .onFailure { uiMessage = it.message ?: "Не удалось удалить сообщение" }
        }
    }

    fun toggleActivePeerBlock() {
        val peer = activeConversation?.peerGlobalId ?: return
        if (sessionAccessToken.isBlank()) return
        val target = !activePeerBlockedByMe
        viewModelScope.launch {
            runCatching { chatRepository.setPeerBlocked(peer, target, sessionAccessToken) }
                .onSuccess { blocked ->
                    activePeerBlockedByMe = blocked
                    uiMessage = when (language) {
                        AppLanguage.RU -> if (blocked) "Пользователь заблокирован. Новые личные сообщения между вами запрещены." else "Пользователь разблокирован."
                        AppLanguage.UK -> if (blocked) "Користувача заблоковано. Нові особисті повідомлення між вами заборонені." else "Користувача розблоковано."
                        AppLanguage.EN -> if (blocked) "User blocked. New direct messages between you are disabled." else "User unblocked."
                    }
                    refreshConversations()
                }
                .onFailure { uiMessage = it.message ?: "Не удалось изменить блокировку" }
        }
    }

    fun reportActivePeer(description: String) {
        val peer = activeConversation?.peerGlobalId ?: return
        if (sessionAccessToken.isBlank() || description.trim().length < 20) return
        viewModelScope.launch {
            runCatching { chatRepository.reportPeer(profile.globalId, peer, description.trim(), sessionAccessToken) }
                .onSuccess {
                    uiMessage = when (language) {
                        AppLanguage.RU -> "Жалоба отправлена в закрытую модерацию. До решения она не снижает публичный рейтинг."
                        AppLanguage.UK -> "Скаргу передано на закриту модерацію. До рішення вона не знижує публічний рейтинг."
                        AppLanguage.EN -> "Report submitted for private moderation. It does not reduce the public score before a decision."
                    }
                }
                .onFailure { uiMessage = it.message ?: "Не удалось отправить жалобу" }
        }
    }

    fun checkForUpdates() {
        viewModelScope.launch {
            appUpdateInfo = runCatching { chatRepository.updateInfo("") }.getOrNull()
        }
    }

    fun changeLanguage(value: AppLanguage) {
        language = value
        settingsStore.setLanguage(value)
    }

    fun setTheme(value: AppThemeMode) {
        themeMode = value
        settingsStore.setTheme(value)
    }

    fun updateProfile(
        name: String,
        description: String,
        city: String,
        birthDate: LocalDate,
        latinName: String,
        goals: List<String>,
        interests: List<String>,
        values: List<String>,
        lifestyle: List<String>
    ) {
        val normalizedLatinName = latinName.trim().uppercase().ifBlank { profile.latinName }
        profile = profile.copy(
            name = name.trim().ifBlank { profile.name },
            age = Period.between(birthDate, LocalDate.now()).years.coerceAtLeast(18),
            description = description.trim(),
            city = city.trim().ifBlank { profile.city },
            birthDate = birthDate,
            latinName = normalizedLatinName,
            goals = goals.filter(String::isNotBlank).map(String::trim).distinct(),
            interests = interests.filter(String::isNotBlank).map(String::trim).distinct(),
            values = values.filter(String::isNotBlank).map(String::trim).distinct(),
            lifestyle = lifestyle.filter(String::isNotBlank).map(String::trim).distinct(),
            completedProfileSections = 10,
            zodiac = ZodiacEngine.sign(birthDate),
            numerology = VedicNumerologyEngine.calculate(birthDate, normalizedLatinName)
        )
        selectedCity = profile.city
        profileStore.save(profile)
        if (sessionAccessToken.isNotBlank()) {
            viewModelScope.launch {
                val profileSent = runCatching { remoteRepository.syncProfile(profile, language, sessionAccessToken, profileVisibility) }.getOrDefault(false)
                val personalitySent = runCatching { remoteRepository.syncPersonalityProfile(profile, sessionAccessToken) }.getOrDefault(false)
                remoteStatus = if (profileSent && personalitySent) "profile_synced" else "profile_queued"
            }
        }
    }

    fun refreshRemoteData() {
        if (sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            remoteLoading = true
            runCatching { remoteRepository.flushPending(sessionAccessToken) }
            val peopleResult = runCatching { remoteRepository.people(selectedCity, radiusKm, profile.globalId, sessionAccessToken) }
            val communityResult = runCatching { remoteRepository.communities(selectedCity, communityKind, sessionAccessToken) }
            peopleResult.getOrNull()?.let { remotePeople = it }
            communityResult.getOrNull()?.let { remoteCommunities = it }
            remoteStatus = when {
                peopleResult.isSuccess || communityResult.isSuccess -> "online_or_cached"
                BuildConfig.DEBUG -> "debug_demo_fallback"
                else -> "offline_no_cache"
            }
            remoteLoading = false
        }
    }

    fun startCoreAssessment(module: String) {
        require(module == "p32" || module == "enneagram")
        activeCoreModule = module
        coreQuestionIndex = 0
        coreAnswers = emptyMap()
    }

    fun selectCoreAnswer(value: Int) {
        require(value in 1..5)
        val question = currentCoreQuestion ?: return
        coreAnswers = coreAnswers + (question.id to value)
    }

    fun previousCoreQuestion() { if (coreQuestionIndex > 0) coreQuestionIndex -= 1 }

    fun nextCoreQuestion() {
        val question = currentCoreQuestion ?: return
        if (coreAnswers[question.id] !in 1..5) return
        if (coreQuestionIndex < coreQuestions.lastIndex) coreQuestionIndex += 1
    }

    fun finishCoreAssessment() {
        if (!canFinishCoreAssessment) return
        profile = when (activeCoreModule) {
            "p32" -> profile.copy(personality32 = CoreProfileCatalog.scorePersonality32(coreAnswers))
            "enneagram" -> profile.copy(enneagram = CoreProfileCatalog.scoreEnneagram(coreAnswers))
            else -> profile
        }
        profileStore.save(profile)
        if (sessionAccessToken.isNotBlank()) {
            viewModelScope.launch {
                val sent = runCatching { remoteRepository.syncPersonalityProfile(profile, sessionAccessToken) }.getOrDefault(false)
                remoteStatus = if (sent) "personality_synced" else "personality_queued"
            }
        }
        activeCoreModule = null
        coreQuestionIndex = 0
        coreAnswers = emptyMap()
    }

    fun closeCoreAssessment() {
        activeCoreModule = null
        coreQuestionIndex = 0
        coreAnswers = emptyMap()
    }

    fun startAssessment(id: String) {
        requireNotNull(AssessmentCatalog.byId(id)) { "Неизвестный тест: $id" }
        activeAssessmentId = id
        currentQuestionIndex = 0
        assessmentAnswers = emptyMap()
        currentResult = null
    }

    fun selectAssessmentAnswer(value: Int) {
        require(value in 1..5)
        val question = currentQuestion ?: return
        assessmentAnswers = assessmentAnswers + (question.id to value)
    }

    fun previousAssessmentQuestion() { if (currentQuestionIndex > 0) currentQuestionIndex -= 1 }

    fun nextAssessmentQuestion() {
        val definition = activeAssessment ?: return
        if (assessmentAnswers[definition.questions[currentQuestionIndex].id] !in 1..5) return
        if (currentQuestionIndex < definition.questions.lastIndex) currentQuestionIndex += 1
    }

    fun finishAssessment() {
        val definition = activeAssessment ?: return
        if (!canFinishAssessment) return
        val result = AssessmentScorer.score(definition, assessmentAnswers)
        assessmentStore.save(result)
        completedResults = completedResults + (definition.id to result)
        currentResult = result
        if (sessionAccessToken.isNotBlank()) {
            viewModelScope.launch {
                val sent = runCatching { remoteRepository.syncAssessmentResult(profile.globalId, result, sessionAccessToken) }.getOrDefault(false)
                remoteStatus = if (sent) "assessment_synced" else "assessment_queued"
                if (sent) refreshRemoteData()
            }
        }
    }

    fun closeAssessment() {
        activeAssessmentId = null
        currentQuestionIndex = 0
        assessmentAnswers = emptyMap()
        currentResult = null
    }

    fun assessmentProgress(definition: AssessmentDefinition): Int {
        if (completedResults.containsKey(definition.id)) return 100
        if (activeAssessmentId != definition.id || definition.questions.isEmpty()) return 0
        return (assessmentAnswers.size * 100 / definition.questions.size).coerceIn(0, 100)
    }

    private fun overlap(first: List<String>, second: List<String>): Int {
        val a = first.map(String::lowercase).toSet()
        val b = second.map(String::lowercase).toSet()
        return a.intersect(b).size * 100 / (a + b).size.coerceAtLeast(1)
    }

    private fun demoCandidateScore(seed: Int, id: String, safetyCritical: Boolean): Int {
        val hash = id.fold(seed * 31) { acc, char -> acc * 33 + char.code }
        val base = 45 + abs(hash % 51)
        return if (safetyCritical) maxOf(35, base) else base
    }

    override fun onCleared() {
        assessmentStore.close()
        remoteRepository.close()
        super.onCleared()
    }
}
