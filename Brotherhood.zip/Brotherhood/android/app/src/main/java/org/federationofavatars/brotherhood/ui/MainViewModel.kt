package org.federationofavatars.brotherhood.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.time.LocalDate
import java.time.Period
import kotlin.math.abs
import kotlinx.coroutines.launch
import org.federationofavatars.brotherhood.BuildConfig
import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.data.AssessmentLocalStore
import org.federationofavatars.brotherhood.data.CoreProfileCatalog
import org.federationofavatars.brotherhood.data.CoreProfileQuestion
import org.federationofavatars.brotherhood.data.DemoRepository
import org.federationofavatars.brotherhood.data.SettingsStore
import org.federationofavatars.brotherhood.data.ProfileLocalStore
import org.federationofavatars.brotherhood.domain.AccountRatingCalculator
import org.federationofavatars.brotherhood.domain.AssessmentScorer
import org.federationofavatars.brotherhood.domain.CrossTestIntegrityAnalyzer
import org.federationofavatars.brotherhood.domain.FriendshipCompatibilityEngine
import org.federationofavatars.brotherhood.domain.HybridCompatibilityEngine
import org.federationofavatars.brotherhood.domain.VedicNumerologyEngine
import org.federationofavatars.brotherhood.domain.ZodiacEngine
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AppRoute
import org.federationofavatars.brotherhood.model.AppThemeMode
import org.federationofavatars.brotherhood.model.AssessmentDefinition
import org.federationofavatars.brotherhood.model.AssessmentKind
import org.federationofavatars.brotherhood.model.AssessmentQuestion
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.AuthProvider
import org.federationofavatars.brotherhood.model.Community
import org.federationofavatars.brotherhood.model.CommunityKind
import org.federationofavatars.brotherhood.model.CompatibilityBreakdown
import org.federationofavatars.brotherhood.model.FriendCandidate
import org.federationofavatars.brotherhood.model.MainTab
import org.federationofavatars.brotherhood.network.RemoteDataRepository

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val assessmentStore = AssessmentLocalStore(application)
    private val settingsStore = SettingsStore(application)
    private val profileStore = ProfileLocalStore(application)
    private val initialProfile = profileStore.load(DemoRepository.profile)
    private val remoteRepository = RemoteDataRepository(application)
    private val sessionAccessToken = if (BuildConfig.DEBUG) "debug-local-session" else ""

    var route by mutableStateOf(AppRoute.AUTH)
        private set
    var selectedTab by mutableStateOf(MainTab.DISCOVER)
        private set
    var language by mutableStateOf(settingsStore.language())
        private set
    var themeMode by mutableStateOf(settingsStore.theme())
        private set
    var authProvider by mutableStateOf<AuthProvider?>(null)
        private set
    var selectedCity by mutableStateOf(initialProfile.city)
        private set
    var radiusKm by mutableIntStateOf(25)
        private set
    var communityKind by mutableStateOf(CommunityKind.INTEREST)
        private set
    var selectedAssessmentKind by mutableStateOf<AssessmentKind?>(null)
        private set
    var locationStatus by mutableStateOf<String?>(null)
        private set
    var selectedCandidateId by mutableStateOf<Long?>(null)
        private set
    var selectedCommunityId by mutableStateOf<String?>(null)
        private set
    var joinedCommunityIds by mutableStateOf<Set<String>>(emptySet())
        private set
    var connectionRequests by mutableStateOf<Set<Long>>(emptySet())
        private set
    var uiMessage by mutableStateOf<String?>(null)
        private set

    var remotePeople by mutableStateOf<List<FriendCandidate>>(emptyList())
        private set
    var remoteCommunities by mutableStateOf<List<Community>>(emptyList())
        private set
    var remoteLoading by mutableStateOf(false)
        private set
    var remoteStatus by mutableStateOf<String?>(null)
        private set

    var activeAssessmentId by mutableStateOf<String?>(null)
        private set
    var currentQuestionIndex by mutableIntStateOf(0)
        private set
    var assessmentAnswers by mutableStateOf<Map<String, Int>>(emptyMap())
        private set
    var currentResult by mutableStateOf<AssessmentResult?>(null)
        private set
    var completedResults by mutableStateOf(assessmentStore.loadAll())
        private set

    var activeCoreModule by mutableStateOf<String?>(null)
        private set
    var coreQuestionIndex by mutableIntStateOf(0)
        private set
    var coreAnswers by mutableStateOf<Map<String, Int>>(emptyMap())
        private set

    val cities = DemoRepository.cities
    val assessmentDefinitions: List<AssessmentDefinition>
        get() = selectedAssessmentKind?.let { AssessmentCatalog.byCategory[it].orEmpty() } ?: AssessmentCatalog.assessments
    val assessmentKinds = AssessmentKind.entries
    val trustEvents = DemoRepository.trustEvents
    var profile by mutableStateOf(initialProfile)
        private set

    val accountRating
        get() = AccountRatingCalculator.calculate(profile.completedProfileSections, completedResults.keys)

    val integrityScreening
        get() = CrossTestIntegrityAnalyzer.analyze(completedResults)

    private val myAssessmentScores: Map<String, Int>
        get() = completedResults.mapValues { it.value.totalScore }

    val candidates: List<FriendCandidate>
        get() {
            val source = if (remotePeople.isNotEmpty()) remotePeople else if (BuildConfig.DEBUG) DemoRepository.people else emptyList()
            return source.filter {
                it.city == selectedCity && it.distanceKm <= radiusKm
            }.map { candidate ->
                if (candidate.serverBacked) {
                    val hybrid = HybridCompatibilityEngine.calculate(
                        me = profile,
                        candidate = candidate,
                        friendshipTests = candidate.friendshipTestScore,
                        sharedTestCount = candidate.commonTestCount
                    )
                    val cappedTotal = if (candidate.compatibilityRiskFlags.isEmpty()) hybrid.total else minOf(hybrid.total, 64)
                    candidate.copy(
                        compatibility = cappedTotal,
                        explanation = candidate.explanation + if (candidate.compatibilityRiskFlags.isEmpty()) "" else " Риски: ${candidate.compatibilityRiskFlags.joinToString()}."
                    )
                } else {
                    val candidateScores = AssessmentCatalog.assessments.associate { definition ->
                        definition.id to demoCandidateScore(candidate.assessmentProfileSeed, definition.id, definition.safetyCritical)
                    }
                    val interestPercent = overlap(profile.interests, candidate.interests)
                    val testResult = FriendshipCompatibilityEngine.calculate(
                        myScores = myAssessmentScores,
                        candidateScores = candidateScores,
                        sharedInterestPercent = interestPercent,
                        trustScore = candidate.trustScore
                    )
                    val hybrid = HybridCompatibilityEngine.calculate(
                        me = profile,
                        candidate = candidate,
                        friendshipTests = testResult.score,
                        sharedTestCount = testResult.commonTests
                    )
                    candidate.copy(
                        compatibility = hybrid.total,
                        explanation = candidate.explanation + if (testResult.riskFlags.isEmpty()) "" else " Риски: ${testResult.riskFlags.joinToString()}."
                    )
                }
            }.sortedByDescending(FriendCandidate::compatibility)
        }

    val selectedCandidate: FriendCandidate?
        get() = selectedCandidateId?.let { id -> candidates.firstOrNull { it.globalId.value == id } ?: if (BuildConfig.DEBUG) DemoRepository.people.firstOrNull { it.globalId.value == id } else null }

    fun compatibility(candidate: FriendCandidate): CompatibilityBreakdown {
        if (candidate.serverBacked) {
            val localBreakdown = HybridCompatibilityEngine.calculate(
                profile, candidate, candidate.friendshipTestScore, candidate.commonTestCount
            )
            return if (candidate.compatibilityRiskFlags.isEmpty()) localBreakdown else localBreakdown.copy(total = minOf(localBreakdown.total, 64))
        }
        val candidateScores = AssessmentCatalog.assessments.associate { definition ->
            definition.id to demoCandidateScore(candidate.assessmentProfileSeed, definition.id, definition.safetyCritical)
        }
        val testResult = FriendshipCompatibilityEngine.calculate(
            myScores = myAssessmentScores,
            candidateScores = candidateScores,
            sharedInterestPercent = overlap(profile.interests, candidate.interests),
            trustScore = candidate.trustScore
        )
        return HybridCompatibilityEngine.calculate(profile, candidate, testResult.score, testResult.commonTests)
    }

    val communities: List<Community>
        get() {
            val source = if (remoteCommunities.isNotEmpty()) remoteCommunities else if (BuildConfig.DEBUG) DemoRepository.communities else emptyList()
            return source.filter {
                it.kind == communityKind && (it.city == selectedCity || it.online)
            }.map { it.copy(joined = it.id in joinedCommunityIds) }
        }

    val selectedCommunity: Community?
        get() = selectedCommunityId?.let { id -> communities.firstOrNull { it.id == id } ?: if (BuildConfig.DEBUG) DemoRepository.communities.firstOrNull { it.id == id }?.copy(joined = id in joinedCommunityIds) else null }

    val activeAssessment: AssessmentDefinition?
        get() = activeAssessmentId?.let(AssessmentCatalog::byId)

    val currentQuestion: AssessmentQuestion?
        get() = activeAssessment?.questions?.getOrNull(currentQuestionIndex)

    val coreQuestions: List<CoreProfileQuestion>
        get() = when (activeCoreModule) {
            "p32" -> CoreProfileCatalog.personality32Questions
            "enneagram" -> CoreProfileCatalog.enneagramQuestions
            else -> emptyList()
        }

    val currentCoreQuestion: CoreProfileQuestion?
        get() = coreQuestions.getOrNull(coreQuestionIndex)

    val canFinishCoreAssessment: Boolean
        get() = coreQuestions.isNotEmpty() && coreQuestions.all { coreAnswers[it.id] in 1..5 }

    val canFinishAssessment: Boolean
        get() = activeAssessment?.questions?.all { assessmentAnswers[it.id] in 1..5 } == true

    fun signIn(provider: AuthProvider) {
        if (!BuildConfig.DEBUG) {
            uiMessage = when (language) {
                AppLanguage.RU -> "Production-вход требует настроенного OAuth/Telegram провайдера на Vercel."
                AppLanguage.UK -> "Production-вхід потребує налаштованого OAuth/Telegram провайдера на Vercel."
                AppLanguage.EN -> "Production sign-in requires a configured OAuth/Telegram provider on Vercel."
            }
            return
        }
        authProvider = provider
        settingsStore.setOnboardingComplete(true)
        route = AppRoute.HOME
        refreshRemoteData()
    }

    fun signOut() {
        authProvider = null
        route = AppRoute.AUTH
    }

    fun selectTab(tab: MainTab) { selectedTab = tab; route = AppRoute.HOME }
    fun selectCity(city: String) { selectedCity = city; locationStatus = when (language) { AppLanguage.RU -> "Город выбран: $city"; AppLanguage.UK -> "Місто обрано: $city"; AppLanguage.EN -> "City selected: $city" }; refreshRemoteData() }
    fun setRadius(value: Int) { radiusKm = value; refreshRemoteData() }
    fun selectCommunityKind(kind: CommunityKind) { communityKind = kind; refreshRemoteData() }
    fun selectAssessmentKind(kind: AssessmentKind?) { selectedAssessmentKind = kind }
    fun reportLocationFailure() { locationStatus = when (language) { AppLanguage.RU -> "Не удалось определить город. Выберите его вручную."; AppLanguage.UK -> "Не вдалося визначити місто. Оберіть його вручну."; AppLanguage.EN -> "Could not determine the city. Choose it manually." } }
    fun openSettings() { route = AppRoute.SETTINGS }
    fun openServices() { route = AppRoute.SERVICES }
    fun openMessages() { route = AppRoute.MESSAGES }
    fun openBusinessCommunities() { communityKind = CommunityKind.BUSINESS; selectedTab = MainTab.COMMUNITIES; route = AppRoute.HOME }
    fun closeOverlay() { route = AppRoute.HOME }
    fun editProfile() { route = AppRoute.EDIT_PROFILE }

    fun openCandidate(candidate: FriendCandidate) {
        selectedCandidateId = candidate.globalId.value
        route = AppRoute.CANDIDATE
    }

    fun requestConnection(candidate: FriendCandidate) {
        connectionRequests = connectionRequests + candidate.globalId.value
    }

    fun showMessage(message: String) { uiMessage = message }
    fun consumeMessage() { uiMessage = null }

    fun openCommunity(community: Community) {
        selectedCommunityId = community.id
        route = AppRoute.COMMUNITY
    }

    fun toggleCommunityMembership(community: Community) {
        joinedCommunityIds = if (community.id in joinedCommunityIds) joinedCommunityIds - community.id else joinedCommunityIds + community.id
    }

    fun changeLanguage(value: AppLanguage) {
        language = value
        settingsStore.setLanguage(value)
    }

    fun setTheme(value: AppThemeMode) {
        themeMode = value
        settingsStore.setTheme(value)
    }

    fun updateProfile(
        name: String,
        description: String,
        city: String,
        birthDate: LocalDate,
        latinName: String,
        goals: List<String>,
        interests: List<String>,
        values: List<String>,
        lifestyle: List<String>
    ) {
        val normalizedLatinName = latinName.trim().uppercase().ifBlank { profile.latinName }
        profile = profile.copy(
            name = name.trim().ifBlank { profile.name },
            age = Period.between(birthDate, LocalDate.now()).years.coerceAtLeast(18),
            description = description.trim(),
            city = city.trim().ifBlank { profile.city },
            birthDate = birthDate,
            latinName = normalizedLatinName,
            goals = goals.filter(String::isNotBlank).map(String::trim).distinct(),
            interests = interests.filter(String::isNotBlank).map(String::trim).distinct(),
            values = values.filter(String::isNotBlank).map(String::trim).distinct(),
            lifestyle = lifestyle.filter(String::isNotBlank).map(String::trim).distinct(),
            completedProfileSections = 10,
            zodiac = ZodiacEngine.sign(birthDate),
            numerology = VedicNumerologyEngine.calculate(birthDate, normalizedLatinName)
        )
        selectedCity = profile.city
        profileStore.save(profile)
        if (sessionAccessToken.isNotBlank()) {
            viewModelScope.launch {
                val profileSent = runCatching { remoteRepository.syncProfile(profile, language, sessionAccessToken) }.getOrDefault(false)
                val personalitySent = runCatching { remoteRepository.syncPersonalityProfile(profile, sessionAccessToken) }.getOrDefault(false)
                remoteStatus = if (profileSent && personalitySent) "profile_synced" else "profile_queued"
            }
        }
    }

    fun refreshRemoteData() {
        if (sessionAccessToken.isBlank()) return
        viewModelScope.launch {
            remoteLoading = true
            runCatching { remoteRepository.flushPending(sessionAccessToken) }
            val peopleResult = runCatching { remoteRepository.people(selectedCity, radiusKm, profile.globalId, sessionAccessToken) }
            val communityResult = runCatching { remoteRepository.communities(selectedCity, communityKind, sessionAccessToken) }
            peopleResult.getOrNull()?.let { remotePeople = it }
            communityResult.getOrNull()?.let { remoteCommunities = it }
            remoteStatus = when {
                peopleResult.isSuccess || communityResult.isSuccess -> "online_or_cached"
                BuildConfig.DEBUG -> "debug_demo_fallback"
                else -> "offline_no_cache"
            }
            remoteLoading = false
        }
    }

    fun startCoreAssessment(module: String) {
        require(module == "p32" || module == "enneagram")
        activeCoreModule = module
        coreQuestionIndex = 0
        coreAnswers = emptyMap()
    }

    fun selectCoreAnswer(value: Int) {
        require(value in 1..5)
        val question = currentCoreQuestion ?: return
        coreAnswers = coreAnswers + (question.id to value)
    }

    fun previousCoreQuestion() { if (coreQuestionIndex > 0) coreQuestionIndex -= 1 }

    fun nextCoreQuestion() {
        val question = currentCoreQuestion ?: return
        if (coreAnswers[question.id] !in 1..5) return
        if (coreQuestionIndex < coreQuestions.lastIndex) coreQuestionIndex += 1
    }

    fun finishCoreAssessment() {
        if (!canFinishCoreAssessment) return
        profile = when (activeCoreModule) {
            "p32" -> profile.copy(personality32 = CoreProfileCatalog.scorePersonality32(coreAnswers))
            "enneagram" -> profile.copy(enneagram = CoreProfileCatalog.scoreEnneagram(coreAnswers))
            else -> profile
        }
        profileStore.save(profile)
        if (sessionAccessToken.isNotBlank()) {
            viewModelScope.launch {
                val sent = runCatching { remoteRepository.syncPersonalityProfile(profile, sessionAccessToken) }.getOrDefault(false)
                remoteStatus = if (sent) "personality_synced" else "personality_queued"
            }
        }
        activeCoreModule = null
        coreQuestionIndex = 0
        coreAnswers = emptyMap()
    }

    fun closeCoreAssessment() {
        activeCoreModule = null
        coreQuestionIndex = 0
        coreAnswers = emptyMap()
    }

    fun startAssessment(id: String) {
        requireNotNull(AssessmentCatalog.byId(id)) { "Неизвестный тест: $id" }
        activeAssessmentId = id
        currentQuestionIndex = 0
        assessmentAnswers = emptyMap()
        currentResult = null
    }

    fun selectAssessmentAnswer(value: Int) {
        require(value in 1..5)
        val question = currentQuestion ?: return
        assessmentAnswers = assessmentAnswers + (question.id to value)
    }

    fun previousAssessmentQuestion() { if (currentQuestionIndex > 0) currentQuestionIndex -= 1 }

    fun nextAssessmentQuestion() {
        val definition = activeAssessment ?: return
        if (assessmentAnswers[definition.questions[currentQuestionIndex].id] !in 1..5) return
        if (currentQuestionIndex < definition.questions.lastIndex) currentQuestionIndex += 1
    }

    fun finishAssessment() {
        val definition = activeAssessment ?: return
        if (!canFinishAssessment) return
        val result = AssessmentScorer.score(definition, assessmentAnswers)
        assessmentStore.save(result)
        completedResults = completedResults + (definition.id to result)
        currentResult = result
        if (sessionAccessToken.isNotBlank()) {
            viewModelScope.launch {
                val sent = runCatching { remoteRepository.syncAssessmentResult(profile.globalId, result, sessionAccessToken) }.getOrDefault(false)
                remoteStatus = if (sent) "assessment_synced" else "assessment_queued"
                if (sent) refreshRemoteData()
            }
        }
    }

    fun closeAssessment() {
        activeAssessmentId = null
        currentQuestionIndex = 0
        assessmentAnswers = emptyMap()
        currentResult = null
    }

    fun assessmentProgress(definition: AssessmentDefinition): Int {
        if (completedResults.containsKey(definition.id)) return 100
        if (activeAssessmentId != definition.id || definition.questions.isEmpty()) return 0
        return (assessmentAnswers.size * 100 / definition.questions.size).coerceIn(0, 100)
    }

    private fun overlap(first: List<String>, second: List<String>): Int {
        val a = first.map(String::lowercase).toSet()
        val b = second.map(String::lowercase).toSet()
        return a.intersect(b).size * 100 / (a + b).size.coerceAtLeast(1)
    }

    private fun demoCandidateScore(seed: Int, id: String, safetyCritical: Boolean): Int {
        val hash = id.fold(seed * 31) { acc, char -> acc * 33 + char.code }
        val base = 45 + abs(hash % 51)
        return if (safetyCritical) maxOf(35, base) else base
    }

    override fun onCleared() {
        assessmentStore.close()
        remoteRepository.close()
        super.onCleared()
    }
}
