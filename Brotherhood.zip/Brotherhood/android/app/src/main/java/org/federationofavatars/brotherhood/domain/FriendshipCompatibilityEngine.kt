package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.model.CompatibilityMode
import org.federationofavatars.brotherhood.model.FriendshipCompatibilityResult

object FriendshipCompatibilityEngine {
    fun calculate(
        myScores: Map<String, Int>,
        candidateScores: Map<String, Int>,
        sharedInterestPercent: Int,
        trustScore: Int
    ): FriendshipCompatibilityResult {
        val commonIds = myScores.keys.intersect(candidateScores.keys).filter { AssessmentCatalog.byId(it) != null }
        if (commonIds.isEmpty()) {
            return FriendshipCompatibilityResult(
                score = ((sharedInterestPercent * 0.45) + (trustScore * 0.55)).roundToInt().coerceIn(0, 100),
                testsScore = 0,
                commonTests = 0,
                confidence = 10,
                riskFlags = emptyList(),
                explanation = "Предварительный результат: общих пройденных тестов пока нет."
            )
        }

        var weighted = 0.0
        var totalWeight = 0.0
        val flags = mutableListOf<String>()
        commonIds.forEach { id ->
            val definition = AssessmentCatalog.byId(id) ?: return@forEach
            val mine = myScores.getValue(id).coerceIn(0, 100)
            val other = candidateScores.getValue(id).coerceIn(0, 100)
            val similarity = 100 - abs(mine - other)
            val contribution = when (definition.compatibilityMode) {
                CompatibilityMode.SIMILARITY -> similarity.toDouble()
                CompatibilityMode.HIGH_IS_GOOD -> similarity * 0.35 + minOf(mine, other) * 0.65
            }
            val weight = if (definition.safetyCritical) 1.8 else 1.0
            weighted += contribution * weight
            totalWeight += weight
            if (definition.safetyCritical && other < 35) {
                flags += "${definition.title}: повышенный риск по самооценке кандидата"
            }
        }

        val testsScore = (weighted / totalWeight).roundToInt().coerceIn(0, 100)
        var finalScore = (testsScore * 0.75 + sharedInterestPercent.coerceIn(0, 100) * 0.10 + trustScore.coerceIn(0, 100) * 0.15)
            .roundToInt().coerceIn(0, 100)
        if (flags.isNotEmpty()) finalScore = minOf(finalScore, 64)
        val confidence = (commonIds.size * 100 / AssessmentCatalog.REQUIRED_TEST_COUNT).coerceIn(10, 100)
        return FriendshipCompatibilityResult(
            score = finalScore,
            testsScore = testsScore,
            commonTests = commonIds.size,
            confidence = confidence,
            riskFlags = flags.take(5),
            explanation = "75% результата формируют общие тесты мужской дружбы, 10% — интересы, 15% — подтверждённая репутация. Уверенность растёт по мере прохождения обоими мужчинами всех 100 тестов."
        )
    }
}
