package org.federationofavatars.brotherhood.domain

import kotlin.math.abs
import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.model.CompatibilityMode
import org.federationofavatars.brotherhood.model.FriendshipCompatibilityResult

object FriendshipCompatibilityEngine {
    fun calculate(
        myScores: Map<String, Int>,
        candidateScores: Map<String, Int>,
        sharedInterestPercent: Int,
        trustScore: Int
    ): FriendshipCompatibilityResult {
        val commonIds = myScores.keys.intersect(candidateScores.keys).filter { AssessmentCatalog.byId(it) != null }
        if (commonIds.isEmpty()) {
            return FriendshipCompatibilityResult(
                score = 0,
                testsScore = 0,
                commonTests = 0,
                confidence = 10,
                riskFlags = emptyList(),
                explanation = "Предварительный результат: общих пройденных тестов пока нет.",
                categoryScores = emptyMap()
            )
        }

        var weighted = 0.0
        var totalWeight = 0.0
        val flags = mutableListOf<String>()
        val byKind = mutableMapOf<String, MutableList<Pair<Double, Double>>>()
        commonIds.forEach { id ->
            val definition = AssessmentCatalog.byId(id) ?: return@forEach
            val mine = myScores.getValue(id).coerceIn(0, 100)
            val other = candidateScores.getValue(id).coerceIn(0, 100)
            val similarity = 100 - abs(mine - other)
            val contribution = when (definition.compatibilityMode) {
                CompatibilityMode.SIMILARITY -> similarity.toDouble()
                CompatibilityMode.HIGH_IS_GOOD -> similarity * 0.35 + minOf(mine, other) * 0.65
            }
            val weight = if (definition.safetyCritical) 1.8 else 1.0
            weighted += contribution * weight
            totalWeight += weight
            byKind.getOrPut(definition.kind.name.lowercase()) { mutableListOf() } += contribution to weight
            if (definition.safetyCritical && other < 35) {
                flags += "${definition.title}: повышенный риск по самооценке кандидата"
            }
        }

        val testsScore = (weighted / totalWeight).roundToInt().coerceIn(0, 100)
        val categoryScores = byKind.mapValues { (_, rows) ->
            val weight = rows.sumOf { it.second }.coerceAtLeast(.001)
            (rows.sumOf { it.first * it.second } / weight).roundToInt().coerceIn(0, 100)
        }
        return FriendshipCompatibilityResult(
            score = testsScore,
            testsScore = testsScore,
            commonTests = commonIds.size,
            confidence = (commonIds.size * 100 / AssessmentCatalog.REQUIRED_TEST_COUNT).coerceIn(10, 100),
            riskFlags = flags.take(5),
            explanation = "Тестовый слой рассчитан только по общим тестам. Интересы, характер, ценности, типы личности, зодиак, нумерология и Trust Score показываются отдельными слоями.",
            categoryScores = categoryScores
        )
    }
}
