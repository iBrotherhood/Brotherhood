package org.federationofavatars.brotherhood.network

import android.content.Context
import android.util.Base64
import org.federationofavatars.brotherhood.data.BrotherhoodCacheStore
import org.federationofavatars.brotherhood.model.AppUpdateInfo
import org.federationofavatars.brotherhood.model.ChatAttachment
import org.federationofavatars.brotherhood.model.ChatAttachmentKind
import org.federationofavatars.brotherhood.model.ChatEncryptionMode
import org.federationofavatars.brotherhood.model.ChatMessage
import org.federationofavatars.brotherhood.model.ConversationKind
import org.federationofavatars.brotherhood.model.ConversationSummaryModel
import org.federationofavatars.brotherhood.model.DeviceKeyBundle
import org.federationofavatars.brotherhood.model.EncryptedDirectPayload
import org.federationofavatars.brotherhood.model.GlobalId
import org.federationofavatars.brotherhood.model.GroupMember
import org.federationofavatars.brotherhood.model.PendingChatAttachment
import org.json.JSONArray
import org.json.JSONObject

class ChatRemoteRepository(context: Context) {
    private val cache = BrotherhoodCacheStore(context.applicationContext)
    private val api = VercelApiClient(ApiConfig.baseUrl)

    suspend fun registerDeviceKey(myGlobalId: GlobalId, local: org.federationofavatars.brotherhood.crypto.PrivateChatCrypto.LocalBundle, token: String): DeviceKeyBundle {
        val body = JSONObject()
            .put("device_id", local.deviceId)
            .put("identity_public_key_b64", local.identityPublicB64)
            .put("prekey_id", local.prekeyId)
            .put("prekey_public_key_b64", local.prekeyPublicB64)
            .put("prekey_signature_b64", local.prekeySignatureB64)
        val response = api.put("v1/e2ee/device-key", body.toString(), token)
        return parseDeviceKey(JSONObject(response))
    }

    suspend fun peerDeviceKeys(globalId: GlobalId, token: String): List<DeviceKeyBundle> {
        val raw = api.get("v1/e2ee/device-keys/${globalId.value}", token)
        val array = JSONArray(raw)
        return buildList { for (i in 0 until array.length()) add(parseDeviceKey(array.getJSONObject(i))) }
    }

    suspend fun conversations(token: String): List<ConversationSummaryModel> {
        val raw = runCatching { api.get("v1/conversations", token) }
            .onSuccess { cache.put("chat:conversations", it, 30_000, entityType = "chat") }
            .getOrElse { cache.get("chat:conversations") ?: throw it }
        val array = JSONArray(raw)
        return buildList { for (i in 0 until array.length()) add(parseConversation(array.getJSONObject(i))) }
    }

    suspend fun openDirect(peer: GlobalId, token: String): ConversationSummaryModel {
        val raw = api.post("v1/conversations/direct", JSONObject().put("peer_global_id", peer.value).toString(), token)
        return parseConversation(JSONObject(raw))
    }

    suspend fun createGroup(title: String, members: List<GlobalId>, token: String): ConversationSummaryModel {
        val memberArray = JSONArray().apply { members.distinctBy { it.value }.forEach { put(it.value) } }
        val raw = api.post("v1/conversations/group", JSONObject().put("title", title).put("member_global_ids", memberArray).toString(), token)
        return parseConversation(JSONObject(raw))
    }

    suspend fun groupMembers(conversationId: String, token: String): List<GroupMember> {
        val raw = api.get("v1/conversations/$conversationId/members", token)
        val array = JSONArray(raw)
        return buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(GroupMember(GlobalId(item.getLong("global_id")), item.getString("role")))
            }
        }
    }

    suspend fun addGroupMember(conversationId: String, member: GlobalId, token: String): List<GroupMember> {
        val raw = api.put("v1/conversations/$conversationId/members/${member.value}", "{}", token)
        val array = JSONArray(raw)
        return buildList { for (i in 0 until array.length()) { val item=array.getJSONObject(i); add(GroupMember(GlobalId(item.getLong("global_id")), item.getString("role"))) } }
    }

    suspend fun removeGroupMember(conversationId: String, member: GlobalId, token: String): List<GroupMember> {
        val raw = api.delete("v1/conversations/$conversationId/members/${member.value}", token)
        val array = JSONArray(raw)
        return buildList { for (i in 0 until array.length()) { val item=array.getJSONObject(i); add(GroupMember(GlobalId(item.getLong("global_id")), item.getString("role"))) } }
    }

    suspend fun messages(conversationId: String, token: String): List<ChatMessage> {
        val key = "chat:messages:$conversationId"
        val raw = runCatching { api.get("v1/conversations/$conversationId/messages", token) }
            .onSuccess { cache.put(key, it, 15_000, entityType = "chat") }
            .getOrElse { cache.get(key) ?: throw it }
        val array = JSONArray(raw)
        return buildList { for (i in 0 until array.length()) add(parseMessage(array.getJSONObject(i))) }
    }

    suspend fun sendDirect(
        conversationId: String,
        clientMessageId: String,
        encrypted: EncryptedDirectPayload,
        token: String,
        replyToMessageId: String? = null,
        createdAt: Long = System.currentTimeMillis(),
    ): ChatMessage {
        val attachments = JSONArray().apply {
            encrypted.attachments.forEach { item ->
                put(JSONObject()
                    .put("client_attachment_id", item.clientAttachmentId)
                    .put("kind", item.kind.name.lowercase())
                    .put("mime_type", item.mimeType)
                    .put("file_name", item.fileName)
                    .put("byte_size", item.byteSize)
                    .put("data_b64", item.dataB64)
                    .put("nonce_b64", item.nonceB64))
            }
        }
        val body = JSONObject()
            .put("client_message_id", clientMessageId)
            .put("message_type", if (encrypted.attachments.isEmpty()) "text" else "media")
            .put("encryption_mode", "e2ee")
            .put("ciphertext_b64", encrypted.ciphertextB64)
            .put("nonce_b64", encrypted.nonceB64)
            .put("key_id", encrypted.keyId)
            .put("ratchet_counter", encrypted.ratchetCounter)
            .putOpt("sender_ephemeral_public_key_b64", encrypted.senderEphemeralPublicKeyB64)
            .putOpt("recipient_prekey_id", encrypted.recipientPrekeyId)
            .putOpt("reply_to_message_id", replyToMessageId)
            .put("attachments", attachments)
            .put("created_at_epoch_ms", createdAt)
        return sendOrQueue(conversationId, clientMessageId, body, token)
    }

    suspend fun sendGroup(
        conversationId: String,
        clientMessageId: String,
        text: String,
        attachments: List<PendingChatAttachment>,
        token: String,
        replyToMessageId: String? = null,
        createdAt: Long = System.currentTimeMillis(),
    ): ChatMessage {
        val array = JSONArray().apply {
            attachments.forEach { item ->
                put(JSONObject()
                    .put("client_attachment_id", item.clientAttachmentId)
                    .put("kind", item.kind.name.lowercase())
                    .put("mime_type", item.mimeType)
                    .put("file_name", item.fileName)
                    .put("byte_size", item.bytes.size)
                    .put("data_b64", Base64.encodeToString(item.bytes, Base64.NO_WRAP)))
            }
        }
        val body = JSONObject()
            .put("client_message_id", clientMessageId)
            .put("message_type", if (attachments.isEmpty()) "text" else "media")
            .put("encryption_mode", "server")
            .put("body", text.takeIf(String::isNotBlank))
            .putOpt("reply_to_message_id", replyToMessageId)
            .put("attachments", array)
            .put("created_at_epoch_ms", createdAt)
        return sendOrQueue(conversationId, clientMessageId, body, token)
    }

    private suspend fun sendOrQueue(conversationId: String, clientMessageId: String, body: JSONObject, token: String): ChatMessage {
        return runCatching {
            val raw = api.post("v1/conversations/$conversationId/messages", body.toString(), token)
            parseMessage(JSONObject(raw)).also { cache.markMessageSent(clientMessageId) }
        }.getOrElse {
            cache.enqueueMessage(clientMessageId, conversationId, body.toString())
            throw it
        }
    }

    suspend fun flushOutbox(token: String): Int {
        var sent = 0
        for (item in cache.pendingMessages()) {
            val result = runCatching { api.post("v1/conversations/${item.conversationId}/messages", item.payload, token) }
            if (result.isSuccess) {
                cache.markMessageSent(item.localId)
                sent++
            } else cache.markMessageFailure(item.localId)
        }
        return sent
    }

    suspend fun attachmentData(attachmentId: String, token: String): Pair<ChatEncryptionMode, ByteArray> {
        val raw = api.get("v1/chat/attachments/$attachmentId", token)
        val json = JSONObject(raw)
        val mode = if (json.getString("encryption_mode") == "e2ee") ChatEncryptionMode.E2EE else ChatEncryptionMode.SERVER
        return mode to Base64.decode(json.getString("data_b64"), Base64.NO_WRAP)
    }

    suspend fun editDirect(
        messageId: String,
        encrypted: EncryptedDirectPayload,
        token: String,
        editedAt: Long = System.currentTimeMillis(),
    ): ChatMessage {
        val body = JSONObject()
            .put("encryption_mode", "e2ee")
            .put("ciphertext_b64", encrypted.ciphertextB64)
            .put("nonce_b64", encrypted.nonceB64)
            .put("key_id", encrypted.keyId)
            .put("ratchet_counter", encrypted.ratchetCounter)
            .putOpt("sender_ephemeral_public_key_b64", encrypted.senderEphemeralPublicKeyB64)
            .putOpt("recipient_prekey_id", encrypted.recipientPrekeyId)
            .put("edited_at_epoch_ms", editedAt)
        return parseMessage(JSONObject(api.put("v1/messages/$messageId", body.toString(), token)))
    }

    suspend fun editGroup(
        messageId: String,
        text: String,
        token: String,
        editedAt: Long = System.currentTimeMillis(),
    ): ChatMessage {
        val body = JSONObject()
            .put("encryption_mode", "server")
            .put("body", text)
            .put("edited_at_epoch_ms", editedAt)
        return parseMessage(JSONObject(api.put("v1/messages/$messageId", body.toString(), token)))
    }

    suspend fun toggleReaction(messageId: String, emoji: String, token: String) {
        api.put("v1/messages/$messageId/reaction", JSONObject().put("emoji", emoji).toString(), token)
    }

    suspend fun deleteMessage(messageId: String, token: String) {
        api.delete("v1/messages/$messageId", token)
    }

    suspend fun setTyping(conversationId: String, typing: Boolean, token: String) {
        api.put("v1/conversations/$conversationId/typing", JSONObject().put("typing", typing).toString(), token)
    }

    suspend fun typingUsers(conversationId: String, token: String): List<GlobalId> {
        val raw = api.get("v1/conversations/$conversationId/typing", token)
        val array = JSONObject(raw).optJSONArray("global_ids") ?: JSONArray()
        return buildList { for (i in 0 until array.length()) add(GlobalId(array.getLong(i))) }
    }

    suspend fun markRead(conversationId: String, messageId: String, token: String) {
        api.put("v1/conversations/$conversationId/read", JSONObject().put("message_id", messageId).toString(), token)
    }

    suspend fun peerBlockedByMe(peer: GlobalId, token: String): Boolean {
        val raw = api.get("v1/users/${peer.value}/block", token)
        return JSONObject(raw).optBoolean("blocked", false)
    }

    suspend fun setPeerBlocked(peer: GlobalId, blocked: Boolean, token: String): Boolean {
        val raw = api.put("v1/users/${peer.value}/block", JSONObject().put("blocked", blocked).toString(), token)
        return JSONObject(raw).optBoolean("blocked", blocked)
    }

    suspend fun reportPeer(myGlobalId: GlobalId, peer: GlobalId, description: String, token: String) {
        val body = JSONObject()
            .put("category", "chat_abuse")
            .put("description", description.take(4000))
            .put("evidence_refs", JSONArray())
        api.post("v1/chat/report/${peer.value}", body.toString(), token)
    }

    suspend fun registerPushToken(deviceId: String, fcmToken: String, token: String) {
        val body = JSONObject()
            .put("device_id", deviceId)
            .put("provider", "fcm")
            .put("token", fcmToken)
        api.put("v1/push/token", body.toString(), token)
    }

    suspend fun updateInfo(token: String): AppUpdateInfo {
        val raw = api.get("v1/app/version", token)
        val json = JSONObject(raw)
        return AppUpdateInfo(
            versionCode = json.getInt("version_code"),
            versionName = json.getString("version_name"),
            minSupportedVersionCode = json.getInt("min_supported_version_code"),
            playUrl = json.optString("play_url").takeIf { it.isNotBlank() && it != "null" },
            testDownloadUrl = json.optString("test_download_url").takeIf { it.isNotBlank() && it != "null" },
            releaseNotes = json.optString("release_notes", ""),
        )
    }

    private fun parseDeviceKey(item: JSONObject) = DeviceKeyBundle(
        globalId = GlobalId(item.getLong("global_id")),
        deviceId = item.getString("device_id"),
        identityPublicKeyB64 = item.getString("identity_public_key_b64"),
        prekeyId = item.getString("prekey_id"),
        prekeyPublicKeyB64 = item.getString("prekey_public_key_b64"),
        prekeySignatureB64 = item.getString("prekey_signature_b64"),
        createdAtEpochMs = item.optLong("created_at_epoch_ms", 0),
    )

    private fun parseConversation(item: JSONObject) = ConversationSummaryModel(
        id = item.getString("id"),
        kind = ConversationKind.valueOf(item.getString("conversation_type").uppercase()),
        title = item.getString("title"),
        peerGlobalId = if (item.has("peer_global_id") && !item.isNull("peer_global_id")) GlobalId(item.getLong("peer_global_id")) else null,
        memberCount = item.getInt("member_count"),
        encryptionMode = if (item.getString("encryption_mode") == "e2ee") ChatEncryptionMode.E2EE else ChatEncryptionMode.SERVER,
        lastMessagePreview = item.optString("last_message_preview", ""),
        lastMessageAtEpochMs = if (item.has("last_message_at_epoch_ms") && !item.isNull("last_message_at_epoch_ms")) item.getLong("last_message_at_epoch_ms") else null,
        unreadCount = item.optInt("unread_count", 0),
    )

    private fun parseMessage(item: JSONObject): ChatMessage {
        val attachmentsJson = item.optJSONArray("attachments") ?: JSONArray()
        val attachments = buildList {
            for (i in 0 until attachmentsJson.length()) {
                val a = attachmentsJson.getJSONObject(i)
                add(ChatAttachment(
                    id = a.getString("id"),
                    clientAttachmentId = a.getString("client_attachment_id"),
                    kind = ChatAttachmentKind.valueOf(a.getString("kind").uppercase()),
                    mimeType = a.getString("mime_type"),
                    fileName = a.getString("file_name"),
                    byteSize = a.getInt("byte_size"),
                    nonceB64 = a.optString("nonce_b64").takeIf { it.isNotBlank() && it != "null" },
                ))
            }
        }
        return ChatMessage(
            id = item.getString("id"),
            conversationId = item.getString("conversation_id"),
            senderGlobalId = GlobalId(item.getLong("sender_global_id")),
            clientMessageId = item.getString("client_message_id"),
            messageType = item.optString("message_type", "text"),
            encryptionMode = if (item.getString("encryption_mode") == "e2ee") ChatEncryptionMode.E2EE else ChatEncryptionMode.SERVER,
            body = item.optString("body").takeIf { it.isNotBlank() && it != "null" },
            ciphertextB64 = item.optString("ciphertext_b64").takeIf { it.isNotBlank() && it != "null" },
            nonceB64 = item.optString("nonce_b64").takeIf { it.isNotBlank() && it != "null" },
            keyId = item.optString("key_id").takeIf { it.isNotBlank() && it != "null" },
            ratchetCounter = if (item.has("ratchet_counter") && !item.isNull("ratchet_counter")) item.getInt("ratchet_counter") else null,
            senderEphemeralPublicKeyB64 = item.optString("sender_ephemeral_public_key_b64").takeIf { it.isNotBlank() && it != "null" },
            recipientPrekeyId = item.optString("recipient_prekey_id").takeIf { it.isNotBlank() && it != "null" },
            replyToMessageId = item.optString("reply_to_message_id").takeIf { it.isNotBlank() && it != "null" },
            attachments = attachments,
            status = item.optString("status", "sent"),
            createdAtEpochMs = item.getLong("created_at_epoch_ms"),
            editedAtEpochMs = if (item.has("edited_at_epoch_ms") && !item.isNull("edited_at_epoch_ms")) item.getLong("edited_at_epoch_ms") else null,
            reactions = item.optJSONObject("reactions")?.let { reactions ->
                buildMap {
                    val keys = reactions.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        put(key, reactions.optInt(key, 0))
                    }
                }
            }.orEmpty(),
            deliveredCount = item.optInt("delivered_count", 0),
            readCount = item.optInt("read_count", 0),
        )
    }
}
