@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package org.federationofavatars.brotherhood.ui

import org.federationofavatars.brotherhood.data.VisualAssessmentFactory
import android.Manifest
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.OnlinePrediction
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.Period
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.federationofavatars.brotherhood.R
import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.data.pick
import org.federationofavatars.brotherhood.data.format
import org.federationofavatars.brotherhood.domain.VedicNumerologyEngine
import org.federationofavatars.brotherhood.location.CityLocationResolver
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AppRoute
import org.federationofavatars.brotherhood.model.AppThemeMode
import org.federationofavatars.brotherhood.model.AssessmentDefinition
import org.federationofavatars.brotherhood.model.AuthProvider
import org.federationofavatars.brotherhood.model.Community
import org.federationofavatars.brotherhood.model.CommunityKind
import org.federationofavatars.brotherhood.model.CompatibilityBreakdown
import org.federationofavatars.brotherhood.model.DiscoveryPreferences
import org.federationofavatars.brotherhood.model.FriendCandidate
import org.federationofavatars.brotherhood.model.MainTab
import org.federationofavatars.brotherhood.model.ProfileVisibility
import org.federationofavatars.brotherhood.model.SearchRole
import org.federationofavatars.brotherhood.model.VisualAssessmentChoice
import org.federationofavatars.brotherhood.model.VisualParadigm
import org.federationofavatars.brotherhood.model.VisualSceneArchetype

@Composable
fun BrotherhoodApp(viewModel: MainViewModel) {
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(viewModel.uiMessage) {
        viewModel.uiMessage?.let {
            snackbar.showSnackbar(it)
            viewModel.consumeMessage()
        }
    }

    val layoutDirection = if (viewModel.language.direction.equals("rtl", ignoreCase = true)) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        Box(Modifier.fillMaxSize()) {
            when (viewModel.route) {
            AppRoute.AUTH -> AuthScreen(viewModel)
            AppRoute.HOME -> HomeScaffold(viewModel, snackbar)
            AppRoute.CANDIDATE -> CandidateDetailScreen(viewModel, snackbar)
            AppRoute.COMMUNITY -> CommunityDetailScreen(viewModel, snackbar)
            AppRoute.SETTINGS -> SettingsScreen(viewModel, snackbar)
            AppRoute.EDIT_PROFILE -> EditProfileScreen(viewModel, snackbar)
            AppRoute.SERVICES -> ServicesScreen(viewModel, snackbar)
            AppRoute.MESSAGES -> MessagesScreen(viewModel, snackbar)
            AppRoute.CHAT -> ChatScreen(viewModel, snackbar)
            AppRoute.SELF_ANALYSIS -> SelfAnalysisScreen(viewModel, snackbar)
            AppRoute.TESTS -> TestsOverlayScreen(viewModel, snackbar)
            AppRoute.TRUST -> TrustOverlayScreen(viewModel, snackbar)
            AppRoute.DISCOVERY_FILTERS -> DiscoveryFiltersScreen(viewModel, snackbar)
            }
        }
    }
}

private fun MainViewModel.t(ru: String, uk: String, en: String): String = language.pick(ru, uk, en)

@Composable
private fun LanguageCarousel(
    languages: List<AppLanguage>,
    selected: AppLanguage,
    onSelect: (AppLanguage) -> Unit,
    compact: Boolean,
) {
    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(languages, key = { it.tag }) { language ->
            FilterChip(
                selected = selected.tag.equals(language.tag, ignoreCase = true),
                onClick = { onSelect(language) },
                label = {
                    Text(if (compact) language.tag.uppercase() else "${language.nativeName} · ${language.tag.uppercase()}")
                },
                leadingIcon = if (selected.tag.equals(language.tag, ignoreCase = true)) {
                    { Icon(Icons.Default.CheckCircle, contentDescription = null) }
                } else null,
            )
        }
    }
}

@Composable
private fun AuthScreen(viewModel: MainViewModel) {
    val lang = viewModel.language
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            LanguageCarousel(
                languages = viewModel.supportedLanguages,
                selected = lang,
                onSelect = viewModel::changeLanguage,
                compact = true,
            )

            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Box(
                    Modifier.size(96.dp).clip(RoundedCornerShape(28.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(painterResource(R.drawable.ic_brotherhood_logo), null, Modifier.size(72.dp), tint = Color.Unspecified)
                }
                Spacer(Modifier.height(24.dp))
                Text("Brotherhood", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text(
                    lang.pick("Настоящие друзья для мужчин", "Справжні друзі для чоловіків", "Real friends for men"),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    lang.pick(
                        "Совместимость характера, ценностей и образа жизни. Без романтических знакомств.",
                        "Сумісність характеру, цінностей і способу життя. Без романтичних знайомств.",
                        "Character, values and lifestyle compatibility. No romantic dating."
                    ),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ProviderButton("G", viewModel.t("Продолжить с Google", "Продовжити з Google", "Continue with Google")) { viewModel.signIn(AuthProvider.GOOGLE) }
                ProviderButton("➤", viewModel.t("Продолжить с Telegram", "Продовжити з Telegram", "Continue with Telegram")) { viewModel.signIn(AuthProvider.TELEGRAM) }
                ProviderButton("f", viewModel.t("Продолжить с Facebook", "Продовжити з Facebook", "Continue with Facebook")) { viewModel.signIn(AuthProvider.FACEBOOK) }
                OutlinedButton(onClick = { viewModel.signIn(AuthProvider.EMAIL) }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Icon(Icons.Default.Email, null)
                    Spacer(Modifier.width(10.dp))
                    Text(viewModel.t("Электронная почта", "Електронна пошта", "Email"))
                }
                OutlinedButton(onClick = { viewModel.signIn(AuthProvider.PASSKEY) }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Icon(Icons.Default.Fingerprint, null)
                    Spacer(Modifier.width(10.dp))
                    Text(viewModel.t("Ключ доступа / Passkey", "Ключ доступу / Passkey", "Passkey"))
                }
                Text(
                    viewModel.t("Архитектура допускает подключение новых провайдеров без смены global_id.", "Архітектура дозволяє підключати нових провайдерів без зміни global_id.", "The architecture supports future providers without changing global_id."),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    viewModel.t(
                        "Вход создаёт единый аккаунт global_id. Провайдеры используются только для подтверждения доступа.",
                        "Вхід створює єдиний акаунт global_id. Провайдери використовуються лише для підтвердження доступу.",
                        "Sign-in creates one global_id account. Providers only verify access."
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun ProviderButton(mark: String, title: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(54.dp)) {
        Box(
            Modifier.size(26.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onPrimary.copy(alpha = .14f)),
            contentAlignment = Alignment.Center
        ) { Text(mark, fontWeight = FontWeight.Black) }
        Spacer(Modifier.width(10.dp))
        Text(title)
    }
}

@Composable
private fun HomeScaffold(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showCityDialog by remember { mutableStateOf(false) }
    var locating by remember { mutableStateOf(false) }
    val unreadCount = viewModel.conversations.sumOf { it.unreadCount }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            locating = true
            scope.launch {
                val city = CityLocationResolver.resolveCity(context)
                if (city != null) viewModel.selectCity(city) else viewModel.reportLocationFailure()
                locating = false
            }
        } else viewModel.reportLocationFailure()
    }

    fun requestCityLocation() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locating = true
            scope.launch {
                val city = CityLocationResolver.resolveCity(context)
                if (city != null) viewModel.selectCity(city) else viewModel.reportLocationFailure()
                locating = false
            }
        } else permissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                            Icon(painterResource(R.drawable.ic_brotherhood_logo), null, Modifier.size(34.dp), tint = Color.Unspecified)
                        }
                        Spacer(Modifier.width(9.dp))
                        Column {
                            Text("Brotherhood", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                            Text("ID ${viewModel.profile.globalId.display}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.selectTab(MainTab.MESSAGES) }, modifier = Modifier.size(48.dp)) {
                        Box {
                            Icon(Icons.Default.Chat, null)
                            if (unreadCount > 0) Badge(modifier = Modifier.align(Alignment.TopEnd)) { Text(unreadCount.coerceAtMost(99).toString()) }
                        }
                    }
                    IconButton(onClick = viewModel::openServices, modifier = Modifier.size(48.dp)) { Icon(Icons.Default.AutoAwesome, null) }
                    IconButton(onClick = viewModel::openSettings, modifier = Modifier.size(48.dp)) { Icon(Icons.Default.Settings, null) }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                MainTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = viewModel.selectedTab == tab,
                        onClick = { viewModel.selectTab(tab) },
                        icon = {
                            Box {
                                Icon(tab.icon(), null)
                                if (tab == MainTab.MESSAGES && unreadCount > 0) {
                                    Badge(modifier = Modifier.align(Alignment.TopEnd)) { Text(unreadCount.coerceAtMost(99).toString()) }
                                }
                            }
                        },
                        label = { Text(tab.label(viewModel.language), maxLines = 1, fontSize = 10.sp, overflow = TextOverflow.Ellipsis) }
                    )
                }
            }
        }
    ) { padding ->
        Surface(Modifier.padding(padding).fillMaxSize()) {
            when (viewModel.selectedTab) {
                MainTab.HOME -> DashboardScreen(viewModel)
                MainTab.DISCOVER -> DiscoverScreen(viewModel, locating, { showCityDialog = true }, ::requestCityLocation)
                MainTab.MESSAGES -> MessagesScreen(viewModel, snackbar, embedded = true)
                MainTab.COMMUNITIES -> CommunitiesScreen(viewModel)
                MainTab.PROFILE -> ProfileScreen(viewModel)
            }
        }
    }

    if (showCityDialog) CityDialog(viewModel) { showCityDialog = false }
}

private fun MainTab.icon(): ImageVector = when (this) {
    MainTab.HOME -> Icons.Default.Home
    MainTab.DISCOVER -> Icons.Default.Explore
    MainTab.MESSAGES -> Icons.Default.Chat
    MainTab.COMMUNITIES -> Icons.Default.Groups
    MainTab.PROFILE -> Icons.Default.Person
}

private fun MainTab.label(language: AppLanguage): String = when (this) {
    MainTab.HOME -> language.pick("Главная", "Головна", "Home")
    MainTab.DISCOVER -> language.pick("Люди", "Люди", "People")
    MainTab.MESSAGES -> language.pick("Чаты", "Чати", "Chats")
    MainTab.COMMUNITIES -> language.pick("Группы", "Групи", "Groups")
    MainTab.PROFILE -> language.pick("Профиль", "Профіль", "Profile")
}

@Composable
private fun DashboardScreen(viewModel: MainViewModel) {
    val l = viewModel.language
    val rating = viewModel.accountRating
    val profile = viewModel.profile
    val unread = viewModel.conversations.sumOf { it.unreadCount }

    LaunchedEffect(Unit) { viewModel.refreshConversations() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(26.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BrotherhoodBrandMark(44.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Brotherhood", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                    }
                    Text(
                        l.pick(
                            "Настоящие друзья, совместимость и познание себя.",
                            "Справжні друзі, сумісність і пізнання себе.",
                            "Real friends, compatibility and self-discovery."
                        ),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard(rating.total.toInt().toString(), l.pick("Аккаунт", "Акаунт", "Account"), Modifier.weight(1f))
                        MetricCard(profile.trustScore.toString(), l.pick("Доверие", "Довіра", "Trust"), Modifier.weight(1f))
                        MetricCard("${rating.completedTests}/100", l.pick("Тесты", "Тести", "Tests"), Modifier.weight(1f))
                    }
                    LinearProgressIndicator(
                        progress = { (rating.completedTests / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        item {
            Text(l.pick("Основные функции", "Основні функції", "Core features"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
        }
        item {
            DashboardFeatureCard(
                icon = Icons.Default.Chat,
                title = l.pick("Чаты", "Чати", "Chats"),
                subtitle = l.pick("Личные E2EE-чаты и групповые чаты с фото, аудио, видео и файлами", "Особисті E2EE-чати та групові чати з фото, аудіо, відео й файлами", "Private E2EE chats and group chats with photos, audio, video and files"),
                badge = if (unread > 0) unread.toString() else "E2EE",
                onClick = { viewModel.selectTab(MainTab.MESSAGES) }
            )
        }
        item {
            DashboardFeatureCard(
                icon = Icons.Default.Explore,
                title = l.pick("Совместимость друзей", "Сумісність друзів", "Friend compatibility"),
                subtitle = l.pick("15 взвешенных слоёв совместимости", "15 зважених шарів сумісності", "15 weighted compatibility layers"),
                badge = "15×",
                onClick = { viewModel.selectTab(MainTab.DISCOVER) }
            )
        }
        item {
            DashboardFeatureCard(
                icon = Icons.Default.Psychology,
                title = l.pick("Познание себя", "Пізнання себе", "Know yourself"),
                subtitle = l.pick("Сильные стороны, индивидуальные стили и положительные ресурсы профиля", "Сильні сторони, індивідуальні стилі та позитивні ресурси профілю", "Strengths, individual styles and positive profile resources"),
                badge = "SELF",
                onClick = viewModel::openSelfAnalysis
            )
        }
        item {
            DashboardFeatureCard(
                icon = Icons.Default.CheckCircle,
                title = l.pick("100 психологических тестов", "100 психологічних тестів", "100 psychological tests"),
                subtitle = l.pick("Совместимость мужской дружбы, честность, верность, конфликты, ценности и образ жизни", "Сумісність чоловічої дружби, чесність, вірність, конфлікти, цінності та спосіб життя", "Male friendship compatibility, integrity, loyalty, conflict, values and lifestyle"),
                badge = "${rating.completedTests}/100",
                onClick = viewModel::openTests
            )
        }
        item {
            DashboardFeatureCard(
                icon = Icons.Default.Shield,
                title = l.pick("Доверие и репутация", "Довіра та репутація", "Trust & reputation"),
                subtitle = l.pick("Подтверждённые взаимодействия, нарушения доверия, жалобы и апелляции", "Підтверджені взаємодії, порушення довіри, скарги та апеляції", "Verified interactions, trust incidents, reports and appeals"),
                badge = "${profile.trustScore}/100",
                onClick = viewModel::openTrust
            )
        }

        item {
            Text(l.pick("Мой психологический профиль", "Мій психологічний профіль", "My profile systems"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
        }
        item {
            DashboardFeatureCard(
                icon = Icons.Default.Fingerprint,
                title = "Brotherhood-32",
                subtitle = "${profile.personality32.code} · ${profile.personality32.title(l)}",
                badge = "32",
                onClick = viewModel::openTests
            )
        }
        item {
            DashboardFeatureCard(
                icon = Icons.Default.Psychology,
                title = l.pick("Эннеаграмма", "Еннеаграма", "Enneagram"),
                subtitle = "${profile.enneagram.type}w${profile.enneagram.wing ?: 0} · ${profile.enneagram.title(l)}",
                badge = "9",
                onClick = viewModel::openTests
            )
        }
        item {
            DashboardFeatureCard(
                icon = Icons.Default.Star,
                title = l.pick("Зодиак", "Зодіак", "Zodiac"),
                subtitle = "${profile.zodiac.symbol} ${profile.zodiac.label(l)}",
                badge = profile.zodiac.symbol,
                onClick = viewModel::openSelfAnalysis
            )
        }
        item {
            DashboardFeatureCard(
                icon = Icons.Default.Star,
                title = l.pick("Ведическая нумерология", "Ведична нумерологія", "Vedic numerology"),
                subtitle = l.pick(
                    "Автоматический расчёт по дате рождения: число души ${profile.numerology.soulNumber}, число судьбы ${profile.numerology.destinyNumber}",
                    "Автоматичний розрахунок за датою народження: число душі ${profile.numerology.soulNumber}, число долі ${profile.numerology.destinyNumber}",
                    "Automatic birth-date calculation: soul ${profile.numerology.soulNumber}, destiny ${profile.numerology.destinyNumber}"
                ),
                badge = "${profile.numerology.soulNumber}/${profile.numerology.destinyNumber}",
                onClick = viewModel::openSelfAnalysis
            )
        }
        item {
            DashboardFeatureCard(
                icon = Icons.Default.BusinessCenter,
                title = l.pick("Сообщества и бизнес", "Спільноти та бізнес", "Communities & business"),
                subtitle = l.pick("Футбол, спорт, автомобили, города, предпринимательство, команды и проекты", "Футбол, спорт, автомобілі, міста, підприємництво, команди та проєкти", "Football, sports, cars, cities, entrepreneurship, teams and projects"),
                badge = l.pick("ГРУППЫ", "ГРУПИ", "GROUPS"),
                onClick = { viewModel.selectTab(MainTab.COMMUNITIES) }
            )
        }
        item {
            OutlinedButton(onClick = viewModel::openServices, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Icon(Icons.Default.AutoAwesome, null)
                Spacer(Modifier.width(8.dp))
                Text(l.pick("Все сервисы Brotherhood", "Усі сервіси Brotherhood", "All Brotherhood services"))
            }
        }
    }
}

@Composable
private fun DashboardFeatureCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badge: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(badge, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(6.dp))
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DiscoveryFiltersScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    var prefs by remember { mutableStateOf(viewModel.discoveryPreferences) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(viewModel.t("Фильтры поиска", "Фільтри пошуку", "Discovery filters"), fontWeight = FontWeight.Black) },
                navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FilterAlt, null, Modifier.size(30.dp))
                            Spacer(Modifier.width(10.dp))
                            Text(viewModel.t("Кого показывать", "Кого показувати", "Who to show"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        }
                        Text(
                            viewModel.t(
                                "Фильтры хранятся на устройстве и применяются поверх расчёта совместимости.",
                                "Фільтри зберігаються на пристрої та застосовуються поверх розрахунку сумісності.",
                                "Filters are stored on-device and applied on top of compatibility scoring."
                            ),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(viewModel.t("Кого вы ищете", "Кого ви шукаєте", "Who are you looking for"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                        Text(
                            viewModel.t(
                                "Вы сами задаёте роль и качества. Brotherhood подбирает людей, которые лучше соответствуют вашему запросу.",
                                "Ви самі задаєте роль і якості. Brotherhood добирає людей, які краще відповідають вашому запиту.",
                                "You choose the role and qualities. Brotherhood finds people who best fit your request."
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(viewModel.searchRoles) { role ->
                                FilterChip(
                                    selected = viewModel.searchIntent.role == role,
                                    onClick = { viewModel.setSearchRole(role) },
                                    label = { Text(searchRoleLabel(role, viewModel.language)) }
                                )
                            }
                        }
                        viewModel.searchQualityDefinitions.groupBy { it.group }.forEach { (group, qualities) ->
                            Text(qualityGroupLabel(group, viewModel.language), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                items(qualities) { quality ->
                                    val selected = viewModel.searchIntent.qualities.any { it.key == quality.key }
                                    FilterChip(
                                        selected = selected,
                                        onClick = { viewModel.toggleDesiredQuality(quality.key) },
                                        label = { Text(quality.label.get(viewModel.language)) }
                                    )
                                }
                            }
                        }
                        if (viewModel.searchIntent.qualities.isNotEmpty()) {
                            Text(viewModel.t("Приоритет выбранных качеств", "Пріоритет вибраних якостей", "Priority of selected qualities"), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            viewModel.searchIntent.qualities.forEach { desired ->
                                val definition = viewModel.searchQualityDefinitions.firstOrNull { it.key == desired.key }
                                if (definition != null) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(definition.label.get(viewModel.language), style = MaterialTheme.typography.bodySmall)
                                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            items((1..5).toList()) { level ->
                                                FilterChip(
                                                    selected = desired.importance == level,
                                                    onClick = { viewModel.setDesiredQualityImportance(desired.key, level) },
                                                    label = { Text(level.toString()) }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            TextButton(onClick = viewModel::clearDesiredQualities) { Text(viewModel.t("Очистить качества", "Очистити якості", "Clear qualities")) }
                        } else {
                            Text(
                                viewModel.t("Качества не выбраны — порядок остаётся по обычной совместимости.", "Якості не вибрані — порядок залишається за звичайною сумісністю.", "No qualities selected — ordering stays based on canonical compatibility."),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            item {
                PreferenceSwitchRow(
                    icon = Icons.Default.Verified,
                    title = viewModel.t("Только подтверждённые", "Лише підтверджені", "Verified only"),
                    subtitle = viewModel.t("Показывать аккаунты с подтверждённой личностью", "Показувати акаунти з підтвердженою особою", "Show identity-verified accounts"),
                    checked = prefs.verifiedOnly,
                    onChecked = { prefs = prefs.copy(verifiedOnly = it) }
                )
            }
            item {
                PreferenceSwitchRow(
                    icon = Icons.Default.OnlinePrediction,
                    title = viewModel.t("Сейчас онлайн", "Зараз онлайн", "Online now"),
                    subtitle = viewModel.t("Показывать только активных пользователей", "Показувати лише активних користувачів", "Show currently active users only"),
                    checked = prefs.onlineOnly,
                    onChecked = { prefs = prefs.copy(onlineOnly = it) }
                )
            }
            item {
                PreferenceSwitchRow(
                    icon = Icons.Default.Star,
                    title = viewModel.t("Общие интересы обязательны", "Спільні інтереси обов’язкові", "Require shared interests"),
                    subtitle = viewModel.t("Хотя бы один общий интерес", "Щонайменше один спільний інтерес", "At least one shared interest"),
                    checked = prefs.requireSharedInterests,
                    onChecked = { prefs = prefs.copy(requireSharedInterests = it) }
                )
            }
            item {
                PreferenceSwitchRow(
                    icon = Icons.Default.People,
                    title = viewModel.t("Скрывать уже отправленные запросы", "Приховувати вже надіслані запити", "Hide requested profiles"),
                    subtitle = viewModel.t("Не показывать повторно тех, кому уже отправлен запрос дружбы", "Не показувати повторно тих, кому вже надіслано запит дружби", "Do not repeat profiles already requested"),
                    checked = prefs.hideRequested,
                    onChecked = { prefs = prefs.copy(hideRequested = it) }
                )
            }
            item {
                ThresholdSelector(
                    title = viewModel.t("Минимальная совместимость", "Мінімальна сумісність", "Minimum compatibility"),
                    value = prefs.minCompatibility,
                    values = listOf(0, 60, 75, 85, 90),
                    onValue = { prefs = prefs.copy(minCompatibility = it) }
                )
            }
            item {
                ThresholdSelector(
                    title = viewModel.t("Минимальное доверие", "Мінімальна довіра", "Minimum trust"),
                    value = prefs.minTrust,
                    values = listOf(0, 60, 75, 85, 90),
                    onValue = { prefs = prefs.copy(minTrust = it) }
                )
            }
            item {
                Text(viewModel.t("Видимость моего профиля", "Видимість мого профілю", "My profile visibility"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ProfileVisibility.entries) { visibility ->
                        FilterChip(
                            selected = viewModel.profileVisibility == visibility,
                            onClick = { viewModel.changeProfileVisibility(visibility) },
                            label = {
                                Text(
                                    when (visibility) {
                                        ProfileVisibility.DISCOVERABLE -> viewModel.t("В поиске", "У пошуку", "Discoverable")
                                        ProfileVisibility.CONNECTIONS -> viewModel.t("Только связи", "Лише зв’язки", "Connections")
                                        ProfileVisibility.PRIVATE -> viewModel.t("Скрыт", "Приховано", "Private")
                                    }
                                )
                            }
                        )
                    }
                }
                Text(
                    viewModel.t(
                        "Если профиль скрыт, сервер не должен выдавать его новым пользователям в поиске.",
                        "Якщо профіль приховано, сервер не повинен показувати його новим користувачам у пошуку.",
                        "A private profile is excluded from new-user discovery by the server."
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                Card(shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(viewModel.t("Город поиска", "Місто пошуку", "Search city"), fontWeight = FontWeight.Bold)
                        Text(viewModel.cityLabel(viewModel.selectedCity), style = MaterialTheme.typography.titleMedium)
                        if (viewModel.selectedCity != viewModel.profile.city) {
                            Text(viewModel.t("Passport mode: ищем друзей в другом городе", "Passport mode: шукаємо друзів в іншому місті", "Passport mode: discovering another city"), color = MaterialTheme.colorScheme.primary)
                        }
                        Text(viewModel.t("Город можно изменить на вкладке «Люди».", "Місто можна змінити на вкладці «Люди».", "Change city from the People tab."), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Button(
                    onClick = {
                        viewModel.updateDiscoveryPreferences(prefs)
                        viewModel.closeOverlay()
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, null)
                    Spacer(Modifier.width(8.dp))
                    Text(viewModel.t("Сохранить фильтры", "Зберегти фільтри", "Save filters"))
                }
            }
            if (viewModel.skippedCandidateIds.isNotEmpty()) {
                item {
                    OutlinedButton(onClick = viewModel::resetSkippedCandidates, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                        Icon(Icons.Default.Undo, null)
                        Spacer(Modifier.width(8.dp))
                        Text(viewModel.t("Вернуть пропущенных (${viewModel.skippedCandidateIds.size})", "Повернути пропущених (${viewModel.skippedCandidateIds.size})", "Restore skipped (${viewModel.skippedCandidateIds.size})"))
                    }
                }
            }
        }
    }
}

private fun searchRoleLabel(role: SearchRole, language: AppLanguage): String = when (role) {
    SearchRole.FRIEND -> language.pick("Друг", "Друг", "Friend")
    SearchRole.CLOSE_FRIEND -> language.pick("Близкий друг", "Близький друг", "Close friend")
    SearchRole.BUSINESS_PARTNER -> language.pick("Бизнес-партнёр", "Бізнес-партнер", "Business partner")
    SearchRole.DIRECTOR -> language.pick("Руководитель / директор", "Керівник / директор", "Director / manager")
    SearchRole.PROJECT_TEAMMATE -> language.pick("Участник проекта", "Учасник проєкту", "Project teammate")
    SearchRole.MENTOR -> language.pick("Наставник", "Наставник", "Mentor")
    SearchRole.ACTIVITY_PARTNER -> language.pick("Партнёр по занятиям", "Партнер для занять", "Activity partner")
    SearchRole.CUSTOM -> language.pick("Другая роль", "Інша роль", "Other role")
}

private fun qualityGroupLabel(group: String, language: AppLanguage): String = when (group) {
    "friendship" -> language.pick("Дружба", "Дружба", "Friendship")
    "communication" -> language.pick("Общение", "Спілкування", "Communication")
    "character" -> language.pick("Характер", "Характер", "Character")
    "business" -> language.pick("Бизнес и работа", "Бізнес і робота", "Business & work")
    "leadership" -> language.pick("Руководство", "Керівництво", "Leadership")
    "lifestyle" -> language.pick("Стиль жизни", "Стиль життя", "Lifestyle")
    else -> group
}

@Composable
private fun PreferenceSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChecked: (Boolean) -> Unit,
) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) {
                Icon(icon, null)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = checked, onCheckedChange = onChecked)
        }
    }
}

@Composable
private fun ThresholdSelector(
    title: String,
    value: Int,
    values: List<Int>,
    onValue: (Int) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(values) { threshold ->
                FilterChip(
                    selected = value == threshold,
                    onClick = { onValue(threshold) },
                    label = { Text(if (threshold == 0) "0+" else "$threshold+") }
                )
            }
        }
    }
}

@Composable
private fun TestsOverlayScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(viewModel.t("100 психологических тестов", "100 психологічних тестів", "100 psychological tests"), fontWeight = FontWeight.Black) },
                navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) { TestsScreen(viewModel) }
    }
}

@Composable
private fun TrustOverlayScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(viewModel.t("Доверие", "Довіра", "Trust"), fontWeight = FontWeight.Black) },
                navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) { TrustScreen(viewModel) }
    }
}

@Composable
private fun DiscoverScreen(viewModel: MainViewModel, locating: Boolean, onChooseCity: () -> Unit, onLocate: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(viewModel.t("Найди настоящего друга", "Знайди справжнього друга", "Find a real friend"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text(
                viewModel.t("Для дружбы, взаимопомощи, спорта и совместных дел", "Для дружби, взаємодопомоги, спорту та спільних справ", "For friendship, mutual support, sports and shared projects"),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item { DiscoveryHero(viewModel) }
        item { LocationControls(viewModel, locating, onChooseCity, onLocate) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf(10, 25, 50, 100)) { radius ->
                    FilterChip(selected = viewModel.radiusKm == radius, onClick = { viewModel.setRadius(radius) }, label = { Text("$radius km") })
                }
            }
        }
        if (viewModel.candidates.isNotEmpty()) {
            item {
                Text(viewModel.t("Быстрый выбор", "Швидкий вибір", "Quick discovery"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    viewModel.t(
                        "Просматривайте кандидатов по одному: пропустить, изучить совместимость или отправить запрос дружбы.",
                        "Переглядайте кандидатів по одному: пропустити, вивчити сумісність або надіслати запит дружби.",
                        "Review one candidate at a time: skip, inspect compatibility, or send a friendship request."
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item { QuickDiscoveryCard(viewModel, viewModel.candidates.first()) }
            if (viewModel.lastSkippedCandidateId != null) {
                item {
                    TextButton(onClick = viewModel::undoLastSkip, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Undo, null)
                        Spacer(Modifier.width(6.dp))
                        Text(viewModel.t("Вернуть последнего пропущенного", "Повернути останнього пропущеного", "Undo last skip"))
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(viewModel.t("Лучшие совпадения", "Найкращі збіги", "Best matches"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                IconButton(onClick = viewModel::openDiscoveryFilters) { Icon(Icons.Default.Tune, null) }
            }
        }
        if (viewModel.candidates.isEmpty()) {
            item { EmptyState(viewModel.t("Нет кандидатов по текущим фильтрам", "Немає кандидатів за поточними фільтрами", "No candidates match current filters")) }
            if (viewModel.skippedCandidateIds.isNotEmpty()) {
                item {
                    OutlinedButton(onClick = viewModel::resetSkippedCandidates, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                        Icon(Icons.Default.Undo, null)
                        Spacer(Modifier.width(8.dp))
                        Text(viewModel.t("Вернуть пропущенных", "Повернути пропущених", "Restore skipped"))
                    }
                }
            }
        } else {
            items(viewModel.candidates, key = { it.globalId.value }) { candidate ->
                CandidateCard(viewModel, candidate)
            }
        }
    }
}

@Composable
private fun DiscoveryHero(viewModel: MainViewModel) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(28.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(viewModel.t("Совместимость настоящей дружбы", "Сумісність справжньої дружби", "Real friendship compatibility"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                Text(
                    viewModel.t(
                        "100 психологических тестов + характер + ценности + образ жизни + Brotherhood‑32 + эннеаграмма + зодиак + ведическая нумерология.",
                        "100 психологічних тестів + характер + цінності + спосіб життя + Brotherhood‑32 + еннеаграма + зодіак + ведична нумерологія.",
                        "100 psychological tests + character + values + lifestyle + Brotherhood‑32 + Enneagram + zodiac + Vedic numerology."
                    ),
                    style = MaterialTheme.typography.bodyMedium
                )
                AssistChip(onClick = { viewModel.openTests() }, label = { Text(viewModel.t("Продолжить тесты", "Продовжити тести", "Continue tests")) }, leadingIcon = { Icon(Icons.Default.AutoAwesome, null) })
            }
            Spacer(Modifier.width(14.dp))
            ScoreRing(viewModel.accountRating.total.toInt(), 82.dp, viewModel.t("рейтинг", "рейтинг", "rating"))
        }
    }
}

@Composable
private fun LocationControls(viewModel: MainViewModel, locating: Boolean, onChooseCity: () -> Unit, onLocate: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f))) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationCity, null)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(viewModel.t("Город поиска", "Місто пошуку", "Search city"), style = MaterialTheme.typography.labelMedium)
                    Text(viewModel.cityLabel(viewModel.selectedCity), fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onChooseCity) { Text(viewModel.t("Изменить", "Змінити", "Change")) }
            }
            OutlinedButton(onClick = onLocate, enabled = !locating, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.MyLocation, null)
                Spacer(Modifier.width(8.dp))
                Text(if (locating) viewModel.t("Определяем город…", "Визначаємо місто…", "Detecting city…") else viewModel.t("Определить мой город", "Визначити моє місто", "Detect my city"))
            }
            viewModel.locationStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun QuickDiscoveryCard(viewModel: MainViewModel, candidate: FriendCandidate) {
    val shared = viewModel.profile.interests.intersect(candidate.interests.toSet()).take(4)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = .72f))
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(candidate.name, candidate.online)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${candidate.name}, ${candidate.age}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        if (candidate.verified) {
                            Spacer(Modifier.width(6.dp))
                            Icon(Icons.Default.Verified, null, Modifier.size(19.dp), tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Text("${viewModel.cityLabel(candidate.city)} · ${candidate.distanceKm} km", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${candidate.personality32.code} · ${candidate.personality32.title(viewModel.language)}", style = MaterialTheme.typography.labelMedium)
                }
                ScoreRing(candidate.compatibility, 76.dp, viewModel.t("совм.", "сум.", "match"))
            }
            if (viewModel.searchIntent.qualities.isNotEmpty()) {
                Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tune, null)
                        Spacer(Modifier.width(8.dp))
                        Text(viewModel.t("Соответствие выбранным качествам", "Відповідність вибраним якостям", "Fit to selected qualities"), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        Text("${candidate.qualityFit}%", fontWeight = FontWeight.Black)
                    }
                }
            }
            if (candidate.positiveQualities.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) { items(candidate.positiveQualities.take(4)) { TraitChip(it) } }
            }
            if (shared.isNotEmpty()) {
                Text(viewModel.t("Общие интересы", "Спільні інтереси", "Shared interests"), style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) { items(shared) { TraitChip(it) } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { viewModel.skipCandidate(candidate) },
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(Icons.Default.Close, null)
                    Spacer(Modifier.width(6.dp))
                    Text(viewModel.t("Пропустить", "Пропустити", "Skip"))
                }
                FilledTonalButton(
                    onClick = { viewModel.openCandidate(candidate) },
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(Icons.Default.Explore, null)
                    Spacer(Modifier.width(6.dp))
                    Text(viewModel.t("Подробнее", "Докладніше", "Details"))
                }
                Button(
                    onClick = {
                        viewModel.requestConnection(candidate)
                        viewModel.showMessage(viewModel.t("Запрос дружбы отправлен", "Запит дружби надіслано", "Friend request sent"))
                    },
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(Icons.Default.People, null)
                }
            }
        }
    }
}

@Composable
private fun CandidateCard(viewModel: MainViewModel, candidate: FriendCandidate) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { viewModel.openCandidate(candidate) },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(candidate.name, candidate.online)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${candidate.name}, ${candidate.age}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (candidate.verified) {
                            Spacer(Modifier.width(5.dp))
                            Icon(Icons.Default.Verified, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.secondary)
                        }
                    }
                    Text("${viewModel.cityLabel(candidate.city)} · ${candidate.distanceKm} km · ID ${candidate.globalId.display}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${candidate.personality32.code} · ${candidate.personality32.title(viewModel.language)}", style = MaterialTheme.typography.labelMedium)
                }
                ScoreRing(candidate.compatibility, 64.dp, viewModel.t("совм.", "сум.", "match"))
            }
            if (viewModel.searchIntent.qualities.isNotEmpty()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(viewModel.t("Под ваши качества", "Під ваші якості", "Your quality fit"), fontWeight = FontWeight.Bold)
                    Text("${candidate.qualityFit}%", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                }
            }
            if (candidate.positiveQualities.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) { items(candidate.positiveQualities.take(5)) { TraitChip(it) } }
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) { items(candidate.interests.take(4)) { TraitChip(it) } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniStat(Icons.Default.Shield, candidate.trustScore.toString(), viewModel.t("доверие", "довіра", "trust"), Modifier.weight(1f))
                MiniStat(Icons.Default.Star, candidate.accountRating.toString(), viewModel.t("аккаунт", "акаунт", "account"), Modifier.weight(1f))
                MiniStat(Icons.Default.AutoAwesome, "${candidate.enneagram.type}w${candidate.enneagram.wing}", "Enneagram", Modifier.weight(1f))
                MiniStat(Icons.Default.CalendarMonth, candidate.zodiac.symbol, viewModel.t("зодиак", "зодіак", "zodiac"), Modifier.weight(1f))
            }
            Button(onClick = { viewModel.openCandidate(candidate) }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(viewModel.t("Открыть совместимость", "Відкрити сумісність", "Open compatibility"))
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Default.ChevronRight, null)
            }
        }
    }
}

@Composable
private fun BrotherhoodBrandMark(size: androidx.compose.ui.unit.Dp) {
    Icon(
        painter = painterResource(R.drawable.ic_brotherhood_logo),
        contentDescription = "Brotherhood",
        modifier = Modifier.size(size),
        tint = Color.Unspecified,
    )
}

@Composable
private fun Avatar(name: String, online: Boolean, imagePath: String? = null, size: androidx.compose.ui.unit.Dp = 56.dp) {
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, imagePath) {
        value = if (imagePath.isNullOrBlank()) null else withContext(Dispatchers.IO) {
            runCatching { BitmapFactory.decodeFile(imagePath) }.getOrNull()
        }
    }
    Box(Modifier.size(size)) {
        Box(
            Modifier.fillMaxSize().clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer),
            contentAlignment = Alignment.Center
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = requireNotNull(bitmap).asImageBitmap(),
                    contentDescription = name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Text(name.take(1).uppercase(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            }
        }
        if (online) {
            val onlineDotSize = if (size < 48.dp) 12.dp else 14.dp
            Box(
                Modifier.size(onlineDotSize).align(Alignment.BottomEnd).clip(CircleShape)
                    .background(Color(0xFF2ECC71)).border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
            )
        }
    }
}

@Composable
private fun ScoreRing(score: Int, size: androidx.compose.ui.unit.Dp, label: String) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(progress = { score.coerceIn(0, 100) / 100f }, modifier = Modifier.fillMaxSize(), strokeWidth = 7.dp, trackColor = MaterialTheme.colorScheme.surfaceVariant)
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$score%", fontWeight = FontWeight.Black, fontSize = if (size > 70.dp) 18.sp else 14.sp)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun TraitChip(text: String) {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceVariant) {
        Text(text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun MiniStat(icon: ImageVector, value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
        Text(value, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
private fun CommunitiesScreen(viewModel: MainViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text(viewModel.t("Мужские сообщества", "Чоловічі спільноти", "Men's communities"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text(viewModel.t("Интересы, спорт, автомобили, взаимопомощь и бизнес", "Інтереси, спорт, автомобілі, взаємодопомога та бізнес", "Interests, sports, cars, mutual support and business"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = viewModel.communityKind == CommunityKind.INTEREST,
                    onClick = { viewModel.selectCommunityKind(CommunityKind.INTEREST) },
                    label = { Text(viewModel.t("Интересы", "Інтереси", "Interests")) },
                    leadingIcon = { Icon(Icons.Default.Groups, null) }
                )
                FilterChip(
                    selected = viewModel.communityKind == CommunityKind.BUSINESS,
                    onClick = { viewModel.selectCommunityKind(CommunityKind.BUSINESS) },
                    label = { Text(viewModel.t("Бизнес", "Бізнес", "Business")) },
                    leadingIcon = { Icon(Icons.Default.BusinessCenter, null) }
                )
            }
        }
        item { CommunityHero(viewModel) }
        items(viewModel.communities, key = Community::id) { community -> CommunityCard(viewModel, community) }
        item {
            OutlinedButton(onClick = { viewModel.showMessage(viewModel.t("Форма создания группы открыта", "Форму створення групи відкрито", "Create group form opened")) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(8.dp))
                Text(viewModel.t("Создать своё сообщество", "Створити свою спільноту", "Create your community"))
            }
        }
    }
}

@Composable
private fun CommunityHero(viewModel: MainViewModel) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), shape = RoundedCornerShape(24.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (viewModel.communityKind == CommunityKind.BUSINESS) Icons.Default.Work else Icons.Default.People, null, Modifier.size(42.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    if (viewModel.communityKind == CommunityKind.BUSINESS) viewModel.t("Деловые связи с правилами доверия", "Ділові зв’язки з правилами довіри", "Business connections with trust rules")
                    else viewModel.t("Общие интересы превращаются в дружбу", "Спільні інтереси перетворюються на дружбу", "Shared interests become friendship"),
                    fontWeight = FontWeight.Bold
                )
                Text(viewModel.t("По городу или онлайн. Можно включить доступ только для подтверждённых аккаунтов.", "За містом або онлайн. Можна увімкнути доступ лише для підтверджених акаунтів.", "Local or online. Verified-only access can be enabled."), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun CommunityCard(viewModel: MainViewModel, community: Community) {
    Card(modifier = Modifier.fillMaxWidth().clickable { viewModel.openCommunity(community) }, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                    Icon(if (community.kind == CommunityKind.BUSINESS) Icons.Default.BusinessCenter else Icons.Default.Groups, null)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(community.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${community.category} · ${viewModel.cityLabel(community.city)} · ${community.members}", style = MaterialTheme.typography.bodySmall)
                }
                if (community.verifiedOnly) Icon(Icons.Default.Verified, null, tint = MaterialTheme.colorScheme.secondary)
            }
            Text(community.description, style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                if (community.online) TraitChip(viewModel.t("Онлайн", "Онлайн", "Online"))
                if (community.verifiedOnly) TraitChip(viewModel.t("Только проверенные", "Лише перевірені", "Verified only"))
            }
            FilledTonalButton(onClick = { viewModel.toggleCommunityMembership(community) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (community.joined) viewModel.t("Вы участник", "Ви учасник", "Joined") else viewModel.t("Вступить", "Вступити", "Join"))
            }
        }
    }
}

@Composable
private fun TestsScreen(viewModel: MainViewModel) {
    if (viewModel.activeAssessment != null) {
        AssessmentDialog(viewModel)
        return
    }

    var coreModule by remember { mutableStateOf<String?>(null) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text(viewModel.t("Профиль совместимости", "Профіль сумісності", "Compatibility profile"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text(viewModel.t("Не один ярлык, а многослойная модель мужской дружбы", "Не один ярлик, а багатошарова модель чоловічої дружби", "Not one label, but a layered model of male friendship"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { TestProgressCard(viewModel) }
        item {
            Text(viewModel.t("Основные модели личности", "Основні моделі особистості", "Core personality models"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                CoreModelCard(Icons.Default.Psychology, "Brotherhood‑32", viewModel.profile.personality32.title(viewModel.language), viewModel.profile.personality32.code) { viewModel.startCoreAssessment("p32") }
                CoreModelCard(Icons.Default.Fingerprint, viewModel.t("Эннеаграмма", "Еннеаграма", "Enneagram"), viewModel.profile.enneagram.title(viewModel.language), "${viewModel.profile.enneagram.type}w${viewModel.profile.enneagram.wing}") { viewModel.startCoreAssessment("enneagram") }
                CoreModelCard(Icons.Default.CalendarMonth, viewModel.t("Зодиак", "Зодіак", "Zodiac"), viewModel.profile.zodiac.label(viewModel.language), viewModel.profile.zodiac.symbol) { coreModule = "zodiac" }
                CoreModelCard(Icons.Default.AutoAwesome, viewModel.t("Ведическая нумерология", "Ведична нумерологія", "Vedic numerology"), viewModel.t("Число души ${viewModel.profile.numerology.soulNumber}", "Число душі ${viewModel.profile.numerology.soulNumber}", "Soul number ${viewModel.profile.numerology.soulNumber}"), "${viewModel.profile.numerology.destinyNumber}") { coreModule = "numerology" }
            }
        }
        item {
            Text(viewModel.t("100 психологических тестов дружбы", "100 психологічних тестів дружби", "100 psychological friendship tests"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(viewModel.t("Каждый завершённый тест добавляет 0,5% к рейтингу аккаунта", "Кожен завершений тест додає 0,5% до рейтингу акаунта", "Each completed test adds 0.5% to account rating"), style = MaterialTheme.typography.bodySmall)
        }
        items(viewModel.assessmentDefinitions, key = AssessmentDefinition::id) { assessment ->
            AssessmentCard(viewModel, assessment)
        }
    }

    if (viewModel.activeCoreModule != null) {
        CoreProfileAssessmentDialog(viewModel)
    }
    coreModule?.let { module ->
        CoreModuleDialog(viewModel, module) { coreModule = null }
    }
}

@Composable
private fun TestProgressCard(viewModel: MainViewModel) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(26.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ScoreRing(viewModel.accountRating.total.toInt(), 76.dp, viewModel.t("аккаунт", "акаунт", "account"))
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(viewModel.t("Рейтинг аккаунта", "Рейтинг акаунта", "Account rating"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    Text(viewModel.t("50% профиль + 50% тесты", "50% профіль + 50% тести", "50% profile + 50% tests"))
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { viewModel.completedResults.size / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("${viewModel.completedResults.size}/100 · ${viewModel.accountRating.testPoints}%", style = MaterialTheme.typography.labelSmall)
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .2f))
            Text(
                viewModel.t(
                    "Детальные психологические выводы остаются внутри алгоритма. В профиле показываются только ваши сильные стороны.",
                    "Детальні психологічні висновки залишаються всередині алгоритму. У профілі показуються лише ваші сильні сторони.",
                    "Detailed psychological inferences stay inside the matching algorithm. Your profile shows only strengths."
                ),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun CoreModelCard(icon: ImageVector, title: String, subtitle: String, badge: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) { Icon(icon, null) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.primaryContainer) { Text(badge, Modifier.padding(horizontal = 9.dp, vertical = 6.dp), fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun AssessmentCard(viewModel: MainViewModel, assessment: AssessmentDefinition) {
    val completed = viewModel.completedResults[assessment.id]
    Card(shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${assessment.id.removePrefix("f").toInt()} / 100", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.weight(1f))
                Text(if (completed == null) "+0.5%" else "✓ +0.5%", fontWeight = FontWeight.Bold)
            }
            Text(viewModel.language.format("assessment.visual_series", "Визуальная серия #{number}", "Візуальна серія #{number}", "Visual series #{number}", mapOf("number" to assessment.id.removePrefix("f"))), fontWeight = FontWeight.Bold)
            Text(
                viewModel.t("6 быстрых выборов без правильного ответа", "6 швидких виборів без правильної відповіді", "6 quick choices with no correct answer"),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(onClick = { viewModel.startAssessment(assessment.id) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (completed == null) viewModel.t("Начать", "Почати", "Start") else viewModel.t("Пройти заново", "Пройти знову", "Retake"))
            }
        }
    }
}

@Composable
private fun AssessmentDialog(viewModel: MainViewModel) {
    val assessment = viewModel.activeAssessment ?: return
    val question = viewModel.currentQuestion ?: return
    AlertDialog(
        onDismissRequest = viewModel::closeAssessment,
        confirmButton = {},
        title = {
            Column {
                Text(viewModel.language.format("assessment.visual_series", "Визуальная серия #{number}", "Візуальна серія #{number}", "Visual series #{number}", mapOf("number" to assessment.id.removePrefix("f"))), fontWeight = FontWeight.Black)
                Text("${viewModel.currentQuestionIndex + 1}/${assessment.questions.size}", style = MaterialTheme.typography.labelMedium)
                LinearProgressIndicator(progress = { (viewModel.currentQuestionIndex + 1f) / assessment.questions.size }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    viewModel.t(
                        "Выберите вариант, который первым кажется вам наиболее естественным.",
                        "Оберіть варіант, який першим здається вам найбільш природним.",
                        "Choose the option that first feels most natural."
                    ),
                    style = MaterialTheme.typography.bodyMedium
                )
                VisualChoiceGrid(
                    paradigm = question.paradigm,
                    sceneArchetype = question.sceneArchetype,
                    seed = question.visualSeed,
                    compositionVariant = question.compositionVariant,
                    choices = question.choices,
                    selected = viewModel.assessmentAnswers[question.id],
                    onSelect = viewModel::selectAssessmentAnswer,
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = viewModel::previousAssessmentQuestion, enabled = viewModel.currentQuestionIndex > 0) { Text(viewModel.t("Назад", "Назад", "Back")) }
                    if (viewModel.currentQuestionIndex == assessment.questions.lastIndex) {
                        Button(onClick = viewModel::finishAssessment, enabled = viewModel.canFinishAssessment) { Text(viewModel.t("Завершить", "Завершити", "Finish")) }
                    } else {
                        Button(onClick = viewModel::nextAssessmentQuestion, enabled = viewModel.assessmentAnswers[question.id] in 1..4) { Text(viewModel.t("Далее", "Далі", "Next")) }
                    }
                }
                viewModel.currentResult?.let {
                    InfoPanel(
                        viewModel.t("Готово", "Готово", "Complete"),
                        viewModel.t(
                            "Готово. Результат серии учтён при персональном подборе.",
                            "Готово. Результат серії враховано під час персонального добору.",
                            "Done. This series is now included in personalized matching."
                        )
                    )
                    Button(onClick = viewModel::closeAssessment, modifier = Modifier.fillMaxWidth()) { Text(viewModel.t("Закрыть", "Закрити", "Close")) }
                }
            }
        }
    )
}

@Composable
private fun VisualChoiceGrid(
    paradigm: VisualParadigm,
    sceneArchetype: VisualSceneArchetype,
    seed: Int,
    compositionVariant: Int,
    choices: List<VisualAssessmentChoice>,
    selected: Int?,
    onSelect: (Int) -> Unit,
) {
    val presentedChoices = remember(seed, choices) {
        VisualAssessmentFactory.presentedChoices(choices, seed)
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        presentedChoices.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { choice ->
                    val answerValue = choice.id.toInt()
                    Card(
                        modifier = Modifier.weight(1f).height(132.dp).clickable { onSelect(answerValue) }
                            .then(if (selected == answerValue) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(18.dp)) else Modifier),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f))
                    ) {
                        VisualAssociationCanvas(paradigm, sceneArchetype, seed, compositionVariant, choice)
                    }
                }
            }
        }
    }
}

@Composable
private fun VisualAssociationCanvas(paradigm: VisualParadigm, sceneArchetype: VisualSceneArchetype, seed: Int, compositionVariant: Int, choice: VisualAssessmentChoice) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val outline = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .55f)
    Canvas(Modifier.fillMaxSize().padding(12.dp)) {
        val w = size.width
        val h = size.height
        val l = choice.layout
        val intensity01 = l.intensity / 3f
        val spacing01 = l.spacing / 3f
        val order01 = l.order / 3f
        val asymmetry01 = l.asymmetry / 3f
        val directionCentered = (l.direction - 1.5f) / 1.5f
        val variant = compositionVariant.coerceIn(0, 7)
        val context = outline.copy(alpha = .12f + (variant % 3) * .025f)

        // Non-scoring scene recipe. It is identical for all four choices in a task and exists only
        // to diversify the stimulus bank and make composition effects empirically measurable.
        when (variant) {
            0 -> drawRoundRect(context, topLeft = Offset(w * .06f, h * .08f), size = Size(w * .88f, h * .84f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f, 18f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.2f))
            1 -> {
                drawLine(context, Offset(w * .04f, h * .82f), Offset(w * .42f, h * .10f), strokeWidth = 1.3f)
                drawLine(context, Offset(w * .58f, h * .90f), Offset(w * .96f, h * .18f), strokeWidth = 1.3f)
            }
            2 -> {
                drawCircle(context, radius = minOf(w, h) * .13f, center = Offset(w * .18f, h * .22f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.2f))
                drawCircle(context, radius = minOf(w, h) * .09f, center = Offset(w * .82f, h * .78f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.2f))
            }
            3 -> {
                drawCircle(context, radius = minOf(w, h) * .38f, center = Offset(w * .50f, h * .50f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.1f))
                drawCircle(context, radius = minOf(w, h) * .23f, center = Offset(w * .50f, h * .50f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.1f))
            }
            4 -> {
                drawLine(context, Offset(w * .08f, h * .24f), Offset(w * .92f, h * .24f), strokeWidth = 1.3f)
                drawLine(context, Offset(w * .08f, h * .76f), Offset(w * .92f, h * .76f), strokeWidth = 1.3f)
            }
            5 -> {
                drawRect(context, topLeft = Offset(w * .07f, h * .16f), size = Size(w * .11f, h * .68f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.2f))
                drawRect(context, topLeft = Offset(w * .82f, h * .16f), size = Size(w * .11f, h * .68f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.2f))
            }
            6 -> {
                val center = Offset(w * .50f, h * .50f)
                listOf(Offset(w * .10f, h * .16f), Offset(w * .90f, h * .16f), Offset(w * .10f, h * .84f), Offset(w * .90f, h * .84f)).forEach { drawLine(context, center, it, strokeWidth = 1.0f) }
            }
            else -> {
                repeat(3) { i ->
                    drawLine(context, Offset(w * (.25f + i * .25f), h * .10f), Offset(w * (.25f + i * .25f), h * .90f), strokeWidth = 1f)
                    drawLine(context, Offset(w * .08f, h * (.25f + i * .25f)), Offset(w * .92f, h * (.25f + i * .25f)), strokeWidth = 1f)
                }
            }
        }

        // Scene archetype is context only. It changes the visual setting, never maps one-to-one to a trait.
        when (sceneArchetype) {
            VisualSceneArchetype.TEAM_TABLE, VisualSceneArchetype.SHARED_TASK, VisualSceneArchetype.NEGOTIATION_TABLE, VisualSceneArchetype.NEW_PROJECT -> {
                drawRoundRect(outline.copy(alpha = .25f), topLeft = Offset(w * (.14f + (variant % 3) * .025f), h * (.28f + (variant % 2) * .08f)), size = Size(w * (.72f - (variant % 3) * .05f), h * (.30f + (variant % 2) * .08f)), cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f))
            }
            VisualSceneArchetype.CROSSROADS, VisualSceneArchetype.PATHS, VisualSceneArchetype.UNKNOWN_TERRAIN, VisualSceneArchetype.DETOUR, VisualSceneArchetype.SPLIT_PATH, VisualSceneArchetype.MEETING_POINT -> {
                drawLine(outline.copy(alpha = .28f), Offset(w * .5f, h * .15f), Offset(w * (.44f + (variant % 3) * .06f), h * (.46f + (variant % 2) * .08f)), strokeWidth = 2f)
                drawLine(outline.copy(alpha = .28f), Offset(w * (.44f + (variant % 3) * .06f), h * (.46f + (variant % 2) * .08f)), Offset(w * .18f, h * .86f), strokeWidth = 2f)
                drawLine(outline.copy(alpha = .28f), Offset(w * (.44f + (variant % 3) * .06f), h * (.46f + (variant % 2) * .08f)), Offset(w * .82f, h * .86f), strokeWidth = 2f)
            }
            VisualSceneArchetype.BRIDGE, VisualSceneArchetype.HANDOFF, VisualSceneArchetype.RIVER_CROSSING, VisualSceneArchetype.SUPPLY_LINE -> {
                drawLine(outline.copy(alpha = .28f), Offset(w * .12f, h * (.62f + (variant % 3) * .05f)), Offset(w * .88f, h * (.62f + (variant % 3) * .05f)), strokeWidth = 4f)
                drawLine(outline.copy(alpha = .18f), Offset(w * .23f, h * .70f), Offset(w * .23f, h * .84f), strokeWidth = 2f)
                drawLine(outline.copy(alpha = .18f), Offset(w * .77f, h * .70f), Offset(w * .77f, h * .84f), strokeWidth = 2f)
            }
            VisualSceneArchetype.OPEN_DOOR, VisualSceneArchetype.CLOSED_DOOR, VisualSceneArchetype.FRONT_LINE, VisualSceneArchetype.BACK_STAGE, VisualSceneArchetype.GATE, VisualSceneArchetype.CHECKPOINT, VisualSceneArchetype.SHARED_SHELTER, VisualSceneArchetype.QUIET_ROOM -> {
                drawRect(outline.copy(alpha = .20f), topLeft = Offset(w * (.24f + (variant % 4) * .12f), h * (.14f + (variant % 2) * .06f)), size = Size(w * (.20f + (variant % 2) * .05f), h * (.68f - (variant % 2) * .08f)), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f))
            }
            VisualSceneArchetype.QUEUE, VisualSceneArchetype.CLOCKWORK, VisualSceneArchetype.RULE_BOARD, VisualSceneArchetype.DEADLINE_BOARD, VisualSceneArchetype.STAIRCASE, VisualSceneArchetype.PARALLEL_TASKS -> {
                if (variant % 2 == 0) {
                    repeat(4) { i -> drawLine(outline.copy(alpha = .16f), Offset(w * .15f, h * (.22f + i * .18f)), Offset(w * .85f, h * (.22f + i * .18f)), strokeWidth = 1.5f) }
                } else {
                    repeat(4) { i -> drawLine(outline.copy(alpha = .16f), Offset(w * (.22f + i * .18f), h * .15f), Offset(w * (.22f + i * .18f), h * .85f), strokeWidth = 1.5f) }
                }
            }
            VisualSceneArchetype.CRISIS_ROOM, VisualSceneArchetype.WORKSPACE, VisualSceneArchetype.TOOLBOX, VisualSceneArchetype.MAP_ROOM, VisualSceneArchetype.WORKBENCH -> {
                drawRect(outline.copy(alpha = .16f), topLeft = Offset(w * .10f, h * .15f), size = Size(w * .80f, h * .70f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f))
            }
            VisualSceneArchetype.CAMP -> {
                drawCircle(outline.copy(alpha = .18f), radius = w * .22f, center = Offset(w * .50f, h * .52f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f))
                repeat(3) { i ->
                    val x = w * (.30f + i * .20f)
                    drawLine(outline.copy(alpha = .25f), Offset(x - 8f, h * .72f), Offset(x, h * .58f), strokeWidth = 2f)
                    drawLine(outline.copy(alpha = .25f), Offset(x, h * .58f), Offset(x + 8f, h * .72f), strokeWidth = 2f)
                }
            }
            VisualSceneArchetype.CIRCLE, VisualSceneArchetype.REVIEW_CIRCLE, VisualSceneArchetype.COMMON_GROUND -> {
                drawCircle(outline.copy(alpha = .24f), radius = minOf(w, h) * .31f, center = Offset(w * .50f, h * .50f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f))
            }
            VisualSceneArchetype.TWO_GROUPS, VisualSceneArchetype.PUBLIC_SQUARE -> {
                drawRoundRect(outline.copy(alpha = .18f), topLeft = Offset(w * .10f, h * .28f), size = Size(w * .32f, h * .44f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f, 18f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f))
                drawRoundRect(outline.copy(alpha = .18f), topLeft = Offset(w * .58f, h * .28f), size = Size(w * .32f, h * .44f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f, 18f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f))
            }
            VisualSceneArchetype.NETWORK_HUB, VisualSceneArchetype.ROTATING_LEAD -> {
                val center = Offset(w * .50f, h * .50f)
                listOf(Offset(w * .20f, h * .25f), Offset(w * .80f, h * .25f), Offset(w * .20f, h * .75f), Offset(w * .80f, h * .75f)).forEach { point ->
                    drawLine(outline.copy(alpha = .22f), center, point, strokeWidth = 1.5f)
                    drawCircle(outline.copy(alpha = .28f), radius = 4f, center = point)
                }
                drawCircle(outline.copy(alpha = .32f), radius = 7f, center = center)
            }
            VisualSceneArchetype.OBSERVER, VisualSceneArchetype.TOWER, VisualSceneArchetype.SIGNAL_POINT -> {
                drawCircle(outline.copy(alpha = .16f), radius = minOf(w, h) * .26f, center = Offset(w * .56f, h * .50f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f))
                drawCircle(outline.copy(alpha = .34f), radius = 6f, center = Offset(w * .16f, h * .50f))
                drawLine(outline.copy(alpha = .20f), Offset(w * .19f, h * .50f), Offset(w * .30f, h * .50f), strokeWidth = 1.5f)
            }
            VisualSceneArchetype.EMPTY_SEAT, VisualSceneArchetype.PAIR_WALK -> {
                val y = h * .64f
                repeat(4) { i ->
                    if (i != 2) drawRect(outline.copy(alpha = .22f), topLeft = Offset(w * (.16f + i * .19f), y), size = Size(w * .10f, h * .12f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f))
                }
                drawRect(outline.copy(alpha = .10f), topLeft = Offset(w * (.16f + 2 * .19f), y), size = Size(w * .10f, h * .12f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1f))
            }
            VisualSceneArchetype.RESOURCE_SPLIT, VisualSceneArchetype.MARKET_STALL -> {
                drawLine(outline.copy(alpha = .22f), Offset(w * .50f, h * .20f), Offset(w * .50f, h * .80f), strokeWidth = 2f)
                drawRoundRect(outline.copy(alpha = .16f), topLeft = Offset(w * .14f, h * .32f), size = Size(w * .26f, h * .36f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f))
                drawRoundRect(outline.copy(alpha = .16f), topLeft = Offset(w * .60f, h * .32f), size = Size(w * .26f, h * .36f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f))
            }
        }

        when (paradigm) {
            VisualParadigm.GROUP_DISTANCE, VisualParadigm.NETWORK, VisualParadigm.CLUSTER -> {
                val count = 3 + l.intensity
                val left = w * (.16f - spacing01 * .03f)
                val right = w * (.84f + spacing01 * .03f)
                val gap = (right - left) / (count - 1).coerceAtLeast(1)
                repeat(count) { i ->
                    val normalized = if (count <= 1) 0f else i / (count - 1f)
                    val orderJitter = (1f - order01) * (((i + seed) % 3) - 1) * h * .10f
                    val directionShift = directionCentered * (normalized - .5f) * h * .24f
                    val asymmetryShift = if (i == count - 1) asymmetry01 * h * .12f else 0f
                    val x = left + gap * i
                    val y = h * .50f + orderJitter + directionShift + asymmetryShift
                    val radius = 6f + intensity01 * 7f + if (i == count - 1) asymmetry01 * 3f else 0f
                    drawCircle(if ((i + seed) % 2 == 0) primary else secondary, radius = radius, center = Offset(x, y))
                    if (i > 0 && (paradigm == VisualParadigm.NETWORK || l.spacing < 3)) {
                        val px = left + gap * (i - 1)
                        drawLine(outline, Offset(px, h * .50f), Offset(x, y), strokeWidth = 1.5f + order01 * 3f)
                    }
                }
            }

            VisualParadigm.PATH, VisualParadigm.DIRECTION, VisualParadigm.CHANGE, VisualParadigm.FLOW -> {
                val steps = 4 + l.order
                repeat(steps) { i ->
                    val normalized = if (steps <= 1) 0f else i / (steps - 1f)
                    val eased = normalized + (spacing01 - .5f) * .08f * kotlin.math.sin(normalized * 3.14159f)
                    val x = w * (.08f + eased * .84f)
                    val slope = directionCentered * h * .26f * (normalized - .5f)
                    val curve = asymmetry01 * h * .18f * kotlin.math.sin(normalized * 3.14159f * 2f + (seed % 3).toFloat())
                    val y = h * .50f + slope + curve
                    if (i > 0) {
                        val prev = (i - 1) / (steps - 1f)
                        val pEased = prev + (spacing01 - .5f) * .08f * kotlin.math.sin(prev * 3.14159f)
                        val px = w * (.08f + pEased * .84f)
                        val py = h * .50f + directionCentered * h * .26f * (prev - .5f) + asymmetry01 * h * .18f * kotlin.math.sin(prev * 3.14159f * 2f + (seed % 3).toFloat())
                        drawLine(primary, Offset(px, py), Offset(x, y), strokeWidth = 2.5f + order01 * 2.5f)
                    }
                    drawCircle(secondary, 5f + intensity01 * 5f, Offset(x, y))
                }
            }

            VisualParadigm.BALANCE, VisualParadigm.RESOURCE, VisualParadigm.BOUNDARY, VisualParadigm.EXCHANGE -> {
                val spread = .18f + spacing01 * .12f
                val leftX = w * (.5f - spread)
                val rightX = w * (.5f + spread)
                val leftRadius = 15f + intensity01 * 8f + asymmetry01 * 7f
                val rightRadius = 15f + intensity01 * 8f + (1f - asymmetry01) * 7f
                val vertical = directionCentered * h * .08f
                drawCircle(primary, leftRadius, Offset(leftX, h * .50f - vertical))
                drawCircle(secondary, rightRadius, Offset(rightX, h * .50f + vertical))
                if (paradigm == VisualParadigm.BOUNDARY) {
                    val boundaryX = w * (.5f + directionCentered * .05f)
                    val gap = 12f + (3 - l.order) * 5f
                    drawLine(outline, Offset(boundaryX, h * .12f), Offset(boundaryX, h * .46f - gap), strokeWidth = 1.5f + order01 * 4f)
                    drawLine(outline, Offset(boundaryX, h * .54f + gap), Offset(boundaryX, h * .88f), strokeWidth = 1.5f + order01 * 4f)
                } else {
                    drawLine(outline, Offset(w * .14f, h * .78f), Offset(w * .86f, h * .78f), strokeWidth = 2f + order01 * 3f)
                    if (paradigm == VisualParadigm.RESOURCE) {
                        repeat(2 + l.intensity) { i ->
                            val side = if ((i + seed) % 2 == 0) leftX else rightX
                            drawCircle(outline, 2.5f + order01 * 1.5f, Offset(side + (i - 1) * 7f, h * .28f + asymmetry01 * i * 3f))
                        }
                    }
                }
            }

            VisualParadigm.RHYTHM, VisualParadigm.STRUCTURE, VisualParadigm.FOCUS, VisualParadigm.AMBIGUITY, VisualParadigm.PRIORITY -> {
                val count = 5 + if (paradigm == VisualParadigm.FOCUS) l.intensity else 0
                repeat(count) { i ->
                    val col = i % 3
                    val row = i / 3
                    val gapX = w * (.21f + spacing01 * .035f)
                    val baseX = w * .18f + col * gapX
                    val baseY = h * .25f + row * h * .36f
                    val disorder = (1f - order01) * 11f
                    val dx = (((i + seed) % 3) - 1) * disorder + if (i == count - 1) asymmetry01 * 15f else 0f
                    val dy = (((i + seed / 3) % 3) - 1) * disorder + directionCentered * (col - 1) * 8f
                    val side = 14f + intensity01 * 9f + if (paradigm == VisualParadigm.FOCUS && i == 0) 7f else 0f
                    drawRect(
                        if ((i + seed) % 2 == 0) primary.copy(alpha = .85f) else secondary.copy(alpha = .75f),
                        topLeft = Offset(baseX + dx, baseY + dy),
                        size = Size(side, side)
                    )
                }
                if (paradigm == VisualParadigm.AMBIGUITY) {
                    drawLine(outline, Offset(w * .15f, h * (.83f - directionCentered * .05f)), Offset(w * (.70f + asymmetry01 * .15f), h * (.83f + directionCentered * .05f)), strokeWidth = 1.5f + order01 * 2.5f)
                }
            }
        }
    }
}

@Composable
private fun CoreProfileAssessmentDialog(viewModel: MainViewModel) {
    val question = viewModel.currentCoreQuestion ?: return
    AlertDialog(
        onDismissRequest = viewModel::closeCoreAssessment,
        confirmButton = {},
        title = {
            Column {
                Text(viewModel.t("Визуальная профильная серия", "Візуальна профільна серія", "Visual profile series"), fontWeight = FontWeight.Black)
                Text("${viewModel.coreQuestionIndex + 1}/${viewModel.coreQuestions.size}", style = MaterialTheme.typography.labelMedium)
                LinearProgressIndicator(progress = { (viewModel.coreQuestionIndex + 1f) / viewModel.coreQuestions.size }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    viewModel.t(
                        "Выберите композицию, которая интуитивно ближе. Значение выбора намеренно не объясняется.",
                        "Оберіть композицію, яка інтуїтивно ближча. Значення вибору навмисно не пояснюється.",
                        "Choose the composition that feels intuitively closer. The meaning of the choice is intentionally not explained."
                    ),
                    style = MaterialTheme.typography.bodyMedium
                )
                VisualChoiceGrid(question.paradigm, question.sceneArchetype, question.visualSeed, question.compositionVariant, question.choices, viewModel.coreAnswers[question.id], viewModel::selectCoreAnswer)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = viewModel::previousCoreQuestion, enabled = viewModel.coreQuestionIndex > 0) { Text(viewModel.t("Назад", "Назад", "Back")) }
                    if (viewModel.coreQuestionIndex == viewModel.coreQuestions.lastIndex) {
                        Button(onClick = viewModel::finishCoreAssessment, enabled = viewModel.canFinishCoreAssessment) { Text(viewModel.t("Завершить", "Завершити", "Finish")) }
                    } else {
                        Button(onClick = viewModel::nextCoreQuestion, enabled = viewModel.coreAnswers[question.id] in 1..4) { Text(viewModel.t("Далее", "Далі", "Next")) }
                    }
                }
            }
        }
    )
}

@Composable
private fun CoreModuleDialog(viewModel: MainViewModel, module: String, onDismiss: () -> Unit) {
    if (module == "numerology") {
        NumerologyModuleDialog(viewModel, onDismiss)
        return
    }
    val title: String
    val body: String
    when (module) {
        "p32" -> {
            title = "Brotherhood‑32 · ${viewModel.profile.personality32.code}"
            body = viewModel.t(
                "${viewModel.profile.personality32.title(viewModel.language)}. Пять осей: социальная энергия, восприятие, решения, жизненный ритм и стиль долгосрочной связи.",
                "${viewModel.profile.personality32.title(viewModel.language)}. П’ять осей: соціальна енергія, сприйняття, рішення, життєвий ритм і стиль довгострокового зв’язку.",
                "${viewModel.profile.personality32.title(viewModel.language)}. Five axes: social energy, perception, decisions, life rhythm and long-term bond style."
            )
        }
        "enneagram" -> {
            title = viewModel.t("Эннеаграмма ${viewModel.profile.enneagram.type}w${viewModel.profile.enneagram.wing}", "Еннеаграма ${viewModel.profile.enneagram.type}w${viewModel.profile.enneagram.wing}", "Enneagram ${viewModel.profile.enneagram.type}w${viewModel.profile.enneagram.wing}")
            body = viewModel.t("Мотивационный слой профиля. Используется как дополнительный, а не решающий фактор.", "Мотиваційний шар профілю. Використовується як додатковий, а не вирішальний фактор.", "Motivational profile layer. Used as an additional, not decisive, factor.")
        }
        else -> {
            title = "${viewModel.profile.zodiac.symbol} ${viewModel.profile.zodiac.label(viewModel.language)}"
            body = viewModel.t("Зодиакальный слой совместимости рассчитывается по дате рождения и имеет небольшой вес.", "Зодіакальний шар сумісності розраховується за датою народження та має невелику вагу.", "The zodiac compatibility layer is calculated from birth date and has a small weight.")
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { Button(onClick = onDismiss) { Text(viewModel.t("Готово", "Готово", "Done")) } },
        title = { Text(title, fontWeight = FontWeight.Black) },
        text = { Text(body) }
    )
}

@Composable
private fun NumerologyModuleDialog(viewModel: MainViewModel, onDismiss: () -> Unit) {
    val reading = viewModel.numerologyReading
    val lifePath = viewModel.numerologyLifePath(reading.lifePathNumber)
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { Button(onClick = onDismiss) { Text(viewModel.t("Готово", "Готово", "Done")) } },
        title = {
            Text(
                viewModel.t("Нумерология — полный профиль", "Нумерологія — повний профіль", "Numerology — full profile"),
                fontWeight = FontWeight.Black,
            )
        },
        text = {
            Column(
                Modifier.fillMaxHeight(0.78f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    viewModel.t(
                        "Расчёт строится автоматически из даты рождения. Введённое латинское имя используется только для отдельных описательных чисел и никогда не входит в дружескую совместимость.",
                        "Розрахунок будується автоматично з дати народження. Введене латинське ім’я використовується лише для окремих описових чисел і ніколи не входить у дружню сумісність.",
                        "The reading is calculated automatically from the birth date. The Latin name is used only for separate descriptive numbers and never enters friendship compatibility."
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                NumerologyInfoCard(
                    title = viewModel.t("Канонический ведический слой", "Канонічний ведичний шар", "Canonical Vedic layer"),
                    lines = listOf(
                        viewModel.t("Число души даты: ${reading.dateSoulNumber}", "Число душі дати: ${reading.dateSoulNumber}", "Birth-date soul number: ${reading.dateSoulNumber}"),
                        viewModel.t("Число судьбы: ${reading.dateDestinyNumber}", "Число долі: ${reading.dateDestinyNumber}", "Destiny number: ${reading.dateDestinyNumber}"),
                        viewModel.t("Число зрелости: ${reading.dateMaturityNumber}", "Число зрілості: ${reading.dateMaturityNumber}", "Maturity number: ${reading.dateMaturityNumber}"),
                        viewModel.t("Вес в общей совместимости: 5% — без изменений", "Вага в загальній сумісності: 5% — без змін", "Weight in total compatibility: 5% — unchanged"),
                    )
                )
                if (lifePath != null) {
                    Text(lifePath.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    lifePath.sections.forEach { section ->
                        NumerologyTextCard(section.title, section.body)
                    }
                } else {
                    NumerologyTextCard(
                        viewModel.t(
                            "Жизненный путь ${reading.lifePathNumber}",
                            "Життєвий шлях ${reading.lifePathNumber}",
                            "Life path ${reading.lifePathNumber}",
                        ),
                        viewModel.t(
                            "В предоставленном исходном материале отдельная подробная характеристика для этого Life Path отсутствует; число рассчитано, но текст не выдумывается.",
                            "У наданому вихідному матеріалі окрема докладна характеристика для цього Life Path відсутня; число розраховано, але текст не вигадується.",
                            "The supplied source material has no separate detailed characteristic for this Life Path; the number is calculated, but no text is invented.",
                        ),
                    )
                }
                HorizontalDivider()
                Text(
                    viewModel.t("Матрица даты рождения", "Матриця дати народження", "Birth-date chart"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                reading.birthChart.forEach { characteristic ->
                    viewModel.numerologyEntry("birth_chart", characteristic.key)?.let { entry ->
                        NumerologyTextCard(entry.title, entry.body)
                    }
                }
                viewModel.numerologyEntry("birth_chart", "NONE")?.let { missingEntry ->
                    reading.missingBirthChartDigits.forEach { digit ->
                        NumerologyTextCard(
                            viewModel.t(
                                "Цифра $digit отсутствует",
                                "Цифра $digit відсутня",
                                "Digit $digit is absent",
                            ),
                            missingEntry.body,
                        )
                    }
                }
                reading.specialBirthChartKeys.forEach { key ->
                    viewModel.numerologyEntry("birth_chart", key)?.let { entry ->
                        NumerologyTextCard(entry.title, entry.body)
                    }
                }
                HorizontalDivider()
                Text(
                    viewModel.t("Четыре жизненных пика", "Чотири життєві піки", "Four life pinnacles"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                reading.pinnacles.forEach { peak ->
                    viewModel.numerologyEntry("pyramid_peaks", peak.number.toString())?.let { entry ->
                        NumerologyTextCard(
                            viewModel.t(
                                "Пик ${peak.index} · в возрасте ${peak.reachedAtAge} лет · число ${peak.number}",
                                "Пік ${peak.index} · у віці ${peak.reachedAtAge} років · число ${peak.number}",
                                "Pinnacle ${peak.index} · at age ${peak.reachedAtAge} · number ${peak.number}",
                            ),
                            entry.body,
                        )
                    }
                }
                if (reading.nameSoulNumber != null || reading.expressionNumber != null) {
                    HorizontalDivider()
                    Text(
                        viewModel.t("Описательные числа имени", "Описові числа імені", "Descriptive name numbers"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    reading.nameSoulNumber?.let { number ->
                        viewModel.numerologyEntry("soul_numbers", number.toString())?.let { entry ->
                            NumerologyTextCard(entry.title, entry.body)
                        }
                    }
                    reading.expressionNumber?.let { number ->
                        viewModel.numerologyEntry("outer_numbers", number.toString())?.let { entry ->
                            NumerologyTextCard(entry.title, entry.body)
                        }
                    }
                    Text(
                        viewModel.t(
                            "Эти числа не изменяют 5% ведической дружеской совместимости.",
                            "Ці числа не змінюють 5% ведичної дружньої сумісності.",
                            "These numbers do not alter the 5% Vedic friendship compatibility layer."
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(
                    viewModel.t(
                        "Интерпретации — культурно-эзотерический материал для самопознания, а не психологическая диагностика или показатель доверия.",
                        "Інтерпретації — культурно-езотеричний матеріал для самопізнання, а не психологічна діагностика чи показник довіри.",
                        "Interpretations are cultural/esoteric self-reflection material, not psychological diagnosis or a Trust signal."
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
    )
}

@Composable
private fun NumerologyInfoCard(title: String, lines: List<String>) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            lines.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun NumerologyTextCard(title: String, body: String) {
    Card {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(body, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun TrustScreen(viewModel: MainViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text(viewModel.t("Репутация доверия", "Репутація довіри", "Trust reputation"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text(viewModel.t("Отдельно от психологических тестов", "Окремо від психологічних тестів", "Separate from personality tests"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(26.dp)) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    ScoreRing(viewModel.profile.trustScore, 88.dp, viewModel.t("доверие", "довіра", "trust"))
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(viewModel.t("Подтверждённая репутация", "Підтверджена репутація", "Verified reputation"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                        Text(viewModel.t("Реальные взаимодействия и решения модерации", "Реальні взаємодії та рішення модерації", "Real interactions and moderation decisions"))
                    }
                }
            }
        }
        items(viewModel.trustEvents, key = { it.id }) { event ->
            Card {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (event.confirmed) Icons.Default.CheckCircle else Icons.Default.Security, null, tint = if (event.confirmed) Color(0xFF2E9D62) else MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(10.dp))
                    Text(event.label(viewModel.language), Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    Text(if (event.impact == 0) "—" else "+${event.impact}", fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            InfoPanel(
                viewModel.t("Как работает «предал / подставил»", "Як працює «зрадив / підставив»", "How betrayal reports work"),
                viewModel.t("Жалоба не меняет публичный рейтинг автоматически. Нужны связь между пользователями, доказательства, ответ второй стороны, решение модератора и право апелляции.", "Скарга не змінює публічний рейтинг автоматично. Потрібні зв’язок між користувачами, докази, відповідь другої сторони, рішення модератора та право апеляції.", "A report never changes the public score automatically. It requires a verified connection, evidence, response, moderation and appeal rights.")
            )
        }
        item {
            OutlinedButton(onClick = { viewModel.showMessage(viewModel.t("Безопасная форма жалобы открыта", "Безпечну форму скарги відкрито", "Secure report form opened")) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Shield, null)
                Spacer(Modifier.width(8.dp))
                Text(viewModel.t("Сообщить о нарушении доверия", "Повідомити про порушення довіри", "Report a trust violation"))
            }
        }
    }
}

@Composable
private fun ProfileScreen(viewModel: MainViewModel) {
    val p = viewModel.profile
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(p.name, true, p.avatarLocalPath, 72.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("${p.name}, ${p.age}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                    Text("global_id ${p.globalId.display}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Verified, null, Modifier.size(17.dp), tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(4.dp))
                        Text(viewModel.t("Личность подтверждена", "Особу підтверджено", "Identity verified"), style = MaterialTheme.typography.labelMedium)
                    }
                }
                IconButton(onClick = viewModel::editProfile) { Icon(Icons.Default.Edit, null) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(viewModel.accountRating.total.toInt().toString(), viewModel.t("Аккаунт", "Акаунт", "Account"), Modifier.weight(1f))
                MetricCard(p.trustScore.toString(), viewModel.t("Доверие", "Довіра", "Trust"), Modifier.weight(1f))
                MetricCard(p.verifiedInteractions.toString(), viewModel.t("Связи", "Зв’язки", "Links"), Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(viewModel.connectionRequests.size.toString(), viewModel.t("Запросы", "Запити", "Requests"), Modifier.weight(1f))
                MetricCard(viewModel.conversations.size.toString(), viewModel.t("Чаты", "Чати", "Chats"), Modifier.weight(1f))
                MetricCard(viewModel.joinedCommunityIds.size.toString(), viewModel.t("Группы", "Групи", "Groups"), Modifier.weight(1f))
            }
        }
        item {
            Card(shape = RoundedCornerShape(20.dp)) {
                Row(
                    Modifier.fillMaxWidth().clickable(onClick = viewModel::openDiscoveryFilters).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (viewModel.profileVisibility == ProfileVisibility.DISCOVERABLE) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(viewModel.t("Видимость и поиск друзей", "Видимість і пошук друзів", "Visibility & discovery"), fontWeight = FontWeight.Bold)
                        Text(
                            when (viewModel.profileVisibility) {
                                ProfileVisibility.DISCOVERABLE -> viewModel.t("Профиль виден в поиске", "Профіль видно в пошуку", "Profile is discoverable")
                                ProfileVisibility.CONNECTIONS -> viewModel.t("Профиль только для связей", "Профіль лише для зв’язків", "Connections only")
                                ProfileVisibility.PRIVATE -> viewModel.t("Профиль скрыт", "Профіль приховано", "Profile hidden")
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
        item {
            Button(onClick = viewModel::openSelfAnalysis, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Psychology, null)
                Spacer(Modifier.width(8.dp))
                Text(viewModel.t("Познание себя", "Пізнання себе", "Know yourself"))
            }
        }
        item { InfoPanel(viewModel.t("О себе", "Про себе", "About"), p.description) }
        item { ProfileSection(viewModel.t("Цели дружбы", "Цілі дружби", "Friendship goals"), p.goals) }
        item { ProfileSection(viewModel.t("Интересы", "Інтереси", "Interests"), p.interests) }
        item { ProfileSection(viewModel.t("Ценности", "Цінності", "Values"), p.values) }
        item { ProfileSection(viewModel.t("Образ жизни", "Спосіб життя", "Lifestyle"), p.lifestyle) }
        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(viewModel.t("Психологический паспорт", "Психологічний паспорт", "Personality passport"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    ProfileLine("Brotherhood‑32", "${p.personality32.code} · ${p.personality32.title(viewModel.language)}")
                    ProfileLine(viewModel.t("Эннеаграмма", "Еннеаграма", "Enneagram"), "${p.enneagram.type}w${p.enneagram.wing} · ${p.enneagram.title(viewModel.language)}")
                    ProfileLine(viewModel.t("Зодиак", "Зодіак", "Zodiac"), "${p.zodiac.symbol} ${p.zodiac.label(viewModel.language)}")
                    ProfileLine(viewModel.t("Ведическая нумерология", "Ведична нумерологія", "Vedic numerology"), "${p.numerology.soulNumber} / ${p.numerology.destinyNumber} / ${p.numerology.maturityNumber}")
                }
            }
        }
    }
}

@Composable
private fun MetricCard(value: String, label: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun ProfileSection(title: String, values: List<String>) {
    Card(shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) { items(values) { TraitChip(it) } }
        }
    }
}

@Composable
private fun ProfileLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, Modifier.weight(.38f), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        Text(value, Modifier.weight(.62f), fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun CandidateDetailScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val candidate = viewModel.selectedCandidate ?: return
    val breakdown = viewModel.compatibility(candidate)
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(viewModel.t("Совместимость", "Сумісність", "Compatibility")) }, navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }) }
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Avatar(candidate.name, candidate.online)
                    Spacer(Modifier.height(10.dp))
                    Text("${candidate.name}, ${candidate.age}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                    Text("${viewModel.cityLabel(candidate.city)} · ID ${candidate.globalId.display}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(14.dp))
                    ScoreRing(breakdown.total, 112.dp, viewModel.t("для вас", "для вас", "for you"))
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(viewModel.t("Базовая: ${breakdown.baseTotal}%", "Базова: ${breakdown.baseTotal}%", "Base: ${breakdown.baseTotal}%"), style = MaterialTheme.typography.labelLarge)
                        Text(viewModel.t("Доверие: ${breakdown.reputation}/100", "Довіра: ${breakdown.reputation}/100", "Trust: ${breakdown.reputation}/100"), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            viewModel.requestConnection(candidate)
                            viewModel.showMessage(viewModel.t("Запрос дружбы отправлен", "Запит дружби надіслано", "Friend request sent"))
                        },
                        modifier = Modifier.weight(1f).height(52.dp)
                    ) {
                        Icon(Icons.Default.People, null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (candidate.globalId.value in viewModel.connectionRequests) viewModel.t("Отправлено", "Надіслано", "Sent") else viewModel.t("Познакомиться", "Познайомитися", "Connect"))
                    }
                    OutlinedButton(onClick = { viewModel.openDirectChat(candidate) }, modifier = Modifier.weight(1f).height(52.dp)) {
                        Icon(Icons.Default.Chat, null)
                        Spacer(Modifier.width(6.dp))
                        Text(viewModel.t("Сообщение", "Повідомлення", "Message"))
                    }
                }
            }
            item {
                Text(viewModel.t("Подробный расчёт", "Детальний розрахунок", "Detailed score"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            }
            item { CompatibilityPanel(viewModel, breakdown) }
            item {
                val vedic = VedicNumerologyEngine.compatibilityBreakdown(viewModel.profile.numerology, candidate.numerology)
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(viewModel.t("Ведическая нумерология — подробно", "Ведична нумерологія — докладно", "Vedic numerology — detail"), fontWeight = FontWeight.Bold)
                        Text(VedicNumerologyEngine.compatibilitySummary(viewModel.profile.numerology, candidate.numerology, viewModel.language), style = MaterialTheme.typography.bodySmall)
                        MetricBar(viewModel.t("Число души", "Число душі", "Soul number"), vedic.soul)
                        MetricBar(viewModel.t("Число судьбы", "Число долі", "Destiny number"), vedic.destiny)
                        MetricBar(viewModel.t("Перекрёстная связь дат", "Перехресний зв’язок дат", "Cross-date link"), vedic.cross)
                        MetricBar(viewModel.t("Композит даты рождения", "Композит дати народження", "Birth-date composite"), vedic.dateComposite)
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(viewModel.t("Профиль личности", "Профіль особистості", "Personality profile"), fontWeight = FontWeight.Bold)
                        ProfileLine("Brotherhood‑32", "${candidate.personality32.code} · ${candidate.personality32.title(viewModel.language)}")
                        ProfileLine(viewModel.t("Эннеаграмма", "Еннеаграма", "Enneagram"), "${candidate.enneagram.type}w${candidate.enneagram.wing} · ${candidate.enneagram.title(viewModel.language)}")
                        ProfileLine(viewModel.t("Зодиак", "Зодіак", "Zodiac"), "${candidate.zodiac.symbol} ${candidate.zodiac.label(viewModel.language)}")
                        ProfileLine(viewModel.t("Ведические числа даты", "Ведичні числа дати", "Vedic birth-date numbers"), "${candidate.numerology.soulNumber} / ${candidate.numerology.destinyNumber} / ${candidate.numerology.maturityNumber}")
                    }
                }
            }
            item { InfoPanel(viewModel.t("Почему вы подходите", "Чому ви підходите", "Why you match"), candidate.explanation) }
            item { ProfileSection(viewModel.t("Общие направления", "Спільні напрями", "Shared areas"), candidate.interests + candidate.values) }
        }
    }
}

@Composable
private fun CompatibilityPanel(viewModel: MainViewModel, b: CompatibilityBreakdown) {
    Card(shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(viewModel.t("Все слои совместимости", "Усі шари сумісності", "All compatibility layers"), fontWeight = FontWeight.Black)
            Text(
                viewModel.t(
                    "Нажмите на показатель, чтобы увидеть, что именно сравнивается.",
                    "Натисніть на показник, щоб побачити, що саме порівнюється.",
                    "Tap a layer to see what is being compared.",
                ),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            CompatibilityMetric(
                viewModel,
                viewModel.t("100 психологических визуальных серий", "100 психологічних візуальних серій", "100 psychological visual series"),
                b.friendshipTests,
                viewModel.t(
                    "Сопоставляет распределённый скрытый профиль, построенный по непрямым визуально-ассоциативным заданиям. Отдельный ответ не является выводом о человеке.",
                    "Порівнює розподілений прихований профіль, побудований за непрямими візуально-асоціативними завданнями. Окрема відповідь не є висновком про людину.",
                    "Compares the distributed private profile built from indirect visual-association tasks. No single answer is treated as a conclusion about a person.",
                ),
            )
            CompatibilityMetric(viewModel, viewModel.t("Характер", "Характер", "Character"), b.character,
                viewModel.t("Сопоставляет устойчивые особенности взаимодействия, самостоятельности, последовательности и отношения к другим людям без моральной маркировки.", "Порівнює стійкі особливості взаємодії, самостійності, послідовності та ставлення до інших людей без морального маркування.", "Compares stable interaction, autonomy and consistency patterns without moral labeling."))
            CompatibilityMetric(viewModel, viewModel.t("Ценности", "Цінності", "Values"), b.values,
                viewModel.t("Сопоставляет заявленные жизненные и дружеские ценности.", "Порівнює заявлені життєві та дружні цінності.", "Compares stated life and friendship values."))
            CompatibilityMetric(viewModel, viewModel.t("Цели дружбы", "Цілі дружби", "Friendship goals"), b.friendshipGoals,
                viewModel.t("Показывает, насколько совпадает формат отношений, который вы оба ищете: близкая дружба, спорт, проекты, путешествия, взаимопомощь и другое.", "Показує, наскільки збігається формат стосунків, який ви обоє шукаєте: близька дружба, спорт, проєкти, подорожі, взаємодопомога та інше.", "Shows how closely your desired friendship formats align: close friendship, sports, projects, travel, mutual aid and more."))
            CompatibilityMetric(viewModel, viewModel.t("Интересы", "Інтереси", "Interests"), b.interests,
                viewModel.t("Совпадение спорта, автомобилей, путешествий, технологий, бизнеса и других интересов профиля.", "Збіг спорту, автомобілів, подорожей, технологій, бізнесу та інших інтересів профілю.", "Overlap in sports, cars, travel, technology, business and other profile interests."))
            CompatibilityMetric(viewModel, viewModel.t("Образ жизни", "Спосіб життя", "Lifestyle"), b.lifestyle,
                viewModel.t("Ритм жизни, активность, формат отдыха, поездки и другие привычки, указанные в профиле.", "Ритм життя, активність, формат відпочинку, поїздки та інші звички, зазначені у профілі.", "Lifestyle rhythm, activity, leisure, travel and other stated habits."))
            CompatibilityMetric(viewModel, viewModel.t("Стиль общения", "Стиль спілкування", "Communication"), b.communication,
                viewModel.t("Частота контакта, прямота, глубина разговора и предпочитаемый формат общения.", "Частота контакту, прямота, глибина розмови та бажаний формат спілкування.", "Contact frequency, directness, conversational depth and preferred communication format."))
            CompatibilityMetric(viewModel, viewModel.t("Конфликты и восстановление", "Конфлікти та відновлення", "Conflict repair"), b.conflict,
                viewModel.t("Сопоставляет стили прохождения разногласий, восстановления контакта и сохранения рабочих или дружеских отношений.", "Порівнює стилі проходження розбіжностей, відновлення контакту та збереження робочих або дружніх відносин.", "Compares ways of handling disagreement, reconnecting and preserving working or friendly relationships."))
            CompatibilityMetric(viewModel, "Brotherhood‑32", b.personality32,
                viewModel.t("Сравнение пяти независимых осей модели Brotherhood‑32.", "Порівняння п'яти незалежних осей моделі Brotherhood‑32.", "Comparison of five independent Brotherhood‑32 axes."))
            CompatibilityMetric(viewModel, viewModel.t("Ведическая нумерология", "Ведична нумерологія", "Vedic numerology"), b.numerology,
                viewModel.t("Совместимость дружбы рассчитывается только по двум датам рождения. Число имени может показываться отдельно и не входит в этот слой.", "Сумісність дружби розраховується лише за двома датами народження. Число імені може показуватися окремо й не входить до цього шару.", "Friendship compatibility uses only the two birth dates. Name number may be shown separately and is not part of this layer."))
            CompatibilityMetric(viewModel, viewModel.t("Эннеаграмма", "Еннеаграма", "Enneagram"), b.enneagram,
                viewModel.t("Дополнительное сопоставление мотивационных типов и крыльев.", "Додаткове порівняння мотиваційних типів і крил.", "Additional comparison of motivational types and wings."))
            CompatibilityMetric(viewModel, viewModel.t("Зодиак", "Зодіак", "Zodiac"), b.zodiac,
                viewModel.t("Культурный астрологический слой с небольшим весом в общем результате.", "Культурний астрологічний шар з невеликою вагою в загальному результаті.", "A cultural astrological layer with a small weight in the overall result."))
            CompatibilityMetric(viewModel, viewModel.t("География", "Географія", "Geography"), b.geography,
                viewModel.t("Город и практическая возможность встречаться; точные координаты другим пользователям не раскрываются.", "Місто та практична можливість зустрічатися; точні координати іншим користувачам не розкриваються.", "City and practical ability to meet; precise coordinates are not exposed to other users."))
            CompatibilityMetric(viewModel, viewModel.t("Бизнес и взаимопомощь", "Бізнес і взаємодопомога", "Business & mutual aid"), b.business,
                viewModel.t("Сопоставляет отношение к обязательствам, партнёрству, помощи, ресурсам и совместным проектам.", "Порівнює ставлення до зобов'язань, партнерства, допомоги, ресурсів і спільних проєктів.", "Compares approaches to obligations, partnership, support, resources and shared projects."))
            CompatibilityMetric(viewModel, viewModel.t("Социальный формат", "Соціальний формат", "Social format"), b.socialFormat,
                viewModel.t("Сопоставляет предпочтения общения один-на-один, в компании и в группах.", "Порівнює вподобання спілкування один-на-один, у компанії та в групах.", "Compares preferences for one-to-one, social-circle and group interaction."))
            HorizontalDivider()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(viewModel.t("Базовая совместимость", "Базова сумісність", "Base compatibility"), fontWeight = FontWeight.Bold)
                Text("${b.baseTotal}%", fontWeight = FontWeight.Black)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(viewModel.t("Совместимость именно для вас", "Сумісність саме для вас", "Compatibility for you"), fontWeight = FontWeight.Bold)
                Text("${b.total}%", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
            }
            Text(
                viewModel.t(
                    "Персональный итог учитывает выбранные вами цели дружбы. Quality Fit по выбранным качествам остаётся отдельным показателем.",
                    "Персональний підсумок враховує обрані вами цілі дружби. Quality Fit за обраними якостями залишається окремим показником.",
                    "The personal result reflects your selected friendship goals. Quality Fit for requested qualities remains a separate score.",
                ),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            HorizontalDivider()
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(viewModel.t("Доверие — отдельный показатель", "Довіра — окремий показник", "Trust is a separate score"), fontWeight = FontWeight.Bold)
                    Text("${b.reputation}/100", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text(viewModel.t("Подтверждённая репутация не смешивается с психологической совместимостью.", "Підтверджена репутація не змішується з психологічною сумісністю.", "Confirmed reputation is not mixed into psychological compatibility."), style = MaterialTheme.typography.bodySmall)
                }
            }
            Text(viewModel.t("Уверенность расчёта: ${b.confidence}%", "Впевненість розрахунку: ${b.confidence}%", "Score confidence: ${b.confidence}%"), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CompatibilityMetric(viewModel: MainViewModel, label: String, score: Int, detail: String) {
    var expanded by remember(label) { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { expanded = !expanded }.padding(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            Text("$score%", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
        }
        LinearProgressIndicator(progress = { score / 100f }, modifier = Modifier.fillMaxWidth())
        if (expanded) Text(detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun MetricBar(label: String, score: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Text("$score%", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
        }
        LinearProgressIndicator(progress = { score / 100f }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun CommunityDetailScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val community = viewModel.selectedCommunity ?: return
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(community.title, maxLines = 1, overflow = TextOverflow.Ellipsis) }, navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }) }
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(28.dp)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(if (community.kind == CommunityKind.BUSINESS) Icons.Default.BusinessCenter else Icons.Default.Groups, null, Modifier.size(48.dp))
                        Text(community.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                        Text(community.description)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TraitChip(community.category)
                            TraitChip(viewModel.cityLabel(community.city))
                            if (community.online) TraitChip(viewModel.t("Онлайн", "Онлайн", "Online"))
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MetricCard(community.members.toString(), viewModel.t("Участники", "Учасники", "Members"), Modifier.weight(1f))
                    MetricCard(if (community.verifiedOnly) "100%" else "—", viewModel.t("Проверка", "Перевірка", "Verified"), Modifier.weight(1f))
                    MetricCard(if (community.online) "24/7" else viewModel.cityLabel(community.city), viewModel.t("Формат", "Формат", "Format"), Modifier.weight(1f))
                }
            }
            item {
                Button(onClick = { viewModel.toggleCommunityMembership(community) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (community.joined) viewModel.t("Покинуть группу", "Покинути групу", "Leave group") else viewModel.t("Вступить в группу", "Вступити до групи", "Join group"))
                }
            }
            item {
                InfoPanel(
                    viewModel.t("Правила сообщества", "Правила спільноти", "Community rules"),
                    viewModel.t("Уважение, отсутствие травли, запрет публикации личной переписки, прозрачность денежных интересов и модерация подтверждённых нарушений.", "Повага, відсутність цькування, заборона публікації особистого листування, прозорість грошових інтересів і модерація підтверджених порушень.", "Respect, no harassment, no publication of private chats, transparent financial interests and moderated verified violations.")
                )
            }
        }
    }
}

@Composable
private fun SettingsScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    var pilotInviteCode by remember { mutableStateOf("") }
    var pilotEligibilityAck by remember { mutableStateOf(false) }
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(viewModel.t("Настройки", "Налаштування", "Settings")) }, navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }) }
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { SettingsSectionTitle(viewModel.t("Язык", "Мова", "Language"), Icons.Default.Language) }
            item {
                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            viewModel.t(
                                "Выберите язык. Переключение применяется ко всему интерфейсу и контенту.",
                                "Оберіть мову. Перемикання застосовується до всього інтерфейсу та контенту.",
                                "Choose a language. The switch applies to the entire interface and content.",
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        LanguageCarousel(
                            languages = viewModel.supportedLanguages,
                            selected = viewModel.language,
                            onSelect = viewModel::changeLanguage,
                            compact = false,
                        )
                    }
                }
            }
            item { SettingsSectionTitle(viewModel.t("Тема", "Тема", "Theme"), if (viewModel.themeMode == AppThemeMode.DARK) Icons.Default.DarkMode else Icons.Default.LightMode) }
            item {
                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeRow(viewModel, AppThemeMode.SYSTEM, viewModel.t("Как в системе", "Як у системі", "System"), Icons.Default.Settings)
                        ThemeRow(viewModel, AppThemeMode.LIGHT, viewModel.t("Светлая", "Світла", "Light"), Icons.Default.LightMode)
                        ThemeRow(viewModel, AppThemeMode.DARK, viewModel.t("Чёрная", "Чорна", "Black"), Icons.Default.DarkMode)
                    }
                }
            }
            item { SettingsSectionTitle(viewModel.t("Обновления", "Оновлення", "Updates"), Icons.Default.Cached) }
            item {
                val context = LocalContext.current
                val info = viewModel.appUpdateInfo
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            viewModel.t(
                                "Установлено: ${org.federationofavatars.brotherhood.BuildConfig.VERSION_NAME} (${org.federationofavatars.brotherhood.BuildConfig.VERSION_CODE})",
                                "Встановлено: ${org.federationofavatars.brotherhood.BuildConfig.VERSION_NAME} (${org.federationofavatars.brotherhood.BuildConfig.VERSION_CODE})",
                                "Installed: ${org.federationofavatars.brotherhood.BuildConfig.VERSION_NAME} (${org.federationofavatars.brotherhood.BuildConfig.VERSION_CODE})"
                            ),
                            fontWeight = FontWeight.Bold
                        )
                        if (info == null) {
                            Text(viewModel.t("Серверный манифест обновлений пока недоступен.", "Серверний маніфест оновлень поки недоступний.", "Update manifest is currently unavailable."), style = MaterialTheme.typography.bodySmall)
                        } else {
                            Text(viewModel.t("Доступная версия: ${info.versionName} (${info.versionCode})", "Доступна версія: ${info.versionName} (${info.versionCode})", "Available version: ${info.versionName} (${info.versionCode})"), style = MaterialTheme.typography.bodySmall)
                            if (info.releaseNotes.isNotBlank()) Text(info.releaseNotes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val link = info.playUrl ?: info.testDownloadUrl
                            if (info.isNewerThan(org.federationofavatars.brotherhood.BuildConfig.VERSION_CODE) && link != null) {
                                Button(onClick = {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                                }, modifier = Modifier.fillMaxWidth()) {
                                    Text(viewModel.t("Открыть обновление", "Відкрити оновлення", "Open update"))
                                }
                            } else {
                                Text(viewModel.t("Версия актуальна или обновление выполняется через Google Play.", "Версія актуальна або оновлення виконується через Google Play.", "Version is current or updates are handled by Google Play."), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        OutlinedButton(onClick = viewModel::checkForUpdates, modifier = Modifier.fillMaxWidth()) { Text(viewModel.t("Проверить обновления", "Перевірити оновлення", "Check for updates")) }
                    }
                }
            }
            item { SettingsSectionTitle(viewModel.t("Улучшение подбора", "Покращення добору", "Improve matching"), Icons.Default.Psychology) }
            item {
                val pilot = viewModel.calibrationPilotInfo
                Card {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(viewModel.t("Закрытый пилот калибровки", "Закритий пілот калібрування", "Controlled calibration pilot"), fontWeight = FontWeight.Bold)
                        Text(
                            viewModel.t(
                                "Участники помогают проверить визуальные композиции на реальных данных. Сырые паттерны ответов хранятся отдельно и никогда не публикуются. Выход прекращает сбор и удаляет сохранённые сырые попытки; агрегированный профиль приложения сохраняется.",
                                "Учасники допомагають перевірити візуальні композиції на реальних даних. Сирі патерни відповідей зберігаються окремо й ніколи не публікуються. Вихід припиняє збір і видаляє збережені сирі спроби; агрегований профіль застосунку зберігається.",
                                "Participants help validate visual compositions with real data. Raw response patterns are stored separately and never published. Leaving stops collection and deletes stored raw attempts; the app's aggregate profile remains."
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (pilot != null) {
                            val localeRemaining = pilot.localeRemaining[viewModel.language.tag] ?: 0
                            Text(
                                viewModel.t(
                                    "Свободно мест: ${pilot.capacityRemaining}; для текущего языка: $localeRemaining",
                                    "Вільно місць: ${pilot.capacityRemaining}; для поточної мови: $localeRemaining",
                                    "Places remaining: ${pilot.capacityRemaining}; current language: $localeRemaining",
                                ),
                                style = MaterialTheme.typography.labelSmall,
                            )
                        }
                        if (viewModel.calibrationOptIn) {
                            Text(
                                viewModel.t("Вы участвуете в controlled pilot.", "Ви берете участь у controlled pilot.", "You are enrolled in the controlled pilot."),
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                            )
                            OutlinedButton(
                                onClick = viewModel::leaveCalibrationPilot,
                                enabled = !viewModel.calibrationPilotBusy,
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text(viewModel.t("Прекратить участие", "Припинити участь", "Leave pilot")) }
                        } else {
                            if (pilot?.inviteRequired != false) {
                                OutlinedTextField(
                                    value = pilotInviteCode,
                                    onValueChange = { pilotInviteCode = it.take(128) },
                                    label = { Text(viewModel.t("Код приглашения", "Код запрошення", "Invitation code")) },
                                    visualTransformation = PasswordVisualTransformation(),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = pilotEligibilityAck, onCheckedChange = { pilotEligibilityAck = it })
                                Text(
                                    viewModel.t(
                                        "Я понимаю добровольный характер участия и отдельное хранение сырых калибровочных данных.",
                                        "Я розумію добровільний характер участі та окреме зберігання сирих калібрувальних даних.",
                                        "I understand that participation is voluntary and raw calibration data is stored separately.",
                                    ),
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                            Button(
                                onClick = {
                                    val oneTimeCode = pilotInviteCode
                                    pilotInviteCode = ""
                                    viewModel.joinCalibrationPilot(oneTimeCode, pilotEligibilityAck)
                                },
                                enabled = pilotEligibilityAck && !viewModel.calibrationPilotBusy && (pilot?.enrollmentOpen != false),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                if (viewModel.calibrationPilotBusy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                else Text(viewModel.t("Вступить в пилот", "Вступити до пілоту", "Join pilot"))
                            }
                        }
                    }
                }
            }
            item { SettingsSectionTitle(viewModel.t("Данные и кеш", "Дані та кеш", "Data & cache"), Icons.Default.Cached) }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SettingInfo(Icons.Default.CloudOff, viewModel.t("Офлайн-режим", "Офлайн-режим", "Offline mode"), viewModel.t("Тесты, профиль и последний поиск доступны без сети", "Тести, профіль і останній пошук доступні без мережі", "Tests, profile and latest search remain available offline"))
                        SettingInfo(Icons.Default.Storage, "Vercel → Neon", viewModel.t("APK работает только с защищённым backend API; пароль базы остаётся на сервере", "APK працює лише із захищеним backend API; пароль бази залишається на сервері", "The APK uses only the protected backend API; database credentials stay on the server"))
                    }
                }
            }
            item {
                OutlinedButton(onClick = viewModel::signOut, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Logout, null)
                    Spacer(Modifier.width(8.dp))
                    Text(viewModel.t("Выйти", "Вийти", "Sign out"))
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionTitle(title: String, icon: ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ThemeRow(viewModel: MainViewModel, mode: AppThemeMode, label: String, icon: ImageVector) {
    Row(Modifier.fillMaxWidth().clickable { viewModel.setTheme(mode) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null)
        Spacer(Modifier.width(10.dp))
        Text(label, Modifier.weight(1f))
        Switch(checked = viewModel.themeMode == mode, onCheckedChange = { if (it) viewModel.setTheme(mode) })
    }
}

@Composable
private fun SettingInfo(icon: ImageVector, title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.width(10.dp))
        Column { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun EditProfileScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val initial = viewModel.profile
    var name by remember(initial) { mutableStateOf(initial.name) }
    var description by remember(initial) { mutableStateOf(initial.description) }
    var city by remember(initial) { mutableStateOf(initial.city) }
    var birthDate by remember(initial) { mutableStateOf(initial.birthDate.toString()) }
    var latinName by remember(initial) { mutableStateOf(initial.latinName) }
    var goals by remember(initial) { mutableStateOf(initial.goals.joinToString(", ")) }
    var interests by remember(initial) { mutableStateOf(initial.interests.joinToString(", ")) }
    var values by remember(initial) { mutableStateOf(initial.values.joinToString(", ")) }
    var lifestyle by remember(initial) { mutableStateOf(initial.lifestyle.joinToString(", ")) }
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) viewModel.importAvatar(uri)
    }

    fun tokens(value: String): List<String> = value
        .split(',', ';', '\n')
        .map(String::trim)
        .filter(String::isNotBlank)
        .distinct()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(viewModel.t("Редактирование профиля", "Редагування профілю", "Edit profile"), fontWeight = FontWeight.Black) },
                navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("global_id ${initial.globalId.display}", fontWeight = FontWeight.Black)
                    Text(
                        viewModel.t(
                            "Профиль хранится локально, работает офлайн и синхронизируется через основной backend.",
                            "Профіль зберігається локально, працює офлайн і синхронізується через основний backend.",
                            "The profile is stored locally, works offline and syncs through the core backend."
                        ),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Card(shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(initial.name, false, viewModel.profile.avatarLocalPath, 88.dp)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(viewModel.t("Фото профиля", "Фото профілю", "Profile photo"), fontWeight = FontWeight.Bold)
                        Text(
                            viewModel.t("Изображение копируется в защищённое хранилище приложения, уменьшается и синхронизируется без доступа ко всей медиатеке.", "Зображення копіюється у захищене сховище застосунку, зменшується та синхронізується без доступу до всієї медіатеки.", "The selected image is copied into app-private storage, resized and synced without broad media-library access."),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(onClick = { avatarPicker.launch("image/*") }) {
                            Icon(Icons.Default.Edit, null)
                            Spacer(Modifier.width(8.dp))
                            Text(viewModel.t("Загрузить аватар", "Завантажити аватар", "Upload avatar"))
                        }
                    }
                }
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Имя", "Ім’я", "Name")) },
                singleLine = true
            )
            OutlinedTextField(
                value = birthDate,
                onValueChange = { birthDate = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Дата рождения", "Дата народження", "Birth date")) },
                supportingText = { Text("YYYY-MM-DD · 18+") },
                singleLine = true
            )
            OutlinedTextField(
                value = latinName,
                onValueChange = { latinName = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Имя латиницей для нумерологии", "Ім’я латиницею для нумерології", "Latin name for numerology")) },
                supportingText = { Text(viewModel.t("Например: ALEX MORGAN", "Наприклад: ALEX MORGAN", "Example: ALEX MORGAN")) },
                singleLine = true
            )
            OutlinedTextField(
                value = city,
                onValueChange = { city = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Город", "Місто", "City")) },
                leadingIcon = { Icon(Icons.Default.LocationCity, null) },
                singleLine = true
            )
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("О себе", "Про себе", "About")) },
                minLines = 3
            )

            SettingsSectionTitle(viewModel.t("Основа совместимости", "Основа сумісності", "Compatibility foundation"), Icons.Default.AutoAwesome)
            OutlinedTextField(
                value = goals,
                onValueChange = { goals = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Цели дружбы", "Цілі дружби", "Friendship goals")) },
                supportingText = { Text(viewModel.t("Разделяйте значения запятыми", "Розділяйте значення комами", "Separate values with commas")) },
                minLines = 2
            )
            OutlinedTextField(
                value = interests,
                onValueChange = { interests = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Интересы", "Інтереси", "Interests")) },
                minLines = 2
            )
            OutlinedTextField(
                value = values,
                onValueChange = { values = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Ценности", "Цінності", "Values")) },
                minLines = 2
            )
            OutlinedTextField(
                value = lifestyle,
                onValueChange = { lifestyle = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Образ жизни", "Спосіб життя", "Lifestyle")) },
                minLines = 2
            )

            val parsedBirthDate = runCatching { LocalDate.parse(birthDate) }.getOrNull()
            val adultBirthDate = parsedBirthDate?.takeIf { Period.between(it, LocalDate.now()).years >= 18 }
            InfoPanel(
                viewModel.t("Автоматические слои", "Автоматичні шари", "Automatic layers"),
                if (adultBirthDate == null)
                    viewModel.t("Укажите корректную дату рождения в формате YYYY-MM-DD (18+).", "Вкажіть коректну дату народження у форматі YYYY-MM-DD (18+).", "Enter a valid birth date as YYYY-MM-DD (18+).")
                else
                    viewModel.t("Зодиак и ведическая нумерология будут пересчитаны при сохранении.", "Зодіак і ведична нумерологія будуть перераховані під час збереження.", "Zodiac and Vedic numerology will be recalculated on save.")
            )

            Button(
                onClick = {
                    val validBirthDate = adultBirthDate ?: return@Button
                    viewModel.updateProfile(
                        name = name,
                        description = description,
                        city = city,
                        birthDate = validBirthDate,
                        latinName = latinName,
                        goals = tokens(goals),
                        interests = tokens(interests),
                        values = tokens(values),
                        lifestyle = tokens(lifestyle)
                    )
                    viewModel.showMessage(viewModel.t("Профиль сохранён локально и поставлен в очередь синхронизации", "Профіль збережено локально та поставлено в чергу синхронізації", "Profile saved locally and queued for synchronization"))
                    viewModel.closeOverlay()
                },
                enabled = adultBirthDate != null,
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.Cached, null)
                Spacer(Modifier.width(8.dp))
                Text(viewModel.t("Сохранить профиль", "Зберегти профіль", "Save profile"))
            }
        }
    }
}

@Composable
private fun CityDialog(viewModel: MainViewModel, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text(viewModel.t("Закрыть", "Закрити", "Close")) } },
        title = { Text(viewModel.t("Выберите город", "Оберіть місто", "Choose city"), fontWeight = FontWeight.Black) },
        text = {
            Column(Modifier.fillMaxHeight(.6f).verticalScroll(rememberScrollState())) {
                viewModel.cities.forEach { city ->
                    Row(Modifier.fillMaxWidth().clickable { viewModel.selectCity(city); onDismiss() }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationCity, null)
                        Spacer(Modifier.width(10.dp))
                        Text(viewModel.cityLabel(city), Modifier.weight(1f))
                        if (city == viewModel.selectedCity) Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                    }
                    HorizontalDivider()
                }
            }
        }
    )
}

@Composable
private fun InfoPanel(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(body, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Search, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        Text(message, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
