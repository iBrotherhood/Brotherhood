@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package org.federationofavatars.brotherhood.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.Period
import kotlinx.coroutines.launch
import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.data.pick
import org.federationofavatars.brotherhood.location.CityLocationResolver
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.AppRoute
import org.federationofavatars.brotherhood.model.AppThemeMode
import org.federationofavatars.brotherhood.model.AssessmentDefinition
import org.federationofavatars.brotherhood.model.AssessmentKind
import org.federationofavatars.brotherhood.model.AuthProvider
import org.federationofavatars.brotherhood.model.Community
import org.federationofavatars.brotherhood.model.CommunityKind
import org.federationofavatars.brotherhood.model.CompatibilityBreakdown
import org.federationofavatars.brotherhood.model.FriendCandidate
import org.federationofavatars.brotherhood.model.MainTab

@Composable
fun BrotherhoodApp(viewModel: MainViewModel) {
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(viewModel.uiMessage) {
        viewModel.uiMessage?.let {
            snackbar.showSnackbar(it)
            viewModel.consumeMessage()
        }
    }

    Box(Modifier.fillMaxSize()) {
        when (viewModel.route) {
            AppRoute.AUTH -> AuthScreen(viewModel)
            AppRoute.HOME -> HomeScaffold(viewModel, snackbar)
            AppRoute.CANDIDATE -> CandidateDetailScreen(viewModel, snackbar)
            AppRoute.COMMUNITY -> CommunityDetailScreen(viewModel, snackbar)
            AppRoute.SETTINGS -> SettingsScreen(viewModel, snackbar)
            AppRoute.EDIT_PROFILE -> EditProfileScreen(viewModel, snackbar)
            AppRoute.SERVICES -> ServicesScreen(viewModel, snackbar)
            AppRoute.MESSAGES -> MessagesScreen(viewModel, snackbar)
        }
    }
}

private fun MainViewModel.t(ru: String, uk: String, en: String): String = language.pick(ru, uk, en)

@Composable
private fun AuthScreen(viewModel: MainViewModel) {
    val lang = viewModel.language
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                AppLanguage.entries.forEach { language ->
                    FilterChip(
                        selected = lang == language,
                        onClick = { viewModel.changeLanguage(language) },
                        label = { Text(language.tag.uppercase()) },
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Box(
                    Modifier.size(96.dp).clip(RoundedCornerShape(28.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Shield, null, Modifier.size(52.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
                Spacer(Modifier.height(24.dp))
                Text("BROTHERHOOD", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text(
                    lang.pick("Настоящие друзья для мужчин", "Справжні друзі для чоловіків", "Real friends for men"),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    lang.pick(
                        "Совместимость характера, ценностей и образа жизни. Без романтических знакомств.",
                        "Сумісність характеру, цінностей і способу життя. Без романтичних знайомств.",
                        "Character, values and lifestyle compatibility. No romantic dating."
                    ),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ProviderButton("G", viewModel.t("Продолжить с Google", "Продовжити з Google", "Continue with Google")) { viewModel.signIn(AuthProvider.GOOGLE) }
                ProviderButton("➤", viewModel.t("Продолжить с Telegram", "Продовжити з Telegram", "Continue with Telegram")) { viewModel.signIn(AuthProvider.TELEGRAM) }
                ProviderButton("f", viewModel.t("Продолжить с Facebook", "Продовжити з Facebook", "Continue with Facebook")) { viewModel.signIn(AuthProvider.FACEBOOK) }
                OutlinedButton(onClick = { viewModel.signIn(AuthProvider.EMAIL) }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Icon(Icons.Default.Email, null)
                    Spacer(Modifier.width(10.dp))
                    Text(viewModel.t("Электронная почта", "Електронна пошта", "Email"))
                }
                OutlinedButton(onClick = { viewModel.signIn(AuthProvider.PASSKEY) }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Icon(Icons.Default.Fingerprint, null)
                    Spacer(Modifier.width(10.dp))
                    Text(viewModel.t("Ключ доступа / Passkey", "Ключ доступу / Passkey", "Passkey"))
                }
                Text(
                    viewModel.t("Архитектура допускает подключение новых провайдеров без смены global_id.", "Архітектура дозволяє підключати нових провайдерів без зміни global_id.", "The architecture supports future providers without changing global_id."),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    viewModel.t(
                        "Вход создаёт единый аккаунт global_id. Провайдеры используются только для подтверждения доступа.",
                        "Вхід створює єдиний акаунт global_id. Провайдери використовуються лише для підтвердження доступу.",
                        "Sign-in creates one global_id account. Providers only verify access."
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun ProviderButton(mark: String, title: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(54.dp)) {
        Box(
            Modifier.size(26.dp).clip(CircleShape).background(MaterialTheme.colorScheme.onPrimary.copy(alpha = .14f)),
            contentAlignment = Alignment.Center
        ) { Text(mark, fontWeight = FontWeight.Black) }
        Spacer(Modifier.width(10.dp))
        Text(title)
    }
}

@Composable
private fun HomeScaffold(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showCityDialog by remember { mutableStateOf(false) }
    var locating by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            locating = true
            scope.launch {
                val city = CityLocationResolver.resolveCity(context)
                if (city != null) viewModel.selectCity(city) else viewModel.reportLocationFailure()
                locating = false
            }
        } else viewModel.reportLocationFailure()
    }

    fun requestCityLocation() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locating = true
            scope.launch {
                val city = CityLocationResolver.resolveCity(context)
                if (city != null) viewModel.selectCity(city) else viewModel.reportLocationFailure()
                locating = false
            }
        } else permissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("BROTHERHOOD", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                        Text("ID ${viewModel.profile.globalId.display}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    IconButton(onClick = viewModel::openMessages) { Icon(Icons.Default.Chat, null) }
                    IconButton(onClick = viewModel::openServices) { Icon(Icons.Default.AutoAwesome, null) }
                    IconButton(onClick = viewModel::openSettings) { Icon(Icons.Default.Settings, null) }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                MainTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = viewModel.selectedTab == tab,
                        onClick = { viewModel.selectTab(tab) },
                        icon = { Icon(tab.icon(), null) },
                        label = { Text(tab.label(viewModel.language), maxLines = 1) }
                    )
                }
            }
        }
    ) { padding ->
        Surface(Modifier.padding(padding).fillMaxSize()) {
            when (viewModel.selectedTab) {
                MainTab.DISCOVER -> DiscoverScreen(viewModel, locating, { showCityDialog = true }, ::requestCityLocation)
                MainTab.COMMUNITIES -> CommunitiesScreen(viewModel)
                MainTab.TESTS -> TestsScreen(viewModel)
                MainTab.TRUST -> TrustScreen(viewModel)
                MainTab.PROFILE -> ProfileScreen(viewModel)
            }
        }
    }

    if (showCityDialog) CityDialog(viewModel) { showCityDialog = false }
}

private fun MainTab.icon(): ImageVector = when (this) {
    MainTab.DISCOVER -> Icons.Default.Explore
    MainTab.COMMUNITIES -> Icons.Default.Groups
    MainTab.TESTS -> Icons.Default.Psychology
    MainTab.TRUST -> Icons.Default.Shield
    MainTab.PROFILE -> Icons.Default.Person
}

private fun MainTab.label(language: AppLanguage): String = when (this) {
    MainTab.DISCOVER -> language.pick("Люди", "Люди", "People")
    MainTab.COMMUNITIES -> language.pick("Группы", "Групи", "Groups")
    MainTab.TESTS -> language.pick("Тесты", "Тести", "Tests")
    MainTab.TRUST -> language.pick("Доверие", "Довіра", "Trust")
    MainTab.PROFILE -> language.pick("Профиль", "Профіль", "Profile")
}

@Composable
private fun DiscoverScreen(viewModel: MainViewModel, locating: Boolean, onChooseCity: () -> Unit, onLocate: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(viewModel.t("Найди своего человека", "Знайди свою людину", "Find your person"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text(
                viewModel.t("Для дружбы, взаимопомощи, спорта и совместных дел", "Для дружби, взаємодопомоги, спорту та спільних справ", "For friendship, mutual support, sports and shared projects"),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item { DiscoveryHero(viewModel) }
        item { LocationControls(viewModel, locating, onChooseCity, onLocate) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf(10, 25, 50, 100)) { radius ->
                    FilterChip(selected = viewModel.radiusKm == radius, onClick = { viewModel.setRadius(radius) }, label = { Text("$radius km") })
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(viewModel.t("Лучшие совпадения", "Найкращі збіги", "Best matches"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                IconButton(onClick = { viewModel.showMessage(viewModel.t("Расширенные фильтры будут открыты", "Розширені фільтри буде відкрито", "Advanced filters opened")) }) { Icon(Icons.Default.Tune, null) }
            }
        }
        if (viewModel.candidates.isEmpty()) {
            item { EmptyState(viewModel.t("В этом городе пока нет совпадений", "У цьому місті поки немає збігів", "No matches in this city yet")) }
        } else {
            items(viewModel.candidates, key = { it.globalId.value }) { candidate ->
                CandidateCard(viewModel, candidate)
            }
        }
    }
}

@Composable
private fun DiscoveryHero(viewModel: MainViewModel) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(28.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(viewModel.t("Совместимость настоящей дружбы", "Сумісність справжньої дружби", "Real friendship compatibility"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                Text(
                    viewModel.t(
                        "100 тестов + характер + ценности + образ жизни + Brotherhood‑32 + эннеаграмма + зодиак + ведическая нумерология.",
                        "100 тестів + характер + цінності + спосіб життя + Brotherhood‑32 + еннеаграма + зодіак + ведична нумерологія.",
                        "100 tests + character + values + lifestyle + Brotherhood‑32 + Enneagram + zodiac + Vedic numerology."
                    ),
                    style = MaterialTheme.typography.bodyMedium
                )
                AssistChip(onClick = { viewModel.selectTab(MainTab.TESTS) }, label = { Text(viewModel.t("Продолжить тесты", "Продовжити тести", "Continue tests")) }, leadingIcon = { Icon(Icons.Default.AutoAwesome, null) })
            }
            Spacer(Modifier.width(14.dp))
            ScoreRing(viewModel.accountRating.total.toInt(), 82.dp, viewModel.t("рейтинг", "рейтинг", "rating"))
        }
    }
}

@Composable
private fun LocationControls(viewModel: MainViewModel, locating: Boolean, onChooseCity: () -> Unit, onLocate: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f))) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationCity, null)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(viewModel.t("Город поиска", "Місто пошуку", "Search city"), style = MaterialTheme.typography.labelMedium)
                    Text(viewModel.selectedCity, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onChooseCity) { Text(viewModel.t("Изменить", "Змінити", "Change")) }
            }
            OutlinedButton(onClick = onLocate, enabled = !locating, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.MyLocation, null)
                Spacer(Modifier.width(8.dp))
                Text(if (locating) viewModel.t("Определяем город…", "Визначаємо місто…", "Detecting city…") else viewModel.t("Определить мой город", "Визначити моє місто", "Detect my city"))
            }
            viewModel.locationStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun CandidateCard(viewModel: MainViewModel, candidate: FriendCandidate) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { viewModel.openCandidate(candidate) },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(candidate.name, candidate.online)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${candidate.name}, ${candidate.age}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (candidate.verified) {
                            Spacer(Modifier.width(5.dp))
                            Icon(Icons.Default.Verified, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.secondary)
                        }
                    }
                    Text("${candidate.city} · ${candidate.distanceKm} km · ID ${candidate.globalId.display}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${candidate.personality32.code} · ${candidate.personality32.title(viewModel.language)}", style = MaterialTheme.typography.labelMedium)
                }
                ScoreRing(candidate.compatibility, 64.dp, viewModel.t("совм.", "сум.", "match"))
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(candidate.interests.take(4)) { TraitChip(it) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniStat(Icons.Default.Shield, candidate.trustScore.toString(), viewModel.t("доверие", "довіра", "trust"), Modifier.weight(1f))
                MiniStat(Icons.Default.Star, candidate.accountRating.toString(), viewModel.t("аккаунт", "акаунт", "account"), Modifier.weight(1f))
                MiniStat(Icons.Default.AutoAwesome, "${candidate.enneagram.type}w${candidate.enneagram.wing}", "Enneagram", Modifier.weight(1f))
                MiniStat(Icons.Default.CalendarMonth, candidate.zodiac.symbol, viewModel.t("зодиак", "зодіак", "zodiac"), Modifier.weight(1f))
            }
            Button(onClick = { viewModel.openCandidate(candidate) }, modifier = Modifier.fillMaxWidth()) {
                Text(viewModel.t("Открыть совместимость", "Відкрити сумісність", "Open compatibility"))
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Default.ChevronRight, null)
            }
        }
    }
}

@Composable
private fun Avatar(name: String, online: Boolean) {
    Box(Modifier.size(56.dp)) {
        Box(
            Modifier.fillMaxSize().clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer),
            contentAlignment = Alignment.Center
        ) { Text(name.take(1).uppercase(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black) }
        if (online) Box(
            Modifier.size(14.dp).align(Alignment.BottomEnd).clip(CircleShape).background(Color(0xFF2ECC71)).border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
        )
    }
}

@Composable
private fun ScoreRing(score: Int, size: androidx.compose.ui.unit.Dp, label: String) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(progress = { score.coerceIn(0, 100) / 100f }, modifier = Modifier.fillMaxSize(), strokeWidth = 7.dp, trackColor = MaterialTheme.colorScheme.surfaceVariant)
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$score%", fontWeight = FontWeight.Black, fontSize = if (size > 70.dp) 18.sp else 14.sp)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun TraitChip(text: String) {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceVariant) {
        Text(text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun MiniStat(icon: ImageVector, value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
        Text(value, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
private fun CommunitiesScreen(viewModel: MainViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text(viewModel.t("Мужские сообщества", "Чоловічі спільноти", "Men's communities"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text(viewModel.t("Интересы, спорт, автомобили, взаимопомощь и бизнес", "Інтереси, спорт, автомобілі, взаємодопомога та бізнес", "Interests, sports, cars, mutual support and business"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = viewModel.communityKind == CommunityKind.INTEREST,
                    onClick = { viewModel.selectCommunityKind(CommunityKind.INTEREST) },
                    label = { Text(viewModel.t("Интересы", "Інтереси", "Interests")) },
                    leadingIcon = { Icon(Icons.Default.Groups, null) }
                )
                FilterChip(
                    selected = viewModel.communityKind == CommunityKind.BUSINESS,
                    onClick = { viewModel.selectCommunityKind(CommunityKind.BUSINESS) },
                    label = { Text(viewModel.t("Бизнес", "Бізнес", "Business")) },
                    leadingIcon = { Icon(Icons.Default.BusinessCenter, null) }
                )
            }
        }
        item { CommunityHero(viewModel) }
        items(viewModel.communities, key = Community::id) { community -> CommunityCard(viewModel, community) }
        item {
            OutlinedButton(onClick = { viewModel.showMessage(viewModel.t("Форма создания группы открыта", "Форму створення групи відкрито", "Create group form opened")) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(8.dp))
                Text(viewModel.t("Создать своё сообщество", "Створити свою спільноту", "Create your community"))
            }
        }
    }
}

@Composable
private fun CommunityHero(viewModel: MainViewModel) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), shape = RoundedCornerShape(24.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (viewModel.communityKind == CommunityKind.BUSINESS) Icons.Default.Work else Icons.Default.People, null, Modifier.size(42.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    if (viewModel.communityKind == CommunityKind.BUSINESS) viewModel.t("Деловые связи с правилами доверия", "Ділові зв’язки з правилами довіри", "Business connections with trust rules")
                    else viewModel.t("Общие интересы превращаются в дружбу", "Спільні інтереси перетворюються на дружбу", "Shared interests become friendship"),
                    fontWeight = FontWeight.Bold
                )
                Text(viewModel.t("По городу или онлайн. Можно включить доступ только для подтверждённых аккаунтов.", "За містом або онлайн. Можна увімкнути доступ лише для підтверджених акаунтів.", "Local or online. Verified-only access can be enabled."), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun CommunityCard(viewModel: MainViewModel, community: Community) {
    Card(modifier = Modifier.fillMaxWidth().clickable { viewModel.openCommunity(community) }, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                    Icon(if (community.kind == CommunityKind.BUSINESS) Icons.Default.BusinessCenter else Icons.Default.Groups, null)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(community.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${community.category} · ${community.city} · ${community.members}", style = MaterialTheme.typography.bodySmall)
                }
                if (community.verifiedOnly) Icon(Icons.Default.Verified, null, tint = MaterialTheme.colorScheme.secondary)
            }
            Text(community.description, style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                if (community.online) TraitChip(viewModel.t("Онлайн", "Онлайн", "Online"))
                if (community.verifiedOnly) TraitChip(viewModel.t("Только проверенные", "Лише перевірені", "Verified only"))
            }
            FilledTonalButton(onClick = { viewModel.toggleCommunityMembership(community) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (community.joined) viewModel.t("Вы участник", "Ви учасник", "Joined") else viewModel.t("Вступить", "Вступити", "Join"))
            }
        }
    }
}

@Composable
private fun TestsScreen(viewModel: MainViewModel) {
    if (viewModel.activeAssessment != null) {
        AssessmentDialog(viewModel)
        return
    }

    var coreModule by remember { mutableStateOf<String?>(null) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text(viewModel.t("Профиль совместимости", "Профіль сумісності", "Compatibility profile"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text(viewModel.t("Не один ярлык, а многослойная модель мужской дружбы", "Не один ярлик, а багатошарова модель чоловічої дружби", "Not one label, but a layered model of male friendship"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { TestProgressCard(viewModel) }
        item {
            Text(viewModel.t("Основные модели личности", "Основні моделі особистості", "Core personality models"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                CoreModelCard(Icons.Default.Psychology, "Brotherhood‑32", viewModel.profile.personality32.title(viewModel.language), viewModel.profile.personality32.code) { viewModel.startCoreAssessment("p32") }
                CoreModelCard(Icons.Default.Fingerprint, viewModel.t("Эннеаграмма", "Еннеаграма", "Enneagram"), viewModel.profile.enneagram.title(viewModel.language), "${viewModel.profile.enneagram.type}w${viewModel.profile.enneagram.wing}") { viewModel.startCoreAssessment("enneagram") }
                CoreModelCard(Icons.Default.CalendarMonth, viewModel.t("Зодиак", "Зодіак", "Zodiac"), viewModel.profile.zodiac.name, viewModel.profile.zodiac.symbol) { coreModule = "zodiac" }
                CoreModelCard(Icons.Default.AutoAwesome, viewModel.t("Ведическая нумерология", "Ведична нумерологія", "Vedic numerology"), viewModel.t("Число души ${viewModel.profile.numerology.soulNumber}", "Число душі ${viewModel.profile.numerology.soulNumber}", "Soul number ${viewModel.profile.numerology.soulNumber}"), "${viewModel.profile.numerology.destinyNumber}") { coreModule = "numerology" }
            }
        }
        item {
            Text(viewModel.t("100 тестов мужской дружбы", "100 тестів чоловічої дружби", "100 male friendship tests"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(viewModel.t("Каждый завершённый тест добавляет 0,5% к рейтингу аккаунта", "Кожен завершений тест додає 0,5% до рейтингу акаунта", "Each completed test adds 0.5% to account rating"), style = MaterialTheme.typography.bodySmall)
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(selected = viewModel.selectedAssessmentKind == null, onClick = { viewModel.selectAssessmentKind(null) }, label = { Text(viewModel.t("Все", "Усі", "All")) }) }
                items(viewModel.assessmentKinds) { kind ->
                    FilterChip(selected = viewModel.selectedAssessmentKind == kind, onClick = { viewModel.selectAssessmentKind(kind) }, label = { Text(kindLabel(kind, viewModel.language)) })
                }
            }
        }
        items(viewModel.assessmentDefinitions, key = AssessmentDefinition::id) { assessment ->
            AssessmentCard(viewModel, assessment)
        }
    }

    if (viewModel.activeCoreModule != null) {
        CoreProfileAssessmentDialog(viewModel)
    }
    coreModule?.let { module ->
        CoreModuleDialog(viewModel, module) { coreModule = null }
    }
}

@Composable
private fun TestProgressCard(viewModel: MainViewModel) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(26.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ScoreRing(viewModel.accountRating.total.toInt(), 76.dp, viewModel.t("аккаунт", "акаунт", "account"))
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(viewModel.t("Рейтинг аккаунта", "Рейтинг акаунта", "Account rating"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    Text(viewModel.t("50% профиль + 50% тесты", "50% профіль + 50% тести", "50% profile + 50% tests"))
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { viewModel.completedResults.size / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("${viewModel.completedResults.size}/100 · ${viewModel.accountRating.testPoints}%", style = MaterialTheme.typography.labelSmall)
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .2f))
            Text(viewModel.t("Проверка согласованности ответов: ${viewModel.integrityScreening.consistencyScore}%", "Перевірка узгодженості відповідей: ${viewModel.integrityScreening.consistencyScore}%", "Answer consistency: ${viewModel.integrityScreening.consistencyScore}%"), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun CoreModelCard(icon: ImageVector, title: String, subtitle: String, badge: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) { Icon(icon, null) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.primaryContainer) { Text(badge, Modifier.padding(horizontal = 9.dp, vertical = 6.dp), fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun AssessmentCard(viewModel: MainViewModel, assessment: AssessmentDefinition) {
    val completed = viewModel.completedResults[assessment.id]
    Card(shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${assessment.id.removePrefix("f").toInt()} / 100", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                if (assessment.safetyCritical) Badge { Text("!") }
                Spacer(Modifier.weight(1f))
                Text(if (completed == null) "+0.5%" else "${completed.totalScore}/100", fontWeight = FontWeight.Bold)
            }
            Text(assessment.title, fontWeight = FontWeight.Bold)
            Text(kindLabel(assessment.kind, viewModel.language), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (completed != null) LinearProgressIndicator(progress = { completed.totalScore / 100f }, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { viewModel.startAssessment(assessment.id) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (completed == null) viewModel.t("Начать", "Почати", "Start") else viewModel.t("Пройти заново", "Пройти знову", "Retake"))
            }
        }
    }
}

private fun kindLabel(kind: AssessmentKind, language: AppLanguage): String = when (kind) {
    AssessmentKind.LOYALTY -> language.pick("Верность", "Вірність", "Loyalty")
    AssessmentKind.INTEGRITY -> language.pick("Честность", "Чесність", "Integrity")
    AssessmentKind.RELIABILITY -> language.pick("Надёжность", "Надійність", "Reliability")
    AssessmentKind.CONFLICT -> language.pick("Конфликты", "Конфлікти", "Conflict")
    AssessmentKind.BOUNDARIES -> language.pick("Границы", "Межі", "Boundaries")
    AssessmentKind.SUPPORT -> language.pick("Поддержка", "Підтримка", "Support")
    AssessmentKind.COMPETITION -> language.pick("Конкуренция", "Конкуренція", "Competition")
    AssessmentKind.COMMUNICATION -> language.pick("Общение", "Спілкування", "Communication")
    AssessmentKind.MUTUAL_AID -> language.pick("Деньги и бизнес", "Гроші та бізнес", "Money & business")
    AssessmentKind.LIFESTYLE -> language.pick("Ценности и жизнь", "Цінності та життя", "Values & lifestyle")
}

@Composable
private fun AssessmentDialog(viewModel: MainViewModel) {
    val assessment = viewModel.activeAssessment ?: return
    val question = viewModel.currentQuestion ?: return
    AlertDialog(
        onDismissRequest = viewModel::closeAssessment,
        confirmButton = {},
        title = {
            Column {
                Text(assessment.title, fontWeight = FontWeight.Black)
                Text("${viewModel.currentQuestionIndex + 1}/${assessment.questions.size}", style = MaterialTheme.typography.labelMedium)
                LinearProgressIndicator(progress = { (viewModel.currentQuestionIndex + 1f) / assessment.questions.size }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(question.text, style = MaterialTheme.typography.titleMedium)
                listOf(
                    viewModel.t("Полностью не согласен", "Повністю не згоден", "Strongly disagree"),
                    viewModel.t("Скорее не согласен", "Скоріше не згоден", "Disagree"),
                    viewModel.t("Не уверен", "Не впевнений", "Unsure"),
                    viewModel.t("Скорее согласен", "Скоріше згоден", "Agree"),
                    viewModel.t("Полностью согласен", "Повністю згоден", "Strongly agree")
                ).forEachIndexed { index, label ->
                    FilterChip(
                        selected = viewModel.assessmentAnswers[question.id] == index + 1,
                        onClick = { viewModel.selectAssessmentAnswer(index + 1) },
                        label = { Text(label) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = viewModel::previousAssessmentQuestion, enabled = viewModel.currentQuestionIndex > 0) { Text(viewModel.t("Назад", "Назад", "Back")) }
                    if (viewModel.currentQuestionIndex == assessment.questions.lastIndex) {
                        Button(onClick = viewModel::finishAssessment, enabled = viewModel.canFinishAssessment) { Text(viewModel.t("Завершить", "Завершити", "Finish")) }
                    } else {
                        Button(onClick = viewModel::nextAssessmentQuestion, enabled = viewModel.assessmentAnswers[question.id] in 1..5) { Text(viewModel.t("Далее", "Далі", "Next")) }
                    }
                }
                viewModel.currentResult?.let { result ->
                    InfoPanel("${result.totalScore}/100 · ${result.label}", result.summary)
                    Button(onClick = viewModel::closeAssessment, modifier = Modifier.fillMaxWidth()) { Text(viewModel.t("Закрыть", "Закрити", "Close")) }
                }
            }
        }
    )
}

@Composable
private fun CoreProfileAssessmentDialog(viewModel: MainViewModel) {
    val module = viewModel.activeCoreModule ?: return
    val question = viewModel.currentCoreQuestion ?: return
    val title = if (module == "p32") "Brotherhood‑32" else viewModel.t("Эннеаграмма", "Еннеаграма", "Enneagram")
    AlertDialog(
        onDismissRequest = viewModel::closeCoreAssessment,
        confirmButton = {},
        title = {
            Column {
                Text(title, fontWeight = FontWeight.Black)
                Text("${viewModel.coreQuestionIndex + 1}/${viewModel.coreQuestions.size}", style = MaterialTheme.typography.labelMedium)
                LinearProgressIndicator(
                    progress = { (viewModel.coreQuestionIndex + 1f) / viewModel.coreQuestions.size },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(question.text(viewModel.language), style = MaterialTheme.typography.titleMedium)
                listOf(
                    viewModel.t("Полностью не согласен", "Повністю не згоден", "Strongly disagree"),
                    viewModel.t("Скорее не согласен", "Скоріше не згоден", "Disagree"),
                    viewModel.t("Не уверен", "Не впевнений", "Unsure"),
                    viewModel.t("Скорее согласен", "Скоріше згоден", "Agree"),
                    viewModel.t("Полностью согласен", "Повністю згоден", "Strongly agree")
                ).forEachIndexed { index, label ->
                    FilterChip(
                        selected = viewModel.coreAnswers[question.id] == index + 1,
                        onClick = { viewModel.selectCoreAnswer(index + 1) },
                        label = { Text(label) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(
                        onClick = viewModel::previousCoreQuestion,
                        enabled = viewModel.coreQuestionIndex > 0
                    ) { Text(viewModel.t("Назад", "Назад", "Back")) }
                    if (viewModel.coreQuestionIndex == viewModel.coreQuestions.lastIndex) {
                        Button(onClick = viewModel::finishCoreAssessment, enabled = viewModel.canFinishCoreAssessment) {
                            Text(viewModel.t("Сохранить результат", "Зберегти результат", "Save result"))
                        }
                    } else {
                        Button(
                            onClick = viewModel::nextCoreQuestion,
                            enabled = viewModel.coreAnswers[question.id] in 1..5
                        ) { Text(viewModel.t("Далее", "Далі", "Next")) }
                    }
                }
            }
        }
    )
}

@Composable
private fun CoreModuleDialog(viewModel: MainViewModel, module: String, onDismiss: () -> Unit) {
    val title: String
    val body: String
    when (module) {
        "p32" -> {
            title = "Brotherhood‑32 · ${viewModel.profile.personality32.code}"
            body = viewModel.t(
                "${viewModel.profile.personality32.title(viewModel.language)}. Пять осей: социальная энергия, восприятие, решения, жизненный ритм и стиль долгосрочной связи.",
                "${viewModel.profile.personality32.title(viewModel.language)}. П’ять осей: соціальна енергія, сприйняття, рішення, життєвий ритм і стиль довгострокового зв’язку.",
                "${viewModel.profile.personality32.title(viewModel.language)}. Five axes: social energy, perception, decisions, life rhythm and long-term bond style."
            )
        }
        "enneagram" -> {
            title = viewModel.t("Эннеаграмма ${viewModel.profile.enneagram.type}w${viewModel.profile.enneagram.wing}", "Еннеаграма ${viewModel.profile.enneagram.type}w${viewModel.profile.enneagram.wing}", "Enneagram ${viewModel.profile.enneagram.type}w${viewModel.profile.enneagram.wing}")
            body = viewModel.t("Мотивационный слой профиля. Используется как дополнительный, а не решающий фактор.", "Мотиваційний шар профілю. Використовується як додатковий, а не вирішальний фактор.", "Motivational profile layer. Used as an additional, not decisive, factor.")
        }
        "zodiac" -> {
            title = "${viewModel.profile.zodiac.symbol} ${viewModel.profile.zodiac.name}"
            body = viewModel.t("Зодиакальный слой совместимости рассчитывается по дате рождения и имеет небольшой вес.", "Зодіакальний шар сумісності розраховується за датою народження та має невелику вагу.", "The zodiac compatibility layer is calculated from birth date and has a small weight.")
        }
        else -> {
            title = viewModel.t("Ведическая нумерология", "Ведична нумерологія", "Vedic numerology")
            body = viewModel.t(
                "Число души ${viewModel.profile.numerology.soulNumber}, судьбы ${viewModel.profile.numerology.destinyNumber}, имени ${viewModel.profile.numerology.nameNumber}, зрелости ${viewModel.profile.numerology.maturityNumber}.",
                "Число душі ${viewModel.profile.numerology.soulNumber}, долі ${viewModel.profile.numerology.destinyNumber}, імені ${viewModel.profile.numerology.nameNumber}, зрілості ${viewModel.profile.numerology.maturityNumber}.",
                "Soul ${viewModel.profile.numerology.soulNumber}, destiny ${viewModel.profile.numerology.destinyNumber}, name ${viewModel.profile.numerology.nameNumber}, maturity ${viewModel.profile.numerology.maturityNumber}."
            )
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { Button(onClick = onDismiss) { Text(viewModel.t("Готово", "Готово", "Done")) } },
        title = { Text(title, fontWeight = FontWeight.Black) },
        text = { Text(body) }
    )
}

@Composable
private fun TrustScreen(viewModel: MainViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text(viewModel.t("Репутация доверия", "Репутація довіри", "Trust reputation"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text(viewModel.t("Отдельно от психологических тестов", "Окремо від психологічних тестів", "Separate from personality tests"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(26.dp)) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    ScoreRing(viewModel.profile.trustScore, 88.dp, viewModel.t("доверие", "довіра", "trust"))
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(viewModel.t("Подтверждённая репутация", "Підтверджена репутація", "Verified reputation"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                        Text(viewModel.t("Реальные взаимодействия и решения модерации", "Реальні взаємодії та рішення модерації", "Real interactions and moderation decisions"))
                    }
                }
            }
        }
        items(viewModel.trustEvents, key = { it.id }) { event ->
            Card {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (event.confirmed) Icons.Default.CheckCircle else Icons.Default.Security, null, tint = if (event.confirmed) Color(0xFF2E9D62) else MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(10.dp))
                    Text(event.label(viewModel.language), Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    Text(if (event.impact == 0) "—" else "+${event.impact}", fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            InfoPanel(
                viewModel.t("Как работает «предал / подставил»", "Як працює «зрадив / підставив»", "How betrayal reports work"),
                viewModel.t("Жалоба не меняет публичный рейтинг автоматически. Нужны связь между пользователями, доказательства, ответ второй стороны, решение модератора и право апелляции.", "Скарга не змінює публічний рейтинг автоматично. Потрібні зв’язок між користувачами, докази, відповідь другої сторони, рішення модератора та право апеляції.", "A report never changes the public score automatically. It requires a verified connection, evidence, response, moderation and appeal rights.")
            )
        }
        item {
            OutlinedButton(onClick = { viewModel.showMessage(viewModel.t("Безопасная форма жалобы открыта", "Безпечну форму скарги відкрито", "Secure report form opened")) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Shield, null)
                Spacer(Modifier.width(8.dp))
                Text(viewModel.t("Сообщить о нарушении доверия", "Повідомити про порушення довіри", "Report a trust violation"))
            }
        }
    }
}

@Composable
private fun ProfileScreen(viewModel: MainViewModel) {
    val p = viewModel.profile
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(p.name, true)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("${p.name}, ${p.age}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                    Text("global_id ${p.globalId.display}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Verified, null, Modifier.size(17.dp), tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(4.dp))
                        Text(viewModel.t("Личность подтверждена", "Особу підтверджено", "Identity verified"), style = MaterialTheme.typography.labelMedium)
                    }
                }
                IconButton(onClick = viewModel::editProfile) { Icon(Icons.Default.Edit, null) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(viewModel.accountRating.total.toInt().toString(), viewModel.t("Аккаунт", "Акаунт", "Account"), Modifier.weight(1f))
                MetricCard(p.trustScore.toString(), viewModel.t("Доверие", "Довіра", "Trust"), Modifier.weight(1f))
                MetricCard(p.verifiedInteractions.toString(), viewModel.t("Связи", "Зв’язки", "Links"), Modifier.weight(1f))
            }
        }
        item { InfoPanel(viewModel.t("О себе", "Про себе", "About"), p.description) }
        item { ProfileSection(viewModel.t("Цели дружбы", "Цілі дружби", "Friendship goals"), p.goals) }
        item { ProfileSection(viewModel.t("Интересы", "Інтереси", "Interests"), p.interests) }
        item { ProfileSection(viewModel.t("Ценности", "Цінності", "Values"), p.values) }
        item { ProfileSection(viewModel.t("Образ жизни", "Спосіб життя", "Lifestyle"), p.lifestyle) }
        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(viewModel.t("Психологический паспорт", "Психологічний паспорт", "Personality passport"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    ProfileLine("Brotherhood‑32", "${p.personality32.code} · ${p.personality32.title(viewModel.language)}")
                    ProfileLine(viewModel.t("Эннеаграмма", "Еннеаграма", "Enneagram"), "${p.enneagram.type}w${p.enneagram.wing} · ${p.enneagram.title(viewModel.language)}")
                    ProfileLine(viewModel.t("Зодиак", "Зодіак", "Zodiac"), "${p.zodiac.symbol} ${p.zodiac.name}")
                    ProfileLine(viewModel.t("Нумерология", "Нумерологія", "Numerology"), "${p.numerology.soulNumber} / ${p.numerology.destinyNumber} / ${p.numerology.nameNumber}")
                }
            }
        }
    }
}

@Composable
private fun MetricCard(value: String, label: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun ProfileSection(title: String, values: List<String>) {
    Card(shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) { items(values) { TraitChip(it) } }
        }
    }
}

@Composable
private fun ProfileLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, Modifier.weight(.38f), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        Text(value, Modifier.weight(.62f), fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun CandidateDetailScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val candidate = viewModel.selectedCandidate ?: return
    val breakdown = viewModel.compatibility(candidate)
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(viewModel.t("Совместимость", "Сумісність", "Compatibility")) }, navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }) }
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Avatar(candidate.name, candidate.online)
                    Spacer(Modifier.height(10.dp))
                    Text("${candidate.name}, ${candidate.age}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                    Text("${candidate.city} · ID ${candidate.globalId.display}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(14.dp))
                    ScoreRing(breakdown.total, 112.dp, viewModel.t("совместимость", "сумісність", "match"))
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            viewModel.requestConnection(candidate)
                            viewModel.showMessage(viewModel.t("Запрос дружбы отправлен", "Запит дружби надіслано", "Friend request sent"))
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.People, null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (candidate.globalId.value in viewModel.connectionRequests) viewModel.t("Отправлено", "Надіслано", "Sent") else viewModel.t("Познакомиться", "Познайомитися", "Connect"))
                    }
                    OutlinedButton(onClick = { viewModel.showMessage(viewModel.t("Чат будет открыт после взаимного согласия", "Чат відкриється після взаємної згоди", "Chat opens after mutual consent")) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Chat, null)
                        Spacer(Modifier.width(6.dp))
                        Text(viewModel.t("Сообщение", "Повідомлення", "Message"))
                    }
                }
            }
            item {
                Text(viewModel.t("Подробный расчёт", "Детальний розрахунок", "Detailed score"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            }
            item { CompatibilityPanel(viewModel, breakdown) }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(viewModel.t("Профиль личности", "Профіль особистості", "Personality profile"), fontWeight = FontWeight.Bold)
                        ProfileLine("Brotherhood‑32", "${candidate.personality32.code} · ${candidate.personality32.title(viewModel.language)}")
                        ProfileLine(viewModel.t("Эннеаграмма", "Еннеаграма", "Enneagram"), "${candidate.enneagram.type}w${candidate.enneagram.wing} · ${candidate.enneagram.title(viewModel.language)}")
                        ProfileLine(viewModel.t("Зодиак", "Зодіак", "Zodiac"), "${candidate.zodiac.symbol} ${candidate.zodiac.name}")
                        ProfileLine(viewModel.t("Ведические числа", "Ведичні числа", "Vedic numbers"), "${candidate.numerology.soulNumber} / ${candidate.numerology.destinyNumber} / ${candidate.numerology.nameNumber}")
                    }
                }
            }
            item { InfoPanel(viewModel.t("Почему вы подходите", "Чому ви підходите", "Why you match"), candidate.explanation) }
            item { ProfileSection(viewModel.t("Общие направления", "Спільні напрями", "Shared areas"), candidate.interests + candidate.values) }
        }
    }
}

@Composable
private fun CompatibilityPanel(viewModel: MainViewModel, b: CompatibilityBreakdown) {
    Card(shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricBar(viewModel.t("100 тестов дружбы", "100 тестів дружби", "100 friendship tests"), b.friendshipTests)
            MetricBar(viewModel.t("Характер", "Характер", "Character"), b.character)
            MetricBar(viewModel.t("Ценности", "Цінності", "Values"), b.values)
            MetricBar(viewModel.t("Образ жизни", "Спосіб життя", "Lifestyle"), b.lifestyle)
            MetricBar("Brotherhood‑32", b.personality32)
            MetricBar(viewModel.t("Эннеаграмма", "Еннеаграма", "Enneagram"), b.enneagram)
            MetricBar(viewModel.t("Зодиак", "Зодіак", "Zodiac"), b.zodiac)
            MetricBar(viewModel.t("Ведическая нумерология", "Ведична нумерологія", "Vedic numerology"), b.numerology)
            MetricBar(viewModel.t("Репутация", "Репутація", "Reputation"), b.reputation)
            HorizontalDivider()
            Text(viewModel.t("Уверенность расчёта: ${b.confidence}%", "Впевненість розрахунку: ${b.confidence}%", "Score confidence: ${b.confidence}%"), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun MetricBar(label: String, score: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Text("$score%", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
        }
        LinearProgressIndicator(progress = { score / 100f }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun CommunityDetailScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val community = viewModel.selectedCommunity ?: return
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(community.title, maxLines = 1, overflow = TextOverflow.Ellipsis) }, navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }) }
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(28.dp)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(if (community.kind == CommunityKind.BUSINESS) Icons.Default.BusinessCenter else Icons.Default.Groups, null, Modifier.size(48.dp))
                        Text(community.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                        Text(community.description)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TraitChip(community.category)
                            TraitChip(community.city)
                            if (community.online) TraitChip(viewModel.t("Онлайн", "Онлайн", "Online"))
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MetricCard(community.members.toString(), viewModel.t("Участники", "Учасники", "Members"), Modifier.weight(1f))
                    MetricCard(if (community.verifiedOnly) "100%" else "—", viewModel.t("Проверка", "Перевірка", "Verified"), Modifier.weight(1f))
                    MetricCard(if (community.online) "24/7" else community.city, viewModel.t("Формат", "Формат", "Format"), Modifier.weight(1f))
                }
            }
            item {
                Button(onClick = { viewModel.toggleCommunityMembership(community) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (community.joined) viewModel.t("Покинуть группу", "Покинути групу", "Leave group") else viewModel.t("Вступить в группу", "Вступити до групи", "Join group"))
                }
            }
            item {
                InfoPanel(
                    viewModel.t("Правила сообщества", "Правила спільноти", "Community rules"),
                    viewModel.t("Уважение, отсутствие травли, запрет публикации личной переписки, прозрачность денежных интересов и модерация подтверждённых нарушений.", "Повага, відсутність цькування, заборона публікації особистого листування, прозорість грошових інтересів і модерація підтверджених порушень.", "Respect, no harassment, no publication of private chats, transparent financial interests and moderated verified violations.")
                )
            }
        }
    }
}

@Composable
private fun SettingsScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(viewModel.t("Настройки", "Налаштування", "Settings")) }, navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }) }
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { SettingsSectionTitle(viewModel.t("Язык", "Мова", "Language"), Icons.Default.Language) }
            item {
                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppLanguage.entries.forEach { language ->
                            Row(Modifier.fillMaxWidth().clickable { viewModel.changeLanguage(language) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(language.nativeName, Modifier.weight(1f))
                                if (viewModel.language == language) Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
            item { SettingsSectionTitle(viewModel.t("Тема", "Тема", "Theme"), if (viewModel.themeMode == AppThemeMode.DARK) Icons.Default.DarkMode else Icons.Default.LightMode) }
            item {
                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeRow(viewModel, AppThemeMode.SYSTEM, viewModel.t("Как в системе", "Як у системі", "System"), Icons.Default.Settings)
                        ThemeRow(viewModel, AppThemeMode.LIGHT, viewModel.t("Светлая", "Світла", "Light"), Icons.Default.LightMode)
                        ThemeRow(viewModel, AppThemeMode.DARK, viewModel.t("Чёрная", "Чорна", "Black"), Icons.Default.DarkMode)
                    }
                }
            }
            item { SettingsSectionTitle(viewModel.t("Данные и кеш", "Дані та кеш", "Data & cache"), Icons.Default.Cached) }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SettingInfo(Icons.Default.CloudOff, viewModel.t("Офлайн-режим", "Офлайн-режим", "Offline mode"), viewModel.t("Тесты, профиль и последний поиск доступны без сети", "Тести, профіль і останній пошук доступні без мережі", "Tests, profile and latest search remain available offline"))
                        SettingInfo(Icons.Default.Storage, "Vercel → Neon", viewModel.t("APK работает только с защищённым backend API; пароль базы остаётся на сервере", "APK працює лише із захищеним backend API; пароль бази залишається на сервері", "The APK uses only the protected backend API; database credentials stay on the server"))
                    }
                }
            }
            item {
                OutlinedButton(onClick = viewModel::signOut, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Logout, null)
                    Spacer(Modifier.width(8.dp))
                    Text(viewModel.t("Выйти", "Вийти", "Sign out"))
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionTitle(title: String, icon: ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ThemeRow(viewModel: MainViewModel, mode: AppThemeMode, label: String, icon: ImageVector) {
    Row(Modifier.fillMaxWidth().clickable { viewModel.setTheme(mode) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null)
        Spacer(Modifier.width(10.dp))
        Text(label, Modifier.weight(1f))
        Switch(checked = viewModel.themeMode == mode, onCheckedChange = { if (it) viewModel.setTheme(mode) })
    }
}

@Composable
private fun SettingInfo(icon: ImageVector, title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.width(10.dp))
        Column { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun EditProfileScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val initial = viewModel.profile
    var name by remember(initial) { mutableStateOf(initial.name) }
    var description by remember(initial) { mutableStateOf(initial.description) }
    var city by remember(initial) { mutableStateOf(initial.city) }
    var birthDate by remember(initial) { mutableStateOf(initial.birthDate.toString()) }
    var latinName by remember(initial) { mutableStateOf(initial.latinName) }
    var goals by remember(initial) { mutableStateOf(initial.goals.joinToString(", ")) }
    var interests by remember(initial) { mutableStateOf(initial.interests.joinToString(", ")) }
    var values by remember(initial) { mutableStateOf(initial.values.joinToString(", ")) }
    var lifestyle by remember(initial) { mutableStateOf(initial.lifestyle.joinToString(", ")) }

    fun tokens(value: String): List<String> = value
        .split(',', ';', '\n')
        .map(String::trim)
        .filter(String::isNotBlank)
        .distinct()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(viewModel.t("Редактирование профиля", "Редагування профілю", "Edit profile"), fontWeight = FontWeight.Black) },
                navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("global_id ${initial.globalId.display}", fontWeight = FontWeight.Black)
                    Text(
                        viewModel.t(
                            "Профиль хранится локально, работает офлайн и синхронизируется через основной backend.",
                            "Профіль зберігається локально, працює офлайн і синхронізується через основний backend.",
                            "The profile is stored locally, works offline and syncs through the core backend."
                        ),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Имя", "Ім’я", "Name")) },
                singleLine = true
            )
            OutlinedTextField(
                value = birthDate,
                onValueChange = { birthDate = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Дата рождения", "Дата народження", "Birth date")) },
                supportingText = { Text("YYYY-MM-DD · 18+") },
                singleLine = true
            )
            OutlinedTextField(
                value = latinName,
                onValueChange = { latinName = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Имя латиницей для нумерологии", "Ім’я латиницею для нумерології", "Latin name for numerology")) },
                supportingText = { Text(viewModel.t("Например: ALEX MORGAN", "Наприклад: ALEX MORGAN", "Example: ALEX MORGAN")) },
                singleLine = true
            )
            OutlinedTextField(
                value = city,
                onValueChange = { city = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Город", "Місто", "City")) },
                leadingIcon = { Icon(Icons.Default.LocationCity, null) },
                singleLine = true
            )
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("О себе", "Про себе", "About")) },
                minLines = 3
            )

            SettingsSectionTitle(viewModel.t("Основа совместимости", "Основа сумісності", "Compatibility foundation"), Icons.Default.AutoAwesome)
            OutlinedTextField(
                value = goals,
                onValueChange = { goals = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Цели дружбы", "Цілі дружби", "Friendship goals")) },
                supportingText = { Text(viewModel.t("Разделяйте значения запятыми", "Розділяйте значення комами", "Separate values with commas")) },
                minLines = 2
            )
            OutlinedTextField(
                value = interests,
                onValueChange = { interests = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Интересы", "Інтереси", "Interests")) },
                minLines = 2
            )
            OutlinedTextField(
                value = values,
                onValueChange = { values = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Ценности", "Цінності", "Values")) },
                minLines = 2
            )
            OutlinedTextField(
                value = lifestyle,
                onValueChange = { lifestyle = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(viewModel.t("Образ жизни", "Спосіб життя", "Lifestyle")) },
                minLines = 2
            )

            val parsedBirthDate = runCatching { LocalDate.parse(birthDate) }.getOrNull()
            val adultBirthDate = parsedBirthDate?.takeIf { Period.between(it, LocalDate.now()).years >= 18 }
            InfoPanel(
                viewModel.t("Автоматические слои", "Автоматичні шари", "Automatic layers"),
                if (adultBirthDate == null)
                    viewModel.t("Укажите корректную дату рождения в формате YYYY-MM-DD (18+).", "Вкажіть коректну дату народження у форматі YYYY-MM-DD (18+).", "Enter a valid birth date as YYYY-MM-DD (18+).")
                else
                    viewModel.t("Зодиак и ведическая нумерология будут пересчитаны при сохранении.", "Зодіак і ведична нумерологія будуть перераховані під час збереження.", "Zodiac and Vedic numerology will be recalculated on save.")
            )

            Button(
                onClick = {
                    val validBirthDate = adultBirthDate ?: return@Button
                    viewModel.updateProfile(
                        name = name,
                        description = description,
                        city = city,
                        birthDate = validBirthDate,
                        latinName = latinName,
                        goals = tokens(goals),
                        interests = tokens(interests),
                        values = tokens(values),
                        lifestyle = tokens(lifestyle)
                    )
                    viewModel.showMessage(viewModel.t("Профиль сохранён локально и поставлен в очередь синхронизации", "Профіль збережено локально та поставлено в чергу синхронізації", "Profile saved locally and queued for synchronization"))
                    viewModel.closeOverlay()
                },
                enabled = adultBirthDate != null,
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.Cached, null)
                Spacer(Modifier.width(8.dp))
                Text(viewModel.t("Сохранить профиль", "Зберегти профіль", "Save profile"))
            }
        }
    }
}

@Composable
private fun CityDialog(viewModel: MainViewModel, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text(viewModel.t("Закрыть", "Закрити", "Close")) } },
        title = { Text(viewModel.t("Выберите город", "Оберіть місто", "Choose city"), fontWeight = FontWeight.Black) },
        text = {
            Column(Modifier.fillMaxHeight(.6f).verticalScroll(rememberScrollState())) {
                viewModel.cities.forEach { city ->
                    Row(Modifier.fillMaxWidth().clickable { viewModel.selectCity(city); onDismiss() }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationCity, null)
                        Spacer(Modifier.width(10.dp))
                        Text(city, Modifier.weight(1f))
                        if (city == viewModel.selectedCity) Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                    }
                    HorizontalDivider()
                }
            }
        }
    )
}

@Composable
private fun InfoPanel(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(body, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Search, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        Text(message, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
