@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package org.federationofavatars.brotherhood.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import org.federationofavatars.brotherhood.data.pick
import org.federationofavatars.brotherhood.model.MainTab

private data class ProductService(
    val icon: ImageVector,
    val title: String,
    val subtitle: String,
    val badge: String,
    val action: () -> Unit
)

@Composable
internal fun ServicesScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val l = viewModel.language
    val services = listOf(
        ProductService(
            Icons.Default.AutoAwesome,
            l.pick("Лаборатория совместимости", "Лабораторія сумісності", "Compatibility lab"),
            l.pick("Характер, образ жизни, ценности и устойчивость дружбы", "Характер, спосіб життя, цінності та стійкість дружби", "Character, lifestyle, values and friendship durability"),
            "9D"
        ) { viewModel.selectTab(MainTab.DISCOVER) },
        ProductService(
            Icons.Default.Psychology,
            l.pick("100 тестов дружбы", "100 тестів дружби", "100 friendship tests"),
            l.pick("600 вопросов, перекрёстная проверка и контроль самопрезентации", "600 запитань, перехресна перевірка та контроль самопрезентації", "600 questions, cross-checking and self-presentation control"),
            "100"
        ) { viewModel.selectTab(MainTab.TESTS) },
        ProductService(
            Icons.Default.Tag,
            "Brotherhood-32",
            l.pick("32 мужских типа личности по пяти независимым осям", "32 чоловічі типи особистості за п’ятьма незалежними осями", "32 male personality types across five independent axes"),
            "32"
        ) { viewModel.showMessage(l.pick("Открыта модель Brotherhood-32", "Відкрито модель Brotherhood-32", "Brotherhood-32 model opened")) },
        ProductService(
            Icons.Default.Stars,
            l.pick("Эннеаграмма", "Еннеаграма", "Enneagram"),
            l.pick("Основной тип, крыло, мотивация и поведение в конфликте", "Основний тип, крило, мотивація та поведінка в конфлікті", "Core type, wing, motivation and conflict behavior"),
            "9"
        ) { viewModel.showMessage(l.pick("Профиль эннеаграммы открыт", "Профіль еннеаграми відкрито", "Enneagram profile opened")) },
        ProductService(
            Icons.Default.AutoAwesome,
            l.pick("Зодиак", "Зодіак", "Zodiac"),
            l.pick("Дополнительный слой совместимости, не заменяющий психологические тесты", "Додатковий шар сумісності, що не замінює психологічні тести", "An additional compatibility layer that does not replace psychological tests"),
            "12"
        ) { viewModel.showMessage(l.pick("Зодиакальный профиль открыт", "Зодіакальний профіль відкрито", "Zodiac profile opened")) },
        ProductService(
            Icons.Default.Calculate,
            l.pick("Ведическая нумерология", "Ведична нумерологія", "Vedic numerology"),
            l.pick("Число души, судьбы, имени и вектор дружеской совместимости", "Число душі, долі, імені та вектор дружньої сумісності", "Soul, destiny and name numbers with a friendship compatibility vector"),
            "V"
        ) { viewModel.showMessage(l.pick("Нумерологический профиль открыт", "Нумерологічний профіль відкрито", "Numerology profile opened")) },
        ProductService(
            Icons.Default.Groups,
            l.pick("Клубы по интересам", "Клуби за інтересами", "Interest clubs"),
            l.pick("Футбол, спорт, автомобили, путешествия, технологии и взаимопомощь", "Футбол, спорт, автомобілі, подорожі, технології та взаємодопомога", "Football, sports, cars, travel, technology and mutual support"),
            l.pick("ГРУППЫ", "ГРУПИ", "GROUPS")
        ) { viewModel.selectTab(MainTab.COMMUNITIES) },
        ProductService(
            Icons.Default.BusinessCenter,
            l.pick("Бизнес-сообщества", "Бізнес-спільноти", "Business communities"),
            l.pick("Партнёры, команда, проекты и прозрачные деловые договорённости", "Партнери, команда, проєкти та прозорі ділові домовленості", "Partners, teams, projects and transparent business agreements"),
            l.pick("БИЗНЕС", "БІЗНЕС", "BUSINESS")
        ) { viewModel.openBusinessCommunities() },
        ProductService(
            Icons.Default.Shield,
            l.pick("Центр доверия", "Центр довіри", "Trust center"),
            l.pick("Подтверждённые взаимодействия, инциденты, модерация и апелляции", "Підтверджені взаємодії, інциденти, модерація та апеляції", "Verified interactions, incidents, moderation and appeals"),
            l.pick("ЗАЩИТА", "ЗАХИСТ", "SAFETY")
        ) { viewModel.selectTab(MainTab.TRUST) },
        ProductService(
            Icons.Default.Cached,
            l.pick("Офлайн и кеш", "Офлайн і кеш", "Offline & cache"),
            l.pick("Тесты и расчёты внутри APK, локальные снимки, очередь синхронизации", "Тести й розрахунки всередині APK, локальні знімки, черга синхронізації", "Tests and calculations in the APK, local snapshots and a sync queue"),
            l.pick("OFFLINE", "OFFLINE", "OFFLINE")
        ) { viewModel.openSettings() },
        ProductService(
            Icons.Default.VerifiedUser,
            l.pick("Единая идентичность", "Єдина ідентичність", "Unified identity"),
            l.pick("global_id над Google, Telegram, Facebook и будущими провайдерами", "global_id над Google, Telegram, Facebook і майбутніми провайдерами", "global_id above Google, Telegram, Facebook and future providers"),
            viewModel.profile.globalId.display
        ) { viewModel.showMessage("global_id ${viewModel.profile.globalId.display}") },
        ProductService(
            Icons.Default.Language,
            l.pick("Языки мира", "Мови світу", "World languages"),
            l.pick("Русский, украинский и английский сейчас; реестр готов к расширению", "Російська, українська та англійська зараз; реєстр готовий до розширення", "Russian, Ukrainian and English now; registry ready to expand"),
            "RU/UA/EN"
        ) { viewModel.openSettings() }
    )

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(l.pick("Сервисы", "Сервіси", "Services"), fontWeight = FontWeight.Black) },
                navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        Modifier.fillMaxWidth().background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primaryContainer,
                                    MaterialTheme.colorScheme.secondaryContainer
                                )
                            )
                        ).padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("BROTHERHOOD", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                        Text(
                            l.pick(
                                "Все инструменты для поиска настоящего друга — в одном мужском приложении.",
                                "Усі інструменти для пошуку справжнього друга — в одному чоловічому застосунку.",
                                "Every tool for finding a real friend in one men-only app."
                            ),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
            items(services) { service -> ServiceCard(service) }
        }
    }
}

@Composable
private fun ServiceCard(service: ProductService) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = service.action),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) { Icon(service.icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(service.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(service.badge, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
                Text(
                    service.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private data class DemoConversation(val initials: String, val name: String, val message: String, val time: String, val unread: Int)

@Composable
internal fun MessagesScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val l = viewModel.language
    var draft by remember { mutableStateOf("") }
    val conversations = listOf(
        DemoConversation("А", "Андрей", l.pick("Договорились: футбол в субботу в 11:00", "Домовилися: футбол у суботу об 11:00", "Agreed: football Saturday at 11:00"), "21:40", 2),
        DemoConversation("Т", "Тарас", l.pick("Отправил маршрут в горы", "Надіслав маршрут у гори", "Sent the mountain route"), "18:05", 0),
        DemoConversation("Б", l.pick("Предприниматели Украины", "Підприємці України", "Entrepreneurs of Ukraine"), l.pick("Новый запрос на партнёрство", "Новий запит на партнерство", "New partnership request"), l.pick("Вчера", "Учора", "Yesterday"), 4)
    )

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(l.pick("Сообщения", "Повідомлення", "Messages"), fontWeight = FontWeight.Black) },
                navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                l.pick(
                                    "Переписка кешируется локально. На сервер отправляются только данные, необходимые для синхронизации.",
                                    "Листування кешується локально. На сервер надсилаються лише дані, потрібні для синхронізації.",
                                    "Chats are cached locally. Only data needed for synchronization is sent to the server."
                                ),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
                items(conversations) { conversation ->
                    Card(modifier = Modifier.fillMaxWidth().clickable { viewModel.showMessage(conversation.name) }) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer),
                                contentAlignment = Alignment.Center
                            ) { Text(conversation.initials, fontWeight = FontWeight.Black) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(conversation.name, fontWeight = FontWeight.Bold)
                                Text(conversation.message, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(conversation.time, style = MaterialTheme.typography.labelSmall)
                                if (conversation.unread > 0) {
                                    Spacer(Modifier.height(5.dp))
                                    Box(Modifier.size(22.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                                        Text(conversation.unread.toString(), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    label = { Text(l.pick("Сообщение", "Повідомлення", "Message")) },
                    singleLine = true
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (draft.isNotBlank()) {
                            viewModel.showMessage(l.pick("Сообщение добавлено в очередь отправки", "Повідомлення додано до черги відправлення", "Message added to the send queue"))
                            draft = ""
                        }
                    },
                    contentPadding = PaddingValues(14.dp)
                ) { Icon(Icons.Default.Send, null) }
            }
        }
    }
}
