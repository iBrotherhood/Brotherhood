@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package org.federationofavatars.brotherhood.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.DateFormat
import java.util.Date
import java.util.UUID
import kotlinx.coroutines.delay
import org.federationofavatars.brotherhood.domain.VedicNumerologyEngine
import org.federationofavatars.brotherhood.model.ChatAttachmentKind
import org.federationofavatars.brotherhood.model.ChatEncryptionMode
import org.federationofavatars.brotherhood.model.ChatMessage
import org.federationofavatars.brotherhood.model.ConversationKind
import org.federationofavatars.brotherhood.model.ConversationSummaryModel
import org.federationofavatars.brotherhood.model.GlobalId
import org.federationofavatars.brotherhood.domain.InsightKind
import org.federationofavatars.brotherhood.model.PendingChatAttachment
import org.federationofavatars.brotherhood.data.pick
import org.federationofavatars.brotherhood.data.format
import org.federationofavatars.brotherhood.model.MainTab

private data class ProductService(
    val icon: ImageVector,
    val title: String,
    val subtitle: String,
    val badge: String,
    val action: () -> Unit
)

@Composable
internal fun ServicesScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val l = viewModel.language
    val services = listOf(
        ProductService(
            Icons.Default.AutoAwesome,
            l.pick("Лаборатория совместимости", "Лабораторія сумісності", "Compatibility lab"),
            l.pick("Характер, образ жизни, ценности и устойчивость дружбы", "Характер, спосіб життя, цінності та стійкість дружби", "Character, lifestyle, values and friendship durability"),
            "15D"
        ) { viewModel.selectTab(MainTab.DISCOVER) },
        ProductService(
            Icons.Default.SelfImprovement,
            l.pick("Познание себя", "Пізнання себе", "Know yourself"),
            l.pick("Сильные стороны, индивидуальные стили, Brotherhood-32, эннеаграмма, зодиак и ведическая нумерология", "Сильні сторони, індивідуальні стилі, Brotherhood-32, еннеаграма, зодіак і ведична нумерологія", "Strengths, individual styles, Brotherhood-32, Enneagram, zodiac and Vedic numerology"),
            l.pick("Я", "Я", "ME")
        ) { viewModel.openSelfAnalysis() },
        ProductService(
            Icons.Default.Psychology,
            l.pick("100 психологических тестов дружбы", "100 психологічних тестів дружби", "100 psychological friendship tests"),
            l.pick("600 непрямых визуально-ассоциативных заданий", "600 непрямих візуально-асоціативних завдань", "600 indirect visual-associative tasks"),
            "100"
        ) { viewModel.openTests() },
        ProductService(
            Icons.Default.Tag,
            "Brotherhood-32",
            l.pick("32 мужских типа личности по пяти независимым осям", "32 чоловічі типи особистості за п’ятьма незалежними осями", "32 male personality types across five independent axes"),
            "32"
        ) { viewModel.openSelfAnalysis() },
        ProductService(
            Icons.Default.Stars,
            l.pick("Эннеаграмма", "Еннеаграма", "Enneagram"),
            l.pick("Основной тип, крыло, мотивация и поведение в конфликте", "Основний тип, крило, мотивація та поведінка в конфлікті", "Core type, wing, motivation and conflict behavior"),
            "9"
        ) { viewModel.openSelfAnalysis() },
        ProductService(
            Icons.Default.AutoAwesome,
            l.pick("Зодиак", "Зодіак", "Zodiac"),
            l.pick("Дополнительный слой совместимости, не заменяющий психологические тесты", "Додатковий шар сумісності, що не замінює психологічні тести", "An additional compatibility layer that does not replace psychological tests"),
            "12"
        ) { viewModel.openSelfAnalysis() },
        ProductService(
            Icons.Default.Calculate,
            l.pick("Ведическая нумерология", "Ведична нумерологія", "Vedic numerology"),
            l.pick("Математический расчёт по дате рождения: число души, судьбы и дружеская совместимость", "Математичний розрахунок за датою народження: число душі, долі та дружня сумісність", "Birth-date mathematics: soul, destiny and friendship compatibility"),
            "V"
        ) { viewModel.openSelfAnalysis() },
        ProductService(
            Icons.Default.Groups,
            l.pick("Клубы по интересам", "Клуби за інтересами", "Interest clubs"),
            l.pick("Футбол, спорт, автомобили, путешествия, технологии и взаимопомощь", "Футбол, спорт, автомобілі, подорожі, технології та взаємодопомога", "Football, sports, cars, travel, technology and mutual support"),
            l.pick("ГРУППЫ", "ГРУПИ", "GROUPS")
        ) { viewModel.selectTab(MainTab.COMMUNITIES) },
        ProductService(
            Icons.Default.BusinessCenter,
            l.pick("Бизнес-сообщества", "Бізнес-спільноти", "Business communities"),
            l.pick("Партнёры, команда, проекты и прозрачные деловые договорённости", "Партнери, команда, проєкти та прозорі ділові домовленості", "Partners, teams, projects and transparent business agreements"),
            l.pick("БИЗНЕС", "БІЗНЕС", "BUSINESS")
        ) { viewModel.openBusinessCommunities() },
        ProductService(
            Icons.Default.Shield,
            l.pick("Центр доверия", "Центр довіри", "Trust center"),
            l.pick("Подтверждённые взаимодействия, инциденты, модерация и апелляции", "Підтверджені взаємодії, інциденти, модерація та апеляції", "Verified interactions, incidents, moderation and appeals"),
            l.pick("ЗАЩИТА", "ЗАХИСТ", "SAFETY")
        ) { viewModel.openTrust() },
        ProductService(
            Icons.Default.Cached,
            l.pick("Офлайн и кеш", "Офлайн і кеш", "Offline & cache"),
            l.pick("Тесты и расчёты внутри APK, локальные снимки, очередь синхронизации", "Тести й розрахунки всередині APK, локальні знімки, черга синхронізації", "Tests and calculations in the APK, local snapshots and a sync queue"),
            l.pick("OFFLINE", "OFFLINE", "OFFLINE")
        ) { viewModel.openSettings() },
        ProductService(
            Icons.Default.VerifiedUser,
            l.pick("Единая идентичность", "Єдина ідентичність", "Unified identity"),
            l.pick("global_id над Google, Telegram, Facebook и будущими провайдерами", "global_id над Google, Telegram, Facebook і майбутніми провайдерами", "global_id above Google, Telegram, Facebook and future providers"),
            viewModel.profile.globalId.display
        ) { viewModel.showMessage("global_id ${viewModel.profile.globalId.display}") },
        ProductService(
            Icons.Default.Language,
            l.pick("Языки мира", "Мови світу", "World languages"),
            l.pick("Русский, украинский и английский сейчас; реестр готов к расширению", "Російська, українська та англійська зараз; реєстр готовий до розширення", "Russian, Ukrainian and English now; registry ready to expand"),
            "RU/UA/EN"
        ) { viewModel.openSettings() }
    )

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(l.pick("Сервисы", "Сервіси", "Services"), fontWeight = FontWeight.Black) },
                navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        Modifier.fillMaxWidth().background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primaryContainer,
                                    MaterialTheme.colorScheme.secondaryContainer
                                )
                            )
                        ).padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Brotherhood", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                        Text(
                            l.pick(
                                "Все инструменты для поиска настоящего друга — в одном мужском приложении.",
                                "Усі інструменти для пошуку справжнього друга — в одному чоловічому застосунку.",
                                "Every tool for finding a real friend in one men-only app."
                            ),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
            items(services) { service -> ServiceCard(service) }
        }
    }
}

@Composable
private fun ServiceCard(service: ProductService) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = service.action),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) { Icon(service.icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(service.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(service.badge, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
                Text(
                    service.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
internal fun MessagesScreen(viewModel: MainViewModel, snackbar: SnackbarHostState, embedded: Boolean = false) {
    val l = viewModel.language
    var showCreateGroup by remember { mutableStateOf(false) }
    var groupTitle by remember { mutableStateOf("") }
    var selectedMembers by remember { mutableStateOf<Set<Long>>(emptySet()) }

    LaunchedEffect(Unit) { viewModel.refreshConversations() }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(l.pick("Чаты", "Чати", "Chats"), fontWeight = FontWeight.Black) },
                navigationIcon = { if (!embedded) IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = { viewModel.refreshConversations() }) { Icon(Icons.Default.Refresh, null) }
                    IconButton(onClick = { showCreateGroup = true }) { Icon(Icons.Default.Add, null) }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Text(l.pick("Личные чаты — E2EE", "Особисті чати — E2EE", "Private chats — E2EE"), fontWeight = FontWeight.Bold)
                        }
                        Text(
                            l.pick(
                                "Текст и вложения личного чата шифруются на устройстве. Vercel и Neon получают ciphertext. Группы используют серверное шифрование и могут модерироваться.",
                                "Текст і вкладення особистого чату шифруються на пристрої. Vercel і Neon отримують ciphertext. Групи використовують серверне шифрування та можуть модеруватися.",
                                "Private text and attachments are encrypted on-device. Vercel and Neon receive ciphertext. Groups use server encryption and can be moderated."
                            ),
                            style = MaterialTheme.typography.bodySmall
                        )
                        viewModel.chatSecurityFingerprint?.let { fingerprint ->
                            Text(
                                l.format(
                                    "chat.e2ee_fingerprint",
                                    "Отпечаток E2EE: {fingerprint}",
                                    "Відбиток E2EE: {fingerprint}",
                                    "E2EE fingerprint: {fingerprint}",
                                    mapOf("fingerprint" to fingerprint),
                                ),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
            if (viewModel.chatLoading) item { Text(l.pick("Синхронизация…", "Синхронізація…", "Syncing…")) }
            if (viewModel.conversations.isEmpty()) {
                item {
                    Card {
                        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Chat, null, Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(10.dp))
                            Text(l.pick("Чатов пока нет", "Чатів поки немає", "No chats yet"), fontWeight = FontWeight.Bold)
                            Text(
                                l.pick("Начните с поиска подходящего человека или создайте группу по общему интересу.", "Почніть із пошуку відповідної людини або створіть групу за спільним інтересом.", "Start by finding a suitable person or create a group around a shared interest."),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                            )
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = { viewModel.selectTab(org.federationofavatars.brotherhood.model.MainTab.DISCOVER) }, modifier = Modifier.fillMaxWidth()) {
                                Text(l.pick("Найти друга", "Знайти друга", "Find a friend"))
                            }
                            OutlinedButton(onClick = { showCreateGroup = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(l.pick("Создать группу", "Створити групу", "Create a group"))
                            }
                        }
                    }
                }
            }
            items(viewModel.conversations, key = { it.id }) { conversation -> ConversationCard(viewModel, conversation) }
        }
    }

    if (showCreateGroup) {
        AlertDialog(
            onDismissRequest = { showCreateGroup = false },
            title = { Text(l.pick("Новая группа", "Нова група", "New group")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = groupTitle,
                        onValueChange = { groupTitle = it.take(80) },
                        label = { Text(l.pick("Название", "Назва", "Title")) },
                        singleLine = true
                    )
                    Text(l.pick("Добавьте участников", "Додайте учасників", "Add members"), fontWeight = FontWeight.Bold)
                    viewModel.candidates.take(12).forEach { candidate ->
                        FilterChip(
                            selected = candidate.globalId.value in selectedMembers,
                            onClick = {
                                selectedMembers = if (candidate.globalId.value in selectedMembers) selectedMembers - candidate.globalId.value else selectedMembers + candidate.globalId.value
                            },
                            label = { Text("${candidate.name} · ${candidate.globalId.display}") }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = groupTitle.isNotBlank() && selectedMembers.isNotEmpty(),
                    onClick = {
                        viewModel.createGroupChat(groupTitle, selectedMembers.map(::GlobalId))
                        showCreateGroup = false
                        groupTitle = ""
                        selectedMembers = emptySet()
                    }
                ) { Text(l.pick("Создать", "Створити", "Create")) }
            },
            dismissButton = { TextButton(onClick = { showCreateGroup = false }) { Text(l.pick("Отмена", "Скасувати", "Cancel")) } }
        )
    }
}

@Composable
private fun ConversationCard(viewModel: MainViewModel, conversation: ConversationSummaryModel) {
    val l = viewModel.language
    Card(modifier = Modifier.fillMaxWidth().clickable { viewModel.openConversation(conversation) }) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(if (conversation.kind == ConversationKind.DIRECT) Icons.Default.Lock else Icons.Default.Groups, null)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(conversation.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (conversation.encryptionMode == ChatEncryptionMode.E2EE) "E2EE" else l.pick("ГРУППА", "ГРУПА", "GROUP"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
                Text(
                    conversation.lastMessagePreview.ifBlank { l.pick("Нет сообщений", "Немає повідомлень", "No messages") },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (conversation.unreadCount > 0) {
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(24.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                    Text(conversation.unreadCount.toString(), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
internal fun ChatScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val conversation = viewModel.activeConversation ?: return
    val l = viewModel.language
    val context = LocalContext.current
    var draft by remember(conversation.id) { mutableStateOf("") }
    var pending by remember(conversation.id) { mutableStateOf<List<PendingChatAttachment>>(emptyList()) }
    var showReportDialog by remember(conversation.id) { mutableStateOf(false) }
    var reportText by remember(conversation.id) { mutableStateOf("") }
    var showBlockConfirm by remember(conversation.id) { mutableStateOf(false) }
    var showGroupMembersDialog by remember(conversation.id) { mutableStateOf(false) }

    fun loadUri(uri: android.net.Uri) {
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        val bytes = runCatching { resolver.openInputStream(uri)?.use { it.readBytes() } }.getOrNull() ?: return
        if (bytes.size > 4 * 1024 * 1024) {
            viewModel.showMessage(l.pick("Файл больше 4 МБ. Для текущей серверной схемы уменьшите его.", "Файл більший за 4 МБ. Для поточної серверної схеми зменште його.", "The file is over 4 MB. Reduce it for the current server setup."))
            return
        }
        val kind = when {
            mime.startsWith("image/") -> ChatAttachmentKind.IMAGE
            mime.startsWith("audio/") -> ChatAttachmentKind.AUDIO
            mime.startsWith("video/") -> ChatAttachmentKind.VIDEO
            else -> ChatAttachmentKind.FILE
        }
        val name = uri.lastPathSegment?.substringAfterLast('/')?.takeLast(90) ?: "attachment"
        pending = pending + PendingChatAttachment(UUID.randomUUID().toString(), kind, mime, name, bytes)
    }

    val imagePicker = rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { it?.let(::loadUri) }
    val audioPicker = rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { it?.let(::loadUri) }
    val filePicker = rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { it?.let(::loadUri) }
    val voiceRecorder = rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.data?.let(::loadUri)
    }

    LaunchedEffect(viewModel.editingMessage?.id) {
        viewModel.editingMessage?.let { draft = (it.decryptedBody ?: it.body).orEmpty() }
    }

    LaunchedEffect(conversation.id) {
        while (true) {
            viewModel.refreshActiveChat()
            delay(4_000)
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(conversation.title, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (viewModel.typingGlobalIds.isNotEmpty()) {
                                l.pick("печатает…", "друкує…", "typing…")
                            } else if (conversation.encryptionMode == ChatEncryptionMode.E2EE) {
                                l.pick("Личный E2EE", "Особистий E2EE", "Private E2EE")
                            } else {
                                l.pick("Групповой · серверное шифрование", "Груповий · серверне шифрування", "Group · server encrypted")
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = { IconButton(onClick = viewModel::openMessages) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    if (conversation.kind == ConversationKind.DIRECT && conversation.peerGlobalId != null) {
                        IconButton(onClick = { showReportDialog = true }, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.Default.Flag, l.pick("Пожаловаться", "Поскаржитися", "Report"))
                        }
                        IconButton(
                            onClick = { if (viewModel.activePeerBlockedByMe) viewModel.toggleActivePeerBlock() else showBlockConfirm = true },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                if (viewModel.activePeerBlockedByMe) Icons.Default.LockOpen else Icons.Default.Block,
                                if (viewModel.activePeerBlockedByMe) l.pick("Разблокировать", "Розблокувати", "Unblock") else l.pick("Заблокировать", "Заблокувати", "Block")
                            )
                        }
                    } else if (conversation.kind == ConversationKind.GROUP) {
                        IconButton(onClick = { viewModel.refreshActiveGroupMembers(); showGroupMembersDialog = true }, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.Default.Groups, l.pick("Участники", "Учасники", "Members"))
                        }
                    }
                    IconButton(onClick = viewModel::refreshActiveChat, modifier = Modifier.size(48.dp)) { Icon(Icons.Default.Refresh, null) }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = if (conversation.encryptionMode == ChatEncryptionMode.E2EE) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (conversation.encryptionMode == ChatEncryptionMode.E2EE) Icons.Default.Lock else Icons.Default.LockOpen, null)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            if (conversation.encryptionMode == ChatEncryptionMode.E2EE)
                                l.pick("Сервер не получает открытый текст. Сверьте fingerprints при первой встрече.", "Сервер не отримує відкритий текст. Звірте fingerprints під час першої зустрічі.", "The server does not receive plaintext. Compare fingerprints on first contact.")
                            else l.pick("Группа не секретная: сообщения доступны серверной модерации и зашифрованы в Neon.", "Група не секретна: повідомлення доступні серверній модерації та зашифровані в Neon.", "This group is not secret: messages can be moderated server-side and are encrypted in Neon."),
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (conversation.encryptionMode == ChatEncryptionMode.E2EE) {
                            viewModel.chatSecurityFingerprint?.let { Text(l.pick("Ваш: $it", "Ваш: $it", "Yours: $it"), style = MaterialTheme.typography.labelSmall) }
                            viewModel.peerChatFingerprint?.let { Text(l.pick("Друг: $it", "Друг: $it", "Peer: $it"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) }
                        }
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(viewModel.chatMessages, key = { it.id }) { message -> MessageBubble(viewModel, message) }
            }

            viewModel.editingMessage?.let { editing ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Edit, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(l.pick("Редактирование", "Редагування", "Editing"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            Text((editing.decryptedBody ?: editing.body).orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { viewModel.cancelEditing(); draft = "" }, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.Close, null) }
                    }
                }
            } ?: viewModel.replyToMessage?.let { reply ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Reply, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(l.pick("Ответ на сообщение", "Відповідь на повідомлення", "Replying to"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            Text((reply.decryptedBody ?: reply.body).orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = viewModel::clearReply, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.Close, null) }
                    }
                }
            }

            if (pending.isNotEmpty()) {
                LazyColumn(modifier = Modifier.fillMaxWidth().height((pending.size.coerceAtMost(2) * 44).dp), contentPadding = PaddingValues(horizontal = 12.dp)) {
                    items(pending, key = { it.clientAttachmentId }) { item ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(attachmentIcon(item.kind), null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(item.fileName, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = { pending = pending.filterNot { it.clientAttachmentId == item.clientAttachmentId } }) { Text("×") }
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (viewModel.editingMessage == null) {
                    IconButton(onClick = { imagePicker.launch("image/*") }, modifier = Modifier.size(44.dp)) { Icon(Icons.Default.Image, null) }
                    IconButton(onClick = { audioPicker.launch("audio/*") }, modifier = Modifier.size(44.dp)) { Icon(Icons.Default.AudioFile, null) }
                    IconButton(
                        onClick = {
                            runCatching { voiceRecorder.launch(android.content.Intent(android.provider.MediaStore.Audio.Media.RECORD_SOUND_ACTION)) }
                                .onFailure { viewModel.showMessage(l.pick("На устройстве нет доступного диктофона", "На пристрої немає доступного диктофона", "No audio recorder is available on this device")) }
                        },
                        modifier = Modifier.size(44.dp)
                    ) { Icon(Icons.Default.Mic, l.pick("Записать голос", "Записати голос", "Record voice")) }
                    IconButton(onClick = { filePicker.launch("*/*") }, modifier = Modifier.size(44.dp)) { Icon(Icons.Default.AttachFile, null) }
                }
                OutlinedTextField(
                    value = draft,
                    onValueChange = {
                        draft = it.take(8_000)
                        viewModel.onChatDraftChanged(draft.isNotBlank())
                    },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(if (viewModel.editingMessage != null) l.pick("Новый текст", "Новий текст", "New text") else l.pick("Сообщение", "Повідомлення", "Message")) },
                    maxLines = 4
                )
                Button(
                    enabled = draft.isNotBlank() || pending.isNotEmpty(),
                    onClick = {
                        viewModel.sendChatMessage(draft, pending)
                        draft = ""
                        pending = emptyList()
                    },
                    modifier = Modifier.size(52.dp),
                    contentPadding = PaddingValues(0.dp)
                ) { Icon(if (viewModel.editingMessage != null) Icons.Default.Edit else Icons.Default.Send, null) }
            }
        }
    }

    if (showGroupMembersDialog) {
        val myRole = viewModel.activeGroupMembers.firstOrNull { it.globalId == viewModel.profile.globalId }?.role
        val isOwner = myRole == "owner"
        AlertDialog(
            onDismissRequest = { showGroupMembersDialog = false },
            title = { Text(l.pick("Участники группы", "Учасники групи", "Group members")) },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth().height(420.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(viewModel.activeGroupMembers, key = { "member-${it.globalId.value}" }) { member ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(member.globalId.display, fontWeight = if (member.role == "owner") FontWeight.Bold else FontWeight.Normal)
                                Text(member.role.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (isOwner && member.role != "owner") {
                                TextButton(onClick = { viewModel.removeActiveGroupMember(member.globalId) }) { Text(l.pick("Удалить", "Видалити", "Remove")) }
                            }
                        }
                    }
                    if (isOwner) {
                        item { Text(l.pick("Добавить из найденных людей", "Додати зі знайдених людей", "Add from discovered people"), fontWeight = FontWeight.Bold) }
                        items(viewModel.candidates.filter { candidate -> viewModel.activeGroupMembers.none { it.globalId == candidate.globalId } }.take(20), key = { "candidate-${it.globalId.value}" }) { candidate ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${candidate.name} · ${candidate.globalId.display}", Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                TextButton(onClick = { viewModel.addActiveGroupMember(candidate.globalId) }) { Text(l.pick("Добавить", "Додати", "Add")) }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showGroupMembersDialog = false }) { Text(l.pick("Готово", "Готово", "Done")) } }
        )
    }

    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text(l.pick("Жалоба на пользователя", "Скарга на користувача", "Report user")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(l.pick(
                        "Опишите конкретный эпизод. Жалоба закрытая и не снижает рейтинг до решения модерации.",
                        "Опишіть конкретний епізод. Скарга закрита й не знижує рейтинг до рішення модерації.",
                        "Describe the specific incident. Reports are private and do not reduce reputation before moderation."
                    ), style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = reportText,
                        onValueChange = { reportText = it.take(4000) },
                        minLines = 4,
                        label = { Text(l.pick("Что произошло", "Що сталося", "What happened")) }
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = reportText.trim().length >= 20,
                    onClick = {
                        viewModel.reportActivePeer(reportText)
                        reportText = ""
                        showReportDialog = false
                    }
                ) { Text(l.pick("Отправить", "Надіслати", "Submit")) }
            },
            dismissButton = { TextButton(onClick = { showReportDialog = false }) { Text(l.pick("Отмена", "Скасувати", "Cancel")) } }
        )
    }

    if (showBlockConfirm) {
        AlertDialog(
            onDismissRequest = { showBlockConfirm = false },
            title = { Text(l.pick("Заблокировать пользователя?", "Заблокувати користувача?", "Block user?")) },
            text = { Text(l.pick(
                "После блокировки новые личные сообщения между вами будут запрещены. Повторное нажатие на значок блокировки снимет её.",
                "Після блокування нові особисті повідомлення між вами будуть заборонені. Повторне натискання на значок блокування зніме його.",
                "After blocking, new direct messages between you are disabled. Tap the block icon again to unblock."
            )) },
            confirmButton = { TextButton(onClick = { showBlockConfirm = false; viewModel.toggleActivePeerBlock() }) { Text(l.pick("Заблокировать", "Заблокувати", "Block")) } },
            dismissButton = { TextButton(onClick = { showBlockConfirm = false }) { Text(l.pick("Отмена", "Скасувати", "Cancel")) } }
        )
    }
}

@Composable
private fun MessageBubble(viewModel: MainViewModel, message: ChatMessage) {
    val mine = message.senderGlobalId == viewModel.profile.globalId
    val l = viewModel.language
    val replied = message.replyToMessageId?.let { id -> viewModel.chatMessages.firstOrNull { it.id == id } }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Card(
            modifier = Modifier.fillMaxWidth(.86f).wrapContentWidth(if (mine) Alignment.End else Alignment.Start),
            colors = CardDefaults.cardColors(containerColor = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                if (!mine) Text(message.senderGlobalId.display, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                replied?.let { target ->
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surface.copy(alpha = .55f)).padding(8.dp)) {
                        Column {
                            Text(l.pick("Ответ", "Відповідь", "Reply"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            Text((target.decryptedBody ?: target.body).orEmpty().ifBlank { l.pick("Вложение", "Вкладення", "Attachment") }, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                val text = message.decryptedBody ?: message.body ?: if (message.encryptionMode == ChatEncryptionMode.E2EE) "🔒" else ""
                if (text.isNotBlank()) Text(text)
                message.attachments.forEach { attachment ->
                    OutlinedButton(onClick = { viewModel.openAttachment(message, attachment) }, modifier = Modifier.fillMaxWidth().height(44.dp)) {
                        Icon(attachmentIcon(attachment.kind), null)
                        Spacer(Modifier.width(6.dp))
                        Text(attachment.fileName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (message.reactions.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        message.reactions.entries.sortedBy { it.key }.take(6).forEach { (emoji, count) ->
                            AssistChip(onClick = { viewModel.toggleReaction(message, emoji) }, label = { Text("$emoji $count") })
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        buildString {
                            append(DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(message.createdAtEpochMs)))
                            if (message.editedAtEpochMs != null) append(l.pick(" · изм.", " · змін.", " · edited"))
                            if (mine) {
                                when {
                                    message.readCount > 0 -> append(" · ✓✓")
                                    message.deliveredCount > 0 -> append(" · ✓")
                                    else -> append(" · •")
                                }
                            }
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { viewModel.toggleReaction(message, "👍") }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)) { Text("👍") }
                    IconButton(onClick = { viewModel.replyTo(message) }, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Reply, l.pick("Ответить", "Відповісти", "Reply"), Modifier.size(18.dp)) }
                    if (mine && message.attachments.isEmpty()) {
                        IconButton(onClick = { viewModel.startEditing(message) }, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Edit, l.pick("Редактировать", "Редагувати", "Edit"), Modifier.size(18.dp)) }
                    }
                    if (mine) {
                        IconButton(onClick = { viewModel.deleteMessage(message) }, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Delete, l.pick("Удалить", "Видалити", "Delete"), Modifier.size(18.dp)) }
                    }
                }
            }
        }
    }
}

private fun attachmentIcon(kind: ChatAttachmentKind) = when (kind) {
    ChatAttachmentKind.IMAGE -> Icons.Default.Image
    ChatAttachmentKind.AUDIO -> Icons.Default.AudioFile
    ChatAttachmentKind.VIDEO -> Icons.Default.Description
    ChatAttachmentKind.FILE -> Icons.Default.AttachFile
}

@Composable
internal fun SelfAnalysisScreen(viewModel: MainViewModel, snackbar: SnackbarHostState) {
    val l = viewModel.language
    val report = viewModel.selfAnalysis
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(l.pick("Познание себя", "Пізнання себе", "Know yourself"), fontWeight = FontWeight.Black) },
                navigationIcon = { IconButton(onClick = viewModel::closeOverlay) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SelfImprovement, null, Modifier.size(34.dp))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(l.pick("Ваш личный портрет", "Ваш особистий портрет", "Your personal portrait"), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                                Text(l.pick("Не диагноз, а инструмент самонаблюдения", "Не діагноз, а інструмент самоспостереження", "Not a diagnosis — a self-reflection tool"), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Text(l.pick("Пройдено тестов: ${report.completedTests}/100 · уверенность ${report.confidence}%", "Пройдено тестів: ${report.completedTests}/100 · впевненість ${report.confidence}%", "Tests completed: ${report.completedTests}/100 · confidence ${report.confidence}%"))
                    }
                }
            }
            item { SelfSectionTitle(l.pick("Сильные стороны", "Сильні сторони", "Strengths")) }
            items(report.strengths) { SelfInsightCard(it.title, it.text, it.score, InsightKind.STRENGTH) }
            item { SelfSectionTitle(l.pick("Ваши стили и ресурсы", "Ваші стилі та ресурси", "Your styles and resources")) }
            items(report.profileInsights) { SelfInsightCard(it.title, it.text, it.score, InsightKind.INFO) }
            item {
                Button(onClick = { viewModel.openTests() }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Psychology, null)
                    Spacer(Modifier.width(8.dp))
                    Text(l.pick("Продолжить узнавать себя", "Продовжити пізнавати себе", "Continue learning about yourself"))
                }
            }
        }
    }
}

@Composable
private fun SelfSectionTitle(title: String) { Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black) }

@Composable
private fun SelfInsightCard(title: String, text: String, score: Int?, kind: InsightKind) {
    Card {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    when (kind) {
                        InsightKind.STRENGTH -> Icons.Default.Stars
                        InsightKind.GROWTH -> Icons.Default.Psychology
                        InsightKind.CAUTION -> Icons.Default.Info
                        InsightKind.INFO -> Icons.Default.AutoAwesome
                    },
                    null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.width(8.dp))
                Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                score?.let { Text("$it%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
            }
            Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
