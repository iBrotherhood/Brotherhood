package org.federationofavatars.brotherhood.network

interface BrotherhoodApi {
    suspend fun get(path: String, accessToken: String): String
    suspend fun post(path: String, jsonBody: String, accessToken: String): String
    suspend fun put(path: String, jsonBody: String, accessToken: String): String
}
