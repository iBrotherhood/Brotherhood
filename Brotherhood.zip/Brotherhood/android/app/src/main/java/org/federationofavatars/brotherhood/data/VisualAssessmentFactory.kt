package org.federationofavatars.brotherhood.data

import org.federationofavatars.brotherhood.model.AssessmentQuestion
import org.federationofavatars.brotherhood.model.VisualAssessmentChoice
import org.federationofavatars.brotherhood.model.VisualChoiceLayout
import org.federationofavatars.brotherhood.model.VisualParadigm
import org.federationofavatars.brotherhood.model.VisualSceneArchetype

/**
 * Deterministic generator for indirect visual-choice tasks.
 *
 * The mapping is deliberately indirect: users see only compositions, while each layout contributes
 * small signals to several private coordinates. A trait is never inferred from one picture.
 *
 * IMPORTANT: these feature-to-trait anchors are theory-informed MODEL HYPOTHESES. They are not a
 * clinical diagnosis and are not represented as validated facts until Brotherhood-specific
 * reliability/construct/outcome studies support them. The model is versioned for that reason.
 */
object VisualAssessmentFactory {
    const val MODEL_VERSION = "visual-latent-v2"
    const val STIMULUS_VERSION = "scene-library-v4"

    private enum class Feature { INTENSITY, SPACING, ORDER, ASYMMETRY, DIRECTION }
    private data class TraitAnchor(val feature: Feature, val highAtHighFeature: Boolean = true)

    private val anchors: Map<String, TraitAnchor> = mapOf(
        "dependability" to TraitAnchor(Feature.ORDER),
        "integrity_sincerity" to TraitAnchor(Feature.ASYMMETRY, false),
        "confidentiality" to TraitAnchor(Feature.SPACING),
        "reciprocity" to TraitAnchor(Feature.ASYMMETRY, false),
        "support_availability" to TraitAnchor(Feature.SPACING, false),
        "empathy" to TraitAnchor(Feature.SPACING, false),
        "directness" to TraitAnchor(Feature.DIRECTION),
        "tact" to TraitAnchor(Feature.INTENSITY, false),
        "forgiveness" to TraitAnchor(Feature.SPACING, false),
        "boundary_respect" to TraitAnchor(Feature.SPACING),
        "autonomy" to TraitAnchor(Feature.SPACING),
        "social_energy" to TraitAnchor(Feature.INTENSITY),
        "contact_intensity" to TraitAnchor(Feature.SPACING, false),
        "response_urgency" to TraitAnchor(Feature.DIRECTION),
        "spontaneity" to TraitAnchor(Feature.ORDER, false),
        "planning" to TraitAnchor(Feature.ORDER),
        "conflict_engagement" to TraitAnchor(Feature.DIRECTION),
        "self_control" to TraitAnchor(Feature.ASYMMETRY, false),
        "status_independence" to TraitAnchor(Feature.SPACING),
        "competitiveness" to TraitAnchor(Feature.INTENSITY),
        "fairness" to TraitAnchor(Feature.ASYMMETRY, false),
        "trust_openness" to TraitAnchor(Feature.SPACING, false),
        "vulnerability_comfort" to TraitAnchor(Feature.SPACING, false),
        "humor_tolerance" to TraitAnchor(Feature.ASYMMETRY),
        "group_orientation" to TraitAnchor(Feature.SPACING, false),
        "independence" to TraitAnchor(Feature.SPACING),
        "optimism" to TraitAnchor(Feature.DIRECTION),
        "emotional_intensity" to TraitAnchor(Feature.INTENSITY),
        "risk_tolerance" to TraitAnchor(Feature.ASYMMETRY),
        "decisiveness" to TraitAnchor(Feature.DIRECTION),
        "assertiveness" to TraitAnchor(Feature.INTENSITY),
        "leadership_orientation" to TraitAnchor(Feature.INTENSITY),
        "adaptability" to TraitAnchor(Feature.ASYMMETRY),
        "perseverance" to TraitAnchor(Feature.DIRECTION),
        "attention_to_detail" to TraitAnchor(Feature.ORDER),
        "cautiousness" to TraitAnchor(Feature.ORDER),
        "cooperation" to TraitAnchor(Feature.SPACING, false),
        "initiative" to TraitAnchor(Feature.DIRECTION),
        "innovation" to TraitAnchor(Feature.ASYMMETRY),
        "intellectual_curiosity" to TraitAnchor(Feature.ASYMMETRY),
        "achievement_orientation" to TraitAnchor(Feature.INTENSITY),
        "stress_tolerance" to TraitAnchor(Feature.ASYMMETRY, false),
        "ambiguity_tolerance" to TraitAnchor(Feature.ASYMMETRY),
        "self_confidence" to TraitAnchor(Feature.INTENSITY),
        "humility" to TraitAnchor(Feature.INTENSITY, false),
        "family_orientation" to TraitAnchor(Feature.SPACING, false),
        "money_discipline" to TraitAnchor(Feature.ORDER),
        "time_discipline" to TraitAnchor(Feature.ORDER),
        "resource_generosity" to TraitAnchor(Feature.INTENSITY),
        "rule_orientation" to TraitAnchor(Feature.ORDER),
    )

    fun question(
        assessmentId: String,
        ordinal: Int,
        primaryTrait: String,
        secondaryTrait: String,
        tertiaryTrait: String,
    ): AssessmentQuestion {
        require(ordinal in 1..6)
        val seed = assessmentId.removePrefix("f").toInt() * 101 + ordinal * 37
        val paradigm = chooseParadigm(primaryTrait, seed)
        val sceneArchetype = chooseSceneArchetype(paradigm, seed, ordinal)
        val variants = optionPatterns(seed, ordinal, primaryTrait, secondaryTrait, tertiaryTrait)
        return AssessmentQuestion(
            id = "${assessmentId}q$ordinal",
            paradigm = paradigm,
            sceneArchetype = sceneArchetype,
            stimulusVersion = STIMULUS_VERSION,
            visualSeed = seed,
            compositionVariant = compositionVariant(sceneArchetype, paradigm, seed),
            choices = variants,
        )
    }


    /** Deterministic screen order makes position effects measurable without exposing scoring logic. */
    fun presentedChoices(question: AssessmentQuestion): List<VisualAssessmentChoice> =
        presentedChoices(question.choices, question.visualSeed)

    /** Single source of truth shared by UI and calibration trace reconstruction. */
    fun presentedChoices(choices: List<VisualAssessmentChoice>, seed: Int): List<VisualAssessmentChoice> {
        val ids = presentationPermutation(seed)
        val byId = choices.associateBy(VisualAssessmentChoice::id)
        return ids.mapNotNull { byId[it.toString()] }
    }

    fun presentationSlot(question: AssessmentQuestion, choiceId: String): Int =
        presentationSlot(question.visualSeed, choiceId)

    fun presentationSlot(seed: Int, choiceId: String): Int =
        presentationPermutation(seed).indexOf(choiceId.toInt()).let { if (it < 0) 0 else it + 1 }

    /**
     * Non-scoring visual recipe. It is stable for a versioned scene/question and shared by all
     * four options, so calibration can distinguish scene-form effects from choice loadings.
     */
    fun compositionVariant(scene: VisualSceneArchetype, paradigm: VisualParadigm, seed: Int): Int {
        // Avalanche mixing avoids the arithmetic cycles that previously left some scenes with only
        // one visual recipe across the 600-task bank. This is stimulus diversity only, not scoring.
        var mixed = seed xor (scene.ordinal * -1640531527) xor (paradigm.ordinal * -2048144789)
        mixed = mixed xor (mixed ushr 16)
        mixed *= 2146121005
        mixed = mixed xor (mixed ushr 15)
        mixed *= -2073254261
        mixed = mixed xor (mixed ushr 16)
        return (mixed and Int.MAX_VALUE) % 8
    }

    private fun presentationPermutation(seed: Int): List<Int> {
        val shift = kotlin.math.abs(seed * 31 + 17) % 4
        val rotated = List(4) { ((it + shift) % 4) + 1 }
        return if (((seed ushr 2) and 1) == 0) rotated else rotated.reversed()
    }

    private fun chooseSceneArchetype(paradigm: VisualParadigm, seed: Int, ordinal: Int): VisualSceneArchetype {
        val family = when (paradigm) {
            VisualParadigm.GROUP_DISTANCE, VisualParadigm.CLUSTER -> listOf(
                VisualSceneArchetype.TEAM_TABLE, VisualSceneArchetype.CIRCLE,
                VisualSceneArchetype.TWO_GROUPS, VisualSceneArchetype.EMPTY_SEAT,
                VisualSceneArchetype.PAIR_WALK, VisualSceneArchetype.PUBLIC_SQUARE,
                VisualSceneArchetype.COMMON_GROUND, VisualSceneArchetype.REVIEW_CIRCLE,
            )
            VisualParadigm.NETWORK, VisualParadigm.EXCHANGE -> listOf(
                VisualSceneArchetype.NETWORK_HUB, VisualSceneArchetype.HANDOFF,
                VisualSceneArchetype.SHARED_TASK, VisualSceneArchetype.TEAM_TABLE,
                VisualSceneArchetype.ROTATING_LEAD, VisualSceneArchetype.SUPPLY_LINE,
                VisualSceneArchetype.NEGOTIATION_TABLE, VisualSceneArchetype.MARKET_STALL,
            )
            VisualParadigm.PATH, VisualParadigm.DIRECTION, VisualParadigm.FLOW -> listOf(
                VisualSceneArchetype.CROSSROADS, VisualSceneArchetype.BRIDGE,
                VisualSceneArchetype.PATHS, VisualSceneArchetype.UNKNOWN_TERRAIN,
                VisualSceneArchetype.DETOUR, VisualSceneArchetype.RIVER_CROSSING,
                VisualSceneArchetype.SPLIT_PATH, VisualSceneArchetype.STAIRCASE,
            )
            VisualParadigm.BALANCE, VisualParadigm.RESOURCE -> listOf(
                VisualSceneArchetype.RESOURCE_SPLIT, VisualSceneArchetype.TOOLBOX,
                VisualSceneArchetype.HANDOFF, VisualSceneArchetype.SHARED_TASK,
                VisualSceneArchetype.MARKET_STALL, VisualSceneArchetype.SUPPLY_LINE,
                VisualSceneArchetype.COMMON_GROUND, VisualSceneArchetype.WORKBENCH,
            )
            VisualParadigm.RHYTHM, VisualParadigm.STRUCTURE, VisualParadigm.PRIORITY -> listOf(
                VisualSceneArchetype.QUEUE, VisualSceneArchetype.WORKSPACE,
                VisualSceneArchetype.RULE_BOARD, VisualSceneArchetype.CLOCKWORK,
                VisualSceneArchetype.DEADLINE_BOARD, VisualSceneArchetype.PARALLEL_TASKS,
                VisualSceneArchetype.NEW_PROJECT, VisualSceneArchetype.MAP_ROOM,
            )
            VisualParadigm.BOUNDARY -> listOf(
                VisualSceneArchetype.OPEN_DOOR, VisualSceneArchetype.CLOSED_DOOR,
                VisualSceneArchetype.FRONT_LINE, VisualSceneArchetype.BACK_STAGE,
                VisualSceneArchetype.GATE, VisualSceneArchetype.CHECKPOINT,
                VisualSceneArchetype.SHARED_SHELTER, VisualSceneArchetype.QUIET_ROOM,
            )
            VisualParadigm.CHANGE -> listOf(
                VisualSceneArchetype.CRISIS_ROOM, VisualSceneArchetype.CAMP,
                VisualSceneArchetype.CROSSROADS, VisualSceneArchetype.UNKNOWN_TERRAIN,
                VisualSceneArchetype.NEW_PROJECT, VisualSceneArchetype.MAP_ROOM,
                VisualSceneArchetype.SIGNAL_POINT, VisualSceneArchetype.ROTATING_LEAD,
            )
            VisualParadigm.FOCUS -> listOf(
                VisualSceneArchetype.OBSERVER, VisualSceneArchetype.WORKSPACE,
                VisualSceneArchetype.FRONT_LINE, VisualSceneArchetype.EMPTY_SEAT,
                VisualSceneArchetype.TOWER, VisualSceneArchetype.QUIET_ROOM,
                VisualSceneArchetype.DEADLINE_BOARD, VisualSceneArchetype.WORKBENCH,
            )
            VisualParadigm.AMBIGUITY -> listOf(
                VisualSceneArchetype.UNKNOWN_TERRAIN, VisualSceneArchetype.OBSERVER,
                VisualSceneArchetype.TWO_GROUPS, VisualSceneArchetype.BACK_STAGE,
                VisualSceneArchetype.MEETING_POINT, VisualSceneArchetype.SIGNAL_POINT,
                VisualSceneArchetype.DETOUR, VisualSceneArchetype.PUBLIC_SQUARE,
            )
        }
        return family[kotlin.math.abs(seed + ordinal * 19) % family.size]
    }

    private fun chooseParadigm(primaryTrait: String, seed: Int): VisualParadigm {
        val family = when (anchors[primaryTrait]?.feature ?: Feature.ASYMMETRY) {
            Feature.SPACING -> listOf(VisualParadigm.GROUP_DISTANCE, VisualParadigm.NETWORK, VisualParadigm.BOUNDARY, VisualParadigm.CLUSTER)
            Feature.ORDER -> listOf(VisualParadigm.STRUCTURE, VisualParadigm.RHYTHM, VisualParadigm.BALANCE, VisualParadigm.PRIORITY)
            Feature.ASYMMETRY -> listOf(VisualParadigm.AMBIGUITY, VisualParadigm.CHANGE, VisualParadigm.RESOURCE, VisualParadigm.EXCHANGE)
            Feature.DIRECTION -> listOf(VisualParadigm.PATH, VisualParadigm.DIRECTION, VisualParadigm.CHANGE, VisualParadigm.FLOW)
            Feature.INTENSITY -> listOf(VisualParadigm.FOCUS, VisualParadigm.GROUP_DISTANCE, VisualParadigm.RESOURCE, VisualParadigm.PRIORITY)
        }
        return family[kotlin.math.abs(seed) % family.size]
    }


    private fun optionPatterns(
        seed: Int,
        ordinal: Int,
        primary: String,
        secondary: String,
        tertiary: String,
    ): List<VisualAssessmentChoice> {
        return (0..3).map { visualIndex ->
            val layout = layoutFor(seed, ordinal, visualIndex)
            VisualAssessmentChoice(
                id = "${visualIndex + 1}",
                layout = layout,
                latentLoadings = linkedMapOf(
                    primary to signal(primary, layout),
                    secondary to signal(secondary, layout),
                    tertiary to signal(tertiary, layout),
                ),
            )
        }
    }

    private fun signal(trait: String, layout: VisualChoiceLayout): Int {
        val anchor = anchors[trait] ?: TraitAnchor(Feature.ASYMMETRY)
        val raw = when (anchor.feature) {
            Feature.INTENSITY -> layout.intensity
            Feature.SPACING -> layout.spacing
            Feature.ORDER -> layout.order
            Feature.ASYMMETRY -> layout.asymmetry
            Feature.DIRECTION -> layout.direction
        }
        val loading = when (raw) {
            0 -> -2
            1 -> -1
            2 -> 1
            else -> 2
        }
        return if (anchor.highAtHighFeature) loading else -loading
    }

    private fun layoutFor(seed: Int, ordinal: Int, visualIndex: Int): VisualChoiceLayout {
        // Latin-square-like offsets guarantee that each of the four visible options spans all four
        // levels of every feature, while different salts prevent a stable A/B/C/D scoring cue.
        fun level(salt: Int): Int = (visualIndex + kotlin.math.abs(seed + ordinal * (salt + 3) + salt * 7)) and 3
        return VisualChoiceLayout(
            intensity = level(1),
            spacing = level(2),
            order = level(3),
            asymmetry = level(4),
            direction = level(5),
        )
    }
}
