package org.federationofavatars.brotherhood.data

import android.content.Context
import org.federationofavatars.brotherhood.model.AppLanguage
import org.json.JSONObject

data class CityOption(
    val id: String,
    /** Stable legacy/search/storage value. Never rewrite it when the UI language changes. */
    val value: String,
    val fallbackRu: String,
    val fallbackUk: String,
    val fallbackEn: String,
)

/**
 * Data-driven labels for Brotherhood's built-in city catalog.
 *
 * A city label is presentation data, while [CityOption.value] is the stable value used by the
 * current search/storage contract. Arbitrary user-provided city strings are intentionally left
 * literal: changing UI language must never rewrite user data.
 */
class CityCatalog(context: Context) {
    private val options: List<CityOption>
    private val byValue: Map<String, CityOption>

    init {
        val root = JSONObject(
            context.applicationContext.assets.open("i18n/cities.json").bufferedReader().use { it.readText() }
        )
        val rows = root.getJSONArray("cities")
        options = buildList {
            for (index in 0 until rows.length()) {
                val row = rows.getJSONObject(index)
                add(
                    CityOption(
                        id = row.getString("id"),
                        value = row.getString("value"),
                        fallbackRu = row.getString("ru"),
                        fallbackUk = row.getString("uk"),
                        fallbackEn = row.getString("en"),
                    )
                )
            }
        }
        byValue = options.associateBy { it.value }
    }

    val values: List<String> get() = options.filterNot { it.id == "online" }.map { it.value }

    fun label(value: String, language: AppLanguage): String {
        val option = byValue[value] ?: return value
        return language.format(
            key = "city.name.${option.id}",
            ru = option.fallbackRu,
            uk = option.fallbackUk,
            en = option.fallbackEn,
        )
    }
}
