package org.federationofavatars.brotherhood.data

import kotlin.math.abs
import kotlin.math.roundToInt
import org.federationofavatars.brotherhood.domain.EnneagramEngine
import org.federationofavatars.brotherhood.domain.Personality32Engine
import org.federationofavatars.brotherhood.model.EnneagramProfile
import org.federationofavatars.brotherhood.model.Personality32Profile
import org.federationofavatars.brotherhood.model.VisualAssessmentChoice
import org.federationofavatars.brotherhood.model.VisualChoiceLayout
import org.federationofavatars.brotherhood.model.VisualParadigm
import org.federationofavatars.brotherhood.model.VisualSceneArchetype

enum class PersonalityAxis { SOCIAL_ENERGY, PERCEPTION, DECISION_STYLE, LIFE_RHYTHM, BOND_STYLE }

data class CoreProfileQuestion(
    val id: String,
    val axis: PersonalityAxis? = null,
    val enneagramType: Int? = null,
    val paradigm: VisualParadigm,
    val sceneArchetype: VisualSceneArchetype,
    val visualSeed: Int,
    val compositionVariant: Int,
    val choices: List<VisualAssessmentChoice>,
) {
    init { require(choices.size == 4) }
}

/**
 * Brotherhood-32 and Enneagram remain descriptive profile layers, not clinical diagnoses.
 * Their interaction is now indirect/visual as well: no user-facing statement exposes a target
 * construct. Enneagram is treated as a descriptive hypothesis layer, not a validated diagnosis.
 */
object CoreProfileCatalog {
    private val axes = PersonalityAxis.entries

    val personality32Questions: List<CoreProfileQuestion> = buildList {
        axes.forEachIndexed { axisIndex, axis ->
            repeat(4) { local -> add(coreQuestion("p32_${axis.name.lowercase()}_${local + 1}", axisIndex * 100 + local + 11, axis = axis)) }
        }
    }

    val enneagramQuestions: List<CoreProfileQuestion> = buildList {
        (1..9).forEach { type ->
            repeat(2) { local -> add(coreQuestion("en_${type}_${local + 1}", 1000 + type * 31 + local * 7, enneagramType = type)) }
        }
    }

    fun scorePersonality32(answers: Map<String, Int>): Personality32Profile {
        require(personality32Questions.all { answers[it.id] in 1..4 })
        fun axisScore(axis: PersonalityAxis): Int {
            val values = personality32Questions.filter { it.axis == axis }.map { q ->
                val choice = q.choices[answers.getValue(q.id) - 1]
                choice.latentLoadings.getValue("p32:${axis.name}")
            }
            return (50 + values.average() * 25).roundToInt().coerceIn(0, 100)
        }
        return Personality32Engine.classify(
            Personality32Engine.AxisInput(
                socialEnergy = axisScore(PersonalityAxis.SOCIAL_ENERGY),
                perception = axisScore(PersonalityAxis.PERCEPTION),
                decisionStyle = axisScore(PersonalityAxis.DECISION_STYLE),
                lifeRhythm = axisScore(PersonalityAxis.LIFE_RHYTHM),
                bondStyle = axisScore(PersonalityAxis.BOND_STYLE),
            )
        )
    }

    fun scoreEnneagram(answers: Map<String, Int>): EnneagramProfile {
        require(enneagramQuestions.all { answers[it.id] in 1..4 })
        val normalized = (1..9).associateWith { type ->
            val values = enneagramQuestions.filter { it.enneagramType == type }.map { q ->
                q.choices[answers.getValue(q.id) - 1].latentLoadings.getValue("enneagram:$type")
            }
            (50 + values.average() * 25).roundToInt().coerceIn(0, 100)
        }
        return EnneagramEngine.classify(normalized)
    }

    private fun coreQuestion(id: String, seed: Int, axis: PersonalityAxis? = null, enneagramType: Int? = null): CoreProfileQuestion {
        val key = axis?.let { "p32:${it.name}" } ?: "enneagram:${requireNotNull(enneagramType)}"
        val base = listOf(2, 1, -1, -2)
        val rotation = abs(seed) % 4
        val choices = (0..3).map { visualIndex ->
            val loading = base[(visualIndex + rotation) % 4]
            VisualAssessmentChoice(
                id = "${visualIndex + 1}",
                layout = VisualChoiceLayout(
                    intensity = abs(seed + visualIndex * 3) % 4,
                    spacing = abs(seed / 3 + visualIndex * 5) % 4,
                    order = abs(seed / 5 + visualIndex * 7) % 4,
                    asymmetry = abs(seed / 7 + visualIndex * 11) % 4,
                    direction = abs(seed / 11 + visualIndex * 13) % 4,
                ),
                latentLoadings = mapOf(key to loading),
            )
        }
        val paradigm = VisualParadigm.entries[abs(seed) % VisualParadigm.entries.size]
        val sceneArchetype = VisualSceneArchetype.entries[abs(seed * 3 + 17) % VisualSceneArchetype.entries.size]
        return CoreProfileQuestion(
            id = id,
            axis = axis,
            enneagramType = enneagramType,
            paradigm = paradigm,
            sceneArchetype = sceneArchetype,
            visualSeed = seed,
            compositionVariant = VisualAssessmentFactory.compositionVariant(sceneArchetype, paradigm, seed),
            choices = choices,
        )
    }
}
