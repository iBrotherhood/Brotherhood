package org.federationofavatars.brotherhood.data

import org.federationofavatars.brotherhood.domain.EnneagramEngine
import org.federationofavatars.brotherhood.domain.Personality32Engine
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.EnneagramProfile
import org.federationofavatars.brotherhood.model.Personality32Profile

enum class PersonalityAxis { SOCIAL_ENERGY, PERCEPTION, DECISION_STYLE, LIFE_RHYTHM, BOND_STYLE }

data class CoreProfileQuestion(
    val id: String,
    val axis: PersonalityAxis? = null,
    val enneagramType: Int? = null,
    val reverse: Boolean = false,
    val ru: String,
    val uk: String,
    val en: String,
) {
    fun text(language: AppLanguage): String = when (language) {
        AppLanguage.RU -> ru
        AppLanguage.UK -> uk
        AppLanguage.EN -> en
    }
}

/**
 * Brotherhood-32 and Enneagram are profile layers, not clinical diagnoses.
 * These questions are original Brotherhood items and are not copied from a proprietary instrument.
 */
object CoreProfileCatalog {
    val personality32Questions = listOf(
        q("p32_se_1", PersonalityAxis.SOCIAL_ENERGY, false, "Мне легко первым начать разговор с незнакомым мужчиной.", "Мені легко першим почати розмову з незнайомим чоловіком.", "I can easily start a conversation with a man I do not know."),
        q("p32_se_2", PersonalityAxis.SOCIAL_ENERGY, true, "После насыщенного общения мне обычно нужно надолго остаться одному.", "Після насиченого спілкування мені зазвичай потрібно надовго залишитися одному.", "After intensive socializing I usually need a long time alone."),
        q("p32_se_3", PersonalityAxis.SOCIAL_ENERGY, false, "Я предпочитаю расширять круг знакомств, а не держаться только нескольких людей.", "Я волію розширювати коло знайомств, а не триматися лише кількох людей.", "I prefer expanding my circle rather than staying with only a few people."),
        q("p32_se_4", PersonalityAxis.SOCIAL_ENERGY, true, "В новой компании я чаще наблюдаю, чем активно включаюсь.", "У новій компанії я частіше спостерігаю, ніж активно долучаюся.", "In a new group I more often observe than actively join in."),

        q("p32_pe_1", PersonalityAxis.PERCEPTION, false, "Мне интереснее идеи и возможности, чем только практические детали.", "Мені цікавіші ідеї та можливості, ніж лише практичні деталі.", "Ideas and possibilities interest me more than only practical details."),
        q("p32_pe_2", PersonalityAxis.PERCEPTION, true, "Я доверяю прежде всего тому, что можно непосредственно проверить и увидеть.", "Я довіряю передусім тому, що можна безпосередньо перевірити й побачити.", "I trust mainly what can be directly checked and observed."),
        q("p32_pe_3", PersonalityAxis.PERCEPTION, false, "Мне нравится обсуждать, как события могут развиваться через несколько лет.", "Мені подобається обговорювати, як події можуть розвиватися через кілька років.", "I enjoy discussing how events may develop years from now."),
        q("p32_pe_4", PersonalityAxis.PERCEPTION, true, "В разговоре я предпочитаю конкретные факты абстрактным теориям.", "У розмові я віддаю перевагу конкретним фактам абстрактним теоріям.", "In conversation I prefer concrete facts to abstract theories."),

        q("p32_de_1", PersonalityAxis.DECISION_STYLE, false, "При важном решении я учитываю влияние на людей не меньше, чем сухую выгоду.", "У важливому рішенні я враховую вплив на людей не менше, ніж суху вигоду.", "In important decisions I consider the impact on people as much as pure utility."),
        q("p32_de_2", PersonalityAxis.DECISION_STYLE, true, "Если логика требует жёсткого решения, чувства участников редко меняют мой выбор.", "Якщо логіка вимагає жорсткого рішення, почуття учасників рідко змінюють мій вибір.", "If logic requires a hard decision, people's feelings rarely change my choice."),
        q("p32_de_3", PersonalityAxis.DECISION_STYLE, false, "Я стараюсь понять мотив человека до того, как оценивать его поступок.", "Я намагаюся зрозуміти мотив людини до того, як оцінювати її вчинок.", "I try to understand a person's motive before judging his action."),
        q("p32_de_4", PersonalityAxis.DECISION_STYLE, true, "В споре для меня важнее доказать правильность позиции, чем сохранить эмоциональный комфорт.", "У суперечці для мене важливіше довести правильність позиції, ніж зберегти емоційний комфорт.", "In an argument proving the correct position matters more to me than emotional comfort."),

        q("p32_lr_1", PersonalityAxis.LIFE_RHYTHM, false, "Мне комфортно менять планы, если появляется более интересная возможность.", "Мені комфортно змінювати плани, якщо з’являється цікавіша можливість.", "I am comfortable changing plans when a better opportunity appears."),
        q("p32_lr_2", PersonalityAxis.LIFE_RHYTHM, true, "Мне спокойнее, когда встречи и дела заранее определены по времени.", "Мені спокійніше, коли зустрічі та справи заздалегідь визначені в часі.", "I feel calmer when meetings and tasks are scheduled in advance."),
        q("p32_lr_3", PersonalityAxis.LIFE_RHYTHM, false, "Спонтанная поездка или встреча обычно радует меня.", "Спонтанна поїздка або зустріч зазвичай мене тішить.", "A spontaneous trip or meeting usually appeals to me."),
        q("p32_lr_4", PersonalityAxis.LIFE_RHYTHM, true, "Я предпочитаю сначала завершить намеченное и только потом менять направление.", "Я волію спочатку завершити заплановане й лише потім змінювати напрям.", "I prefer finishing what was planned before changing direction."),

        q("p32_bs_1", PersonalityAxis.BOND_STYLE, false, "Я спокойно принимаю, что близкий друг может надолго уйти в свои дела без ущерба дружбе.", "Я спокійно приймаю, що близький друг може надовго піти у свої справи без шкоди дружбі.", "I accept that a close friend can focus on his own life for a long time without harming the friendship."),
        q("p32_bs_2", PersonalityAxis.BOND_STYLE, true, "Для настоящей дружбы мне важны регулярность контакта и устойчивые договорённости.", "Для справжньої дружби мені важливі регулярність контакту та сталі домовленості.", "For real friendship I value regular contact and stable agreements."),
        q("p32_bs_3", PersonalityAxis.BOND_STYLE, false, "Я считаю нормальным иметь несколько независимых близких кругов общения.", "Я вважаю нормальним мати кілька незалежних близьких кіл спілкування.", "I consider it normal to have several independent close social circles."),
        q("p32_bs_4", PersonalityAxis.BOND_STYLE, true, "Если я называю человека близким другом, я ожидаю высокой взаимной включённости на годы.", "Якщо я називаю людину близьким другом, я очікую високої взаємної залученості на роки.", "If I call someone a close friend, I expect strong mutual involvement for years."),
    )

    val enneagramQuestions = listOf(
        e("en_1a", 1, "Я замечаю ошибки и чувствую обязанность исправлять неправильное.", "Я помічаю помилки й відчуваю обов’язок виправляти неправильне.", "I notice errors and feel responsible for correcting what is wrong."),
        e("en_1b", 1, "Для меня особенно важно поступать правильно, даже когда никто не видит.", "Для мене особливо важливо чинити правильно, навіть коли ніхто не бачить.", "Doing the right thing matters greatly to me even when nobody sees."),
        e("en_2a", 2, "Я легко замечаю, кому нужна поддержка, и стремлюсь помочь.", "Я легко помічаю, кому потрібна підтримка, і прагну допомогти.", "I easily notice who needs support and want to help."),
        e("en_2b", 2, "Мне важно чувствовать, что близкие люди ценят мою помощь.", "Мені важливо відчувати, що близькі люди цінують мою допомогу.", "It matters to me that close people value my help."),
        e("en_3a", 3, "Меня сильно мотивируют результат, достижения и признание компетентности.", "Мене сильно мотивують результат, досягнення та визнання компетентності.", "Results, achievement and recognition of competence strongly motivate me."),
        e("en_3b", 3, "Я умею быстро перестраиваться, чтобы добиться поставленной цели.", "Я вмію швидко перебудовуватися, щоб досягти поставленої мети.", "I can adapt quickly to achieve a goal."),
        e("en_4a", 4, "Мне важно сохранять индивидуальность и не быть как все.", "Мені важливо зберігати індивідуальність і не бути як усі.", "Maintaining individuality and not being like everyone else matters to me."),
        e("en_4b", 4, "Я глубоко переживаю эмоциональные оттенки отношений и событий.", "Я глибоко переживаю емоційні відтінки стосунків і подій.", "I experience the emotional nuances of relationships and events deeply."),
        e("en_5a", 5, "Перед действием я предпочитаю собрать знания и самостоятельно всё понять.", "Перед дією я волію зібрати знання й самостійно все зрозуміти.", "Before acting I prefer gathering knowledge and understanding things independently."),
        e("en_5b", 5, "Мне важно иметь достаточно личного пространства и времени на размышления.", "Мені важливо мати достатньо особистого простору й часу на роздуми.", "I need enough personal space and time to think."),
        e("en_6a", 6, "Я заранее замечаю риски и проверяю, кому действительно можно доверять.", "Я заздалегідь помічаю ризики й перевіряю, кому справді можна довіряти.", "I anticipate risks and test who can truly be trusted."),
        e("en_6b", 6, "Верность людям и взаимные обязательства для меня особенно важны.", "Вірність людям і взаємні зобов’язання для мене особливо важливі.", "Loyalty and mutual commitments are especially important to me."),
        e("en_7a", 7, "Я постоянно замечаю новые возможности и не люблю чувствовать себя ограниченным.", "Я постійно помічаю нові можливості й не люблю почуватися обмеженим.", "I constantly see new possibilities and dislike feeling constrained."),
        e("en_7b", 7, "Мне легче переключиться на новое занятие, чем долго оставаться в неприятных переживаниях.", "Мені легше переключитися на нове заняття, ніж довго залишатися в неприємних переживаннях.", "It is easier for me to switch to something new than stay with unpleasant feelings for long."),
        e("en_8a", 8, "Я предпочитаю говорить прямо и защищать себя и своих людей без обходных путей.", "Я волію говорити прямо й захищати себе та своїх людей без обхідних шляхів.", "I prefer speaking directly and defending myself and my people without detours."),
        e("en_8b", 8, "Мне трудно спокойно относиться к попыткам контролировать меня.", "Мені важко спокійно ставитися до спроб контролювати мене.", "I find it hard to accept attempts to control me."),
        e("en_9a", 9, "Я стараюсь снижать напряжение и искать решение, с которым смогут жить все стороны.", "Я намагаюся знижувати напруження й шукати рішення, з яким зможуть жити всі сторони.", "I try to reduce tension and find a solution all sides can live with."),
        e("en_9b", 9, "Иногда я откладываю собственные требования, чтобы не разрушать мир в отношениях.", "Іноді я відкладаю власні вимоги, щоб не руйнувати мир у стосунках.", "Sometimes I postpone my own demands to preserve peace in a relationship."),
    )

    fun scorePersonality32(answers: Map<String, Int>): Personality32Profile {
        require(personality32Questions.all { answers[it.id] in 1..5 })
        fun axis(axis: PersonalityAxis): Int {
            val questions = personality32Questions.filter { it.axis == axis }
            val values = questions.map { question ->
                val raw = answers.getValue(question.id)
                val oriented = if (question.reverse) 6 - raw else raw
                (oriented - 1) * 25
            }
            return values.average().toInt().coerceIn(0, 100)
        }
        return Personality32Engine.classify(
            Personality32Engine.AxisInput(
                socialEnergy = axis(PersonalityAxis.SOCIAL_ENERGY),
                perception = axis(PersonalityAxis.PERCEPTION),
                decisionStyle = axis(PersonalityAxis.DECISION_STYLE),
                lifeRhythm = axis(PersonalityAxis.LIFE_RHYTHM),
                bondStyle = axis(PersonalityAxis.BOND_STYLE),
            )
        )
    }

    fun scoreEnneagram(answers: Map<String, Int>): EnneagramProfile {
        require(enneagramQuestions.all { answers[it.id] in 1..5 })
        val rawScores = (1..9).associateWith { type ->
            enneagramQuestions.filter { it.enneagramType == type }.sumOf { answers.getValue(it.id) }
        }
        val maxRaw = rawScores.values.maxOrNull()?.coerceAtLeast(1) ?: 1
        val normalized = rawScores.mapValues { (_, value) -> (value * 100 / maxRaw).coerceIn(0, 100) }
        return EnneagramEngine.classify(normalized)
    }

    private fun q(id: String, axis: PersonalityAxis, reverse: Boolean, ru: String, uk: String, en: String) =
        CoreProfileQuestion(id = id, axis = axis, reverse = reverse, ru = ru, uk = uk, en = en)

    private fun e(id: String, type: Int, ru: String, uk: String, en: String) =
        CoreProfileQuestion(id = id, enneagramType = type, ru = ru, uk = uk, en = en)
}
