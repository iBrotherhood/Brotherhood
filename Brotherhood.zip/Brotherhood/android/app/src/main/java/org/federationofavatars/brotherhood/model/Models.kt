package org.federationofavatars.brotherhood.model

import java.time.LocalDate
import org.federationofavatars.brotherhood.data.pick

/** Runtime locale descriptor. New languages are data-driven through assets/i18n/languages.json. */
data class AppLanguage(
    val tag: String,
    val nativeName: String,
    val direction: String = "ltr",
    val translations: Map<String, String> = emptyMap(),
) {
    init {
        require(tag.matches(Regex("^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")))
        require(direction in setOf("ltr", "rtl"))
    }

    companion object {
        val RU = AppLanguage("ru", "Русский")
        val UK = AppLanguage("uk", "Українська")
        val EN = AppLanguage("en", "English")
        val CORE = listOf(RU, UK, EN)

        fun fallback(tag: String?): AppLanguage = CORE.firstOrNull { it.tag.equals(tag, ignoreCase = true) } ?: RU
    }
}

enum class AppThemeMode { SYSTEM, LIGHT, DARK }

enum class MainTab { HOME, DISCOVER, MESSAGES, COMMUNITIES, PROFILE }

enum class AppRoute { AUTH, HOME, CANDIDATE, COMMUNITY, SETTINGS, EDIT_PROFILE, SERVICES, MESSAGES, CHAT, SELF_ANALYSIS, TESTS, TRUST, DISCOVERY_FILTERS }

enum class ProfileVisibility { DISCOVERABLE, CONNECTIONS, PRIVATE }

data class DiscoveryPreferences(
    val verifiedOnly: Boolean = false,
    val onlineOnly: Boolean = false,
    val requireSharedInterests: Boolean = false,
    val hideRequested: Boolean = false,
    val minTrust: Int = 0,
    val minCompatibility: Int = 0,
)

enum class AuthProvider { GOOGLE, TELEGRAM, FACEBOOK, EMAIL, PASSKEY }

enum class CommunityKind { INTEREST, BUSINESS }

data class GlobalId(val value: Long) {
    init { require(value in 1L..9_999_999_999L) }
    val display: String get() = value.toString().padStart(10, '0')
    override fun toString(): String = display
}

data class AuthIdentity(
    val provider: AuthProvider,
    val providerSubject: String,
    val globalId: GlobalId
)

data class Personality32Profile(
    val code: String,
    val titleRu: String,
    val titleUk: String,
    val titleEn: String,
    val socialEnergy: Int,
    val perception: Int,
    val decisionStyle: Int,
    val lifeRhythm: Int,
    val bondStyle: Int
) {
    fun title(language: AppLanguage): String = language.pick(titleRu, titleUk, titleEn)
}

data class EnneagramProfile(
    val type: Int,
    val wing: Int?,
    val score: Int,
    val titleRu: String,
    val titleUk: String,
    val titleEn: String
) {
    fun title(language: AppLanguage): String = language.pick(titleRu, titleUk, titleEn)
}

enum class ZodiacSign(val symbol: String) {
    ARIES("♈"), TAURUS("♉"), GEMINI("♊"), CANCER("♋"),
    LEO("♌"), VIRGO("♍"), LIBRA("♎"), SCORPIO("♏"),
    SAGITTARIUS("♐"), CAPRICORN("♑"), AQUARIUS("♒"), PISCES("♓");

    fun label(language: AppLanguage): String = when (this) {
        ARIES -> language.pick("Овен", "Овен", "Aries")
        TAURUS -> language.pick("Телец", "Телець", "Taurus")
        GEMINI -> language.pick("Близнецы", "Близнюки", "Gemini")
        CANCER -> language.pick("Рак", "Рак", "Cancer")
        LEO -> language.pick("Лев", "Лев", "Leo")
        VIRGO -> language.pick("Дева", "Діва", "Virgo")
        LIBRA -> language.pick("Весы", "Терези", "Libra")
        SCORPIO -> language.pick("Скорпион", "Скорпіон", "Scorpio")
        SAGITTARIUS -> language.pick("Стрелец", "Стрілець", "Sagittarius")
        CAPRICORN -> language.pick("Козерог", "Козоріг", "Capricorn")
        AQUARIUS -> language.pick("Водолей", "Водолій", "Aquarius")
        PISCES -> language.pick("Рыбы", "Риби", "Pisces")
    }
}

data class VedicNumerologyProfile(
    val soulNumber: Int,
    val destinyNumber: Int,
    val nameNumber: Int?,
    val maturityNumber: Int,
    val compatibilityVector: List<Int>
)

data class FriendCandidate(
    val globalId: GlobalId,
    val name: String,
    val age: Int,
    val city: String,
    val distanceKm: Int,
    val compatibility: Int,
    val trustScore: Int,
    val accountRating: Int,
    val interests: List<String>,
    val goals: List<String> = emptyList(),
    val values: List<String>,
    val lifestyle: List<String>,
    val explanation: String,
    val assessmentProfileSeed: Int,
    val personality32: Personality32Profile,
    val enneagram: EnneagramProfile,
    val zodiac: ZodiacSign,
    val numerology: VedicNumerologyProfile,
    val friendshipTestScore: Int = 0,
    val commonTestCount: Int = 0,
    val testCategoryScores: Map<String, Int> = emptyMap(),
    val verified: Boolean = true,
    val online: Boolean = false,
    val serverBacked: Boolean = false,
    val friendshipExpectationsScore: Int = 0,
    /** Separate user-authored desired-quality match; never mixed into canonical Compatibility. */
    val qualityFit: Int = 0,
    /** Public positive projection only. Raw latent coordinates are never stored in this UI model. */
    val positiveQualities: List<String> = emptyList()
)

data class Community(
    val id: String,
    val title: String,
    val category: String,
    val city: String,
    val members: Int,
    val kind: CommunityKind,
    val online: Boolean,
    val description: String,
    val joined: Boolean = false,
    val verifiedOnly: Boolean = false
)

data class TrustEvent(
    val id: String,
    val labelRu: String,
    val labelUk: String,
    val labelEn: String,
    val confirmed: Boolean,
    val impact: Int
) {
    fun label(language: AppLanguage): String = language.pick(labelRu, labelUk, labelEn)
}

data class UserProfile(
    val globalId: GlobalId,
    val name: String,
    val age: Int,
    val city: String,
    val birthDate: LocalDate,
    val latinName: String,
    val description: String,
    val goals: List<String>,
    val interests: List<String>,
    val values: List<String>,
    val lifestyle: List<String>,
    val trustScore: Int,
    val verifiedInteractions: Int,
    val completedProfileSections: Int,
    val personality32: Personality32Profile,
    val enneagram: EnneagramProfile,
    val zodiac: ZodiacSign,
    val numerology: VedicNumerologyProfile,
    val avatarLocalPath: String? = null
)

data class CompatibilityBreakdown(
    val total: Int,
    val baseTotal: Int,
    val friendshipTests: Int,
    val interests: Int,
    val character: Int,
    val values: Int,
    val lifestyle: Int,
    val friendshipGoals: Int,
    val communication: Int,
    val conflict: Int,
    val business: Int,
    val socialFormat: Int,
    val personality32: Int,
    val enneagram: Int,
    val zodiac: Int,
    val numerology: Int,
    val geography: Int,
    /** Shadow predictor derived from expectation-oriented tests. Not yet part of the 100% weighted total. */
    val friendshipExpectations: Int,
    val reputation: Int,
    val confidence: Int
)

/** Public-safe controlled-pilot state. Invite secrets and raw calibration traces are never present. */
data class CalibrationPilotInfo(
    val mode: String,
    val cohortId: String,
    val pilotWave: String,
    val consentVersion: String,
    val modelVersion: String,
    val stimulusVersion: String,
    val acceptedLocales: Set<String>,
    val capacityTotal: Int,
    val capacityUsed: Int,
    val capacityRemaining: Int,
    val localeRemaining: Map<String, Int>,
    val inviteRequired: Boolean,
) {
    val enrollmentOpen: Boolean get() = mode != "disabled" && capacityRemaining > 0
}
