package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.domain.AccountRatingCalculator
import org.junit.Assert.assertEquals
import org.junit.Test

class AccountRatingCalculatorTest {
    @Test
    fun fullProfileAndAllTestsMakeOneHundredPoints() {
        val result = AccountRatingCalculator.calculate(10, AssessmentCatalog.assessments.map { it.id }.toSet())
        assertEquals(50.0, result.profilePoints, 0.0001)
        assertEquals(50.0, result.testPoints, 0.0001)
        assertEquals(100.0, result.total, 0.0001)
    }

    @Test
    fun duplicateOrUnknownTestsDoNotAddPoints() {
        val result = AccountRatingCalculator.calculate(2, setOf("f001", "f001", "unknown"))
        assertEquals(10.0, result.profilePoints, 0.0001)
        assertEquals(0.5, result.testPoints, 0.0001)
    }
}
