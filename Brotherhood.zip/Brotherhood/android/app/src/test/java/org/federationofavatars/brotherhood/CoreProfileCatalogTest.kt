package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.data.CoreProfileCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreProfileCatalogTest {
    @Test
    fun brotherhood32_questionnaire_produces_canonical_type() {
        assertEquals(20, CoreProfileCatalog.personality32Questions.size)
        val answers = CoreProfileCatalog.personality32Questions.associate { it.id to 4 }
        val profile = CoreProfileCatalog.scorePersonality32(answers)
        assertEquals(5, profile.code.length)
    }

    @Test
    fun enneagram_questionnaire_covers_nine_types() {
        assertEquals(18, CoreProfileCatalog.enneagramQuestions.size)
        assertEquals((1..9).toSet(), CoreProfileCatalog.enneagramQuestions.mapNotNull { it.enneagramType }.toSet())
        val answers = CoreProfileCatalog.enneagramQuestions.associate { it.id to if (it.enneagramType == 8) 5 else 2 }
        assertEquals(8, CoreProfileCatalog.scoreEnneagram(answers).type)
    }
}
