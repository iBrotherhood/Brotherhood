package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.data.CoreProfileCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreProfileCatalogTest {
    @Test
    fun brotherhood32_questionnaire_produces_canonical_type() {
        assertEquals(20, CoreProfileCatalog.personality32Questions.size)
        val answers = CoreProfileCatalog.personality32Questions.associate { it.id to 4 }
        val profile = CoreProfileCatalog.scorePersonality32(answers)
        assertEquals(5, profile.code.length)
    }

    @Test
    fun enneagram_questionnaire_covers_nine_types() {
        assertEquals(18, CoreProfileCatalog.enneagramQuestions.size)
        assertEquals((1..9).toSet(), CoreProfileCatalog.enneagramQuestions.mapNotNull { it.enneagramType }.toSet())
        val answers = CoreProfileCatalog.enneagramQuestions.associate { question ->
            val targetKey = "enneagram:${question.enneagramType}"
            val selectedIndex = question.choices.indices.maxBy { index ->
                val loading = question.choices[index].latentLoadings.getValue(targetKey)
                if (question.enneagramType == 8) loading else -loading
            }
            question.id to (selectedIndex + 1)
        }
        assertEquals(8, CoreProfileCatalog.scoreEnneagram(answers).type)
    }

    @Test
    fun core_items_use_indirect_visual_choices_without_axis_revealing_text() {
        val questions = CoreProfileCatalog.personality32Questions + CoreProfileCatalog.enneagramQuestions
        assertEquals(38, questions.map { it.id }.distinct().size)
        assertTrue(questions.all { it.compositionVariant in 0..7 })
        assertTrue(questions.all { question ->
            question.choices.size == 4 &&
                question.choices.map { it.id }.distinct().size == 4 &&
                question.choices.all { choice ->
                    choice.latentLoadings.size == 1 && choice.latentLoadings.values.single() in -2..2
                }
        })
    }
}
