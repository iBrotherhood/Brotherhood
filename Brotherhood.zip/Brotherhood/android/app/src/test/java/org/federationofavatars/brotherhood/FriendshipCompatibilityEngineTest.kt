package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.domain.FriendshipCompatibilityEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FriendshipCompatibilityEngineTest {
    @Test
    fun commonTestsDriveCompatibilityAndConfidence() {
        val mine = (1..100).associate { "f${it.toString().padStart(3, '0')}" to 85 }
        val other = (1..100).associate { "f${it.toString().padStart(3, '0')}" to 82 }
        val result = FriendshipCompatibilityEngine.calculate(mine, other, 70, 90)
        assertTrue(result.commonTests == 100)
        assertTrue(result.confidence == 100)
        assertTrue(result.score >= 80)
    }

    @Test
    fun retiredFriendshipExpectationsDiagnosticRemainsInactive() {
        val equal = FriendshipCompatibilityEngine.calculate(
            mapOf("f065" to 80, "f071" to 70, "f078" to 90),
            mapOf("f065" to 80, "f071" to 70, "f078" to 90),
            0,
            0
        )
        assertEquals(0, equal.friendshipExpectationsScore)

        val opposite = FriendshipCompatibilityEngine.calculate(
            mapOf("f065" to 100, "f071" to 100, "f078" to 100),
            mapOf("f065" to 0, "f071" to 0, "f078" to 0),
            100,
            100
        )
        assertEquals(0, opposite.friendshipExpectationsScore)
    }

    @Test
    fun lowSimilarityDoesNotCreateMoralRiskFlags() {
        val result = FriendshipCompatibilityEngine.calculate(
            mapOf("f001" to 90, "f002" to 90),
            mapOf("f001" to 20, "f002" to 25),
            100,
            100
        )
        assertTrue(result.riskFlags.isEmpty())
        assertTrue(result.score in 0..100)
        assertTrue(result.score == result.testsScore)
    }
}
