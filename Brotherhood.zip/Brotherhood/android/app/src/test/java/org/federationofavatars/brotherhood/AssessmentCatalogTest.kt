package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.data.VisualAssessmentFactory
import org.federationofavatars.brotherhood.model.CompatibilityMode
import org.federationofavatars.brotherhood.model.VisualParadigm
import org.federationofavatars.brotherhood.model.VisualSceneArchetype
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AssessmentCatalogTest {
    @Test
    fun catalogContainsExactlyOneHundredUniqueTests() {
        assertEquals(100, AssessmentCatalog.assessments.size)
        assertEquals(100, AssessmentCatalog.assessments.map { it.id }.distinct().size)
        assertTrue(AssessmentCatalog.assessments.all { it.questions.size == 6 })
        assertEquals(600, AssessmentCatalog.assessments.sumOf { it.questions.size })
        assertEquals(50.0, AssessmentCatalog.assessments.sumOf { it.accountWeightPercent }, 0.0001)
    }

    @Test
    fun allMiniTestsUseVersionedIndirectVisualTasks() {
        val questions = AssessmentCatalog.assessments.flatMap { it.questions }

        assertEquals(600, questions.map { it.id }.distinct().size)
        assertTrue(
            AssessmentCatalog.assessments.all {
                it.compatibilityMode == CompatibilityMode.SIMILARITY && !it.safetyCritical
            }
        )
        assertTrue(questions.all { it.stimulusVersion == VisualAssessmentFactory.STIMULUS_VERSION })
        assertTrue(questions.all { it.compositionVariant in 0..7 })
        assertTrue(questions.all { question ->
            question.choices.size == 4 &&
                question.choices.map { it.id }.distinct().size == 4 &&
                question.choices.all { choice ->
                    choice.latentLoadings.isNotEmpty() &&
                        choice.latentLoadings.values.all { it in -2..2 }
                }
        })

        assertEquals(VisualSceneArchetype.entries.toSet(), questions.map { it.sceneArchetype }.toSet())
        assertEquals(VisualParadigm.entries.toSet(), questions.map { it.paradigm }.toSet())
        assertEquals((0..7).toSet(), questions.map { it.compositionVariant }.toSet())
    }
}
