package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AssessmentCatalogTest {
    @Test
    fun catalogContainsExactlyOneHundredUniqueTests() {
        assertEquals(100, AssessmentCatalog.assessments.size)
        assertEquals(100, AssessmentCatalog.assessments.map { it.id }.distinct().size)
        assertTrue(AssessmentCatalog.assessments.all { it.questions.size == 6 })
        assertEquals(50.0, AssessmentCatalog.assessments.sumOf { it.accountWeightPercent }, 0.0001)
    }
}
