package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AssessmentCatalogTest {
    @Test
    fun catalogContainsExactlyOneHundredUniqueTests() {
        assertEquals(100, AssessmentCatalog.assessments.size)
        assertEquals(100, AssessmentCatalog.assessments.map { it.id }.distinct().size)
        assertTrue(AssessmentCatalog.assessments.all { it.questions.size == 6 })
        assertEquals(600, AssessmentCatalog.assessments.sumOf { it.questions.size })
        assertEquals(50.0, AssessmentCatalog.assessments.sumOf { it.accountWeightPercent }, 0.0001)
    }

    @Test
    fun allMiniTestsUseBalancedPairsAndSituationalPresentation() {
        val questions = AssessmentCatalog.assessments.flatMap { it.questions }
        assertTrue(questions.all { it.pairId != null })
        AssessmentCatalog.assessments.forEach { definition ->
            val groups = definition.questions.groupBy { it.pairId }
            assertEquals(3, groups.size)
            assertTrue(groups.values.all { it.size == 2 })
            assertTrue(groups.values.all { pair -> pair.count { it.reverse } == 1 })
        }
        val forbiddenOpeners = listOf(
            "В дружбе я стараюсь",
            "Если мне выгодно",
            "Мои друзья могут ожидать",
            "Если никто не узнает"
        )
        assertTrue(questions.none { question -> forbiddenOpeners.any(question.text::startsWith) })
    }
}
