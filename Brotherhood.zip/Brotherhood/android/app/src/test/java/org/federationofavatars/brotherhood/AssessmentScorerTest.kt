package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.domain.AssessmentScorer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AssessmentScorerTest {
    @Test
    fun perfect_pattern_is_marked_as_idealized_self_presentation() {
        val definition = requireNotNull(AssessmentCatalog.byId("f011"))
        val answers = definition.questions.associate { it.id to if (it.reverse) 1 else 5 }
        val result = AssessmentScorer.score(definition, answers)

        assertEquals(100, result.idealizedSelfPresentation)
        assertTrue(result.label.contains("проверки"))
    }

    @Test
    fun all_assessments_can_be_scored_with_complete_answers() {
        AssessmentCatalog.assessments.forEach { definition ->
            val answers = definition.questions.associate { it.id to 3 }
            val result = AssessmentScorer.score(definition, answers)
            assertTrue(result.totalScore in 0..100)
            assertTrue(result.dimensions.isNotEmpty())
        }
    }
}
