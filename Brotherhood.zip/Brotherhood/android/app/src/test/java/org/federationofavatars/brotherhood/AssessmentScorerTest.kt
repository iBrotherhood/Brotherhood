package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.data.AssessmentCatalog
import org.federationofavatars.brotherhood.data.VisualAssessmentFactory
import org.federationofavatars.brotherhood.domain.AssessmentScorer
import org.federationofavatars.brotherhood.model.AssessmentModelVersions
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AssessmentScorerTest {
    @Test
    fun visual_scoring_does_not_create_moral_risk_or_idealized_self_presentation() {
        val definition = requireNotNull(AssessmentCatalog.byId("f011"))
        val answers = definition.questions.associate { it.id to 1 }
        val result = AssessmentScorer.score(definition, answers)

        assertEquals(AssessmentModelVersions.ACTIVE, result.modelVersion)
        assertEquals(VisualAssessmentFactory.STIMULUS_VERSION, result.stimulusVersion)
        assertEquals(0, result.riskScore)
        assertEquals(0, result.idealizedSelfPresentation)
        assertEquals(definition.questions.size, result.responseTrace.size)
        assertTrue(result.dimensions.isNotEmpty())
    }

    @Test
    fun all_assessments_can_be_scored_with_complete_visual_answers() {
        AssessmentCatalog.assessments.forEachIndexed { assessmentIndex, definition ->
            val answers = definition.questions.mapIndexed { questionIndex, question ->
                question.id to ((assessmentIndex + questionIndex) % 4 + 1)
            }.toMap()
            val result = AssessmentScorer.score(definition, answers)
            assertTrue(result.totalScore in 0..100)
            assertTrue(result.answerConsistency in 0..100)
            assertTrue(result.dimensions.isNotEmpty())
            assertEquals(6, result.responseTrace.size)
            assertTrue(result.responseTrace.all { it.presentationSlot in 1..4 })
        }
    }
}
