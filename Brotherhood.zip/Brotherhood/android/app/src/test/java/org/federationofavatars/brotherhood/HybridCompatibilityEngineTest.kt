package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.data.DemoRepository
import org.federationofavatars.brotherhood.domain.HybridCompatibilityEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HybridCompatibilityEngineTest {
    @Test
    fun trustIsDisplayedSeparatelyAndDoesNotChangeCompatibility() {
        val me = DemoRepository.profile
        val candidate = DemoRepository.people.first()
        val lowTrust = HybridCompatibilityEngine.calculate(me, candidate.copy(trustScore = 20), friendshipTests = 82, sharedTestCount = 60)
        val highTrust = HybridCompatibilityEngine.calculate(me, candidate.copy(trustScore = 98), friendshipTests = 82, sharedTestCount = 60)
        assertEquals(lowTrust.baseTotal, highTrust.baseTotal)
        assertEquals(lowTrust.total, highTrust.total)
        assertEquals(20, lowTrust.reputation)
        assertEquals(98, highTrust.reputation)
    }

    @Test
    fun everyCompatibilityLayerAndBothTotalsStayInRange() {
        val result = HybridCompatibilityEngine.calculate(
            DemoRepository.profile,
            DemoRepository.people.first(),
            friendshipTests = 75,
            sharedTestCount = 44,
        )
        val values = listOf(
            result.total, result.baseTotal, result.friendshipTests, result.interests, result.character,
            result.values, result.lifestyle, result.friendshipGoals, result.communication, result.conflict,
            result.business, result.socialFormat, result.personality32, result.enneagram, result.zodiac,
            result.numerology, result.geography, result.reputation, result.confidence,
        )
        assertTrue(values.all { it in 0..100 })
    }
}
