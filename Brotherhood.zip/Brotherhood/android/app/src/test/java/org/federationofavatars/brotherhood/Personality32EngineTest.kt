package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.domain.Personality32Engine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class Personality32EngineTest {
    @Test
    fun canonical_registry_contains_exactly_32_unique_types() {
        val profiles = Personality32Engine.allCanonicalProfiles()
        assertEquals(32, profiles.size)
        assertEquals(32, profiles.map { it.code }.toSet().size)
        assertTrue(profiles.all { it.code.matches(Regex("^[ER][PV][LH][SF][GA]$")) })
    }

    @Test
    fun identical_profiles_have_maximum_compatibility() {
        val profile = Personality32Engine.classify(Personality32Engine.AxisInput(70, 30, 80, 20, 15))
        assertEquals(100, Personality32Engine.compatibility(profile, profile))
    }
}
