package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.data.LatentTraitCatalog
import org.federationofavatars.brotherhood.domain.PositiveProfileProjector
import org.federationofavatars.brotherhood.model.AppLanguage
import org.federationofavatars.brotherhood.model.LatentProfile
import org.federationofavatars.brotherhood.model.LatentTraitScore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PositiveProfileProjectorTest {
    private fun profile(score: Int, confidence: Int = 70): LatentProfile = LatentProfile(
        traits = LatentTraitCatalog.traits.associate { definition ->
            definition.key to LatentTraitScore(definition.key, score, 6)
        },
        confidence = confidence,
    )

    @Test
    fun everyCompletedSeriesProducesPositivePublicQualities() {
        val reveal = PositiveProfileProjector.reveal(
            assessmentId = "f001",
            before = LatentProfile(emptyMap(), 0),
            after = profile(75),
            language = AppLanguage.RU,
            completedTests = 1,
            isRetake = false,
        )
        assertTrue(reveal.qualityLabels.isNotEmpty())
        assertTrue(reveal.usefulContexts.isNotEmpty())
        assertEquals(0.5, reveal.accountDeltaPercent, 0.0)
    }

    @Test
    fun retakeRefinesProfileWithoutDuplicateAccountCredit() {
        val before = profile(70)
        val reveal = PositiveProfileProjector.reveal(
            assessmentId = "f001",
            before = before,
            after = profile(72, 75),
            language = AppLanguage.EN,
            completedTests = 1,
            isRetake = true,
        )
        assertTrue(reveal.qualityLabels.isNotEmpty())
        assertEquals(0.0, reveal.accountDeltaPercent, 0.0)
        assertTrue(reveal.summary.contains("retake", ignoreCase = true))
    }
}
