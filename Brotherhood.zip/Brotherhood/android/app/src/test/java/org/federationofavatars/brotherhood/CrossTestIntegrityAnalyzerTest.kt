package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.domain.CrossTestIntegrityAnalyzer
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.DimensionScore
import org.junit.Assert.assertTrue
import org.junit.Test

class CrossTestIntegrityAnalyzerTest {
    private fun result(id: String, score: Int, idealization: Int = 0) = AssessmentResult(
        assessmentId = id,
        startedAtEpochMs = 1L,
        totalScore = score,
        riskScore = 100 - score,
        label = "test",
        summary = "test summary",
        dimensions = listOf(DimensionScore(id, id, score)),
        answerConsistency = 100,
        idealizedSelfPresentation = idealization
    )

    @Test
    fun contradictionsAcrossRelatedTestsIncreaseRisk() {
        val analysis = CrossTestIntegrityAnalyzer.analyze(mapOf(
            "f002" to result("f002", 95),
            "f041" to result("f041", 20),
            "f006" to result("f006", 90),
            "f022" to result("f022", 25)
        ))
        assertTrue(analysis.riskScore >= 40)
        assertTrue(analysis.flags.isNotEmpty())
    }
}
