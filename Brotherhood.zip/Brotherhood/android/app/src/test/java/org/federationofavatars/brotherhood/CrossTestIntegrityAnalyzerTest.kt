package org.federationofavatars.brotherhood

import org.federationofavatars.brotherhood.domain.CrossTestIntegrityAnalyzer
import org.federationofavatars.brotherhood.model.AssessmentResult
import org.federationofavatars.brotherhood.model.DimensionScore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CrossTestIntegrityAnalyzerTest {
    private fun result(id: String, score: Int) = AssessmentResult(
        assessmentId = id,
        startedAtEpochMs = 1L,
        totalScore = score,
        riskScore = 0,
        label = "test",
        summary = "test summary",
        dimensions = listOf(DimensionScore("shared_trait", "shared_trait", score)),
        answerConsistency = 100,
        idealizedSelfPresentation = 0,
    )

    @Test
    fun contradictionsAcrossRelatedTestsReduceInternalConsistencyWithoutMoralRisk() {
        val analysis = CrossTestIntegrityAnalyzer.analyze(
            mapOf(
                "f002" to result("f002", 95),
                "f041" to result("f041", 20),
                "f006" to result("f006", 90),
                "f022" to result("f022", 25),
            )
        )

        assertEquals(0, analysis.riskScore)
        assertTrue(analysis.consistencyScore < 50)
        assertEquals(1, analysis.evaluatedPairs)
        assertTrue(analysis.confidence > 0)
        assertTrue(analysis.flags.isEmpty())
    }
}
