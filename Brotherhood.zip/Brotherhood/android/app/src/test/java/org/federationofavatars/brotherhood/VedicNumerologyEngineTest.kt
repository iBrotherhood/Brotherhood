package org.federationofavatars.brotherhood

import java.time.LocalDate
import org.federationofavatars.brotherhood.domain.VedicNumerologyEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VedicNumerologyEngineTest {
    @Test
    fun calculation_is_deterministic_and_bounded() {
        val profile = VedicNumerologyEngine.calculate(LocalDate.of(1990, 1, 1), "ALEX MORGAN")
        assertEquals(1, profile.soulNumber)
        assertTrue(profile.destinyNumber in 1..9)
        assertTrue(profile.nameNumber in 1..9)
        assertTrue(profile.maturityNumber in 1..9)
    }
    @Test
    fun compatibility_is_symmetric_and_explainable() {
        val first = VedicNumerologyEngine.calculate(LocalDate.of(1986, 4, 13), "DENYS HLUSHAK")
        val second = VedicNumerologyEngine.calculate(LocalDate.of(1988, 9, 21), "ALEX MORGAN")
        val forward = VedicNumerologyEngine.compatibilityBreakdown(first, second)
        val reverse = VedicNumerologyEngine.compatibilityBreakdown(second, first)
        assertEquals(forward.total, reverse.total)
        assertEquals(forward.soul, reverse.soul)
        assertTrue(forward.total in 25..100)
        assertTrue(forward.soul in 30..94)
        assertTrue(VedicNumerologyEngine.compatibilitySummary(first, second, org.federationofavatars.brotherhood.model.AppLanguage.EN).isNotBlank())
    }

    @Test
    fun compatibility_depends_on_birth_dates_not_names() {
        val dateA = LocalDate.of(1986, 4, 13)
        val dateB = LocalDate.of(1989, 4, 28)
        val firstNames = VedicNumerologyEngine.compatibility(
            VedicNumerologyEngine.calculate(dateA, "FIRST NAME"),
            VedicNumerologyEngine.calculate(dateB, "SECOND NAME"),
        )
        val otherNames = VedicNumerologyEngine.compatibility(
            VedicNumerologyEngine.calculate(dateA, "COMPLETELY DIFFERENT"),
            VedicNumerologyEngine.calculate(dateB, "ANOTHER NAME"),
        )
        assertEquals(firstNames, otherNames)
    }

}
