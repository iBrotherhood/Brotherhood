package org.federationofavatars.brotherhood

import java.time.LocalDate
import org.federationofavatars.brotherhood.domain.VedicNumerologyEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VedicNumerologyEngineTest {
    @Test
    fun calculation_is_deterministic_and_bounded() {
        val profile = VedicNumerologyEngine.calculate(LocalDate.of(1990, 1, 1), "ALEX MORGAN")
        assertEquals(1, profile.soulNumber)
        assertTrue(profile.destinyNumber in 1..9)
        assertTrue(profile.nameNumber in 1..9)
        assertTrue(profile.maturityNumber in 1..9)
    }
}
