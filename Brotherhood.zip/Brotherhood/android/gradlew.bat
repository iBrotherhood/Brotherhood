@ECHO OFF
SETLOCAL
SET APP_HOME=%~dp0
SET JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
IF NOT EXIST "%JAR%" (
  ECHO Gradle wrapper JAR is missing. Downloading and verifying SHA-256...
  java "%APP_HOME%gradle\wrapper\WrapperDownloader.java" "%JAR%"
  IF ERRORLEVEL 1 EXIT /B 1
)
java %JAVA_OPTS% %GRADLE_OPTS% -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
ENDLOCAL
