# Third-party source review

Brotherhood v0.5.7 не содержит прямых копий исходного кода из предоставленных сторонних проектов.

Для архитектурного и UI-анализа использовались:

- Mark42 — MIT License, copyright (c) 2022 Artur Stambultsian.
- TelegramUI — MIT License, copyright (c) 2024 XeleneStudio.
- fastapi-telegram-mini-app — MIT License, copyright (c) 2024 zytfo.

MyTonWallet (GPLv3) и SberID SDK (Sber Public License AT-NC-SA) были рассмотрены, но их исходный код в Brotherhood не включён.
