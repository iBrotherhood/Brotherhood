# Third-party source review

Brotherhood v0.5.7 не содержит прямых копий исходного кода из предоставленных сторонних проектов.

Для архитектурного и UI-анализа использовались:

- Mark42 — MIT License, copyright (c) 2022 Artur Stambultsian.
- TelegramUI — MIT License, copyright (c) 2024 XeleneStudio.
- fastapi-telegram-mini-app — MIT License, copyright (c) 2024 zytfo.

MyTonWallet (GPLv3) и SberID SDK (Sber Public License AT-NC-SA) были рассмотрены, но их исходный код в Brotherhood не включён.

## v0.5.10 sandbox review

The following user-provided projects were reviewed as references: Alovoa, Humbble, Complete Dating App, Pegava Dating App, Tinder Clone, Tinder React Native, Tindev, DostiPak, Android Java Dating App and Numerology.

No source files, images, fonts or other copyrighted assets from those archives are copied into Brotherhood v0.5.10. MIT/CC0 projects informed independently reimplemented UX/architecture patterns. AGPL and no-license projects are reference-only. See `docs/SANDBOX_SOURCE_AUDIT_v0_5_10.md`.

